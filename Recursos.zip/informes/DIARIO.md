# DIARIO del proyecto — Gen'ei Toshi / Illusion City [CASTELLANO]

> **Para Buffy (leer SIEMPRE al empezar sesión):** continúa desde aquí, no desde cero.
> Actualiza este archivo al final de cada tarea. El informe técnico detallado está en
> `INFORME_TRADUCCION.md`; este diario es el estado vivo y las decisiones de David.

## Contexto humano
- David es quien prueba el juego en **Genesis Plus 1.3.5** con
  `Gen'ei Toshi - Illusion City (Japan) [CASTELLANO].cue`. Trátalo por su nombre.
- Él ve las pantallas; Buffy no puede ejecutar el emulador. Las capturas que
  adjunta son la fuente de verdad visual.
- Entre sesiones Buffy "olvida": por eso existe este diario. Leerlo entero antes
  de proponer cambios.

## Canon de nombres (APROBADO por David — no usar otras formas)
- 天人 = **Tianren** (término del lore de Shadowrun, NO es un nombre de persona)
- 美紅 = **Meifan** · シュウ老師 = **Maestro Shu** · ホウメイ = **Houmei**
- カッシュ = **Cash** · アイザック = **Isaac** · ドク = **Doc**
- アイレン = **Airén** · シャオメイ = **Xiao Mei** · 薬師カイ = **Kai**
- 魔天王 = **Rey Maten** (culto 魔天教 = Secta Maten) · 南天リー = **Lee** (dialogo: "Lee del Cielo Sur")
- 西天フェイ = **Fei** · 樹羅帝ヴァーラ = **Vaara** · 東天ダイ = **Dai**
- 雷帝アーク = **Ark** · 妖鋼妃 = **Consorte del Acero** (nombre real: Aya) · 北天メシュメル = **Meshmer**
- 月琴明王ヤマ = **Yama** · リュウケイ = **Liu-Kei** · デュラン = **Durand**
- クロガネ = **Kurogane** · スメラギ = **Sumeragi** · ライデン = **Raiden**
- ワダツミ = **Wadatsumi** · ネオティカス = **Neoticus** · エルファス = **Elphas**
- マクレガー = **McGregor** · 天人王 = **Rey Deva** · フラメンコ = **Flamenco**
- SIVA役員 = **Ejecutivo de SIVA** · ノイ = **Noi** · タオ・ホー = **Tao Ho**
- R・モーティマー = **R. Mortimer** · テツ = **Tetsu**
- Regla de recorte: en HUD/batalla solo el nombre propio (Lee, Fei, Vaara, Dai,
  Ark, Meshmer, Yama); los títulos largos solo en diálogos.
- Herramienta: `tools/lote_nombres.py` (re-ejecutable).

## Lectura de términos de magia (propuesta de David, pendiente de adaptar al menú)
栄気 = Energía Vital · 練気 = Ki Concentrado · 気功弾 = Bala de Ki
被甲護身 = Cuerpo Acorazado · 防呪結界 = Barrera Anti-Maleficios
守気 = Ki Guardián · 攻気 = Ki Ofensivo · 封呪 = Sello Mágico · 遅動 = Ralentizar
Restricción: deben caber en el menú SIN abreviaturas.

## Unidades del HUD (decisión tomada)
**NV / PV / PM** (nivel, vida, magia). El motor japonés usa 術気 ("energía mágica")
como recurso de magia → su traducción de UI es PM. ATENCIÓN: parches viejos del
CSV usan "chakra" en textos de batalla (ids 2324/2325/2336) → unificar a PM.

## Errores y lecciones aprendidas
1. **膨 vs 冒**: David ve 膨 (0x9663) donde Buffy decía 冒 (0x9660). El slot 'á'
   es 0x9660 y el bitmap reemplazado es el de 冒; si David ve 膨, la fuente que
   dibuja esa pantalla NO es la parcheada (otra copia/tamaño de fuente o celda
   grande distinta). Recordatorio: los kanji visuales de las celdas grandes
   derivados por bitmap NO son fiables (ya pasó con 1345/1420 vs 1393/1424).
   NUNCA asegurar qué kanji se ve: trabajar por códigos y bitmaps exactos.
2. **Menú Velocidad (regresión de colores)**: el parche v3 cambió "&4速い…&7遅い&7"
   a "&5Velocidad … Rápido … Lento". &4=amarillo/blanco resaltado, &5=azul.
   El original: L0 ［スピード調整］ con &5, L2 con &4 (Rápido/Lento en amarillo),
   L4-L6 blancos (sin &). Al parchear se pusieron &5 (azul) en casi todo.
   TAREA: restaurar colores exactos del original en Z22 y revisar Z5/Z19/Z21.
3. **Menú Velocidad (alineación)**: el original pone un espacio fullwidth
   inicial en L0/L2/L3/L5/L6; el parche lo quitó. Restaurar la geometría
   original celda a celda (ver desensamblado de Z22 más abajo).
4. **"Rápido" sin tilde**: el parche actual es raw:Rapi (la versión raw de-acentúa).
   El objetivo es Rápido con tilde vía slot 0x9660 (una vez resuelto el punto 1).
5. **Rebuild global NO** (rompió INIT: tablas de offsets fijos → GAME OVER en
   emulador). Pipeline por defecto: in-situ seguro. Las 329 cadenas que no caben
   siguen bloqueadas hasta encontrar una vía de crecimiento por archivo.
6. **"now" → Ahora, "max" → pendiente**: la plantilla Z5 del menú de Magia se
   parcheó con now/max; David pide Ahora (ya aplicado) y revisar max.

## Estado del disco (última regeneración: sesión "lote_nombres")
- `track01_castellano.iso` + `…[CAST].bin` + `…(Track 01).bin` (el .cue usa este
  último) generados con `tools/reconstruir_iso.py` (modo seguro) — in-situ
  ok=147, no_cabe=329, errores=0; bitmaps 48/48; START.BIN parcheado.
- El .cue [CASTELLANO] apunta a `…(Track 01) [CAST].bin`; el .cue ORIGINAL
  apunta a `…(Track 01).bin` — ambos se reescriben en cada pipeline.
- **Queja de David: "no veo ningún cambio"** → PENDIENTE diagnosticar: ¿Genesis
  Plus 1.3.5 carga el .cue [CASTELLANO]? ¿cachea? ¿el binario es el correcto?
  Verificar bytes de traducción dentro de cada .bin publicado antes de culpar
  al emulador.

## Frentes abiertos (orden propuesto)
1. [EN CURSO] Diagnóstico "no veo cambios" + fuente que dibuja 膨.
2. Menú Velocidad: colores originales (&4 amarillo en Rápido/Lento, blanco en
   Mensajes/Moverse/Combate, &5 solo en la cabecera) + tilde + geometría.
3. Menú Magia: cabecera "[Magia] Tianren" (sin espacio inicial), alinear
   Ahora/max con PM/Coste; etiqueta 〔個〕/〔集〕→ Ind/Grp con leyenda para David.
4. Ventana ［術効果］: Efect→Efecto, Grp→Grupo; probar "Individual" (¿cabe?).
5. HUD: LV/HP/MP → NV/PV/PM (buscar dónde: ¿CHR.BIN? ¿plantillas? ¿VRAM?)
   y nombres 天人/美紅 en los rectángulos del HUD.
6. Técnicas (栄気…) con los nombres de David cabiendo sin abreviaturas.
7. Vía de crecimiento segura para desbloquear no_cabe=329 (¡sin romper INIT!).
8. Continuar guion (A10.BIN y siguientes) cuando se desbloquee el crecimiento.

## Detalles técnicos útiles (chuleta)
- Plantillas de START.BIN: Z5 Magia 0x13D60 (136B), Z19 Ficha 0x13F8A (338B),
  Z22 Velocidad 0x143EE (130B), Efect/Ind/Grp 0x13DF6-0x13E16. Parcheadas por
  `tools/parchear_start.py` → `analisis/START_CAST.BIN` (misma longitud).
- Marcadores de color/posición en plantillas: &4 (resaltado), &5 (azul),
  &7 (valores), ?4; /n = salto; ｎｏｗ/ｍａｘ = campos del motor (¡cuidado!).
- Slots secuestrados: 'á'=0x9660 (kanji 冒). El bitmap reemplazado se busca por
  patrón exacto en TODO el disco (3 copias: INIT.BIN, OPEN.BIN, GFONT.BIN).
- encode: `tools/codificador_castellano.py` (raw: = ASCII 1B, de-acentúa).
- Pipeline: `python3 tools/reconstruir_iso.py` (seguro) / `--dry` para probar.

## Registro de sesiones
### 2026-09-18 (sesión en curso)
- David reporta: no ve cambios; 膨 en vez de tilde; menú Velocidad con colores
  azules (regresión) y desalineado; pide "[Magia] Tianren" sin espacio inicial,
  alinear Ahora/PM/Coste, Efect→Efecto, HUD NV/PV/PM, nombres en HUD, técnicas
  sin abreviar; recuerda el canon (Meifan/Tianren...).
- Creado este DIARIO. Diagnosticando el punto 1 (ver frentes abiertos).
- Corrección aplicada: la fuente fina de menú usa `GFONT.BIN`, celda 226 para
  el código secuestrado `0x9660` de `á`; ahora se parchea esa celda directamente.
  Las copias gruesas siguen siendo 48/48. Esto elimina la causa conocida de
  que el juego pintase 膨 aunque el texto fuese `Rápido`.
- `Z22` actualizado: cabecera azul, Rápido/Lento amarillos, Mensajes/Moverse/
  Combate sin azul, y `á` conservada (no se escribe el kanji 膨: es la lectura
  cp932 del byte 0x9660).
- `Z5` actualizado a `[Magia] Tianren`, sin espacio inicial; labels PM/Coste y
  Ahora/Ind/Grupo ajustados al presupuesto fijo de 136 B.
- Ventana de objetivo: `Efecto`, `Ind`, `Grupo`; HUD: Tianren/Meifan/Isaac y
  PV/PM en las tres filas de START.BIN, respetando los huecos disponibles.
- Regenerados `track01_castellano.iso`, `…[CAST].bin` y el `.bin` que usa el
  CUE. Verificación: `ok=147`, `no_cabe=329`, `errores=0`, GFONT celda 226
  parcheada y 48 bitmaps gruesos reemplazados.
- Pendiente de prueba visual de David en Genesis Plus: el texto binario ya
  contiene `[Magia] Tianren`, `Efecto`, `Grupo`, `Rápido` con `0x9660`, y HUD
  actualizado. Las técnicas largas y las 329 cadenas que no caben siguen
  pendientes de una estrategia de crecimiento.
- Corrección posterior de David: la geometría de Z22 debe ser exactamente la
  original: Rápido en celdas 4-9, Lento en 11-15, dígitos en 8-15 y las tres
  etiquetas inferiores desde la celda 1. Restaurada esa geometría; las
  etiquetas inferiores se codifican en bytes ASCII compactos para no desbordar
  el bloque fijo de 130 B. Además, la celda fina 226 no era una sola copia:
  ahora se sustituyen sus **3 copias** en el disco, no solo la de GFONT.BIN.
  Última regeneración: fuente fina 3/3, bitmaps gruesos 48/48, sin errores.
- Nueva captura de David: los ASCII de un byte fueron interpretados como
  japonés, así que se retiraron. Z22 vuelve a usar fullwidth; por el límite
  rígido de 130 B las etiquetas inferiores quedan temporalmente como `Mens.`
  y `Mov.` mientras se estudia una reubicación segura. En Z5 se retiró el
  `Tianren` literal que se solapaba con el nombre dinámico y se dejó `Max`
  con mayúscula. La ventana Efecto se devolvió a sus tres ranuras estables
  (`Efect`, `Ind`, `Grp`) para evitar que la `o` invadiera la fila siguiente.
  Sigue pendiente localizar la tabla de fuente que produce visualmente 膨.
- Ajuste solicitado por David para Z5: PM en celdas 7-8, Coste 10-14;
  Ahora 1-5, valor 7-8, Ind 10-12, valor 13-14; Max 1-3 y sus valores
  separados. Aplicado en la plantilla y regenerado. `Mensaje`/`Moverse`
  completos no caben junto con la geometría original dentro de los 130 B:
  requieren reubicar la tabla siguiente, no otro recorte textual.
