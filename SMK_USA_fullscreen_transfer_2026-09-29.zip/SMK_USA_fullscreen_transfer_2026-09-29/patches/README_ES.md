# Parches

No hay todavía un IPS final aprobado.

El IPS se generará aquí únicamente cuando un candidato estable haya pasado las pruebas de perspectiva, OAM, HUD, `ROUND 1`, meta, 2P y compatibilidad RetroArch/bsnes.