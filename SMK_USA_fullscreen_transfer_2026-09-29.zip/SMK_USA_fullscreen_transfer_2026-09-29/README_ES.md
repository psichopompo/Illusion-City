# Super Mario Kart USA — proyecto de pantalla completa

Proyecto de ROM hacking para la versión USA HiROM de 1 MiB.

## Estructura

- `roms/`
  - `Super Mario Kart USA Full Screen.sfc`: base limpia del hack fullscreen.
  - `t_vK58.sfc`: candidato activo de Fase 1.
  - ROM USA original y archivos SRAM de referencia.
- `states/`
  - `t_vK58.state`: state suministrado para validar la llegada a meta.
  - `t_vK58_payload.bin`: versión sin compresión usada por el harness bsnes.
  - Otros states/payloads de pruebas anteriores.
- `cores/`
  - `bsnes_clean.so`: core bsnes reproducible sin instrumentación.
  - `bsnes_instr.so`: core bsnes con trazas de input, OAM/PPU y WRAM.
- `user_upload/`
  - Harnesses libretro (`run_bsnes_state`, `run_bsnes_drive`, `run_bsnes_input`) y sus fuentes.
- `tools/`
  - Scripts de parcheo, análisis de OAM y reconstrucción de la instrumentación.
- `docs/`
  - Documentación técnica y notas de transferencia.
- `diagnostics/`
  - Trazas/dumps esenciales conservados como referencia.
- `originalgrego_repo/`, `smk_disassembly/`
  - Fuente del hack fullscreen original y desensamblado.

Las capturas PNG, PPM y logs temporales se han eliminado. Las validaciones se pueden repetir desde los states y los cores, evitando acumular resultados intermedios.

## Estado actual

`t_vK58.sfc` conserva la perspectiva del escenario de v14, coloca el kart en la mitad inferior y escala los objetos con la profundidad. La rotación de cámara y la transición de meta se han comprobado con `states/t_vK58.state`; no se ha observado el shrink inconsistente de la versión anterior.

Pendiente antes de emitir el IPS final:

1. HUD inferior alineado: coches sobre monedas.
2. Validación completa de `ROUND 1`, meta y todos los sprites.
3. Validación 2P con P1 en la mitad inferior.
4. Colisiones con escenario y rivales (fase posterior).

La rama de orden OAM de rivales de la parrilla ya fue cerrada: en la carrera reproducible el orden de los quads es estable y coherente con la prioridad SNES; no se conserva ningún parche experimental de reordenamiento. Véase `docs/DOCUMENTACION_ES.md`.

## Reproducción rápida

Desde `/home/user/smk_work`:

```bash
user_upload/run_bsnes_state \
  cores/bsnes_clean.so \
  roms/t_vK58.sfc \
  states/t_vK58_payload.bin 1
```

El harness deja sus salidas de diagnóstico en `user_upload/`. No se considera estable ningún candidato únicamente por una captura aislada: debe funcionar con el state y el core indicados.
