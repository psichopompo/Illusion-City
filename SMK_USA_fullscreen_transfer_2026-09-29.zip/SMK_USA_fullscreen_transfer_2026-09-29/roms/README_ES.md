# ROMs

- `Super Mario Kart USA Full Screen.sfc`: base limpia del hack fullscreen USA.
- `t_vK58.sfc`: candidato activo.
- `Super Mario Kart (USA).sfc`: referencia USA vanilla.
- Archivos `.srm`: memorias SRAM de referencia.

No se guardan aquí variantes descartadas. Las ROMs candidatas deben conservarse separadas de la base para que cualquier IPS pueda reconstruirse y verificarse byte a byte.