# Prompt de transferencia — Super Mario Kart USA Fullscreen

Fecha de la transferencia: 2026-09-29. Responder siempre en español.

Actúa como especialista en ROM hacking de SNES/65816, PPU/OAM, Mode 7 y bsnes/libretro. Continúa el trabajo técnico desde el paquete que contiene este prompt. No reinicies la investigación ni vuelvas a probar hipótesis ya cerradas. Encadena los experimentos y conserva el workspace pequeño: una ROM candidata, una comparación visual y solo los dumps imprescindibles.

## Objetivo final del usuario

Hack fullscreen de **Super Mario Kart USA**, ROM HiROM USA de 1 MiB, que debe mantener simultáneamente:

- kart de P1 en la mitad inferior de la pantalla, también en carreras 2P;
- perspectiva Mode 7 descendida y estable, con el giro/rotación aceptados de v14;
- reescalado por profundidad, aproximadamente 2x abajo;
- posiciones estables de todos los sprites, sin saltos ni descomposición al chocar;
- HUD con margen superior correcto;
- `ROUND 1` completo y validación específica de `$0406` durante esa transición;
- meta consistente con la física y con la cámara, sin shrink inconsistente;
- reproducción determinista en RetroArch/bsnes.

Las colisiones con escenario y rivales son una fase posterior. No deben confundirse con el orden visual OAM de los sprites.

No generar el `.ips` final hasta que exista un único candidato estable que pase todas las pruebas. El entregable final será una única `.sfc` limpia, el `.ips` equivalente y documentación.

## Contenido del paquete

- `roms/t_vK58.sfc`: candidato activo.
- `roms/Super Mario Kart USA Full Screen.sfc`: base limpia del hack fullscreen, necesaria para comparar/reconstruir.
- `states/state_payload.bin`: state válido de carrera inicial para el harness.
- `states/t_vK58_payload.bin`: state de carrera avanzada/meta.
- `states/state_2p_payload.bin`: archivo etiquetado como 2P, pero que localmente carga el menú de copas; no usarlo como evidencia de carrera 2P.
- `states/*.state`: estados comprimidos de referencia para RetroArch, incluidos por trazabilidad; los `*_payload.bin` son los que usa el harness local.
- `cores/bsnes_instr.so`: core bsnes instrumentado incluido para poder reproducir los dumps de OAM/WRAM. Es el mismo core bsnes usado para la validación, con instrumentación adicional.
- `user_upload/run_bsnes_state.c`, `user_upload/run_bsnes_input.c`, `user_upload/libretro.h`: fuentes de harness. Los binarios compilados no son necesarios; compilar de nuevo si hace falta.
- `tools/`: scripts pequeños de instrumentación y pruebas de compositor/OAM; ninguno de los candidatos temporales está promovido.
- `smk_disassembly/bank00.asm`, `bank01.asm`, `bank05.asm`, `labels.txt`, `pcToFixedFuncName.txt`, etc.: desensamblado relevante.
- `originalgrego_repo/SuperMarioKart_FullScreen.asm`: fuente del parche fullscreen original.
- `docs/DOCUMENTACION_ES.md`: documentación técnica acumulada.
- `diagnostics/oam_base_t.png`: captura visual de referencia; las demás capturas históricas no son necesarias para tomar decisiones.

Si el core incluido no carga en el entorno nuevo, reconstruir/obtener un core bsnes equivalente antes de interpretar resultados. La referencia reconstruible usada anteriormente fue el commit `bsnes-emu/bsnes` `0c2fa0d`. No interpretar PPM vacíos o capturados antes del callback de vídeo: tras `unserialize` hay que ejecutar al menos **2 frames**.

## Reproducción mínima

Desde la carpeta raíz del paquete, compilar el harness:

```bash
gcc -O2 -Iuser_upload -o /tmp/run_bsnes_state user_upload/run_bsnes_state.c -ldl
```

El fuente incluido usa rutas absolutas `/home/user/smk_work/user_upload/` para sus salidas. Si el paquete se extrae en otra ruta, modificar esas rutas en el fuente o crear el directorio esperado.

Prueba de carrera válida:

```bash
/tmp/run_bsnes_state \
  cores/bsnes_instr.so \
  roms/t_vK58.sfc \
  states/state_payload.bin 2
```

El harness deja `state_core_frame.ppm`, `wram_dump.bin` y `state_debug_after.bin` en `user_upload/`. Son temporales: no conservar colecciones de resultados.

Para comparar la base, ejecutar el mismo comando sustituyendo la ROM por `roms/Super Mario Kart USA Full Screen.sfc`.

## Estado exacto del candidato

La ROM candidata no ha sido modificada durante la última investigación. Su SHA-256 es:

```text
c5bedb813c920337e1e38d7e7a9ea3300363addc33e900175f0dc8573194211c
```

La base fullscreen tiene SHA-256:

```text
6f9110e29737dc37d628096eccb6db94f93c733e993fff64d6677e36f05e53d1
```

Diferencias exactas de archivo entre base y candidato:

```text
offset 0x00CEC6: 66 -> BE
offset 0x00CEE6: D6 -> 2E
offset 0x00CEE7: FF -> 00
offset 0x01BC5A: 55 -> 00
```

No hay IPS final. No reescribir estos bytes por conjetura.

## Hallazgos Mode 7 aceptados

El resultado visual aceptado es el de v14/t_vK58:

- perspectiva y rotación del escenario correctas;
- centro/eje de Mode 7 descendido y estable;
- kart de P1 en la mitad inferior;
- escala por profundidad correcta;
- meta sin el shrink inconsistente de las ramas antiguas.

En el parche fullscreen original, la rutina `Set_New_Perspective_Params` se encuentra en el área libre del banco 88. El valor de trabajo que resultó visualmente correcto fue:

```text
M7Y = $02F3 + $40 = $0333
$7C = $60
$E0 = $6A
```

No cambiar la cámara, la inclinación, la rotación ni la escala para intentar corregir un problema de prioridad OAM. El candidato v17 queda rechazado: rompía el menú, dejaba humo arriba y eliminaba la rotación.

## Hallazgos de OAM y cierre de esa rama

La transferencia OAM real es una sola DMA del canal 0:

```text
WRAM fuente: $000200-$00041F
DMA destino: $2104
tamaño:      $0220
modo:        $00
```

La tabla baja está en `$0200-$03FF` y la tabla alta de X/tamaño en `$0400-$041F`. La hipótesis de una tabla alternativa en `$0420` queda descartada.

En el state de carrera inicial, los objetos relevantes son:

- slots 24–27, bytes `$0260-$026F`, tiles `00/02/04/06`: overlay `ROUND 1`;
- slots 28–31, bytes `$0270-$027F`, tiles `80/80/A0/A0`: quad de P1;
- rivales en quads contiguos de cuatro slots: 32, 36, 40, 44, 48, 52 y 56, índices hex `$20,$24,$28,$2C,$30,$34,$38`.

La comparación completa de base frente a `t_vK58` usando `state_payload.bin` después de 2, 10, 30, 60 y 120 frames mostró:

- los rivales no cambian entre ambas ROM: misma posición, tile, atributo, tamaño y tabla alta;
- solo cambian los cuatro bytes Y de P1 en `$0271`, `$0275`, `$0279` y `$027D`;
- en el frame inicial los grupos rivales aparecen aproximadamente en Y de pantalla `38,36,35,34,33,32,31`, en orden descendente;
- los nodos de rivales son `$1100-$1700`, todos con bucket `$0E=$000C`;
- P1 está en `$0E=$000D`;
- la coordenada proyectada `$34` de esos nodos es monotónica (`-111,-113,...,-123` en el frame inicial) y el orden de lista ya alimenta los quads OAM en ese orden.

La prioridad SNES confirma que el índice OAM menor queda delante. Por tanto, la aparente superposición de la parrilla es geométrica: los karts están muy próximos en la proyección. No es una inversión OAM demostrada.

Se probaron ROMs temporales, siempre partiendo de `t_vK58.sfc` y sin conservarlas:

1. invertir solo el desempate de igualdad en `$80BBA0`: imagen y OAM idénticos;
2. mantener la comparación primaria por `$0E` y desempatar por `$34` ascendente: imagen y OAM idénticos;
3. desempatar por `$34` descendente: cambia los rivales, devuelve P1 arriba a Y aproximadamente `$46/$56` y altera la imagen aceptada.

Conclusión operativa: **no promover ningún reordenamiento OAM**, no intercambiar slots a ciegas y no modificar `$8094A1`, `oamPriority`, cámara, escala o raster. Esta rama está cerrada salvo que una futura captura reproducible demuestre un fallo nuevo y distinto.

## P1, HUD y `$0406`

Los intentos de mover P1 escribiendo directamente la OAM desde el hook temprano fallaban porque el juego reconstruía la OAM después. La corrección que funciona en el candidato se produce antes/durante la generación de las coordenadas aceptadas, y se debe preservar.

El byte de la tabla alta `$0406` se escribe desde la rutina alrededor de `$81BC57`:

```asm
LDA #$55       ; inmediato en archivo 0x1BC5A en la base
STA $0406
STA $0626
```

En `t_vK58.sfc` ese inmediato es `$00` en el offset `0x1BC5A`. Esto es una modificación deliberada para el objetivo fullscreen, pero **todavía no está aprobado durante `ROUND 1`** porque el state de carrera restaura `$0406=$55` desde el propio state.

Requisito pendiente: capturar la ejecución real desde arranque/carga de pista, localizar los frames del texto `ROUND 1` y registrar:

- `$0406` por frame;
- `$0626` y la tabla alta de OAM;
- PPM válido del texto completo;
- especialmente ausencia de clipping/cortes horizontales en las letras `R` y `O`.

No concluir que `$0406` está validado solo por una captura de carrera avanzada.

## 2P: discrepancia pendiente

`states/README_ES.md` y el nombre `state_2p_payload.bin` lo describen como carrera 2P, pero al cargarlo con la ROM original y con `t_vK58.sfc` el resultado local es el menú de copas; `$0D28=0` y el hook de la ruta 1P no se ejecuta. No usarlo para afirmar que P1 está correcto en carrera 2P.

La ruta 2P debe reproducirse con un state auténtico o conduciendo el menú desde arranque. Una prueba de una ruta 1P no basta para aprobar 2P. El objetivo es comprobar que P1 también aparece abajo sin romper la pantalla del segundo jugador ni la prioridad de los rivales.

## Qué no repetir

- No usar PPM de 0/1 frame como prueba visual: pueden no contener el frame actualizado.
- No tratar slots 24–27 como restos del kart de P1: son `ROUND 1`.
- No usar `$0420` como tabla OAM alternativa: la DMA real sale de `$0200`.
- No reordenar todos los quads en la rutina de DMA `$8094A1`: experimentos anteriores rompieron la ventana raster/HDMA y corrompieron el escenario.
- No cambiar perspectiva o rotación para corregir la superposición inicial.
- No confundir colisión con prioridad visual.
- No emitir IPS ni ROM final mientras `$0406/ROUND 1`, 2P, HUD y meta no estén validados.

## Próxima secuencia recomendada

1. Auditar que el core/harness del entorno nuevo es reproducible y que `unserialize` funciona.
2. Reproducir la carrera 1P con `state_payload.bin` y conservar solo una captura comparativa.
3. Obtener/capturar un estado auténtico durante la transición `ROUND 1`; instrumentar escrituras a `$0400`, `$0406`, `$0600`, `$0620` con frame y PC.
4. Validar `$0406` sin forzar la tabla alta permanentemente en menús/pantallas no relacionadas.
5. Localizar o generar un state de carrera 2P real y comprobar P1 abajo, sprites estables y no regresión de Mode 7.
6. Validar HUD, meta, varios frames de movimiento y ausencia de saltos/descomposición.
7. Solo entonces reconstruir desde la base fullscreen, eliminar hooks temporales, generar una única `.sfc`, calcular hash, generar IPS y documentar bytes.

No detener el trabajo tras una única captura: encadenar estas pruebas y solo pedir aclaración si falta una decisión del usuario que no pueda resolverse técnicamente.
