from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42'))
# DBR=00 exposes the WRAM mirror at 0000:02xx. Skip hidden/finish or a tie;
# exchange only a strict Y0>Y1 inversion.
p += bytes.fromhex('ad a1 02 c9 e0 f0');skip1=len(p);p.append(0)
p += bytes.fromhex('ad 81 02 cd 91 02 90');skip2=len(p);p.append(0)
p += bytes.fromhex('f0');skip3=len(p);p.append(0)
# two complete hardware DMA transfers
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 90 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42 a9 48 8d 02 21 9c 03 21 a9 80 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42')
done=len(p);p += bytes.fromhex('ab 7a fa 68 28 4c a6 94')
for pos in [skip1,skip2,skip3]:p[pos]=(done-(pos+1))&255
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_post_adjacent_fast.sfc').write_bytes(b);print(len(p),hex(done))
