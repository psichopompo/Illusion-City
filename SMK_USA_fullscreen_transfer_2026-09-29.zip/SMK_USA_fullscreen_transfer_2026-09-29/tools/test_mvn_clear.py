from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
p=bytes.fromhex('08 48 da 5a 8b e2 30 c2 30 a9 65 00 a2 00 8b a0 00 8f 54 7f 88 e2 30 ab 7a fa 68 28 4c a6 94')
b[0xff20:0xff20+len(p)]=p;Path('/tmp/test_mvn_clear.sfc').write_bytes(b)
