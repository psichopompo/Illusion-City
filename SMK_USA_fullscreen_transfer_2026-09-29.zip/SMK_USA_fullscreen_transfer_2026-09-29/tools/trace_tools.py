#!/usr/bin/env python3
"""Herramientas: agrega traza de escrituras y desensambla regiones de la ROM."""
import sys
from collections import Counter, defaultdict

def load_trace(path):
    recs = []
    for line in open(path):
        line = line.strip()
        if not line:
            continue
        p = dict(kv.split('=', 1) for kv in line.split())
        recs.append((int(p['pc'], 16), int(p['a'], 16), int(p['d'], 16)))
    return recs

def summarize(recs):
    bypc = Counter()
    byaddr = Counter()
    for pc, a, d in recs:
        bypc[pc] += 1
        byaddr[a] += 1
    print("== writes per target address (top) ==")
    for a, c in sorted(byaddr.items()):
        print(f"  ${a:04x}: {c}")
    print("== writer PCs ==")
    per = defaultdict(Counter)
    for pc, a, d in recs:
        per[pc][a & ~1] += 1
    for pc, cnt in sorted(bypc.items()):
        addrs = sorted(per[pc].items())
        rng = f"{addrs[0][0]:04x}..{addrs[-1][0]:04x}" if addrs else ""
        print(f"  pc=${pc:06x} n={cnt} addrs={rng} {dict((hex(a), c) for a, c in addrs[:8])}")

# ---- mini desensamblador 65816 (suficiente para identificar rutinas) ----
OPS = {
    0xA9: ('LDA #imm', 3, 16), 0xAD: ('LDA abs', 3, 16), 0xBD: ('LDA abs,x', 3, 16),
    0xB5: ('LDA dp,x', 2, 8), 0xA5: ('LDA dp', 2, 8), 0xBF: ('LDA abs,l', 4, 16),
    0x8D: ('STA abs', 3, 0), 0x9D: ('STA abs,x', 3, 0), 0x99: ('STA abs,y', 3, 0),
    0x85: ('STA dp', 2, 0), 0x95: ('STA dp,x', 2, 0), 0x87: ('STA dp,l', 2, 0),
    0x97: ('STA dp,l,y', 2, 0), 0x8F: ('STA abs,l', 4, 0),
    0xA2: ('LDX #imm', 3, 16), 0xAE: ('LDX abs', 3, 16), 0xA6: ('LDX dp', 2, 8),
    0x8E: ('STX abs', 3, 0), 0x86: ('STX dp', 2, 0), 0x96: ('STX dp,y', 2, 0),
    0xA0: ('LDY #imm', 3, 16), 0xAC: ('LDY abs', 3, 16), 0xB9: ('LDA abs,y', 3, 16),
    0x8C: ('STY abs', 3, 0), 0x84: ('STY dp', 2, 0), 0x94: ('STY dp,x', 2, 0),
    0xAA: ('TAX', 1, 0), 0xA8: ('TAY', 1, 0), 0x8A: ('TXA', 1, 0), 0x98: ('TYA', 1, 0),
    0xBA: ('TSX', 1, 0), 0x9A: ('TXS', 1, 0), 0x3A: ('DEC A', 1, 0), 0x1A: ('INC A', 1, 0),
    0xC9: ('CMP #imm', 3, 16), 0xCD: ('CMP abs', 3, 16), 0xDD: ('CMP abs,x', 3, 16),
    0xC5: ('CMP dp', 2, 8), 0xE0: ('CPX #imm', 3, 16), 0xC0: ('CPY #imm', 3, 16),
    0xEC: ('CPX abs', 3, 16), 0xCC: ('CPY abs', 3, 16),
    0x18: ('CLC', 1, 0), 0x38: ('SEC', 1, 0), 0x58: ('CLI', 1, 0), 0x78: ('SEI', 1, 0),
    0xB8: ('CLV', 1, 0), 0xD8: ('CLD', 1, 0), 0xF8: ('SED', 1, 0),
    0x69: ('ADC #imm', 3, 16), 0x65: ('ADC dp', 2, 8), 0x75: ('ADC dp,x', 2, 8),
    0x6D: ('ADC abs', 3, 16), 0x7D: ('ADC abs,x', 3, 16), 0x79: ('ADC abs,y', 3, 16),
    0xE9: ('SBC #imm', 3, 16), 0xE5: ('SBC dp', 2, 8), 0xF5: ('SBC dp,x', 2, 8),
    0xED: ('SBC abs', 3, 16), 0xFD: ('SBC abs,x', 3, 16), 0xF9: ('SBC abs,y', 3, 16),
    0xE6: ('INC dp', 2, 0), 0xEE: ('INC abs', 3, 0), 0xF6: ('INC dp,x', 2, 0),
    0xFE: ('INC abs,x', 3, 0), 0xE8: ('INX', 1, 0), 0xC8: ('INY', 1, 0),
    0xC6: ('DEC dp', 2, 0), 0xCE: ('DEC abs', 3, 0), 0xD6: ('DEC dp,x', 2, 0),
    0xDE: ('DEC abs,x', 3, 0), 0xCA: ('DEX', 1, 0), 0x88: ('DEY', 1, 0),
    0x4C: ('JMP abs', 3, 0), 0x6C: ('JMP (abs)', 3, 0), 0x7C: ('JMP (abs,x)', 3, 0),
    0x5C: ('JMP abs24', 4, 0), 0x20: ('JSR abs', 3, 0), 0x22: ('JSR abs24', 4, 0),
    0x60: ('RTS', 1, 0), 0x6B: ('RTL', 1, 0), 0x00: ('BRK', 2, 0), 0x40: ('RTI', 1, 0),
    0xF0: ('BEQ rel8', 2, 0), 0xD0: ('BNE rel8', 2, 0), 0x90: ('BCC rel8', 2, 0),
    0xB0: ('BCS rel8', 2, 0), 0x30: ('BMI rel8', 2, 0), 0x10: ('BPL rel8', 2, 0),
    0x50: ('BVC rel8', 2, 0), 0x70: ('BVS rel8', 2, 0),
    0x80: ('BRA rel8', 2, 0), 0x82: ('BRL rel16', 3, 0),
    0x29: ('AND #imm', 3, 16), 0x25: ('AND dp', 2, 8), 0x2D: ('AND abs', 3, 16),
    0x3D: ('AND abs,x', 3, 16), 0x39: ('AND abs,y', 3, 16), 0x35: ('AND dp,x', 2, 8),
    0x09: ('ORA #imm', 3, 16), 0x05: ('ORA dp', 2, 8), 0x0D: ('ORA abs', 3, 16),
    0x1D: ('ORA abs,x', 3, 16), 0x19: ('ORA abs,y', 3, 16), 0x15: ('ORA dp,x', 2, 8),
    0x49: ('EOR #imm', 3, 16), 0x45: ('EOR dp', 2, 8), 0x4D: ('EOR abs', 3, 16),
    0x5D: ('EOR abs,x', 3, 16), 0x55: ('EOR dp,x', 2, 8),
    0x0A: ('ASL A', 1, 0), 0x06: ('ASL dp', 2, 0), 0x0E: ('ASL abs', 3, 0),
    0x4A: ('LSR A', 1, 0), 0x46: ('LSR dp', 2, 0), 0x4E: ('LSR abs', 3, 0),
    0x2A: ('ROL A', 1, 0), 0x26: ('ROL dp', 2, 0), 0x6A: ('ROR A', 1, 0), 0x66: ('ROR dp', 2, 0),
    0x48: ('PHA', 1, 0), 0x68: ('PLA', 1, 0), 0xDA: ('PHX', 1, 0), 0xFA: ('PLX', 1, 0),
    0x5A: ('PHY', 1, 0), 0x7A: ('PLY', 1, 0), 0x08: ('PHP', 1, 0), 0x28: ('PLP', 1, 0),
    0xF4: ('PEA', 3, 0),
    0xC2: ('REP #imm8', 2, 8), 0xE2: ('SEP #imm8', 2, 8),
    0xEB: ('XBA', 1, 0), 0xDB: ('STP', 1, 0), 0x42: ('WDM', 2, 0), 0xEA: ('NOP', 1, 0),
    0x9C: ('STZ abs', 3, 0), 0x9E: ('STZ abs,x', 3, 0), 0x64: ('STZ dp', 2, 0), 0x74: ('STZ dp,x', 2, 0),
    0xA7: ('LDA dp,l', 2, 8), 0xB7: ('LDA dp,l,y', 2, 8),
    0x24: ('BIT dp', 2, 8), 0x2C: ('BIT abs', 3, 16), 0x89: ('BIT #imm', 3, 16),
    0x3C: ('BIT abs,x', 3, 16),
    0x04: ('TSB dp', 2, 0), 0x0C: ('TSB abs', 3, 0), 0x14: ('TRB dp', 2, 0), 0x1C: ('TRB abs', 3, 0),
    0x54: ('MVN', 3, 0), 0x44: ('MVP', 3, 0),
}

def cpu2file(pc):
    bank = pc >> 16
    off = pc & 0xFFFF
    if bank >= 0x80 or (0x40 <= bank < 0x80 and off >= 0x8000):
        return (bank - 0x80 if bank >= 0x80 else bank - 0x40) * 0x8000 + (off - 0x8000)
    if bank < 0x40 and off >= 0x8000:
        return (bank) * 0x8000 + (off - 0x8000)
    return None

def disasm(rom, pc, n=24):
    out = []
    f0 = cpu2file(pc)
    if f0 is None:
        return [f"${pc:06x}: (no rom mapping)"]
    i = f0
    cur = pc
    for _ in range(n):
        op = rom[i]
        if op in OPS:
            name, ln, kind = OPS[op]
            if ln == 1:
                out.append(f"${cur:06x}: {name}")
            else:
                val = int.from_bytes(rom[i + 1:i + ln], 'little')
                # nota: modo M/X asumido 16b para imm de 3 bytes; 8b-> el tamanno real depende de flags
                out.append(f"${cur:06x}: {name} ${val:04x}")
        else:
            out.append(f"${cur:06x}: .db ${op:02x}")
            i += 1
            cur += 1
            continue
        i += ln
        cur += ln
    return out

if __name__ == '__main__':
    recs = load_trace(sys.argv[1])
    summarize(recs)
