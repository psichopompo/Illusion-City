from pathlib import Path
rom=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert rom[0xbb7e:0xbb83] == bytes.fromhex('ae f0 0f b4 0a')
rom[0xbb7e:0xbb82] = bytes.fromhex('22 00 89 88')
h=bytearray();labels={};branches=[]
def E(*x):h.extend(x)
def L(name):labels[name]=len(h)
def B(op,name):branches.append((len(h)+1,name));E(op,0)
def JML(addr):E(0x5c,addr&255,(addr>>8)&255,(addr>>16)&255)
# Entry is after the original PHB/PHK/PLB/JSR BBCC and list-head setup.
E(0xad,0xf0,0x0f,0xc9,0xb4,0x00);B(0xd0,'skip')
E(0xad,0xf4,0x0f,0xc9,0xc4,0x00);B(0xd0,'skip')
# Diagnostic reverse of the eight kart records in the first (B4/$0A) list.
for x,y in [(0x1000,0x1100),(0x1100,0x1200),(0x1200,0x1300),(0x1300,0x1400),(0x1400,0x1500),(0x1500,0x1600),(0x1600,0x1700),(0x1700,0x00b4)]:
    E(0xa2,x&255,(x>>8)&255,0xa0,y&255,(y>>8)&255,0x94,0x0a)
L('skip')
# Recreate the overwritten LDx/LDy and continue at CPY $80BB83.
E(0xad,0xf0,0x0f,0xb4,0x0a);JML(0x80bb83)
for pos,name in branches:h[pos]=(labels[name]-(pos+1))&255
rom[0x88900:0x88900+len(h)]=h
Path('/tmp/list_reverse_diag.sfc').write_bytes(rom);print('helper',len(h),h.hex(' '))
