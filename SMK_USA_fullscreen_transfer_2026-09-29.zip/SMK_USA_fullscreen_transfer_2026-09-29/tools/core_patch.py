#!/usr/bin/env python3
"""Reaplica la instrumentación smk al árbol bsnes master (0c2fa0d) en /tmp/bsnes_src."""
import sys
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/tmp/bsnes_src'

# 1) memory-inline.hpp: hook en Bus::write
p = f'{ROOT}/bsnes/sfc/memory/memory-inline.hpp'
s = open(p).read()
old = '''auto Bus::write(uint addr, uint8 data) -> void {
  return writer[lookup[addr]](target[addr], data);
}'''
new = '''extern "C" void smkTraceWrite(unsigned addr, unsigned data);
auto Bus::write(uint addr, uint8 data) -> void {
  smkTraceWrite(addr, data);
  return writer[lookup[addr]](target[addr], data);
}'''
assert old in s
open(p, 'w').write(s.replace(old, new))

# 2) memory.cpp: trazas + dump + WRAM export
p = f'{ROOT}/bsnes/sfc/memory/memory.cpp'
s = open(p).read()
add = '''

// ==== smk instrumentation ====
#include <cstdio>
static uint32 trPC[262144]; static uint16 trAddr[262144]; static uint8 trData[262144];
static uint16 trX[262144]; static uint32 trCount = 0;
extern "C" void smkTraceWrite(unsigned addr, unsigned data) {
  uint off = addr & 0xffff; uint bank = addr >> 16;
  bool hit = (bank == 0x00 || bank == 0x7e) && ((off >= 0x0260 && off < 0x0280) || (off >= 0x0400 && off < 0x0640) || (off >= 0x2100 && off < 0x2200) || (off >= 0x4200 && off < 0x4400));
  if(!hit) return;
  if(trCount < 262144) {
    trPC[trCount] = SuperFamicom::cpu.r.pc.d;
    trAddr[trCount] = (uint16)addr;
    trData[trCount] = (uint8)data;
    trX[trCount] = (uint16)SuperFamicom::cpu.r.x.w;
    trCount++;
  }
}
extern "C" { extern uint32 smkPcRingC[65536]; extern unsigned smkPcRingCN;
extern uint32 smkMiniTraceC[4096]; extern unsigned smkMiniTraceN; }

extern "C" __attribute__((visibility("default"))) void bsnes_debug_dump(const char* path) {
  FILE* f = fopen(path, "w");
  if(f) {
    fprintf(f, "# pcring n=%u\\n", smkPcRingCN);
    unsigned n = smkPcRingCN < 65536 ? smkPcRingCN : 65536;
    unsigned start = smkPcRingCN <= 65536 ? 0 : smkPcRingCN & 65535;
    for(unsigned i = 0; i < n; i++) fprintf(f, "e=%06x\\n", smkPcRingC[(start + i) & 65535]);
    for(uint32 i = 0; i < trCount; i++) fprintf(f, "pc=%06x a=%04x d=%02x x=%04x\\n", trPC[i], trAddr[i], trData[i], trX[i]);
    fprintf(f, "# minitrace n=%u\\n", smkMiniTraceN);
    for(unsigned i = 0; i < smkMiniTraceN && i < 4096; i++) fprintf(f, "m=%06x\\n", smkMiniTraceC[i]);
    fclose(f);
  }
  trCount = 0; smkPcRingCN = 0; smkMiniTraceN = 0;
}
extern "C" __attribute__((visibility("default"))) void bsnes_debug_refresh(void) {}
extern "C" __attribute__((visibility("default"))) uint8* bsnes_wram_data(void) { return SuperFamicom::cpu.wram; }
extern "C" __attribute__((visibility("default"))) unsigned bsnes_wram_size(void) { return sizeof(SuperFamicom::cpu.wram); }
// ==== fin smk ====
'''
open(p, 'a').write(add)

# 3) instruction.cpp: ring + minitrace
p = f'{ROOT}/bsnes/processor/wdc65816/instruction.cpp'
s = open(p).read()
old = 'auto WDC65816::instruction() -> void {'
new = '''extern "C" { uint32 smkPcRingC[65536]; unsigned smkPcRingCN = 0;
uint32 smkMiniTraceC[4096]; unsigned smkMiniTraceN = 0; unsigned smkMiniArm = 0; }

auto WDC65816::instruction() -> void {
  if(PC.d == 0x80bc96 && smkMiniArm == 0) { smkMiniArm = 1; smkMiniTraceN = 0; }
  if(smkMiniArm && smkMiniTraceN < 4096) smkMiniTraceC[smkMiniTraceN++] = PC.d;
  if(smkMiniTraceN >= 4096) smkMiniArm = 2;
  if((PC.d >= 0x80bc00 && PC.d < 0x80be00) || (PC.d >= 0x8048d0 && PC.d < 0x804930) || (PC.d >= 0xc04850 && PC.d < 0xc04930)) smkPcRingC[smkPcRingCN++ & 65535] = PC.d;'''
assert old in s
open(p, 'w').write(s.replace(old, new, 1))

# 4) libretro.cpp: WRAM como SYSTEM_RAM
p = f'{ROOT}/bsnes/target-libretro/libretro.cpp'
s = open(p).read()
old = '''RETRO_API void *retro_get_memory_data(unsigned id)
{
\treturn nullptr;
}

RETRO_API size_t retro_get_memory_size(unsigned id)
{
\treturn 0;
}'''
new = '''extern "C" uint8* bsnes_wram_data(void);
extern "C" unsigned bsnes_wram_size(void);
RETRO_API void *retro_get_memory_data(unsigned id)
{
\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_data();
\treturn nullptr;
}

RETRO_API size_t retro_get_memory_size(unsigned id)
{
\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_size();
\treturn 0;
}'''
assert old in s
open(p, 'w').write(s.replace(old, new))

# 5) link.T
p = f'{ROOT}/bsnes/target-libretro/link.T'
open(p, 'w').write('{\n   global: retro_*; bsnes_*; smk*;\n   local: *;\n};\n')
print("parches aplicados en", ROOT)
