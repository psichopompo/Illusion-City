import sys
from collections import Counter

def frames(path):
    fr=[]; cur=[]
    for l in open(path):
        if not l.startswith('pc='): continue
        a=int(l.split('a=')[1].split()[0],16); d=int(l.split('d=')[1].split()[0],16)
        if a==0x2102:
            if cur: fr.append(cur)
            cur=[]
        elif a==0x2104:
            cur.append(d)
    if cur: fr.append(cur)
    return fr

def oam(stream):
    o=[]
    for i in range(0,len(stream)-3,4):
        o.append((stream[i],stream[i+1],stream[i+2],stream[i+3]))
    return o

fb=frames('tr_base.log'); ff=frames('tr_fin.log')
print("frames base/fin:", len(fb), len(ff))
n=min(len(fb),len(ff))
diffcnt=Counter()
detail=[]
for fno in range(n):
    ob=oam(fb[fno]); of=oam(ff[fno])
    m=min(len(ob),len(of))
    for i in range(m):
        xb,yb,tb,ab=ob[i]; xf,yf,tf,af=of[i]
        dy=yf-yb; dx=xf-xb
        if dy or dx or tb!=tf or ab!=af:
            diffcnt[(i,dy,dx)]+=1
            if len(detail)<40 and fno>2:
                detail.append((fno,i,xb,yb,tb,ab,xf,yf,tf,af))
print("top diffs (slot, dY, dX): count")
for k,c in diffcnt.most_common(30):
    print(f"  slot={k[0]:3d} dY={k[1]:4d} dX={k[2]:4d}  n={c}")
print("\nsamples:")
for d in detail:
    print(f"  f={d[0]:3d} slot={d[1]:3d} base(X={d[2]:3d} Y={d[3]:3d} t={d[4]:02x} a={d[5]:02x}) fin(X={d[6]:3d} Y={d[7]:3d} t={d[8]:02x} a={d[9]:02x})")
