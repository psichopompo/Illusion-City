from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x9486:0x9489]==bytes.fromhex('9c 04 43')
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x9486:0x9489]=bytes.fromhex('4c e4 fe')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
# Pre hook: six fast MVN copies. Active third block means race path and reverse
# order; E0 means the accepted finish/hidden path and identity order.
w=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 c2 30 e2 20 ad a1 02 c9 e0 f0'))
beq=len(w);w.append(0)
w += bytes.fromhex('c2 30')
for i in range(6):
    src=0x280+0x10*(5-i);dst=0x8f00+0x10*i
    w += bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e])
bra=len(w);w += bytes([0x80,0])
identity=len(w);w += bytes.fromhex('c2 30')
for i in range(6):
    src=0x280+0x10*i;dst=0x8f00+0x10*i
    w += bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e])
finish=len(w)
# MVN leaves DBR=7f. Mark scratch valid for the next post hook.
w += bytes.fromhex('e2 30 a9 a5 8d 70 8f ab 7a fa 68 28 6b')
w[beq]=(identity-(beq+1))&255
w[bra+1]=(finish-(bra+2))&255
assert len(w)<0x200
b[0x88900:0x88900+len(w)]=w
# Bank-80 stub also restores the original skipped STZ $4304.
b[0xfee4:0xfee4+10]=bytes.fromhex('22 00 89 88 9c 04 43 4c 89 94')
# Post hook with a one-byte valid flag at 7f:8f70. It always performs the
# original full DMA; the sorted scratch DMA is skipped on the first cold frame.
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42'))
# Load flag and branch over the short sorted DMA if it is not A5.
p += bytes.fromhex('af 70 8f 7f c9 a5 d0')
skip_branch=len(p);p.append(0)
# Sorted scratch -> OAM blocks 32..55.
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 00 8d 00 43 a9 04 8d 01 43 a9 00 8d 02 43 a9 8f 8d 03 43 a9 7f 8d 04 43 a9 60 8d 05 43 9c 06 43 a9 01 8d 0b 42')
skip=len(p)
p += bytes.fromhex('e2 30 ab 7a fa 68 28 4c a6 94')
p[skip_branch]=((skip-(skip_branch+1))&255)
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_scratch_flagged.sfc').write_bytes(b)
print('helper',len(w),'post',len(p),'flag_branch',hex(skip_branch),'skip',hex(skip))
