from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42'))
# At the post hook the source buffer is still in WRAM. Hidden third block E0
# identifies the accepted finish path, where the exchange must be skipped.
p += bytes.fromhex('af a1 02 7e c9 e0 f0');beq=len(p);p.append(0)
# exchange 16-byte source blocks 0280/0290 in PPU OAM using two hardware DMAs
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 90 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42')
p += bytes.fromhex('a9 48 8d 02 21 9c 03 21 a9 80 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42')
skip=len(p);p += bytes.fromhex('ab 7a fa 68 28 4c a6 94')
p[beq]=(skip-(beq+1))&255
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_post_cond_swap.sfc').write_bytes(b);print(len(p))
