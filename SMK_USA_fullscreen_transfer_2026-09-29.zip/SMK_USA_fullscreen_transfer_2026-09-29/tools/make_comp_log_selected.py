from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0xbba8:0xbbac]==bytes.fromhex('8d f0 0f a8')
assert b[0xbbb9:0xbbbe]==bytes.fromhex('8c f4 0f 84 b4')
b[0xbba8:0xbbac]=bytes.fromhex('22 00 89 88')
b[0xbbb9:0xbbbe]=bytes.fromhex('22 10 89 88 ea')
# helper 8900: log selected first-list pointer (A), perform original STA/TAY, RTL.
b[0x88900:0x88900+12]=bytes.fromhex('8f 00 06 00 8d f0 0f a8 6b')
# helper 8910: log selected second-list pointer (Y), perform original STY/STY, RTL.
b[0x88910:0x88910+14]=bytes.fromhex('98 8f 02 06 00 8c f4 0f 84 b4 6b')
Path('/tmp/comp_log_selected.sfc').write_bytes(b);print('ok')
