from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42'))
# Skip the accepted finish/hidden path; otherwise exchange only when Y0 > Y1.
p += bytes.fromhex('af a1 02 7e c9 e0 f0');hidden=len(p);p.append(0)
# Save Y1 on stack, compare Y0 against stack-relative Y1.
p += bytes.fromhex('af 91 02 7e 48 af 81 02 7e c3 01 90')
less=len(p);p.append(0)
p += bytes.fromhex('f0');equal=len(p);p.append(0)
# Both BCC/BEQ land at no_swap, where the temporary Y1 is popped.
p += bytes.fromhex('68')
# Swap complete 16-byte OAM blocks using hardware DMA.
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 90 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42 a9 48 8d 02 21 9c 03 21 a9 80 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42')
# Swap path must jump over the no-swap temporary pop.
bra=len(p);p += bytes([0x80,0])
no_swap=len(p);p += bytes.fromhex('68')
done=len(p);p += bytes.fromhex('ab 7a fa 68 28 4c a6 94')
p[bra+1]=(done-(bra+2))&255
p[hidden]=(done-(hidden+1))&255
p[less]=(no_swap-(less+1))&255
p[equal]=(no_swap-(equal+1))&255
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_post_adjacent.sfc').write_bytes(b);print(len(p),'hidden',hidden,'no',no_swap)
