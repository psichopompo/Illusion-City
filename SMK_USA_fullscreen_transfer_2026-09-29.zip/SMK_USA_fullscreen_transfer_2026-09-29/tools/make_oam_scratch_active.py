from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x9486:0x9489]==bytes.fromhex('9c 04 43') and b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x9486:0x9489]=bytes.fromhex('4c e4 fe');b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
# Pre-hook sorter/gather. The low byte of the builder pointer selects how many
# active blocks are present; hidden E0 path stays identity. Active 3/5 paths
# reverse only active slots, preventing hidden sprites from entering slot 32.
w=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 c2 30 e2 20 ad a1 02 c9 e0 f0'))
beq_hidden=len(w);w.append(0)
w += bytes.fromhex('ad 3c 00 c9 b0 f0');beq3=len(w);w.append(0)
w += bytes.fromhex('c9 d0 f0');beq5=len(w);w.append(0)
w += bytes.fromhex('c9 90 f0');beq_id1=len(w);w.append(0)
w += bytes.fromhex('c9 80 f0');beq_id2=len(w);w.append(0)
paths={}
def mvn_path(name, order):
    paths[name]=len(w)
    w.extend(bytes.fromhex('c2 30'))
    for i,src_i in enumerate(order):
        src=0x280+0x10*src_i;dst=0x8f00+0x10*i
        w.extend(bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e]))
    bra=len(w);w.extend([0x80,0]);return bra
# 6 active, active 5, active 3, identity.
bra6=mvn_path('six',[5,4,3,2,1,0])
bra6op= len(w)-2
id_label=len(w);bra_id1_target=id_label
# identity path target is shared; put identity after branch-around six/5/3 paths.
# We need path labels before emitting branch-around targets; emit path5/3/identity
# in sequence with each path's BRA patched later.
path5=len(w);w.extend(bytes.fromhex('c2 30'))
for i,src_i in enumerate([4,3,2,1,0,5]):
    src=0x280+0x10*src_i;dst=0x8f00+0x10*i
    w.extend(bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e]))
bra5=len(w);w.extend([0x80,0])
path3=len(w);w.extend(bytes.fromhex('c2 30'))
for i,src_i in enumerate([2,1,0,3,4,5]):
    src=0x280+0x10*src_i;dst=0x8f00+0x10*i
    w.extend(bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e]))
bra3=len(w);w.extend([0x80,0])
identity=len(w);w.extend(bytes.fromhex('c2 30'))
for i in range(6):
    src=0x280+0x10*i;dst=0x8f00+0x10*i
    w.extend(bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e]))
finish=len(w)
# Mark scratch valid for the next post hook.
w.extend(bytes.fromhex('e2 30 a9 a5 8d 70 8f ab 7a fa 68 28 6b'))
# Patch all path branches (BRA operand is relative from following instruction).
for pos,target in [(beq_hidden,identity),(beq3,path3),(beq5,path5),(beq_id1,identity),(beq_id2,identity)]:w[pos]=(target-(pos+1))&255
for pos,target in [(bra6,finish),(bra5,finish),(bra3,finish)]:w[pos+1]=(target-(pos+2))&255
assert len(w)<0x400
b[0x88900:0x88900+len(w)]=w
b[0xfee4:0xfee4+10]=bytes.fromhex('22 00 89 88 9c 04 43 4c 89 94')
# Post hook with cold-frame flag; low scratch DMA is skipped until pre has made it valid.
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42 af 70 8f 7f c9 a5 d0'))
skip_branch=len(p);p.append(0)
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 00 8d 00 43 a9 04 8d 01 43 a9 00 8d 02 43 a9 8f 8d 03 43 a9 7f 8d 04 43 a9 60 8d 05 43 9c 06 43 a9 01 8d 0b 42')
skip=len(p);p += bytes.fromhex('e2 30 ab 7a fa 68 28 4c a6 94')
p[skip_branch]=(skip-(skip_branch+1))&255
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_scratch_active.sfc').write_bytes(b);print('helper',len(w),'post',len(p),'paths',paths,'identity',identity)
