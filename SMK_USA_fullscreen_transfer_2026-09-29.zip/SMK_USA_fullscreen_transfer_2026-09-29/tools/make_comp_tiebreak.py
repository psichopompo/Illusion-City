from pathlib import Path
base=Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes()
assert base[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12')
# Return carry=0 iff primary depth is smaller; on equal compare selected field.
# BBA0..BBA4 is exactly five bytes available before the original BCC at BBA5.
for name,field in [('34',0x34),('32',0x32)]:
 b=bytearray(base);b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
 h=bytes([0xb5,0x0e,0xd9,0x0e,0x00,0x90,0x07,0xd0,0x05,0xb5,field,0xd9,field,0x00,0x6b])
 b[0x88900:0x88900+len(h)]=h
 Path(f'/tmp/comp_tie_{name}.sfc').write_bytes(b)
 print(name,len(h))
