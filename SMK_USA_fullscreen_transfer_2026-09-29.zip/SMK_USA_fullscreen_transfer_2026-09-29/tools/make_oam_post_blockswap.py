from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
w=bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42 '
'a9 40 8d 02 21 9c 03 21 a9 90 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42 '
'a9 48 8d 02 21 9c 03 21 a9 80 8d 02 43 a9 02 8d 03 43 9c 04 43 a9 10 8d 05 43 9c 06 43 a9 01 8d 0b 42 '
'ab 7a fa 68 28 4c a6 94')
b[0xff20:0xff20+len(w)]=w
Path('/tmp/oam_post_blockswap.sfc').write_bytes(b);print(len(w))
