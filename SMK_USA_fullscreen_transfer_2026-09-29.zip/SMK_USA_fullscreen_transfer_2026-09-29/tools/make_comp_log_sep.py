from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
h=bytes.fromhex('e2 20 b5 0e d9 0e 00 90 11 d0 0f 8a 8f 74 8f 7f 98 8f 76 8f 7f b5 34 d9 34 00 6b')
b[0x88900:0x88900+len(h)]=h;Path('/tmp/comp_log_sep.sfc').write_bytes(b);print(len(h))
