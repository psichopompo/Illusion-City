from pathlib import Path
base=Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes();assert base[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12')
for name,field in [('34',0x34),('32',0x32)]:
 b=bytearray(base);b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
 # Primary unchanged. Equal: a<b -> SEC (choose second), a>b/equal -> CLC (choose first).
 # Primary returns at the final RTL. On equal primary, reverse the secondary order:
 # secondary a<b -> SEC (choose second); a>b -> CLC (choose first).
 h=bytes([0xb5,0x0e,0xd9,0x0e,0x00,0x90,0x0e,0xd0,0x0c,
          0xb5,field,0xd9,field,0x00,0x90,0x04,0xd0,0x00,0x18,0x6b,0x38,0x6b])
 b[0x88900:0x88900+len(h)]=h;Path(f'/tmp/comp_tie_inv_{name}.sfc').write_bytes(b);print(name,len(h))
