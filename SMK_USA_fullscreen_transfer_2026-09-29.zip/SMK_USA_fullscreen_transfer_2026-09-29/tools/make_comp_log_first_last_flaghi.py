from pathlib import Path
rom=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert rom[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12');rom[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
c=bytearray();labels={};br=[]
def E(*x):c.extend(x)
def AF(a):E(0xaf,a&255,(a>>8)&255,0x7f)
def SF(a):E(0x9f,a&255,(a>>8)&255,0x7f)
def B(op,n):br.append((len(c)+1,n));E(op,0)
def L(n):labels[n]=len(c)
E(0xb5,0x0e,0xd9,0x0e,0x00);B(0x90,'done');B(0xd0,'done')
# First flag in 7f:ff00; pointer pairs in the known-safe low scratch.
E(0xaf,0x00,0xff,0x7f);B(0xd0,'last')
E(0x8a);SF(0x8f74);E(0x98);SF(0x8f76);E(0xa9,0xa5,0x00);E(0x8f,0x00,0xff,0x7f)
L('last');E(0x8a);SF(0x8f78);E(0x98);SF(0x8f7a)
E(0xb5,0x34,0xd9,0x34,0x00,0x6b);L('done');E(0x6b)
for p,n in br:c[p]=(labels[n]-(p+1))&255
rom[0x88900:0x88900+len(c)]=c;Path('/tmp/comp_log_first_last_flaghi.sfc').write_bytes(rom);print(len(c),c.hex(' '))
