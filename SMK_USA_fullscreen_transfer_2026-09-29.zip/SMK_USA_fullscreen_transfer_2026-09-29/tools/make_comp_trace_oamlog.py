from pathlib import Path
rom=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert rom[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12');rom[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
c=bytearray();labels={};br=[]
def E(*x):c.extend(x)
def B(op,n):br.append((len(c)+1,n));E(op,0)
def L(n):labels[n]=len(c)
def AF(addr):E(0xaf,addr&255,(addr>>8)&255,0x00)
def SF(addr):E(0x8f,addr&255,(addr>>8)&255,0x00)
# Native M/X mode, same primary key and equal path as original.
E(0xb5,0x0e,0xd9,0x0e,0x00);B(0x90,'done');B(0xd0,'done')
E(0x8a);SF(0x0600);E(0x98);SF(0x0602)
E(0xb5,0x0e);SF(0x0604);E(0xb9,0x0e,0x00);SF(0x0606)
E(0xb5,0x34);SF(0x0608);E(0xb9,0x34,0x00);SF(0x060a)
E(0xb5,0x34,0xd9,0x34,0x00,0x6b)
L('done');E(0x6b)
for p,n in br:c[p]=(labels[n]-(p+1))&255
rom[0x88900:0x88900+len(c)]=c;Path('/tmp/comp_trace_oamlog.sfc').write_bytes(rom);print(len(c),c.hex(' '))
