from pathlib import Path
rom=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert rom[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12');rom[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
c=bytearray();labels={};br=[]
def E(*x):c.extend(x)
def AF(a):E(0xaf,a&255,(a>>8)&255,0x7f)
def SF(a):E(0x9f,a&255,(a>>8)&255,0x7f)
def B(op,n):br.append((len(c)+1,n));E(op,0)
def L(n):labels[n]=len(c)
# Original comparator is M=8, X=16. Keep that mode for the primary key.
E(0xe2,0x20);E(0xb5,0x0e,0xd9,0x0e,0x00);B(0x90,'done');B(0xd0,'done')
# Equal: use 16-bit A only while logging the 16-bit pointers and secondary field.
E(0xc2,0x20);AF(0x8f72);B(0xd0,'last')
E(0x8a);SF(0x8f74);E(0x98);SF(0x8f76);E(0xa9,0xa5);SF(0x8f72)
L('last');E(0x8a);SF(0x8f78);E(0x98);SF(0x8f7a)
E(0xb5,0x34,0xd9,0x34,0x00,0xe2,0x20,0x6b)
L('done');E(0x6b)
for p,n in br:c[p]=(labels[n]-(p+1))&255
rom[0x88900:0x88900+len(c)]=c;Path('/tmp/comp_log_first_last_m8.sfc').write_bytes(rom);print(len(c))
