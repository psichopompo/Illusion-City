# Herramientas

Scripts de análisis y parcheo reutilizables. Las variantes experimentales y sus capturas no se conservan en la raíz; los resultados deben reproducirse desde `roms/`, `states/` y `cores/`.