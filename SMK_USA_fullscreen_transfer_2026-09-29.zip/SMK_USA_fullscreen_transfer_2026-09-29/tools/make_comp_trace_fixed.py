from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert b[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12');b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
# Fixed high-WRAM log for the last comparator call.
h=bytes.fromhex('c2 30 8a 9f 10 ff 7f 98 9f 12 ff 7f b5 0e 9f 14 ff 7f b9 0e 00 9f 16 ff 7f b5 34 9f 18 ff 7f b9 34 00 9f 1a ff 7f b5 0e d9 0e 00 90 07 d0 05 b5 34 d9 34 00 6b')
b[0x88900:0x88900+len(h)]=h;Path('/tmp/comp_trace_fixed.sfc').write_bytes(b);print(len(h))
