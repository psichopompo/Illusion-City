from pathlib import Path
rom=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert rom[0xbba0:0xbba7] == bytes.fromhex('b5 0e d9 0e 00 90 12')
rom[0xbba0:0xbba5] = bytes.fromhex('22 00 89 88 ea')
c=bytearray();labels={};branches=[]
def E(*xs): c.extend(xs)
def label(n): labels[n]=len(c)
def branch(op,n): branches.append((len(c)+1,n));E(op,0)
def AF(a): E(0xaf,a&255,(a>>8)&255,0x7f)
def SF(a): E(0x9f,a&255,(a>>8)&255,0x7f)
E(0xc2,0x30)
E(0xb5,0x0e,0xd9,0x0e,0x00);branch(0x90,'done');branch(0xd0,'done')
# Only equal-depth pairs are logged: pointer pair in 7f:8f80, 16 bytes per entry.
E(0x8a);SF(0x8f74);E(0x98);SF(0x8f76)
AF(0x8f72);E(0x1a);SF(0x8f72)      # equal-pair count
AF(0x8f72);E(0x3a,0x0a,0x0a,0x0a,0x0a,0xaa) # X=(count-1)*16
AF(0x8f74);E(0x9f,0x80,0x8f,0x7f)  # X pointer
AF(0x8f76);E(0x9f,0x82,0x8f,0x7f)  # Y pointer
AF(0x8f74);E(0xaa);AF(0x8f76);E(0xa8)
# Secondary comparison, return its carry.
E(0xb5,0x34,0xd9,0x34,0x00,0x6b)
label('done');E(0x6b)
for pos,n in branches:
    c[pos]=(labels[n]-(pos+1))&255
rom[0x88900:0x88900+len(c)]=c
Path('/tmp/comp_log_equal_pairs.sfc').write_bytes(rom);print('helper',len(c))
