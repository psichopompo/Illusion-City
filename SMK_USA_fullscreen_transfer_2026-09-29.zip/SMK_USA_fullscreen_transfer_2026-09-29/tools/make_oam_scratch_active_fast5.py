from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x9486:0x9489]==bytes.fromhex('9c 04 43') and b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x9486:0x9489]=bytes.fromhex('4c e4 fe');b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
w=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 c2 30 e2 20 ad a1 02 c9 e0 f0'))
beq_id=len(w);w.append(0)
w += bytes.fromhex('ad d1 02 c9 e0 f0');beq5=len(w);w.append(0)
w += bytes.fromhex('c2 30')
def path(order):
    for i,src_i in enumerate(order):
        src=0x280+16*src_i;dst=0x8f00+16*i
        w.extend(bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e]))
path([5,4,3,2,1,0]);bra6=len(w);w.extend([0x80,0])
path5=len(w);w.extend(bytes.fromhex('c2 30'));path([4,3,2,1,0,5]);bra5=len(w);w.extend([0x80,0])
identity=len(w);w.extend(bytes.fromhex('c2 30'));path([0,1,2,3,4,5]);finish=len(w)
w.extend(bytes.fromhex('e2 30 a9 a5 8d 70 8f ab 7a fa 68 28 6b'))
w[beq_id]=(identity-(beq_id+1))&255;w[beq5]=(path5-(beq5+1))&255;w[bra6+1]=(finish-(bra6+2))&255;w[bra5+1]=(finish-(bra5+2))&255
assert len(w)<0x300
b[0x88900:0x88900+len(w)]=w;b[0xfee4:0xfee4+10]=bytes.fromhex('22 00 89 88 9c 04 43 4c 89 94')
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42 af 70 8f 7f c9 a5 d0'));skipop=len(p);p.append(0)
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 00 8d 00 43 a9 04 8d 01 43 a9 00 8d 02 43 a9 8f 8d 03 43 a9 7f 8d 04 43 a9 60 8d 05 43 9c 06 43 a9 01 8d 0b 42')
skip=len(p);p += bytes.fromhex('e2 30 ab 7a fa 68 28 4c a6 94');p[skipop]=(skip-(skipop+1))&255
assert len(p)<0xe0;b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_scratch_active5.sfc').write_bytes(b);print(len(w),len(p),hex(path5),hex(identity))
