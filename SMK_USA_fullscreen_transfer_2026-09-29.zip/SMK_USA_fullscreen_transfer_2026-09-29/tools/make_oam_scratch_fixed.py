from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes())
assert b[0x9486:0x9489]==bytes.fromhex('9c 04 43')
assert b[0x94a3:0x94a6]==bytes.fromhex('8d 0b 42')
b[0x9486:0x9489]=bytes.fromhex('4c e4 fe')
b[0x94a3:0x94a6]=bytes.fromhex('4c 20 ff')
# Bank 88 helper: copy source blocks 5..0 into a contiguous bank-7f scratch
# area before the original OAM DMA. MVN is faster and leaves source WRAM intact.
w=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 c2 30'))
for i in range(6):
    src=0x280+0x10*(5-i); dst=0x8f00+0x10*i
    w += bytes([0xa9,0x0f,0x00,0xa2,src&255,(src>>8)&255,
                0xa0,dst&255,(dst>>8)&255,0x54,0x7f,0x7e])
w += bytes.fromhex('e2 30 ab 7a fa 68 28 6b')
assert len(w)<0x200
b[0x88900:0x88900+len(w)]=w
# Bank-80 stub: call helper, restore the original skipped STZ $4304, continue.
b[0xfee4:0xfee4+10]=bytes.fromhex('22 00 89 88 9c 04 43 4c 89 94')
# Post hook: original full DMA, one contiguous 96-byte DMA to OAM, clear scratch.
p=bytearray(bytes.fromhex('08 48 da 5a 8b e2 30 a9 00 48 ab a9 01 8d 0b 42'))
p += bytes.fromhex('a9 40 8d 02 21 9c 03 21 a9 00 8d 00 43 a9 04 8d 01 43 a9 00 8d 02 43 a9 8f 8d 03 43 a9 7f 8d 04 43 a9 60 8d 05 43 9c 06 43 a9 01 8d 0b 42')
# MVN from a free zero-filled ROM area (88:8b00) to restore the scratch.
p += bytes.fromhex('c2 30 a9 65 00 a2 00 8b a0 00 8f 54 7f 88 e2 30 ab 7a fa 68 28 4c a6 94')
assert len(p)<0xe0
b[0xff20:0xff20+len(p)]=p
Path('/tmp/oam_scratch_fixed.sfc').write_bytes(b)
print('pre_helper',len(w),'post',len(p))
