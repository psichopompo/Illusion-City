from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert b[0xbba0:0xbba5]==bytes.fromhex('b5 0e d9 0e 00');b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
# Marker at 7f:8f70, then original primary/secondary comparator.
h=bytes.fromhex('08 e2 20 a9 a5 8f 70 8f 7f 28 b5 0e d9 0e 00 90 07 d0 05 b5 34 d9 34 00 6b')
b[0x88900:0x88900+len(h)]=h;Path('/tmp/comp_trace.sfc').write_bytes(b);print(len(h))
