from pathlib import Path
b=bytearray(Path('/home/user/smk_work/roms/t_vK58.sfc').read_bytes());assert b[0xbba0:0xbba7]==bytes.fromhex('b5 0e d9 0e 00 90 12');b[0xbba0:0xbba5]=bytes.fromhex('22 00 89 88 ea')
h=bytes.fromhex('b5 0e d9 0e 00 90 03 d0 01 18 6b') # equal CLC; BCC/BNE to RTL
b[0x88900:0x88900+len(h)]=h;Path('/tmp/comp_tie_flip.sfc').write_bytes(b);print(len(h))
