# Documentación actual — SMK USA Full Screen

## Candidato activo

- Base: `roms/Super Mario Kart USA Full Screen.sfc`
- Candidato: `roms/t_vK58.sfc`
- State de validación de meta: `states/t_vK58.state`
- Payload equivalente para el harness: `states/t_vK58_payload.bin`

La ROM base es HiROM USA de 1 MiB y el candidato difiere actualmente solo en los dos valores de cámara/posición de sprites y en la corrección del banner `ROUND 1`.

## Validado

- Perspectiva del escenario conservada según v14.
- Rotación de la pista estable.
- Kart del jugador en la mitad inferior.
- Reescalado con profundidad.
- El state de meta carga correctamente en bsnes (`serialize_size = 286469`, `unserialize = 1`).
- La cámara gira al cruzar la meta sin reproducir el shrink inconsistente observado en la lógica anterior.

## Pendiente

### Orden de dibujado

El solapamiento ocasional de un rival con el jugador apunta al orden de emisión OAM/prioridad de sprites, no a una colisión. El arreglo debe trabajar en el punto común posterior a la composición OAM, manteniendo juntos los cuatro subsprites de cada kart y ordenando los karts por profundidad. No se deben reintroducir los hooks por objeto dentro del camino rasterizado de v14.

### HUD y textos

Mover el bloque de coches y monedas a la disposición objetivo, comprobando específicamente `$0406` durante `ROUND 1`, sin afectar el texto ni el mapa/escenario.

### Colisiones

Las colisiones con el escenario y con rivales todavía no están validadas. Se abordarán después de estabilizar la proyección, la escala y el orden de dibujado.

### 2P y entrega

Quedan por validar el intercambio de pantallas en dobles, con P1 abajo, y la reproducción final en RetroArch/bsnes. No se debe emitir un IPS final hasta que un candidato único pase esas pruebas.

## Investigación OAM en curso

Se ha confirmado que los karts ocupan quads contiguos de cuatro entradas en OAM, normalmente en los slots `$28-$3B`, y que el índice OAM determina qué sprite queda delante cuando se solapan.

Se probó de forma experimental un ordenamiento completo en la rutina de DMA de OAM (`$8094A1`). Queda **descartado**: el coste temporal rompe la ventana de raster/HDMA y produce corrupción visible del escenario. No se conserva esa ROM. El arreglo deberá ejecutarse en un punto de composición anterior y no crítico, o limitarse a una operación constante muy pequeña.

### Resultado de la instrumentación PPU/DMA

La instrumentación del PPU rápido y de la transferencia DMA, usando el state reproducible y sin modificar `t_vK58.sfc`, cierra la hipótesis de rotación de prioridad:

- `oamBaseAddress = $000`, `oamPriority = 0`, `firstSprite = 0` y `rangeOver/timeOver = 0` al terminar el frame. No hay rotación del punto inicial OAM ni desbordamiento de objetos.
- Se observa una sola transferencia OAM de 544 bytes, en modo fijo hacia `$2104`, desde `$000200-$00041F`: los 512 bytes bajos y la tabla alta `$0400-$041F` llegan al PPU en orden.
- Los quads de carrera llegan como cuatro entradas completas por kart en los slots OAM `$28-$3B`; los atributos y la tabla alta acompañan a cada grupo. El índice fijo de composición es, por tanto, la causa relevante del solapamiento, no una reordenación interna del PPU/DMA.
- La prioridad OBJ de los karts es la misma (`2` en este estado), así que tampoco hay una prioridad de atributo que pueda corregirlo sin alterar la lógica visual aceptada.

Conclusión operativa: la próxima solución debe identificar los quads dinámicamente durante la composición (manteniendo los 16 bytes bajos y la entrada alta asociada como unidad) y ajustar solo el orden de los karts cuando el orden de profundidad lo requiera. No se autoriza un intercambio fijo de slots ni tocar cámara, escala, posición o raster.

### Validación de `$0406` y entrada en carrera

Se añadió una traza de escrituras con frame y PC a `$0400`, `$0406`, `$0600` y `$0620`, y se condujo el state de selección hasta la parrilla de carrera. El resultado no debe confundirse con la validación de `ROUND 1`:

- En el state de selección, `$0406` parte en `$AA`; durante la transición se observa el borrado a `$00` (frame 113) y una escritura transitoria `$AA` desde el compositor de quads (frame 123). En la parrilla/carrera de esa reproducción queda en `$00`, con `$0600=$80` y la tabla alta general en `$FF`.
- En `states/t_vK58_payload.bin`, que ya es un state de carrera avanzado, `$0406=$55` permanece estable durante 80 frames; no hubo una escritura posterior que permita atribuir ese valor a la entrada en `ROUND 1`.
- El desensamblado identifica la rutina de carga que escribe el valor constante en `$81BC5B` (`STA $0406`, acompañada de `STA $0626`). En la base el inmediato es `$55`, mientras que `t_vK58` contiene `$00` en el byte anterior (`$81BC5A`). Por tanto, todavía hay que capturar la ejecución real desde el arranque/carga de pista hasta el texto `ROUND 1`; no se aprueba todavía `$0406` ni se revierte ese byte por conjetura.

### Criterio de profundidad encontrado

El punto de composición ya permite separar profundidad de identidad del sprite:

- `$80CA64-$80CA83` obtiene el resultado de proyección del DSP1 (`$6000`), calcula las coordenadas proyectadas en `$32,x` y `$34,x`, y guarda el bucket de profundidad en `$0E,x`.
- `$80BB9F-$80BBA5` ordena la lista de objetos comparando `$0E` antes de llamar a los renderizadores en `$80BB6C-$80BBB5`. Es el orden que termina alimentando los quads consecutivos en `$0490-$0500` y, después, la OAM.
- En la traza de `t_vK58`, `$14` llega como A a `$80C128`, pero identifica el tipo/variante que selecciona la ruta de render; no debe utilizarse como profundidad.
- En la parrilla, los siete rivales comparten `$0E=$000C`; P1 queda en `$0E=$000D`. El orden restante de los rivales es el de la lista (`$1100,$1200,...,$1700`) y en el state válido ya resulta monotónico en `$34`. No se debe sustituir ese orden por `$14` ni por un intercambio fijo de OAM.

Esto acota el próximo experimento a un desempate local en la lista/composición, no a `$8094A1`, `oamPriority`, cámara, escala ni raster. El criterio secundario aún debe validarse con dos frames de solapamiento antes de tocar la ROM.

### Cierre de la rama de solapamiento inicial

La comparación completa de la carrera válida (`states/state_payload.bin`, 2/10/30/60/120 frames) separa el problema que se estaba mezclando:

- Entre la ROM base fullscreen y `t_vK58.sfc` solo cambian los cuatro bytes Y de P1 en `$0271/$0275/$0279/$027D`; los grupos de rivales y sus atributos permanecen idénticos en `$0200-$041F`.
- Los rivales están en los nodos `$1100-$1700`, todos con el bucket `$0E=$000C`. Su orden de lista ya es monotónico por la coordenada proyectada `$34` (`-111,-113,...,-123` en el frame inicial), y alimenta los quads consecutivos de OAM de los slots 32, 36, 40, 44, 48, 52 y 56 (`$20,$24,...,$38` como índices hexadecimales).
- Los slots 28–31 (`$0270-$027F`) siguen siendo el quad de P1; los slots 24–27 (`$0260-$026F`) son `ROUND 1`, no un rival. No hay que intercambiar esos slots.
- La secuencia OAM inicial es coherente con la prioridad SNES: el quad con mayor Y de pantalla ocupa el índice menor y queda delante. La aparente superposición de la parrilla es geométrica por la cercanía/proyección de los karts, no una inversión de prioridad.

Se hicieron tres pruebas temporales desde `t_vK58.sfc`, sin conservar ninguna ROM:

1. invertir únicamente el desempate de igualdad: imagen y OAM idénticos;
2. desempatar por `$34` ascendente: imagen y OAM idénticos;
3. desempatar por `$34` descendente: cambia los rivales, devuelve P1 a `$46/$56` y altera toda la imagen aceptada.

Resultado: no se promueve un arreglo OAM en esta rama. Cualquier reordenamiento fijo o desempate inverso empeora la lógica de v14; la estabilidad de rivales debe conservarse como está y las colisiones quedan fuera de esta fase.

### Resultado del diagnóstico del hook `$81:82B5`

Se probó únicamente en una ROM temporal, sin modificar `roms/t_vK58.sfc`: el `JSL` de `$81:82B5` llama a `$88:8900`, el helper conserva el estado de CPU/DBR, llama al `$80BB6C` original y escribe una marca fuera del área usada por el juego.

- Con `states/state_payload.bin` y el harness sin entrada, la marca confirma una invocación por frame (1, 10, 50, 100 y 400 frames); la imagen de 400 frames es idéntica a la base.
- En el retorno del compositor, el puntero de trabajo observado fue `$3C=$0500`. El snapshot de `$0200-$03FF` todavía cambia en las rutinas posteriores de construcción OAM; por tanto, el retorno de `$80BB6C` no es todavía una prueba de que los bloques dinámicos `$0260-$02EF` estén definitivamente listos.
- Las permutaciones mínimas de 16 bytes probadas en esa ROM temporal no se promueven: las de `$04xx` no alteraron la imagen visible y las que cambiaron `$0200-$025F` afectaron datos auxiliares, no demostraron corregir la superposición de karts.
- En `states/state_2p_payload.bin` con 400 frames sin entrada, `$0D28=0` y la marca de `$81:82B5` permanece en cero: la ruta 2P no pasa por este caller. Esto impide usarlo como solución común para 1P/2P sin localizar el caller de la otra rama.

Conclusión: el hook queda validado como punto de instrumentación para la ruta 1P, pero no como solución OAM. No se conserva ninguna ROM temporal ni se altera la ROM base.

## Harness

```bash
user_upload/run_bsnes_state \
  cores/bsnes_clean.so \
  roms/t_vK58.sfc \
  states/t_vK58_payload.bin 1
```

`cores/bsnes_instr.so` añade las trazas usadas para depurar input, PPU/OAM y WRAM. Los resultados temporales del harness se escriben en `user_upload/` y pueden borrarse después de cada investigación.
