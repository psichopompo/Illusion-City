# States de prueba

- `t_vK58.state`: state RZIP suministrado por el usuario, justo antes de la meta.
- `t_vK58_payload.bin`: contenido descomprimido usado por el harness local.
- `state_payload.bin`: state/payload de carrera inicial.
- `state2_raw.state` y `state2_payload.bin`: menú de copas 50cc.
- `state_2p.state` y `state_2p_payload.bin`: carrera 2P.
- `Super Mario Kart USA Full Screen.state`: state original suministrado.

Los `.state` comprimidos son aptos para RetroArch; los `*_payload.bin` se usan con los harnesses C de `user_upload/`.
