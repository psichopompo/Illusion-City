#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <dlfcn.h>
#include "libretro.h"
#ifndef RETRO_ENVIRONMENT_SET_MESSAGE_EXT
#define RETRO_ENVIRONMENT_SET_MESSAGE_EXT 66
#endif

void retro_set_environment(retro_environment_t);
void retro_set_video_refresh(retro_video_refresh_t);
void retro_set_audio_sample(retro_audio_sample_t);
void retro_set_audio_sample_batch(retro_audio_sample_batch_t);
void retro_set_input_poll(retro_input_poll_t);
void retro_set_input_state(retro_input_state_t);
void retro_init(void); void retro_deinit(void);
bool retro_load_game(const struct retro_game_info*);
void retro_unload_game(void); void retro_run(void);
size_t retro_serialize_size(void); bool retro_unserialize(const void*, size_t);

static unsigned char *last_frame; static unsigned last_w,last_h,last_pitch; static enum retro_pixel_format pixfmt=RETRO_PIXEL_FORMAT_XRGB8888;
static bool env(unsigned cmd, void *data) {
  switch(cmd) {
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char**)data="/tmp"; return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data="/tmp"; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: pixfmt=*(enum retro_pixel_format*)data; return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: return true;
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS: return true;
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME: return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data=false; return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: { struct retro_variable *v=(struct retro_variable*)data; if(v->key && strcmp(v->key,"bsnes_ppu_fast")==0){v->value="ON"; return true;} return false; }
    case RETRO_ENVIRONMENT_GET_FASTFORWARDING: *(bool*)data=false; return true;
    case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return false;
    case RETRO_ENVIRONMENT_SET_MESSAGE: return true;
    case RETRO_ENVIRONMENT_SET_MESSAGE_EXT: return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: return false;
    default: return false;
  }
}
static void video(const void *data,unsigned w,unsigned h,size_t pitch) {
  free(last_frame); last_frame=malloc(pitch*h); memcpy(last_frame,data,pitch*h); last_w=w;last_h=h;last_pitch=pitch;
}
static void aud(int16_t l,int16_t r) {(void)l;(void)r;} static size_t audb(const int16_t *d,size_t f){(void)d;return f;}
static void poll(void){} static int16_t input(unsigned p,unsigned d,unsigned i,unsigned id){(void)p;(void)d;(void)i;(void)id;return 0;}
static void save_ppm(const char *path) {
  FILE *f=fopen(path,"wb"); if(!f)return; fprintf(f,"P6\n%u %u\n255\n",last_w,last_h);
  for(unsigned y=0;y<last_h;y++) for(unsigned x=0;x<last_w;x++) {
    unsigned char *p=last_frame+y*last_pitch+x*(pixfmt==RETRO_PIXEL_FORMAT_RGB565?2:4); unsigned r,g,b;
    if(pixfmt==RETRO_PIXEL_FORMAT_RGB565){uint16_t v=p[0]|p[1]<<8;r=((v>>11)&31)*255/31;g=((v>>5)&63)*255/63;b=(v&31)*255/31;}
    else {r=p[2];g=p[1];b=p[0];} fputc(r,f);fputc(g,f);fputc(b,f);
  } fclose(f);
}
int main(int argc,char**argv){if(argc<4){fprintf(stderr,"usage: %s core.so rom state\n",argv[0]);return 2;}
  void *h=dlopen(argv[1],RTLD_NOW); if(!h){fprintf(stderr,"dlopen %s\n",dlerror());return 3;}
  #define SYM(n) n=(typeof(n))dlsym(h,#n)
  void (*_setenv)(retro_environment_t); void (*_setvideo)(retro_video_refresh_t); void (*_setaud)(retro_audio_sample_t); void (*_setaudb)(retro_audio_sample_batch_t); void (*_setpoll)(retro_input_poll_t);void(*_setinput)(retro_input_state_t); void(*_init)(void); bool(*_load)(const struct retro_game_info*);size_t(*_ss)(void);bool(*_us)(const void*,size_t);void(*_run)(void);void(*_debug)(const char*);void(*_refresh)(void);void(*_unload)(void);void(*_deinit)(void); void*(*_memdata)(unsigned);
  _setenv=(void*)dlsym(h,"retro_set_environment");_setvideo=(void*)dlsym(h,"retro_set_video_refresh");_setaud=(void*)dlsym(h,"retro_set_audio_sample");_setaudb=(void*)dlsym(h,"retro_set_audio_sample_batch");_setpoll=(void*)dlsym(h,"retro_set_input_poll");_setinput=(void*)dlsym(h,"retro_set_input_state");_init=(void*)dlsym(h,"retro_init");_load=(void*)dlsym(h,"retro_load_game");_ss=(void*)dlsym(h,"retro_serialize_size");_us=(void*)dlsym(h,"retro_unserialize");_run=(void*)dlsym(h,"retro_run");_debug=(void*)dlsym(h,"bsnes_debug_dump");_refresh=(void*)dlsym(h,"bsnes_debug_refresh");_unload=(void*)dlsym(h,"retro_unload_game");_deinit=(void*)dlsym(h,"retro_deinit");_memdata=(void*)dlsym(h,"retro_get_memory_data");
  _setenv(env);_setvideo(video);_setaud(aud);_setaudb(audb);_setpoll(poll);_setinput(input);_init();
  FILE *rf=fopen(argv[2],"rb");fseek(rf,0,SEEK_END);long n=ftell(rf);rewind(rf);void *rom=malloc(n);fread(rom,1,n,rf);fclose(rf);
  struct retro_game_info gi={argv[2],rom,(size_t)n,NULL}; if(!_load(&gi)){fprintf(stderr,"load failed\n");return 4;}
  printf("state_size=%zu pixel=%d\n",_ss(),pixfmt);
  FILE *sf=fopen(argv[3],"rb");fseek(sf,0,SEEK_END);long sn=ftell(sf);rewind(sf);unsigned char *sp=malloc(sn);fread(sp,1,sn,sf);fclose(sf);
  if(sn<16 || memcmp(sp,"RASTATE\1",8)){fprintf(stderr,"bad wrapper\n");return 5;}
  uint32_t ln=sp[12]|sp[13]<<8|sp[14]<<16|sp[15]<<24; printf("chunk_len=%u total=%ld\n",ln,sn);
  bool ok=_us(sp+16,ln); printf("unserialize=%d\n",ok);
  if(_debug) _debug("/home/user/smk_work/user_upload/state_debug.bin"); if(_refresh) { _refresh(); save_ppm("/home/user/smk_work/user_upload/state_before.ppm"); }
  int frames=1; if(argc>4) frames=atoi(argv[4]); for(int fi=0;fi<frames;fi++) _run();
  if(_memdata){unsigned char*w=(unsigned char*)_memdata(2); if(w){FILE*f=fopen("/home/user/smk_work/user_upload/wram_dump.bin","wb"); if(f){fwrite(w,1,0x20000,f);fclose(f);} }}
  if(_debug) _debug("/home/user/smk_work/user_upload/state_debug_after.bin"); printf("frame=%ux%u pitch=%u\n",last_w,last_h,(unsigned)last_pitch); save_ppm("/home/user/smk_work/user_upload/state_core_frame.ppm");
  _unload();_deinit();return ok?0:6;
}
