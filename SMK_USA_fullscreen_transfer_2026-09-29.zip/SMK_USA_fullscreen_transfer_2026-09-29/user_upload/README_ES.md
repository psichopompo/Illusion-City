# Harness libretro

Contiene los ejecutables y fuentes C usados para cargar ROMs y states con bsnes.

Los argumentos de ROM, core y state son rutas externas; por ejemplo:

```bash
user_upload/run_bsnes_state cores/bsnes_clean.so roms/t_vK58.sfc states/t_vK58_payload.bin 1
```

Las salidas temporales se escriben aquí y se pueden borrar tras cada prueba.