# Cores bsnes

- `bsnes_clean.so`: core reproducible sin trazas.
- `bsnes_instr.so`: core instrumentado de input, PPU/OAM y WRAM, reconstruido desde bsnes `0c2fa0d`.

Ambos corresponden al mismo core bsnes y al mismo tamaño de serialización usado por RetroArch. El core instrumentado se usa solo para diagnóstico; la validación visual normal usa `bsnes_clean.so`.