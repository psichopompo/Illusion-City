#!/usr/bin/env python3
"""perf.py rom state f0 f1 [top]  -> reparto de ciclos maestros por fotograma (HIST) y fotogramas con lag (cronometro $0100 sin avanzar).
Idle del hack: 88:8900..893F (bucle de espera). En vanilla: 80:8040..807F."""
import sys, os, subprocess, shutil
from collections import defaultdict
rom, st, f0, f1 = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]); top = int(sys.argv[5]) if len(sys.argv) > 5 else 14
d = '/tmp/perf_%d' % os.getpid(); shutil.rmtree(d, True); os.makedirs(d)
env = dict(os.environ, HIST='%d,%d' % (f0, f1), WLOG='100,4')
subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(f1 + 2), '/tmp/acc.txt', d, '0'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
n = f1 - f0
h = defaultdict(lambda: [0, 0])
for l in open(d + '/hist.txt'):
    if l[0] == '#': continue
    a, k, c = l.split(); a = int(a, 16); h[a][0] += int(k); h[a][1] += int(c)
tot = sum(v[1] for v in h.values())
idle = sum(v[1] for a, v in h.items() if 0x888900 <= a < 0x888940 or 0x808040 <= a < 0x808080)
w = [x.split()[1:] for x in open(d + '/wlog.txt')]
stall = sum(1 for i in range(f0 + 1, f1 + 1) if w[i] == w[i - 1])
logic = n - stall
busy = tot - idle
print('%s f%d-%d: idle %.1f%%  busy %.0f clk/frame  | fotogramas con lag %d/%d  | trabajo por fotograma de logica %.0f' % (os.path.basename(rom), f0, f1, 100 * idle / tot, busy / n, stall, n, busy / max(logic, 1)))
g = defaultdict(lambda: [0, 0])
for a, (k, c) in h.items():
    if (a >> 16) == 0x88 and not (0x8900 <= (a & 0xFFFF) < 0x8940):
        g[a & 0xFFE0][0] += k; g[a & 0xFFE0][1] += c
print('  banco 88 sin idle: %.0f clk/frame' % (sum(v[1] for v in g.values()) / n))
for k, v in sorted(g.items(), key=lambda x: -x[1][1])[:top]:
    print('    88:%04X %7.0f clk/f %6.1f exec/f' % (k & 0xFFFF, v[1] / n, v[0] / n))
shutil.rmtree(d, True)
