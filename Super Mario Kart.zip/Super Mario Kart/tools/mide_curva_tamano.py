#!/usr/bin/env python3
"""Mide la ley TAMAÑO DIBUJADO vs FILA (y_bot) a partir de oamlog.bin.
Uso: python3 tools/mide_curva_tamano.py carpeta [carpeta2 ...]  -> imprime tabla y guarda curvas.json
Agrupa los sprites de rivales (slots 32-63) por proximidad; descarta grupos >4 sprites
o con salto de x >100 (copias por wrap)."""
import sys, statistics, json
from collections import defaultdict
FR=544
def scan(path):
    d=open(path+'/oamlog.bin','rb').read(); N=len(d)//FR; out=[]; pl=[]
    for fr in range(N):
        o=fr*FR; sp=[]
        for s in range(28,64):
            p=o+s*4; y=d[p+1]; t=d[p+2]; x=d[p]
            if s<32:
                if y<0xE0: pl.append((x,y))
                continue
            if y>=0xE0 or t==0xF0: continue
            sp.append([x,y])
        gs=[]
        for s in sp:
            for g in gs:
                if any(abs(s[0]-q[0])<=18 and abs(s[1]-q[1])<=18 for q in g): g.append(s); break
            else: gs.append([s])
        for g in gs:
            xs=[q[0] for q in g]
            if len(g)>4 or max(xs)-min(xs)>100: continue
            ys=[q[1] for q in g]
            out.append((max(ys)+16, max(ys)-min(ys)+16, max(xs)-min(xs)+16, len(g)))
    return out, pl
def curva(pts):
    b=defaultdict(list)
    for yb,h,w,n in pts:
        if n>=2: b[(yb//10)*10].append(h)
    return {k:(round(statistics.mean(v),1),len(v)) for k,v in sorted(b.items())}
if __name__=='__main__':
    res={}
    for p in sys.argv[1:]:
        pts,pl=scan(p); res[p]=curva(pts)
        from collections import Counter
        print(f"{p}: jugador cajas {Counter([( (max([q[0] for q in pl])-min([q[0] for q in pl])+16) if pl else 0, (max([q[1] for q in pl])-min([q[1] for q in pl])+16) if pl else 0)]).most_common(2)}")
    rows=sorted({k for c in res.values() for k in c})
    print("fila      "+"".join(f"{p.split('/')[-1]:>14}" for p in res))
    for r in rows:
        print(f"{r:3d}-{r+9:3d} "+"".join(f"{str(res[p].get(r,'-')):>14}" for p in res))
    json.dump({k:{str(a):b for a,b in v.items()} for k,v in res.items()}, open('/tmp/curvas.json','w'))
