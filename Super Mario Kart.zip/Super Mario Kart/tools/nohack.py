# variante de diagnostico: desactiva las puertas del hack (todo vanilla) -> uso: nohack.py in.sfc out.sfc
import sys
r=bytearray(open(sys.argv[1],'rb').read())
for pat,idx in ((bytes.fromhex('AF AA 00 7E C9 00 10'),6),(bytes.fromhex('AF AB 00 7E C9 10'),5)):
    i=0
    while True:
        i=r.find(pat,i)
        if i<0: break
        r[i+idx]=0x11; i+=len(pat)
open(sys.argv[2],'wb').write(r)
