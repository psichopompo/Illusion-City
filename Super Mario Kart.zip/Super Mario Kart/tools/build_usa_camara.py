#!/usr/bin/env python3
"""Candidato Europa: base fullscreen portada + camara de carrera mas cercana con rampa (tools/make_camera_ramp.py)
+ sprites de relleno aparcados en Y=$F0 (en PAL, Y=$E0 entra en las lineas visibles).
uso: build_eu_camara.py [salida]   (por defecto roms/eu_camara_candidato.sfc)"""
import sys, hashlib, os
DXON = False   # el desplazamiento en caliente (88:9700) se sustituye por el desplazamiento unico al inicializar (88:9D00)
SKIP = os.environ.get('SMK_SKIP', '')   # depuracion: rk,dx,hud
PRUEBA = os.environ.get('SMK_PRUEBA', '1') == '1'   # PROMOVIDO (ronda 6): por defecto HUD abajo-izq., digitos, menus, banners, platano, humo, topo, monedas. SMK_PRUEBA=0 = candidato anterior (HUD arriba)
from pathlib import Path
R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R / 'tools'))
import make_camera_ramp as m
out = Path(sys.argv[1]) if len(sys.argv) > 1 else R / 'roms' / ('usa_camara_candidato.sfc' if PRUEBA else 'usa_camara_candidato_anterior.sfc')
rom = bytearray((R / 'roms' / 'Super Mario Kart USA Full Screen.sfc').read_bytes())
assert rom[0x01BC5A] == 0x55; rom[0x01BC5A] = 0x00               # igual que el candidato t_vK58 (solo toca $0406)
# Numero de puesto en 1P (2026-10-01): el juego ya mantiene la tabla de ventanas HDMA del digito (canal 7, $7F:E500) tambien en 1P;
# el port la anulaba ($420C=$7E, $2131/$2125 a 0, $2130=$30). Se restauran: HDMAEN $FE, $2131/$2125 vanilla, $2130=$10.
assert bytes(rom[0x8AC5:0x8ACA]) == bytes.fromhex('A97E8D0C42'); rom[0x8AC6] = 0xFE
assert bytes(rom[0x8BC2:0x8BC5]) == bytes.fromhex('9C3121'); rom[0x8BC2] = 0x8D
assert bytes(rom[0x8BDA:0x8BDD]) == bytes.fromhex('9C2521'); rom[0x8BDA] = 0x8D
assert rom[0x8BE4:0x8BE6] == bytes.fromhex('A930'); rom[0x8BE5] = 0x10
# 1P tambien vanilla en $212E/$2130 (ventanas/mate. del digito; al acabar la carrera el juego los usa para el parpadeo azul/transparente)
rom[0x8BE0:0x8BE6] = bytes.fromhex('8D2E21BD7A01')
S, Rt, n = m.apply(rom, 0xACB6, 0xCEC5, 0xCEE5)                     # camara + sprite P1 (constantes vanilla + s)
# (los parches estaticos de aparcado en Y=$F0 se quitaron: el barrido de final de fotograma cubre todos los casos y solo actua en 1P)

# Sprites aparcados en Y=$E0 (vista NTSC: fuera; en PAL las lineas 224..231 si se ven -> tiras de rival/Mario/tubo abajo).
# Se reescriben en cada fotograma, asi que el barrido va al FINAL del fotograma: bucle principal `80:8056 JSL $81E067` (justo antes
# de esperar al NMI que hace la DMA del OAM) -> `JSL $88:8740`: OAM Y==$E0 -> $F0 y `JML $81E067`.
MAIN = 0x008056
assert rom[MAIN:MAIN+4] == bytes([0x22, 0x67, 0xE0, 0x81]), rom[MAIN:MAIN+4].hex()
SAN = 0x089100        # (antes 0x88740: se amplio con la subida de los coches x N)
assert set(rom[SAN:SAN+0x100]) == {0}
# Rendimiento (2026-10-01): el barrido de 128 sprites costaba ~11k ciclos de reloj maestro por vuelta del bucle (3% del fotograma NTSC;
# con las demas puertas bastaba para que una escena pesada pasara de 1 fotograma por vuelta y el juego fuese ralentizado). Ahora:
#  * Contador de coches (HUD): ocupa SIEMPRE los slots OAM 16..19 (comprobado en varios estados) y se escribe una sola vez -> solo se miran esos 4.
#  * Sombra de Mario: el juego la copia cada fotograma con `80:EC73 MVN $7F,$80` (16 bytes = 4 sprites desde el buffer `$7F:DF00..`, plantillas Y=$5F/$5C)
#    al OAM (indice $3C). Se sustituye `MVN ; STY $3C` por `JSL stub` (con gate 1P): la rutina hace el MVN y suma s a la Y de esos 4 sprites si
#    Y en $5C..$5F (igual que el antiguo barrido, pero solo cuando se dibuja la sombra).
assert bytes(rom[0xEC73:0xEC78]) == bytes.fromhex('54807F843C')
SHD = 0x089200
assert set(rom[SHD:SHD+0x60]) == {0}
shd = bytes.fromhex('54807F 843C')                    # MVN $7F,$80 ; STY $3C (Y = fin del destino)
shd += bytes.fromhex('98 38 E90F00 AA E220')          # TYA ; SEC ; SBC #15 ; TAX (X -> Y del primer sprite) ; SEP #$20  (DB=$80 tras el MVN)
for k in range(4):
    shd += bytes.fromhex('BD0000 C95C 900C C960 B008 18 6F860A7E 9D0000')   # LDA $0000,x ; CMP #$5C ; BCC +12 ; CMP #$60 ; BCS +8 ; CLC ; ADC $7E0A86 ; STA $0000,x
    shd += bytes.fromhex('E8E8E8E8')                  # 4 x INX
shd += bytes.fromhex('C220 6B')                       # REP #$20 ; RTL
rom[SHD:SHD+len(shd)] = shd
rom[0xEC73:0xEC78] = bytes([0x22, SHD & 0xFF, (SHD >> 8) & 0xFF, 0x88, 0xEA])
code_ = bytearray(); lab = {}; fix = []
def raw(h): code_.extend(bytes.fromhex(h.replace(' ', '')))
def br(op, name): code_.extend([op, 0]); fix.append((len(code_) - 1, name))
def label(name): lab[name] = len(code_)
raw('08 C2 20 A9 0003 8F BA0F00 E2 20')              # PHP REP#20 ; LDA #$0300 ; STA $0FBA (umbral de ocultar objetos por escala: 1P usa $0300 en vez del vanilla $0200,
                                                     #  asi C714/C737 ya no necesitan puerta: se leian ~8 veces por vuelta) ; SEP#20 (A se pierde: el JML $81E067 final la machaca igual)
for i in range(16, 20):
    b0 = 0x0200 + 4 * i; nx = 'n%d' % i
    raw('AF'); code_.extend((b0 + 1).to_bytes(2, 'little') + b'\x00'); raw('C9 54'); br(0xD0, nx)      # Y == $54
    raw('AF'); code_.extend((b0 + 3).to_bytes(2, 'little') + b'\x00'); raw('C9 28'); br(0xD0, nx)      # atributo $28
    raw('AF'); code_.extend((b0).to_bytes(2, 'little') + b'\x00'); raw('C9 B6'); br(0x90, nx); raw('C9 D0'); br(0xB0, nx)   # X en 182..207
    raw('A9 B3 8F'); code_.extend((b0 + 1).to_bytes(2, 'little') + b'\x00')                            # Y = $B3 (9 filas sobre las monedas, Y=$BC)
    label(nx)
if PRUEBA and 'hud' not in SKIP: raw('20 0099')                              # JSR $9800 (PRUEBA: contadores abajo a la izquierda)
raw('20 0094')                                       # JSR $9400 (tabla LAP TIME centrada en Y, ver mas abajo)
raw('28 5C67E081')                                   # PLP JML $81E067
for pos, name in fix:
    d = lab[name] - (pos + 1); assert -128 <= d <= 127, (name, d); code_[pos] = d & 0xFF
san = bytes(code_)
assert len(san) < 0x100, len(san)
rom[SAN:SAN+len(san)] = san
# Final de carrera (1P): la tabla "LAP TIME" (sprites OAM 28..102, atributo $29, Y 21..97) y la lista de los 4 primeros puestos de la
# izquierda (caras: sprites 0..7, Y 39/56/73/90 con atributo $3D en los slots impares) estan pensadas para la mitad superior. Se bajan
# LAPDY lineas (15 + 5 + 5 = 25; v1.1: el usuario pidio 5 px mas; ojo con el numero de puesto GRANDE).
#  * Tabla: se detecta con el slot 28 (tile $80, atr $29, Y==$15 = sin desplazar; asi tampoco se suma dos veces si el juego no reescribe
#    el OAM en esa vuelta) y se suma LAPDY a la Y de los slots 28..102 con atr $29 y Y<$A0.
#  * Caras: el juego escribe sus Y una sola vez (no cada fotograma): se detecta slot1 tile $40 + atr $3D (visibles; en carrera estan
#    ocultas con atr $33) y slot0 Y==$27 (sin desplazar) y se escriben las 4 Y finales (absolutas: 39,56,73,90 + LAPDY).
LAPDY = 25
LP = 0x089400
lp = bytes.fromhex('E2 20 C2 10')                                     # SEP #$20 ; REP #$10
lp += bytes.fromhex('AF 06 02 7E C9 40 D0 38  AF 07 02 7E C9 3D D0 30  AF 01 02 7E C9 27 D0 28')   # slot1 tile $40, atr $3D, slot0 Y $27 (si no -> tabla)
for k, y0 in enumerate((39, 56, 73, 90)):
    lp += bytes([0xA9, y0 + LAPDY]) + bytes.fromhex('8F') + (0x201 + 8*k).to_bytes(2, 'little') + b'\x7E' + bytes.fromhex('8F') + (0x205 + 8*k).to_bytes(2, 'little') + b'\x7E'
FACES = len(lp)
lp += bytes.fromhex('AF 72 02 7E C9 80 D0 33  AF 73 02 7E C9 29 D0 2B  AF 71 02 7E C9 15 D0 23')   # slot28: tile $80, atr $29, Y $15 (si no, RTS)
lp += bytes.fromhex('A2 7000')                                        # LDX #$0070 (offset OAM del slot 28)
lp += bytes.fromhex('BF 03 02 7E C9 29 D0 0F  BF 01 02 7E C9 A0 B0 07 18 69') + bytes([LAPDY]) + bytes.fromhex('9F 01 02 7E')
lp += bytes.fromhex('E8 E8 E8 E8 E0 9C01 D0 E0 60')                   # 4xINX ; CPX #$019C (slot 103) ; BNE bucle ; RTS
assert len(lp) == 128 and set(rom[LP:LP+0x90]) == {0}, len(lp)
rom[LP:LP+len(lp)] = lp
rom[MAIN:MAIN+4] = bytes([0x22, SAN & 0xFF, (SAN >> 8) & 0xFF, 0x88])
# Digito de puesto en 1P (canal 7 HDMA indirecto, ventanas + mates. de color; lo mantiene el propio juego, tambien la animacion de
# cambio de puesto). Vanilla 1P: tabla en $7F:E500 = 36+44 lineas en blanco, digito (lineas 80..99) y despues punteros a $E528 (ventana
# completa: aclara toda la parte baja del 1P vanilla). Aqui, tras `JSL $84EBDC` (que reescribe la tabla en cada fotograma), se copia
# su cabecera (4 tramos) a un buffer `$7E:0AC0` precedida de un tramo en blanco de $60 lineas (digito en 176..195, junto al HUD
# inferior) y cerrada con fin de tabla; y se apunta el canal 7 ($4372/3/4) al buffer.
DIG = 0x0887A0
dg = bytes.fromhex('C2 10 DA')
# Digito de puesto: dos tamanos. Pequeno (normal, junto a los contadores) = 80 lineas en blanco + 20 de digito -> debe quedar en el sitio
# original (prefijo $60). Grande (animacion al cambiar de puesto y permanente al terminar) = 41 en blanco + 64 de digito -> 16 lineas mas
# arriba (prefijo $50, para que no pise los contadores). La rutina `88:9500` mide las lineas en blanco B previas al digito (suma de los
# tramos no repetidos de la tabla copiada) y escribe el prefijo $50 + tabla[B-41] (16*(B-41)/39 redondeado): interpola la subida durante la animacion.
DIGBASE = 0x70 if PRUEBA else 0x50
dg += bytes([0xA9, 0x24, 0x8F, 0xC1, 0x0A, 0x7E, 0xA9, 0xE5, 0x8F, 0xC2, 0x0A, 0x7E])    # puntero del primer tramo -> $E524 (ventana vacia); el contador ($0AC0) lo pone 88:9500
dg += bytes.fromhex('A2 0000 BF 00E57F 9F C30A7E E8 E0 0C00 D0 F2')
dg += bytes.fromhex('A9 00 8F CF0A7E')
dg += bytes.fromhex('20 00 95')
if PRUEBA and DXON: dg += bytes.fromhex('20 00 97')                          # JSR $9700 (PRUEBA: alinea el digito pequeno con el GRANDE en X)                                      # JSR $9500 (prefijo en blanco segun el tamano del digito)
for reg, val in ((0x4372, 0xC0), (0x4373, 0x0A), (0x4374, 0x7E)):
    dg += bytes([0xA9, val, 0x8F, reg & 255, reg >> 8, 0x00])
dg += bytes.fromhex('20 00 90 FA 60')                                  # JSR $9000 (copia x=0 -> x=1) ; PLX ; RTS
assert set(rom[DIG:DIG+len(dg)]) == {0}, len(dg)
assert len(dg) <= 0x48, len(dg)
rom[DIG:DIG+len(dg)] = dg
# $88:9000 (X=16 bit, A=8 bit): en 1P el digito vive en la region "x=1" del IRQ (lineas > 102), pero el juego anima los colores de
# la region superior (x=0: $016A,$016C,$016E,$0170,$0108,$014E,$017A). Se copian a los huecos x=1 ($016B..$0171,$0109,$014F,$017B)
# justo despues de que el juego los actualice (`JSL $84EBDC`) -> el digito usa en todo momento los colores y mezcla del original.
CP = 0x089000
cp = bytes.fromhex('A2 0000 BF 6A017E 9F 6B017E E8 E8 E0 0800 D0 F1'
                   ' AF 08017E 8F 09017E AF 4E017E 8F 4F017E AF 7A017E 8F 7B017E 60')
assert not any(rom[CP:CP+len(cp)])
rom[CP:CP+len(cp)] = cp

# --- 88:9500: prefijo en blanco del digito (ver arriba) + tabla 88:9600 ---
DR = 0x089500; DT = 0x089600
tab = bytes(round(2 * (39 - i) / 39) for i in range(40)) if PRUEBA else bytes(round(i * 16 / 39) for i in range(40))   # PRUEBA: pequeno y GRANDE terminan en la misma linea (prefijo $70..$72: borde inferior en la fila 211 = 7 px sobre la franja negra inferior, como vanilla)
b = bytearray(); L = {}; F = []
def e(h): b.extend(bytes.fromhex(h.replace(' ', '')))
def lb(n): L[n] = len(b)
def bj(op, n): b.extend([op, 0]); F.append((len(b) - 1, n))
e('C2 30 A2 0000 A0 0000'); lb('loop')
e('BF C30A7E 29 FF00'); bj(0xF0, 'done'); e('C9 8000'); bj(0xB0, 'done')
e('48 98 18 63 01 A8 68 E8 E8 E8 E0 0C00'); bj(0x90, 'loop')
lb('done'); e('98 38 E9 2900 B0 03 A9 0000 C9 2800 90 03 A9 2700 AA E2 20')
e('BF') ; b.extend((DT & 0xFFFF).to_bytes(2, 'little') + bytes([0x88]))
e('18 69'); b.append(DIGBASE); e('8F C00A7E 60')
for pos, n in F:
    d = L[n] - (pos + 1); assert -128 <= d <= 127, (n, d); b[pos] = d & 0xFF
assert not any(rom[DR:DR+len(b)]) and not any(rom[DT:DT+len(tab)])
rom[DR:DR+len(b)] = b; rom[DT:DT+len(tab)] = tab

if PRUEBA:
    sys.path.insert(0, str(R / 'tools'))
    from asm65816_min import asm
    # --- 88:9700: desplaza en X los datos de ventana HDMA del digito, en sitio (tramos repetidos de $7E:0AC3.., datos $7F:P).
    # Linea = 4 bytes W1L,W1R,W2L,W2R. Se desplaza byte a byte solo las ventanas NO vacias (L<=R).
    # Marca "ya desplazado": primera linea con ventana 2 vacia -> (W2L,W2R)=($FF,$FE). Si el juego regenera los datos la marca desaparece.
    # DX por tramo: puntero < $E800 (digito pequeno) -> DXS ; si no (GRANDE) -> DXG.  Scratch $7E:0A90 fin, 0A92 marca, 0A94 P, 0A96 tramo, 0A98 DX.
    DXG = 0
    DXS = -8
    fastseg = ''
    for S in (0, 3, 6, 9):
        fastseg += f"""
        SEP #$20
        LDA $7E{0x0AC3 + S:04X}
        BNE c{S}
        JMP done
    c{S}:
        BPL nx{S}
        REP #$20
        LDA $7E{0x0AC4 + S:04X}
        TAX
        LDA $7F0002,x
        CMP #$FEFF
        BEQ nx{S}
        LDA #${S:04X}
        STA $7E0A96
        JSR slow
    nx{S}:"""
    DBGC = "        LDA $7E0A9A\n        CLC\n        ADC #$0001\n        STA $7E0A9A\n" if os.environ.get("SMK_DBG") else ""
    dx = asm(f"""
        PHP
        REP #$10
    {fastseg}
    done:
        PLP
        RTS
    slow:
        REP #$30
        LDA $7E0A96
        TAX
        LDA $7E0AC3,x
        AND #$007F
        ASL
        ASL
        STA $7E0A90
        LDA $7E0AC4,x
        STA $7E0A94
        CLC
        ADC $7E0A90
        STA $7E0A90
        LDA $7E0A94
        TAX
    find:
        SEP #$20
        LDA $7F0002,x
        CMP $7F0003,x
        BEQ nxt
        BCS found
    nxt:
        REP #$20
        INX
        INX
        INX
        INX
        TXA
        CMP $7E0A90
        BCC find
        RTS
    found:
        LDA $7F0002,x
        CMP #$FF
        BNE ok
        LDA $7F0003,x
        CMP #$FE
        BNE ok
        RTS
    ok:
        REP #$20
{DBGC}        TXA
        STA $7E0A92
        LDA $7E0A94
        CMP #$E800
        SEP #$20
        BCC small
        JMP mark
    small:
        LDA #${DXS & 0xFF:02X}
    setdx:
        STA $7E0A98
        REP #$20
        LDA $7E0A94
        TAX
        SEP #$20
    shift:
        LDA $7F0000,x
        CMP $7F0001,x
        BCC a1
        BNE w2
        CLC
    a1:
        ADC $7E0A98
        STA $7F0000,x
        LDA $7F0001,x
        CLC
        ADC $7E0A98
        STA $7F0001,x
    w2:
        LDA $7F0002,x
        CMP $7F0003,x
        BCC a2
        BNE nx
        CLC
    a2:
        ADC $7E0A98
        STA $7F0002,x
        LDA $7F0003,x
        CLC
        ADC $7E0A98
        STA $7F0003,x
    nx:
        INX
        INX
        INX
        INX
        REP #$20
        TXA
        CMP $7E0A90
        SEP #$20
        BCC shift
    mark:
        REP #$20
        LDA $7E0A92
        TAX
        SEP #$20
        LDA #$FF
        STA $7F0002,x
        LDA #$FE
        STA $7F0003,x
        RTS
    """, 0x9700)
    DXA = 0x089700
    if DXON:
        assert not any(rom[DXA:DXA+len(dx)]), 'DX ocupado'; rom[DXA:DXA+len(dx)] = dx
    # --- 88:9900: contadores (OAM 16..19 coches, 20..23 monedas) abajo a la izquierda, valores absolutos por frame.
    # Margen visible: izquierdo 15 px (el icono del coche empieza 4 px dentro de su sprite), inferior 8 px.
    HX = 11 ; HY = 196        # sprite del coche (X, Y); monedas: X+8, Y+9. Abajo a la izquierda: margen izq. 15, borde inferior visible en la fila 211 (margen inf. 7 sobre la franja negra, como vanilla)
    def seq(slot0, xs0, y):
        t = ''
        for k in range(4):
            t += f"LDA #${xs0 + 8 * k:02X}\n STA $7E{0x200 + 4 * (slot0 + k):04X}\n"
        return t
    hx = asm(f"""
        PHP
        SEP #$20
        LDA $7E0242
        CMP #$5E
        BNE coins
        LDA $7E0243
        CMP #$28
        BNE coins
        {seq(16, HX, HY)}
        LDA #${HY:02X}
        STA $7E0241
        STA $7E0245
        STA $7E0249
        STA $7E024D
    coins:
        LDA $7E0252
        CMP #$80
        BNE cn2
        LDA $7E0259
        CMP #$BC
        BNE cn2
        LDA $7E0258
        CMP #$80
        BNE cn2
        LDA $7E025A
        CMP #$A7
        BNE cn2
        LDA #$F0
        STA $7E0251
        STA $7E0255
        STA $7E0259
        STA $7E025D
        BRA fin
    cn2:
        LDA $7E0252
        CMP #$4F
        BNE fin
        LDA $7E0253
        CMP #$28
        BNE fin
        {seq(20, HX + 8, HY + 9)}
        LDA #${HY + 9:02X}
        STA $7E0251
        STA $7E0255
        STA $7E0259
        STA $7E025D
    fin:
        PLP
        RTS
    """)
    HXA = 0x089900
    assert not any(rom[HXA:HXA+len(hx)]), 'HUD ocupado'; rom[HXA:HXA+len(hx)] = hx
    # --- RANKED OUT (1P): el juego hace caer las letras por el borde inferior y reaparecen por arriba (la Y da la vuelta a 8 bits).
    # En vanilla la parte inferior del 1P (mapa) las tapa; a pantalla completa se veian abajo. Gancho en 81:B0B0 (final de la rutina de objetos
    # 81:B066, justo antes del RTS): en 1P las letras (tiles $E6..$F7) con Y inferior en 100..223 se aparcan en Y=$F0.
    RKA = 0x089E00
    # Banners de texto (1P): Ranked Out sube 5 px y se aparca lo que queda abajo; ROUND N (+56) y GAME OVER (+48) se centran en Y.
    # Se pasa por 81:B0B0 (cola del escritor de sprites de objeto, X = direccion WRAM del par de sprites).
    def _shift(n, tag, lim=0xE0):
        return f"""
        LDA $7E0001,x
        CMP #$F0
        BCC {tag}c1
        CLC
        ADC #${n:02X}
        STA $7E0001,x
        BRA {tag}f
    {tag}c1:
        CMP #$E0
        BCS {tag}f
        CLC
        ADC #${n:02X}
        BCS {tag}h
        CMP #${lim:02X}
        BCS {tag}h
        STA $7E0001,x
        BRA {tag}f
    {tag}h:
        LDA #$F0
        STA $7E0001,x
    {tag}f:
        LDA $7E0005,x
        CMP #$F0
        BCC {tag}c2
        CLC
        ADC #${n:02X}
        STA $7E0005,x
        JMP norm
    {tag}c2:
        CMP #$E0
        BCS {tag}g
        CLC
        ADC #${n:02X}
        BCS {tag}i
        CMP #${lim:02X}
        BCS {tag}i
        STA $7E0005,x
        JMP norm
    {tag}i:
        LDA #$F0
        STA $7E0005,x
    {tag}g:
        JMP norm
        """
    rk = asm("""
        LDA $7E0002,x
        CMP #$10
        BCS rkr
        LDA $7E0003,x
        CMP #$39
        BEQ rk1
        JMP norm
    rk1:
        REP #$20
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        SEP #$20
        BEQ rk2
        JMP norm
    rk2:
        CPX #$0260
        BCS rk3
        JMP norm
    rk3:
        CPX #$0270
        BCS rk4
        JMP rnd
    rk4:
        CPX #$02F0
        BCS rk6
        JMP gov
    rk6:
        JMP norm
    rkr:
        CMP #$E6
        BCC norm
        CMP #$F8
        BCS norm
        REP #$20
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        SEP #$20
        BNE norm
        LDA $7E0001,x
        CMP #$E0
        BCS rs2
        CMP #$64
        BCC rr1
        LDA #$F0
        STA $7E0001,x
        BRA rs2
    rr1:
        SEC
        SBC #$05
        STA $7E0001,x
    rs2:
        LDA $7E0005,x
        CMP #$E0
        BCS norm
        CMP #$64
        BCC rr2
        LDA #$F0
        STA $7E0005,x
        BRA norm
    rr2:
        SEC
        SBC #$05
        STA $7E0005,x
    norm:
        REP #$21
        TXA
        ADC #$0008
        STA.d $3C
        JML $81B0B8
    rnd:
""" + _shift(0x38, 'r') + """
    gov:
""" + _shift(0x30, 'g', 0xC0), 0x9E00)
    assert len(rk) < 0x200, len(rk)
    assert not any(rom[RKA:RKA+len(rk)]), 'RK ocupado'; rom[RKA:RKA+len(rk)] = rk
    assert bytes(rom[0x1B0B0:0x1B0B9]) == bytes.fromhex('C221 8A 690800 853C 60'), rom[0x1B0B0:0x1B0B9].hex()
    if 'rk' not in SKIP: rom[0x1B0B0:0x1B0B4] = bytes([0x5C, RKA & 0xFF, (RKA >> 8) & 0xFF, 0x88])        # JML $88:9A00 (el resto del original se reproduce en el stub)
    # Menu RETRY / END (81:A883): pensado para la mitad superior (Y=$30..$40). Debajo de RANKED OUT (Y 84..99) con la misma separacion
    # (12 px) que habia por encima: +64 en Y; y 25 px a la izquierda. (Menu solo de 1P: en 2P no hay RETRY.)
    # Menu RETRY/END tras retirarse: el juego oscurece la imagen con la tabla del canal 7 ($7F:E500, tramos con ventana $E528). En este modo
    # no corre nuestro gancho del manejador de carrera, asi que el canal 7 seguia apuntando a nuestro buffer del digito (obsoleto) y el fondo
    # quedaba claro. El gancho de `81:A883` (se ejecuta cada fotograma que se dibuja el menu) devuelve el canal 7 a la tabla vanilla y copia
    # los colores (x=0 -> x=1), pero solo en 1P y si la tabla NO es la del digito (primer tramo con puntero $E524).
    MKA = 0x089B80
    mk = asm("""
        PHP
        REP #$20
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        BNE van
        SEP #$20
        LDA $7FE501
        CMP #$24
        BEQ out
        REP #$10
        PHX
        LDA #$00
        STA $004372
        LDA #$E5
        STA $004373
        LDA #$7F
        STA $004374
        JSR $9000
        PLX
    out:
        PLP
        LDA #$6857
        LDY #$AD35
        RTL
    van:
        PLP
        LDA #$3070
        LDY #$AD35
        RTL
    """, 0x9B80)
    assert not any(rom[MKA:MKA+len(mk)]); rom[MKA:MKA+len(mk)] = mk
    assert bytes(rom[0x1A883:0x1A889]) == bytes.fromhex('A97030 A035AD'), rom[0x1A883:0x1A889].hex()
    rom[0x1A883:0x1A889] = bytes([0x22, MKA & 0xFF, (MKA >> 8) & 0xFF, 0x88, 0xEA, 0xEA])
    # `84:EDB3` pone los valores "claros" (ventanas/mates. de color) de la region y=1 en cada fotograma del modo retirada: pisaba la copia
    # x=0 -> x=1 y el tramo inferior (region x=1) quedaba sin oscurecer. Se sustituye por un stub que hace lo mismo y, en 1P, copia x=0 -> x=1.
    MKB = 0x089BC0
    orig = bytes.fromhex('E220A9A0990801A910994E01A930997A01C220' '60')
    assert bytes(rom[0x4EDB3:0x4EDB3+len(orig)]) == orig, rom[0x4EDB3:0x4EDC7].hex()
    mkb_head = bytes.fromhex('08 E220 A9A0 990801 A910 994E01 A930 997A01 C220')
    mkb = mkb_head + asm("""
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        BNE out
        SEP #$20
        LDA $7E0A9E
        BNE clr
        REP #$10
        PHX
        JSR $9000
        PLX
        JMP out
    clr:
        LDA #$00
        STA $7E0A9E
    out:
        PLP
        REP #$20
        RTL
    """, 0x9BC0 + len(mkb_head))
    assert not any(rom[MKB:MKB+len(mkb)]); rom[MKB:MKB+len(mkb)] = mkb
    rom[0x4EDB3:0x4EDB3+len(orig)] = bytes([0x22, MKB & 0xFF, (MKB >> 8) & 0xFF, 0x88, 0x60]) + bytes([0xEA]) * (len(orig) - 5)
    # Monedas (uso del objeto / perdidas): `85:E6F3` las dibuja con Y de pantalla relativa a la posicion vanilla del coche (Y=70..): en 1P el
    # coche esta 88 px mas abajo, asi que se suma ese desplazamiento al origen (el recorrido, la caida y el reparto no cambian).
    MKC = 0x089C00
    assert bytes(rom[0x5E700:0x5E704]) == bytes.fromhex('65BA9500')
    mkc = bytes.fromhex('65BA 18 6F9C0A7E 9500 6B')   # ADC $BA; CLC; ADC $7E0A9C (LARGO: el DBR no es $7E/$00 en todas las llamadas); STA $00,x  ($0A9C = $5800 en 1P, 0 si no: lo fija 88:9B00 una vez por fotograma)
    assert not any(rom[MKC:MKC+len(mkc)]); rom[MKC:MKC+len(mkc)] = mkc
    rom[0x5E700:0x5E704] = bytes([0x22, MKC & 0xFF, (MKC >> 8) & 0xFF, 0x88])
    # Menu "GIVE UP? / YES / NO" (START en carrera): vanilla lo dibuja arriba (Y=$20; selector Y=$40/$50). En 1P se baja 40 px (+$28).
    # `81:A28F` (texto) y `81:A2A3` (selector, via JMP $AA63): ganchos que suman $2800 solo si $7E:00AA == $1000 (1P).
    MKD = 0x089C40; MKE = 0x089C80
    assert bytes(rom[0x1A28F:0x1A295]) == bytes.fromhex('A96020 A003AD'), rom[0x1A28F:0x1A295].hex()
    assert bytes(rom[0x1A2A3:0x1A2A9]) == bytes.fromhex('A02FAD 4C63AA'), rom[0x1A2A3:0x1A2A9].hex()
    mkd = asm("""
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        BNE no
        LDA #$4860
        JMP fin
    no:
        LDA #$2060
    fin:
        LDY #$AD03
        RTL
    """, 0x9C40)
    mke = asm("""
        PHA
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        BNE no
        PLA
        CLC
        ADC #$2800
        JMP fin
    no:
        PLA
    fin:
        LDY #$AD2F
        JML $81AA63
    """, 0x9C80)
    assert not any(rom[MKD:MKD+len(mkd)]) and not any(rom[MKE:MKE+len(mke)])
    rom[MKD:MKD+len(mkd)] = mkd; rom[MKE:MKE+len(mke)] = mke
    rom[0x1A28F:0x1A295] = bytes([0x22, MKD & 0xFF, (MKD >> 8) & 0xFF, 0x88, 0xEA, 0xEA])
    rom[0x1A2A3:0x1A2A9] = bytes([0x5C, MKE & 0xFF, (MKE >> 8) & 0xFF, 0x88, 0xEA, 0xEA])
    # Opcion C (usuario): el digito PEQUENO se desplaza -8 px en X (GRANDE no se mueve). Los datos de ventana de los 8 digitos pequenos
    # (8 x 20 lineas x 4 bytes = $7F:E580..E7FF) los descomprime el juego UNA vez al iniciar (`84:EA17`: JSL $84E09E en `84:EA23`) y despues
    # son estaticos. Se desplazan aqui, justo tras la descompresion (coste unico fuera de la carrera): cada ventana no vacia (L<=R) -8.
    # Solo en 1P ($7E:00AA == $1000). Sustituye al desplazamiento en caliente de 88:9700 (que costaba 1 fotograma la primera vez que salia cada cifra).
    SHA = 0x089D00
    shs = asm("""
        PHP
        REP #$30
        PHA
        PHX
        JSR $8F00
        BNE fin
        SEP #$20
        LDX #$E580
    lin:
        LDA $7F0000,x
        CMP $7F0001,x
        BCC a1
        BNE w2
        CLC
    a1:
        ADC #$F8
        STA $7F0000,x
        LDA $7F0001,x
        CLC
        ADC #$F8
        STA $7F0001,x
    w2:
        LDA $7F0002,x
        CMP $7F0003,x
        BCC b1
        BNE nx
        CLC
    b1:
        ADC #$F8
        STA $7F0002,x
        LDA $7F0003,x
        CLC
        ADC #$F8
        STA $7F0003,x
    nx:
        INX
        INX
        INX
        INX
        CPX #$E800
        BNE lin
    fin:
        REP #$30
        PLX
        PLA
        PLP
        RTL
    """, 0x9D00 + 4)
    shs = bytes([0x22, 0x9E, 0xE0, 0x84]) + shs          # JSL $84E09E (descompresion original) + desplazamiento
    assert not any(rom[SHA:SHA+len(shs)]); rom[SHA:SHA+len(shs)] = shs
    assert bytes(rom[0x4EA23:0x4EA27]) == bytes([0x22, 0x9E, 0xE0, 0x84]), rom[0x4EA23:0x4EA27].hex()
    if 'sh' not in SKIP: rom[0x4EA23:0x4EA27] = bytes([0x22, SHA & 0xFF, (SHA >> 8) & 0xFF, 0x88])
    if os.environ.get('SMK_TESTSH'):   # solo pruebas con states anteriores: aplicar el desplazamiento una vez al cargar (el state no pasa por el inicio)
        pass
    # ROUND N (1P): el texto lo escribe una sola vez la rutina de sprites `80:C096` (lista de entradas x,y,tile,attr; OAM $0260..$026F = slots 24..27,
    # tile<$10, attr $39). Se intercepta el almacenamiento de Y (`80:C0B3`: LDA $0001,y / CLC / ADC $01 / STA $01,x) y se suma 56 px (centrado en 224 lineas).
    ROA = 0x089F80
    ro = bytearray()
    def emit(*b): ro.extend(b)
    emit(0xB9,0x01,0x00, 0x18, 0x65,0x01, 0x95,0x01)            # original
    fix = []
    def br(op):
        emit(op, 0); fix.append(len(ro)-1)
    emit(0xE0,0x60,0x02); br(0x90)                               # CPX #$0260 ; BCC out
    emit(0xE0,0x70,0x02); br(0xB0)                               # CPX #$0270 ; BCS out
    emit(0xC2,0x20, 0x20,0x00,0x8F, 0xEA,0xEA,0xEA,0xEA, 0xE2,0x20); br(0xD0)   # solo 1P
    emit(0xB5,0x01, 0x18, 0x69,0x38, 0xB0,0x02, 0x95,0x01)       # Y += 56 (si no hay acarreo)
    for f in fix: ro[f] = len(ro) - (f + 1)
    emit(0x6B)
    ro = bytes(ro)
    assert not any(rom[ROA:ROA+len(ro)]); rom[ROA:ROA+len(ro)] = ro
    assert bytes(rom[0xC0B3:0xC0BB]) == bytes.fromhex('B9010018650195 01'.replace(' ','')), rom[0xC0B3:0xC0BB].hex()
    if 'ro' not in SKIP: rom[0xC0B3:0xC0BB] = bytes([0x22, ROA & 0xFF, (ROA >> 8) & 0xFF, 0x88, 0xEA, 0xEA, 0xEA, 0xEA])
    # Platano (1P): se suelta/arrastra a menos distancia detras del kart (vanilla LDY #$0800 antes de JSL $80FE52 en 80:F3F0 y 80:F475).
    # Con la camara cercana del 1P el platano a 8 unidades caia bajo el borde inferior de la pantalla; a 5.5 unidades se ve junto al kart
    # (a 4 el propio kart lo toca y pierde monedas). Las llamadas pasan por un puente que solo cambia Y en 1P; en 2P el codigo es el de vanilla.
    BAN = int(os.environ.get('SMK_BAN', '0x0580'), 16)
    BNA = 0x089FC0
    bn = bytes([0x48, 0x20,0x00,0x8F, 0xEA,0xEA,0xEA,0xEA, 0xD0,0x03, 0xA0,BAN & 0xFF,BAN >> 8, 0x68, 0x5C,0x52,0xFE,0x80])
    assert not any(rom[BNA:BNA+len(bn)]); rom[BNA:BNA+len(bn)] = bn
    for a_ in (0xF3F0, 0xF475):
        assert bytes(rom[a_:a_+4]) == bytes([0x22, 0x52, 0xFE, 0x80]), rom[a_:a_+4].hex()
        if 'ban' not in SKIP: rom[a_:a_+4] = bytes([0x22, BNA & 0xFF, (BNA >> 8) & 0xFF, 0x88])
    # Humo/chispas del aplastamiento (1P): el kart cuadrado/aplastado se dibuja en `80:D9A1` con `JSR $DEB9` (4 pares de sprites cuya Y = tabla + $BA,
    # con $BA = origen del jugador, 0 para P1). El kart del 1P esta 88 px mas abajo ($7E:0A86) y el humo salia a la altura de vanilla.
    # Copia de `80:DEB9` en bank 88 con la Y sumada a ($BA + s<<8) solo en 1P; se llama con JSL desde `80:D9BD` (TAY ; JSR $DEB9).
    SMA = 0x08A000
    sm = bytearray()
    def emit2(*b): sm.extend(b)
    emit2(0xA8, 0xDA)                                    # TAY ; PHX
    emit2(0xA5,0xBA, 0x8F,0x9A,0x0A,0x7E)                # LDA $BA ; STA $7E0A9A
    emit2(0x20,0x00,0x8F, 0xEA,0xEA,0xEA,0xEA, 0xD0,0x0F) # LDA $7E00AA ; CMP #$1000 ; BNE +15
    emit2(0xAF,0x86,0x0A,0x7E, 0x29,0xFF,0x00, 0xEB, 0x18, 0x65,0xBA, 0x8F,0x9A,0x0A,0x7E)  # LDA s ; AND #$FF ; XBA ; CLC ; ADC $BA ; STA $7E0A9A
    emit2(0xA6,0x3C)                                     # LDX $3C
    for k in range(4):
        emit2(0xB9, 4*k, 0x00)                           # LDA $004k,y   (posicion X/Y)
        emit2(0x18, 0x6F,0x9A,0x0A,0x7E)                 # CLC ; ADC $7E0A9A
        emit2(0x95, 4*k)                                 # STA $4k,x
        emit2(0xB9, 4*k+2, 0x00, 0x95, 4*k+2)            # LDA tile/attr ; STA $4k+2,x
    emit2(0x8A, 0x18, 0x69,0x10,0x00, 0x85,0x3C)         # TXA ; CLC ; ADC #$0010 ; STA $3C
    emit2(0x8A, 0x4A,0x4A,0x4A,0x4A, 0x65,0xCC, 0xAA)    # TXA ; LSR x4 ; ADC $CC ; TAX
    emit2(0xA9,0xAA,0x00, 0x95,0x00)                     # LDA #$00AA ; STA $00,x
    emit2(0xFA, 0x6B)                                    # PLX ; RTL
    sm = bytes(sm)
    assert len(sm) < 0x100
    assert not any(rom[SMA:SMA+len(sm)]); rom[SMA:SMA+len(sm)] = sm
    assert bytes(rom[0xD9BD:0xD9C1]) == bytes([0xA8, 0x20, 0xB9, 0xDE]), rom[0xD9BD:0xD9C1].hex()
    if 'sm' not in SKIP: rom[0xD9BD:0xD9C1] = bytes([0x22, SMA & 0xFF, (SMA >> 8) & 0xFF, 0x88])
    # Topo pegado (80:FD6C, overlay del mole en pantalla): Y = tabla+$58+$BB; en 1P hay que sumar s ($7E:0A86) como al humo.
    MOA = 0x08A100
    mo = bytes([0x65,0xBB, 0x48, 0xAF,0xAB,0x00,0x7E, 0xC9,0x10, 0xD0,0x08, 0x68, 0x18, 0x6F,0x86,0x0A,0x7E, 0x80,0x01, 0x68, 0x85,0x1E, 0x6B])
    assert bytes(rom[0xFD88:0xFD8C]) == bytes([0x65,0xBB,0x85,0x1E])
    assert not any(rom[MOA:MOA+len(mo)]); rom[MOA:MOA+len(mo)] = mo
    if 'mo' not in SKIP: rom[0xFD88:0xFD8C] = bytes([0x22, MOA & 0xFF, (MOA >> 8) & 0xFF, 0x88])
    for a_, old_, new_ in ((0x1A88C, 0x3060, 0x6847), (0x1A894, 0x4060, 0x7847), (0x1A8CD, 0x2C9C, 0x6483)):
        assert rom[a_] == 0xA9 and int.from_bytes(rom[a_+1:a_+3], 'little') == old_, hex(a_)
        rom[a_+1:a_+3] = new_.to_bytes(2, 'little')
    print('prueba: digito dx', len(dx), 'bytes; hud', len(hx), 'bytes')
# El manejador de carrera (80:806E) llama a JSL $84EBDC, que REESCRIBE la tabla cada fotograma justo tras el NMI (antes del HDMA del
# fotograma siguiente): por eso el parche se aplica justo despues de esa llamada: JSL $88:87E8 = JSL $84EBDC + parche.
W = 0x0887E8
DGJ = 0x87A0 if not PRUEBA else 0x9B00
if PRUEBA:
    # Tras retirarse (RETRY/END) vanilla oscurece la imagen con la tabla HDMA del canal 7 en $7F:E500 (tramos con ventana completa $E528).
    # Nuestro buffer del digito solo vale para la tabla del digito (primer tramo con puntero $E524): si no lo es, se deja la tabla vanilla.
    van = asm("""
        REP #$20
        JSR $8F00
        NOP
        NOP
        NOP
        NOP
        BNE k0
        LDA #$5800
        JMP kset
    k0:
        LDA #$0000
    kset:
        STA $7E0A9C
        SEP #$20
        LDA #$01
        STA $7E0A9E
        LDA $7FE501
        CMP #$24
        BNE van
        JMP $87A0
    van:
        REP #$10
        LDA #$00
        STA $004372
        LDA #$E5
        STA $004373
        LDA #$7F
        STA $004374
        JMP $9000
    """, 0x9B00)
    assert not any(rom[0x089B00:0x089B00+len(van)]); rom[0x089B00:0x089B00+len(van)] = van
NEG = os.environ.get('SMK_NEG')   # experimento: niega las entradas [a,b) de las tablas de matriz Mode 7 (A,B,C,D) en cada NMI
if NEG:
    na, nb = (int(v) for v in NEG.split(','))
    NS = 0x08A200
    st = bytearray([0x08, 0xC2, 0x30, 0xDA, 0xA2, (2*na) & 255, (2*na) >> 8])           # PHP ; REP #$30 ; PHX ; LDX #2a
    loop = len(st)
    for base in (0x4540, 0xD540, 0x6A00, 0xA540):
        st += bytes([0xBF, base & 255, base >> 8, 0x7E, 0x49, 0xFF, 0xFF, 0x1A, 0x9F, base & 255, base >> 8, 0x7E])   # LDA $7E:base,x ; EOR #$FFFF ; INC ; STA $7E:base,x
    st += bytes([0xE8, 0xE8, 0xE0, (2*nb) & 255, (2*nb) >> 8])                          # INX INX ; CPX #2b
    off = loop - (len(st) + 2)
    st += bytes([0x90, off & 255])                                                       # BCC loop
    st += bytes([0xFA, 0x28, 0x20, DGJ & 255, DGJ >> 8, 0x60])                           # PLX ; PLP ; JSR DGJ ; RTS
    assert not any(rom[NS:NS+len(st)]); rom[NS:NS+len(st)] = st
    DGJ = NS & 0xFFFF
POKE = os.environ.get('SMK_POKE')   # experimento: escribe bytes fijos en WRAM en cada NMI (formato addr:hex)
if POKE:
    pa, ph = POKE.split(':'); pa = int(pa, 16); pb = bytes.fromhex(ph)
    NS = 0x08A300
    st = bytearray([0x08, 0xE2, 0x20])
    for i, b in enumerate(pb):
        st += bytes([0xA9, b, 0x8F, (pa+i) & 255, (pa+i) >> 8, 0x7E])
    st += bytes([0x28, 0x20, DGJ & 255, DGJ >> 8, 0x60])
    assert not any(rom[NS:NS+len(st)]); rom[NS:NS+len(st)] = st
    DGJ = NS & 0xFFFF
SEL = os.environ.get('SMK_SEL')   # variante aparte: Select cicla 0 nada -> 1 retrovisor -> 2 (reservado mapa); flag en 7E:08A0
FLAG = 0x7E7000
if SEL:
    F = FLAG & 0xFFFF; T = F + 2
    def lng(op, a): return bytes([op, a & 255, (a >> 8) & 255, 0x7E])
    base = 0x08A400
    fold = bytes([0x29, 0xFF, 0x00, 0xC9, 0x80, 0x00, 0x90, 0x03, 0x49, 0xFF, 0x00, 0x60])                     # AND #$FF ; CMP #$80 ; BCC +3 ; EOR #$FF ; RTS
    mul = lng(0x8F, T) + bytes([0x0A, 0x18]) + lng(0x6F, T) + bytes([0x0A]*6 + [0x60])                      # v*3*64 = v*192
    assert not any(rom[base:base+len(fold)+len(mul)]); rom[base:base+len(fold)] = fold; rom[base+len(fold):base+len(fold)+len(mul)] = mul
    FOLD = base & 0xFFFF; MUL = (base + len(fold)) & 0xFFFF
    NS = 0x08A440
    jsr = lambda a: bytes([0x20, a & 255, a >> 8])
    items = [bytes([0x08, 0xC2, 0x30, 0xDA, 0x5A, 0xE2, 0x20])]                     # PHP ; REP #$30 ; PHX ; PHY ; SEP #$20
    def banks(vals):
        r = b''
        for ch, v in zip((0x4317, 0x4327, 0x4337, 0x4347), vals): r += bytes([0xA9, v, 0x8F, ch & 255, ch >> 8, 0x00, 0x00][:6])
        return r
    # solo actua con el hack de carrera activo (7E:00AA==$1000 -> byte 00AB=$10); fuera de carrera es transparente
    items += [lng(0xAF, 0x00AB), bytes([0xC9, 0x10, 0xF0, 0x03]), ('jmp', 'out')]
    items += [jsr(0xAC00), banks((0xC9, 0xCA, 0xC9, 0xCA)), bytes([0xC2, 0x20]), lng(0xAF, F), bytes([0xC9, 0x02, 0x00, 0xD0, 0x03]), ('jmp', 'rear'),
              bytes([0xC9, 0x01, 0x00, 0xF0, 0x03]), ('jmp', 'out')]
    # MAPA en el panel superior: tablas propias A/D (perspectiva mas plana), N lineas; el resto del segmento 1 sigue siendo P1
    envf = lambda k, d: float(os.environ.get(k, d))
    PN = int(envf('SMK_PN', 52)); R0 = envf('SMK_R0', 40); TY0 = envf('SMK_TY0', 0); TY1 = envf('SMK_TY1', 1016); AN = envf('SMK_AN', 4.0)
    FOFF = int(os.environ.get('SMK_FOFF', 0))
    assert 8 <= PN <= 95
    items += [('jmp', 'mapa')]

    items += [('label', 'rear')]
    items += [lng(0xAF, 0x0094), bytes([0x18, 0x69, 0x00, 0x80, 0xEB, 0x29, 0xFF, 0x00]), lng(0x8F, T+2)]
    items += [jsr(FOLD), jsr(MUL), lng(0x8F, T+4)]
    items += [lng(0xAF, T+2), bytes([0x18, 0x69, 0x40, 0x00]), jsr(FOLD), jsr(MUL), lng(0x8F, T+6)]
    items += [lng(0xAF, T+2), bytes([0x38, 0xE9, 0x40, 0x00]), jsr(FOLD), jsr(MUL), lng(0x8F, T+8)]
    for src, dsts in ((T+4, (0x0644, 0x066B)), (T+6, (0x0651,)), (T+8, (0x065E,))):
        items += [lng(0xAF, src)] + [lng(0x8F, d) for d in dsts] + [bytes([0x18, 0x69, 0x00, 0x80])] + [lng(0x8F, d + 3) for d in dsts]
    items += [('label', 'out'), bytes([0x7A, 0xFA, 0x28]), jsr(DGJ), bytes([0x60])]
    # ensamblar con etiquetas (saltos JMP abs de 3 bytes; el BEQ/BNE saltan 3 = sobre un JMP)
    pos = {'mapa': 0xAA00}; p = NS
    for it in items:
        if isinstance(it, tuple):
            if it[0] == 'label': pos[it[1]] = p
            else: p += 3
        else: p += len(it)
    st = bytearray()
    for it in items:
        if isinstance(it, tuple):
            if it[0] == 'jmp': st += bytes([0x4C, pos[it[1]] & 255, (pos[it[1]] >> 8) & 255])
        else: st += it
    assert not any(rom[NS:NS+len(st)]); rom[NS:NS+len(st)] = st
    # --- codigo del mapa (88:AA00) y tablas A/D generadas ---
    import struct as _st
    K = (TY1 - TY0) * R0 * (R0 + PN) / PN
    wa, wd = [], []
    for r in range(PN):
        A = AN * (R0 + PN) / (R0 + r)
        T = TY1 - K * (1 / (R0 + r) - 1 / (R0 + PN))
        D = (T - 512) / (r + 64)
        wa.append(int(round(A * 256)) & 0xFFFF); wd.append(int(round(D * 256)) & 0xFFFF)
    for bank, w in ((0x090000, wa), (0x0A0000, wd)):
        assert not any(rom[bank+0xE000:bank+0xE200]); rom[bank+0xE000:bank+0xE000+2*PN] = _st.pack('<%dH' % PN, *w)
    MZ = 0xE100
    # restauracion (88:AB00, JSR desde la pila del Select): si la tabla HDMA esta marcada como nuestra (ptr1 con bit15) se devuelven punteros\n    # originales desde las sombras (7E:08C0..) y los contadores normales; FA9D solo reescribe los punteros cuando cambia el angulo.
    SH = lambda c, k: 0x7020 + 4 * c + 2 * k
    rs = bytes([0xC2, 0x20])
    for c in range(4):
        b0 = 0x0640 + 13 * c
        rs += lng(0xAF, b0 + 4) + bytes([0x10, 16]) + lng(0xAF, SH(c, 0)) + lng(0x8F, b0 + 4) + lng(0xAF, SH(c, 1)) + lng(0x8F, b0 + 7)
    rs += bytes([0xE2, 0x20])
    for c in range(4):
        b0 = 0x0640 + 13 * c
        for off, v in ((3, 0xE0), (6, 0xE0), (9, 0x00)):
            rs += bytes([0xA9, v]) + lng(0x8F, b0 + off)
    rs += bytes([0x60])
    assert not any(rom[0x08AC00:0x08AC00+len(rs)]); rom[0x08AC00:0x08AC00+len(rs)] = rs
    mp = b''
    for c, tab in enumerate((0xE000, MZ, MZ, 0xE000)):
        b0 = 0x0640 + 13 * c
        mp += lng(0xAF, b0 + 4) + lng(0x8F, SH(c, 0)) + lng(0xAF, b0 + 7) + lng(0x8F, SH(c, 1))
        mp += lng(0xAF, b0 + 4) + bytes([0x18, 0x69, (2*PN + FOFF) & 255, ((2*PN + FOFF) >> 8) & 255, 0xA8]) + lng(0xAF, b0 + 7) + bytes([0xAA])      # Y = ptr1 + 2N ; X = ptr2
        mp += bytes([0xA9, tab & 255, tab >> 8]) + lng(0x8F, b0 + 4) + bytes([0x98]) + lng(0x8F, b0 + 7) + bytes([0x8A]) + lng(0x8F, b0 + 10)
    mp += bytes([0xE2, 0x20])
    for c in range(4):
        b0 = 0x0640 + 13 * c
        for off, v in ((3, 0x80 | PN), (6, 0x80 | (96 - PN)), (9, 0xE0), (12, 0x00)):
            mp += bytes([0xA9, v]) + lng(0x8F, b0 + off)
    mp += bytes([0xC2, 0x20, 0x4C, pos['out'] & 255, (pos['out'] >> 8) & 255])
    assert not any(rom[0x08AA00:0x08AA00+len(mp)]); rom[0x08AA00:0x08AA00+len(mp)] = mp
    DGJ = NS & 0xFFFF
    # Select/X: en vez de alternar $0174 (6<->2) cicla el flag; $0174 se queda en 6
    SS = 0x08A600
    ss = bytes([0x08, 0xC2, 0x30]) + lng(0xAF, F) + bytes([0x1A, 0xC9, 0x03, 0x00, 0x90, 0x03, 0xA9, 0x00, 0x00]) + lng(0x8F, F) \
        + bytes([0xA9, 0x06, 0x00, 0x8F, 0x74, 0x01, 0x7E, 0x28, 0x6B])
    assert not any(rom[SS:SS+len(ss)]); rom[SS:SS+len(ss)] = ss
    assert bytes(rom[0x9F41:0x9F53]) == bytes.fromhex('B5A4C9020 0F005A9020080 03A9060 08D7401'.replace(' ', '')), bytes(rom[0x9F41:0x9F53]).hex()
    rom[0x9F41:0x9F53] = bytes([0x22, SS & 255, (SS >> 8) & 255, 0x88]) + bytes([0xEA] * 14)
wr = bytes.fromhex('22C0EC84') + bytes.fromhex('08 C2 20 48 E2 20 20') + DGJ.to_bytes(2, 'little') + bytes.fromhex('C2 20 68 28 6B')
assert set(rom[W:W+len(wr)]) == {0}; rom[W:W+len(wr)] = wr
assert bytes(rom[0x806E:0x8072]) == bytes.fromhex('22C0EC84'); rom[0x806E:0x8072] = bytes([0x22, 0xE8, 0x87, 0x88])
# 1P: Select/X alternaban $0174 entre 6 y 2 (mapa/retrovisor del original). Con $0174=2 la pausa/"GIVE UP?" deja la mitad inferior
# (aqui la carrera) en el fundido a negro del modo $10. Se fija $0174=6 en la rama 1P (80:9F48: LDA #$0002 -> LDA #$0006).
if not SEL:
    assert bytes(rom[0x9F48:0x9F4D]) == bytes.fromhex('A902008003'); rom[0x9F49] = 0x06
import subprocess, tempfile
tmp = Path(tempfile.gettempdir()) / '_usa_sin_gate.sfc'
tmp.write_bytes(rom)
subprocess.run([sys.executable, str(R / 'tools' / 'gate2p_usa.py'), str(tmp), str(out)], check=True, stdout=subprocess.DEVNULL)
rom = bytearray(out.read_bytes())
if SEL:
    def put(off, data):
        assert not any(rom[off:off+len(data)]), hex(off); rom[off:off+len(data)] = data
    fl = lng(0xAF, F)
    # NMI: 80:86FD (carga X=0 y $A4) -> en modo mapa usa los registros de la vista 4 (X=4, $A6) para la parte alta
    wr_ = lambda reg: bytes([0x8F, reg & 255, reg >> 8, 0x00])
    m = bytes([0xA9, 0xC0]) + wr_(0x2110) + bytes([0xA9, 0x00]) + wr_(0x2110)
    for val, reg in ((384, 0x210D), (512 + 64 - 24, 0x210E), (512, 0x211F), (512, 0x2120)):      # Mode 7 propio del mapa (CX=CY=512, y_eff = r+64)
        m += bytes([0xA9, val & 255]) + wr_(reg) + bytes([0xA9, val >> 8]) + wr_(reg)
    m += bytes([0xA9, 0x00]) + wr_(0x210F) + wr_(0x210F)
    for dp, reg in ((0x64, 0x2111), (0x6A, 0x2112), (0x70, 0x2113), (0x76, 0x2114)):      # BG2/BG3 de P1 (vista 0)
        m += bytes([0xA5, dp]) + wr_(reg) + bytes([0xA5, dp+1]) + wr_(reg)
    m += bytes([0xA2, 0x00, 0x68, 0x68, 0x5C, 0xE3, 0x8A, 0x80])      # X=0 como el original (8BBF indexa con X)
    nor = bytes([0xA2, 0x00, 0xA5, 0xA4, 0x5C, 0x01, 0x87, 0x80])
    gate = lng(0xAF, 0x00AB) + bytes([0xC9, 0x10, 0xF0, 0x06, 0xA9, 0x00]) + lng(0x8F, F)      # fuera de carrera: flag = 0
    nadr = 0xA900 + len(gate) + len(fl) + 7 + len(m)
    put(0x08A900, gate + fl + bytes([0xC9, 0x01, 0xF0, 0x03, 0x4C, nadr & 255, nadr >> 8]) + m + nor)
    assert bytes(rom[0x86FD:0x8701]) == bytes.fromhex('A200A5A4'); rom[0x86FD:0x8701] = bytes([0x5C, 0x00, 0xA9, 0x88])
    # IRQ de corte (88:88DE): en modo mapa restablece los registros de P1 (X=0) para la parte baja
    m7 = b''
    for dp, reg in ((0x50, 0x210D), (0x56, 0x210E), (0x5C, 0x211F), (0x62, 0x2120)):      # M7 de P1 (vista 4) para la parte baja
        m7 += bytes([0xA5, dp]) + wr_(reg) + bytes([0xA5, dp+1]) + wr_(reg)
    put(0x08A830, fl + bytes([0xC9, 0x01, 0xD0, 0x0E + len(m7)]) + m7 + bytes([0xA9, 0x01, 0x48, 0xF4, 0x6C, 0x8B, 0xA2, 0x00, 0xA5, 0xA4, 0x5C, 0x01, 0x87, 0x80,
                              0xA5, 0xAB, 0xC9, 0x10, 0xF0, 0x04, 0x5C, 0xE4, 0x88, 0x88, 0x5C, 0xEE, 0x88, 0x88]))
    assert bytes(rom[0x0888DE:0x0888E4]) == bytes.fromhex('A5ABC910F00A'); rom[0x0888DE:0x0888E4] = bytes([0x5C, 0x30, 0xA8, 0x88, 0xEA, 0xEA])
    # lineas de los IRQ: 107 -> 119 y 114 -> 126 solo en modo mapa (la parte alta ocupa las lineas 24..119 del segmento 1)
    put(0x08AD00, fl + bytes([0xC9, 0x01, 0xF0, 0x04, 0xA9, 0x6B, 0x80, 0x02, 0xA9, 24 + PN - 1, 0x8D, 0x09, 0x42, 0x5C, 0x36, 0x8B, 0x80]))      # termina en JML 80:8B36 (RTS original), no en RTS
    assert bytes(rom[0x8B31:0x8B36]) == bytes.fromhex('A96B8D0942'); rom[0x8B31:0x8B36] = bytes([0x5C, 0x00, 0xAD, 0x88, 0xEA])
    put(0x08AD20, fl + bytes([0xC9, 0x01, 0xF0, 0x04, 0xA9, 0x72, 0x80, 0x02, 0xA9, int(os.environ.get("SMK_V2", max(0x72, 24 + PN + 6))), 0x8D, 0x09, 0x42, 0x6B]))
    put(0x08AD40, fl + bytes([0xC9, 0x01, 0xF0, 0x04, 0xA9, 0x6B, 0x80, 0x02, 0xA9, 24 + PN - 1, 0x8D, 0x09, 0x42, 0x6B]))
    assert bytes(rom[0x8BAF:0x8BB4]) == bytes.fromhex('A96B8D0942'); rom[0x8BAF:0x8BB4] = bytes([0x22, 0x40, 0xAD, 0x88, 0xEA])      # el IRQ de fin de cuadro fija V=107 para el cuadro siguiente
    assert bytes(rom[0x8B48:0x8B4D]) == bytes.fromhex('A9728D0942'); rom[0x8B48:0x8B4D] = bytes([0x22, 0x20, 0xAD, 0x88, 0xEA])
out.write_bytes(rom)
print(out, hashlib.sha256(out.read_bytes()).hexdigest())   # candidato final: hack solo en 1P (gate2p.py), vanilla en 2P
