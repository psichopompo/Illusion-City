import sys
from collections import Counter
f=sys.argv[1]; frames=int(sys.argv[2]) if len(sys.argv)>2 else 400
h={}
for l in open(f):
    if l[0]=='#': continue
    a,n,c=l.split(); h[int(a,16)]=(int(n),int(c))
tot=sum(c for n,c in h.values())
print('clk/frame',tot/frames,'(NTSC 357368)')
idle=sum(c for a,(n,c) in h.items() if a in (0x888913,0x888915))
print('idle %.1f%%'%(100*idle/tot), 'busy clk/frame', (tot-idle)/frames)
r=Counter()
for a,(n,c) in h.items(): r[a&0xFFFFC0]+=c
for k,v in r.most_common(int(sys.argv[3]) if len(sys.argv)>3 else 30): print('%06x %6.0f clk/frame %.1f%%'%(k,v/frames,100*v/tot))
bk=Counter()
for a,(n,c) in h.items(): bk[a>>16]+=c
print({hex(k):round(100*v/tot,1) for k,v in bk.items()})
