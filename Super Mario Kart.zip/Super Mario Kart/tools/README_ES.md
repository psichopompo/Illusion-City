# Herramientas

**Cadena de construcción** (`bash tools/reconstruir_release.sh`):
`build_usa_camara.py` (usa `make_camera_ramp.py`, `gate2p_usa.py`, `asm65816_min.py`) → `add_signature.py` (+ `firma_psicopompo.png`) → `lakitu_sombra.py` → `ranked_borde.py` → `hud_coin_y.py`.
`make_patches.py clean.sfc parcheada.sfc base_salida` genera `.ips` y `.bps` y los comprueba (también expone `apply_ips`/`apply_bps`).

**Pruebas** (necesitan `/tmp/drive`: `bash tools/env_rapido.sh`):
- `cmp.py` (`run(rom, state, n, script, tag)` → carpeta con `fNNNN.ppm`), `sheet.py`, `sheet2.py` (hojas de contacto; `ld(dir, frame)`), `mont.py`, `oamseq.py` (entradas OAM por fotograma), `lag.sh` (fotogramas con lag), `rzip_to_payload.py` (`.state` RZIP → payload), `zscan.py`, `histrep.py`, `diffoam.py`, `nohack.py`.
- `dis65816.py` (desensamblador), `core_patch.py` / `core_patch_prof.py` (reconstruyen los cores instrumentados), `trace_tools.py`, `setup_tmp.sh`.

Entrada del arnés (`/tmp/acc.txt`): líneas `inicio fin botón` (id libretro: 0=B acelerar, 6=izq., 7=der., 8=A…). `0 5000 0` = mantener B.

## mide_tuberias.py
Mide el recuadro (bbox) de las tuberías verdes fotograma a fotograma en capturas PPM, para
comprobar si el decorado del Mode-7 escala de forma monótona.
Uso: `python3 tools/mide_tuberias.py <dir_ppms> [--every N] [--min-px N] [--csv salida.csv]`

## offset_sprites.py
Ajusta la tabla de offset vertical de sprites del banco $88 (`$88:8480`) que la hack suma a la Y
de todos los sprites vía `$7E:0A86`. Con `72` se corrige el desajuste medido de ~16 px respecto a
la calzada.
Uso: `python3 tools/offset_sprites.py in.sfc out.sfc 72`

## setup_cores.sh
Descarga los cores (snes9x y bsnes) del buildbot de libretro y compila el harness
(`harness/drive.c` + `harness/libretro_vfs.h`, imprescindible para bsnes).
Uso: `bash tools/setup_cores.sh [/tmp]`
