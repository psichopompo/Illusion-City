#!/bin/bash
# Reconstruye el core bsnes INSTRUMENTADO (WRAM + VRAM + trazas) en /tmp.
# El parche añade: bsnes_wram_data/size, bsnes_vram_data/size (VRAM del PPU "fast"),
# ring de PCs y micro-traza de escrituras a WRAM.
# Uso:  bash tools/build_instrumented.sh [/tmp]
set -e
DEST="${1:-/tmp}"
ROOT_ABS="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$DEST/bsnes_src"

if [ ! -d "$SRC/.git" ]; then
  rm -rf "$SRC"
  git clone --quiet https://github.com/bsnes-emu/bsnes.git "$SRC"
fi
cd "$SRC"
git checkout --quiet 0c2fa0d

# --- parches base (WRAM export + ring de PCs + micro-traza) ---
python3 "$ROOT_ABS/tools/core_patch.py" "$SRC"
python3 "$ROOT_ABS/tools/core_patch_prof.py" "$SRC"

# --- parche VRAM (ppufast) ---
python3 - "$SRC" <<'PY'
import sys
root = sys.argv[1]
p = f'{root}/bsnes/sfc/ppu/ppu.hpp'
s = open(p).read()
if 'smkVramPointer' not in s:
    old = '  auto power(bool reset) -> void;'
    assert old in s
    s = s.replace(old, old + '\n  auto smkVramPointer() -> uint8* { return (uint8*)vram.data; }', 1)
    open(p, 'w').write(s)

p = f'{root}/bsnes/sfc/memory/memory.cpp'
s = open(p).read()
if 'bsnes_vram_data' not in s:
    s += ('\nextern "C" __attribute__((visibility("default"))) uint8* bsnes_vram_data(void) '
          '{ return (uint8*)SuperFamicom::ppufast.vram; }\n'
          'extern "C" __attribute__((visibility("default"))) unsigned bsnes_vram_size(void) { return 65536; }\n')
    open(p, 'w').write(s)

p = f'{root}/bsnes/target-libretro/libretro.cpp'
s = open(p).read()
if 'bsnes_vram_data' not in s:
    s = s.replace('extern "C" unsigned bsnes_wram_size(void);',
                  'extern "C" unsigned bsnes_wram_size(void);\n'
                  'extern "C" uint8* bsnes_vram_data(void);\n'
                  'extern "C" unsigned bsnes_vram_size(void);', 1)
    s = s.replace('\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_data();\n\treturn nullptr;',
                  '\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_data();\n'
                  '\tif (id == RETRO_MEMORY_VIDEO_RAM) return bsnes_vram_data();\n\treturn nullptr;', 1)
    s = s.replace('\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_size();\n\treturn 0;',
                  '\tif (id == RETRO_MEMORY_SYSTEM_RAM) return bsnes_wram_size();\n'
                  '\tif (id == RETRO_MEMORY_VIDEO_RAM) return bsnes_vram_size();\n\treturn 0;', 1)
    open(p, 'w').write(s)
print('parche VRAM aplicado')
PY

cd "$SRC/bsnes"
make target=libretro -j"$(nproc)" 2>&1 | grep -E "error|Error" | head -5 || true
ls -la "$SRC/bsnes/out/bsnes_libretro.so"
echo "core instrumentado: $SRC/bsnes/out/bsnes_libretro.so"
