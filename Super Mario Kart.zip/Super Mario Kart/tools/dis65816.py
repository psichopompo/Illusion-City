#!/usr/bin/env python3
"""Desensamblador minimo de 65816 (subconjunto usado por SMK). 
Uso: dis65816.py <rom> <bank>:<addr> [n_bytes]"""
import sys
from pathlib import Path
OPS={
 0x00:('BRK','i'),0x01:('ORA','(dp,x)'),0x05:('ORA','dp'),0x06:('ASL','dp'),0x08:('PHP','i'),
 0x09:('ORA','#'),0x0A:('ASL','a'),0x0D:('ORA','abs'),0x0E:('ASL','abs'),
 0x10:('BPL','r'),0x11:('ORA','(dp),y'),0x15:('ORA','dp,x'),0x16:('ASL','dp,x'),0x18:('CLC','i'),0x19:('ORA','abs,y'),0x1A:('INC','a'),0x1D:('ORA','abs,x'),0x1E:('ASL','abs,x'),
 0x20:('JSR','abs'),0x21:('AND','(dp,x)'),0x24:('BIT','dp'),0x25:('AND','dp'),0x26:('ROL','dp'),0x28:('PLP','i'),
 0x29:('AND','#'),0x2A:('ROL','a'),0x2C:('BIT','abs'),0x2D:('AND','abs'),0x2E:('ROL','abs'),
 0x30:('BMI','r'),0x31:('AND','(dp),y'),0x35:('AND','dp,x'),0x36:('ROL','dp,x'),0x38:('SEC','i'),0x39:('AND','abs,y'),0x3A:('DEC','a'),0x3D:('AND','abs,x'),0x3E:('ROL','abs,x'),
 0x40:('RTI','i'),0x41:('EOR','(dp,x)'),0x45:('EOR','dp'),0x46:('LSR','dp'),0x48:('PHA','i'),0x49:('EOR','#'),0x4A:('LSR','a'),
 0x4C:('JMP','abs'),0x4D:('EOR','abs'),0x4E:('LSR','abs'),0x50:('BVC','r'),0x51:('EOR','(dp),y'),0x55:('EOR','dp,x'),0x56:('LSR','dp,x'),0x58:('CLI','i'),0x59:('EOR','abs,y'),0x5A:('PHY','i'),0x5D:('EOR','abs,x'),0x5E:('LSR','abs,x'),
 0x60:('RTS','i'),0x61:('ADC','(dp,x)'),0x64:('STZ','dp'),0x65:('ADC','dp'),0x66:('ROR','dp'),0x68:('PLA','i'),0x69:('ADC','#'),
 0x6A:('ROR','a'),0x6B:('RTL','i'),0x6C:('JMP','(abs)'),0x6D:('ADC','abs'),0x6E:('ROR','abs'),0x70:('BVS','r'),0x71:('ADC','(dp),y'),0x74:('STZ','dp,x'),0x75:('ADC','dp,x'),0x76:('ROR','dp,x'),0x78:('SEI','i'),0x79:('ADC','abs,y'),0x7A:('PLY','i'),0x7C:('JMP','(abs,x)'),0x7D:('ADC','abs,x'),0x7E:('ROR','abs,x'),
 0x80:('BRA','r'),0x81:('STA','(dp,x)'),0x84:('STY','dp'),0x85:('STA','dp'),0x86:('STX','dp'),0x88:('DEY','i'),0x89:('BIT','#'),0x8A:('TXA','i'),0x8C:('STY','abs'),0x8D:('STA','abs'),0x8E:('STX','abs'),
 0x90:('BCC','r'),0x91:('STA','(dp),y'),0x94:('STY','dp,x'),0x95:('STA','dp,x'),0x96:('STX','dp,y'),0x98:('TYA','i'),0x99:('STA','abs,y'),0x9A:('TXS','i'),0x9B:('TXY','i'),0x9C:('STZ','abs'),0x9D:('STA','abs,x'),0x9E:('STZ','abs,x'),0x9F:('STA','abs,x'),
 0xA0:('LDY','#'),0xA1:('LDA','(dp,x)'),0xA2:('LDX','#'),0xA4:('LDY','dp'),0xA5:('LDA','dp'),0xA6:('LDX','dp'),0xA8:('TAY','i'),0xA9:('LDA','#'),0xAA:('TAX','i'),0xAB:('PLB','i'),0xAC:('LDY','abs'),0xAD:('LDA','abs'),0xAE:('LDX','abs'),
 0xB0:('BCS','r'),0xB1:('LDA','(dp),y'),0xB4:('LDY','dp,x'),0xB5:('LDA','dp,x'),0xB6:('LDX','dp,y'),0xB8:('CLV','i'),0xB9:('LDA','abs,y'),0xBA:('TSX','i'),0xBB:('TYX','i'),0xBC:('LDY','abs,x'),0xBD:('LDA','abs,x'),0xBE:('LDX','abs,y'),
 0xC0:('CPY','#'),0xC1:('CMP','(dp,x)'),0xC2:('REP','#'),0xC4:('CPY','dp'),0xC5:('CMP','dp'),0xC6:('DEC','dp'),0xC8:('INY','i'),0xC9:('CMP','#'),0xCA:('DEX','i'),0xCB:('WAI','i'),0xCC:('CPY','abs'),0xCD:('CMP','abs'),0xCE:('DEC','abs'),
 0xD0:('BNE','r'),0xD1:('CMP','(dp),y'),0xD5:('CMP','dp,x'),0xD6:('DEC','dp,x'),0xD8:('CLD','i'),0xD9:('CMP','abs,y'),0xDA:('PHX','i'),0xDB:('STP','i'),0xDD:('CMP','abs,x'),0xDE:('DEC','abs,x'),
 0xE0:('CPX','#'),0xE1:('SBC','(dp,x)'),0xE2:('SEP','#'),0xE4:('CPX','dp'),0xE5:('SBC','dp'),0xE6:('INC','dp'),0xE8:('INX','i'),0xE9:('SBC','#'),0xEA:('NOP','i'),0xEB:('XBA','i'),0xEC:('CPX','abs'),0xED:('SBC','abs'),0xEE:('INC','abs'),
 0xF0:('BEQ','r'),0xF1:('SBC','(dp),y'),0xF5:('SBC','dp,x'),0xF6:('INC','dp,x'),0xF8:('SED','i'),0xF9:('SBC','abs,y'),0xFA:('PLX','i'),0xFD:('SBC','abs,x'),0xFE:('INC','abs,x'),
}

LEN={'i':1,'#':None,'dp':2,'dp,x':2,'dp,y':2,'(dp,x)':2,'(dp),y':2,'abs':3,'abs,x':3,'abs,y':3,'(abs)':3,'(abs,x)':3,'a':1,'r':2}
OPS.update({
 0x0F:('ORA','long'),0x1F:('ORA','long,x'),0x2F:('ROL','long'),0x3F:('AND','long,x'),
 0x4F:('EOR','long'),0x5F:('EOR','long,x'),0x6F:('ROR','long'),0x7F:('ADC','long,x'),
 0x8F:('STA','long'),0x9F:('STA','long,x'),0xAF:('LDA','long'),0xBF:('LDA','long,x'),
 0xCF:('CMP','long'),0xDF:('CMP','long,x'),0xEF:('SBC','long'),0xFF:('SBC','long,x'),
 0x22:('JSL','long'),0x5C:('JML','long'),0xFC:('JSR','(abs,x)'),0x0B:('PHD','i'),0x2B:('PLD','i'),
 0x42:('MVP','i'),0x44:('MVP','i'),0x54:('MVN','i'),0xDC:('JML','(abs)'),
 0x07:('ORA','[dp]'),0x17:('ORA','[dp],y'),0x27:('AND','[dp]'),0x37:('AND','[dp],y'),
 0x47:('EOR','[dp]'),0x57:('EOR','[dp],y'),0x67:('ADC','[dp]'),0x77:('ADC','[dp],y'),
 0x87:('STA','[dp]'),0x97:('STA','[dp],y'),0xA7:('LDA','[dp]'),0xB7:('LDA','[dp],y'),
 0xC7:('CMP','[dp]'),0xD7:('CMP','[dp],y'),0xE7:('SBC','[dp]'),0xF7:('SBC','[dp],y'),
 0x13:('ORA','(dp,s),y'),0x03:('ORA','dp,s'),0x23:('AND','dp,s'),0x33:('AND','(dp,s),y'),
 0x43:('EOR','dp,s'),0x53:('EOR','(dp,s),y'),0x63:('ADC','dp,s'),0x73:('ADC','(dp,s),y'),
 0x83:('STA','dp,s'),0x93:('STA','(dp,s),y'),0xA3:('LDA','dp,s'),0xB3:('LDA','(dp,s),y'),
 0xC3:('CMP','dp,s'),0xD3:('CMP','(dp,s),y'),0xE3:('SBC','dp,s'),0xF3:('SBC','(dp,s),y'),
})
LEN.update({'long':4,'long,x':4,'[dp]':2,'[dp],y':2,'dp,s':2,'(dp,s),y':2,'(abs,x)':3})


def dis(rom,bank,addr,n):
    fo=(bank-0x80)*0x10000+addr
    out=[]; i=0
    while i<n:
        a=addr+i; op=rom[fo+i]
        if op not in OPS:
            out.append(f'${bank:02X}:{a:04X}  db ${op:02X}'); i+=1; continue
        name,mode=OPS[op]
        ln=LEN[mode] if mode!='#' else (3 if False else 2)
        # longitud variable: # es 2 en 8-bit, 3 en 16-bit -> asumimos 16 (REP #$20) salvo M=1
        raw=rom[fo+i:fo+i+ln]
        if mode=='#':
            ln=3 if len(raw)>=3 else len(raw)
            raw=rom[fo+i:fo+i+ln]
            val=raw[1]|(raw[2]<<8) if ln==3 else raw[1]
            arg=f'#${val:04X}' if ln==3 else f'#${val:02X}'
        elif mode=='i': arg=''; ln=1
        elif mode=='a': arg=''
        elif mode=='r':
            off=raw[1]; off=off-256 if off>127 else off
            arg=f'${(a+2+off)&0xFFFF:04X}'
        elif mode=='#': arg=''
        elif mode in ('long','long,x'):
            arg=f'${raw[3]:02X}{raw[2]:02X}{raw[1]:02X}' + (',x' if mode.endswith(',x') else '')
        else:
            if ln==2: arg=f'${raw[1]:02X}'
            elif ln==3: arg=f'${raw[2]:02X}{raw[1]:02X}'
        out.append(f'${bank:02X}:{a:04X}  {name} {arg}'.rstrip())
        i+=ln
    return out
if __name__=='__main__':
    rom=Path(sys.argv[1]).read_bytes()
    bank,addr=sys.argv[2].split(':'); bank=int(bank,16); addr=int(addr,16)
    n=int(sys.argv[3],16) if len(sys.argv)>3 else 0x60
    for l in dis(rom,bank,addr,n): print(l)
