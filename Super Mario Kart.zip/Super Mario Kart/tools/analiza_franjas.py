#!/usr/bin/env python3
"""Mide por fotograma, para cada kart: escala $06, escala de dibujo $18, separacion (dx,dy)
de sus 4 sprites, posicion Y en pantalla y tamano del arte renderizado.
Uso: analiza_franjas.py <dir_captura> [--csv salida.csv]"""
import sys, os, re

def dec(vram, tno, base=0x8000):
    off=base+32*tno
    px=[[0]*8 for _ in range(8)]
    for r in range(8):
        p=[vram[off+r*2+1], vram[off+r*2], vram[off+16+r*2+1], vram[off+16+r*2]]
        for k in range(8):
            b=7-k
            px[r][k]=((p[0]>>b)&1)|(((p[1]>>b)&1)<<1)|(((p[2]>>b)&1)<<2)|(((p[3]>>b)&1)<<3)
    return px

def measure(vram, low, high, base, sr=0x8000):
    slots=[]
    for i in range(base,base+4):
        k=i*4
        x,y,t,a=low[k],low[k+1],low[k+2],low[k+3]
        hb=(high[i>>2]>>((i&3)*2))&3
        x|=(hb&1)<<8; big=(hb>>1)&1
        slots.append((x,y,t,a,big))
    if any(s[1]>=232 for s in slots): return None
    x0=min(s[0] for s in slots); y0=min(s[1] for s in slots)
    dx=abs(slots[1][0]-slots[0][0]); dy=abs(slots[2][1]-slots[1][1])
    C=112; OFF=40; cv=[[0]*C for _ in range(C)]
    for (x,y,t,a,big) in slots:
        n=2 if big else 1
        for ty in range(n):
            for tx in range(n):
                px=dec(vram,(t+(ty*16 if big else 0)+tx)&0x1FF,sr)
                if (a>>6)&1: px=[r[::-1] for r in px]
                if (a>>7)&1: px=px[::-1]
                Y=y-y0+ty*8+OFF; X=x-x0+tx*8+OFF
                if Y+8>C or X+8>C: continue
                for yy in range(8):
                    for xx in range(8):
                        if px[yy][xx] and not cv[Y+yy][X+xx]: cv[Y+yy][X+xx]=px[yy][xx]
    ys=[y for y in range(C) if any(cv[y])]
    xs=[x for x in range(C) if any(cv[y][x] for y in range(C))]
    if not ys: return None
    return dict(x0=x0,y0=y0,dx=dx,dy=dy,w=xs[-1]-xs[0]+1,h=ys[-1]-ys[0]+1,t0=low[base*4+2])

def main():
    d=sys.argv[1]
    oam=open(f'{d}/oamlog.bin','rb').read()
    wl=open(f'{d}/wlog.txt').read().splitlines()
    vram_cache={}
    out=[]
    for fr in range(len(wl)):
        vf=None
        for cand in (fr, fr-1, fr+1, fr-2, fr+2):
            p=f'{d}/vram_{cand}.bin'
            if os.path.exists(p): vf=p; break
        if not vf: continue
        if vf not in vram_cache: vram_cache[vf]=open(vf,'rb').read()
        vram=vram_cache[vf]
        b=(fr-1)*544
        if b<0 or b+544>len(oam): continue
        low=oam[b:b+512]; high=oam[b+512:b+544]
        w=bytes(int(t,16) for t in wl[fr].split()[1:])
        for k in range(8):
            sc=w[0x100*k+6]|(w[0x100*k+7]<<8)
            s18=w[0x100*k+0x18]|(w[0x100*k+0x19]<<8)
            r=measure(vram,low,high,28+4*k)
            if not r: continue
            out.append((fr,k,sc,s18,r['dx'],r['dy'],r['y0'],r['w'],r['h'],r['t0']))
    if '--csv' in sys.argv:
        p=sys.argv[sys.argv.index('--csv')+1]
        with open(p,'w') as f:
            f.write('frame,kart,escala06,escala18,dx,dy,y_pant,art_w,art_h,tile0\n')
            for o in out:
                f.write(','.join(str(x) for x in o)+'\n')
        print('escrito',p,len(out),'muestras')
    else:
        print('frame kart escala06 escala18 dx dy y art tile0')
        for o in out: print(' '.join(str(x) for x in o))

if __name__=='__main__': main()
