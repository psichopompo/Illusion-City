#!/usr/bin/env python3
"""Mide el tamaño de las tuberías (y opcionalmente del kart del jugador) fotograma a fotograma,
para comprobar si el escalado de los objetos del decorado es monótono o da saltos.

Uso: mide_tuberias.py <dir_con_ppms> [--every N] [--min-px N]
Salida: una línea por fotograma con el recuadro (bbox) de la tubería más grande y del resto.
Opcional: --csv fichero.csv
"""
import sys, glob, os
import numpy as np
from PIL import Image

def mascara_tuberia(a):
    r, g, b = a[:, :, 0].astype(int), a[:, :, 1].astype(int), a[:, :, 2].astype(int)
    return (r < 12) & (b < 12) & (g > 60)

def etiquetas(m, minpx):
    from collections import deque
    seen = np.zeros(m.shape, dtype=bool)
    out = []
    ys, xs = np.nonzero(m)
    for y0, x0 in zip(ys, xs):
        if seen[y0, x0]:
            continue
        q = deque([(y0, x0)]); seen[y0, x0] = True
        minx = maxx = x0; miny = maxy = y0; n = 0
        while q:
            y, x = q.popleft(); n += 1
            if x < minx: minx = x
            if x > maxx: maxx = x
            if y < miny: miny = y
            if y > maxy: maxy = y
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    yy, xx = y + dy, x + dx
                    if 0 <= yy < m.shape[0] and 0 <= xx < m.shape[1] and m[yy, xx] and not seen[yy, xx]:
                        seen[yy, xx] = True; q.append((yy, xx))
        if n >= minpx:
            out.append(dict(x0=minx, x1=maxx, y0=miny, y1=maxy, n=n))
    out.sort(key=lambda o: (o['y1'] - o['y0'] + 1) * (o['x1'] - o['x0'] + 1), reverse=True)
    return out

def mascara_kart_jugador(a):
    """Mario: rojo puro (gorra) y azul del mono, en la mitad inferior de la pantalla."""
    r, g, b = a[:, :, 0].astype(int), a[:, :, 1].astype(int), a[:, :, 2].astype(int)
    return (r > 180) & (g < 80) & (b < 80)

def main():
    d = sys.argv[1]
    every = int(sys.argv[sys.argv.index('--every') + 1]) if '--every' in sys.argv else 1
    minpx = int(sys.argv[sys.argv.index('--min-px') + 1]) if '--min-px' in sys.argv else 60
    csv = sys.argv[sys.argv.index('--csv') + 1] if '--csv' in sys.argv else None
    fs = sorted(glob.glob(os.path.join(d, 'f*.ppm')))[::every]
    rows = []
    print(f'{"f":>5}  tubería_mayor: bbox  ancho alto  |  otras')
    for f in fs:
        fr = int(os.path.basename(f)[1:-4])
        a = np.array(Image.open(f).convert('RGB'))
        boxes = etiquetas(mascara_tuberia(a), minpx)
        if not boxes:
            print(f'{fr:5d}  (sin tuberías)'); continue
        b0 = boxes[0]
        w = b0['x1'] - b0['x0'] + 1; h = b0['y1'] - b0['y0'] + 1
        otras = ' '.join(f"{bx['x1']-bx['x0']+1}x{bx['y1']-bx['y0']+1}@({bx['x0']},{bx['y0']})" for bx in boxes[1:4])
        print(f'{fr:5d}  x{b0["x0"]:3d}-{b0["x1"]:3d} y{b0["y0"]:3d}-{b0["y1"]:3d}  {w:3d} {h:3d}  | {otras}')
        rows.append((fr, b0['x0'], b0['x1'], b0['y0'], b0['y1'], w, h))
    if csv and rows:
        with open(csv, 'w') as fh:
            fh.write('frame,x0,x1,y0,y1,ancho,alto\n')
            for r in rows:
                fh.write(','.join(str(v) for v in r) + '\n')
        print('csv:', csv)

if __name__ == '__main__':
    main()
