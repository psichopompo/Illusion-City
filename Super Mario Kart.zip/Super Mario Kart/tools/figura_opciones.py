#!/usr/bin/env python3
"""Figura-resumen: en qué fila empieza a encoger cada opción y qué le pasa a Mario."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
rows=[('v1.3 (referencia)', 73, '32x32 intacto', '#777777'),
      ('x1,25  (opcion B)', 86, '32x32, +1 px abajo', '#2f7fbf'),
      ('x1,5   (opcion A)', 96, '32x32, +2 px abajo', '#1a9e6a'),
      ('forzar fila 110/125', 110, 'ROTO: 23x24', '#c23b3b')]
fig,ax=plt.subplots(figsize=(11,4.6))
for i,(nom,b,nota,col) in enumerate(rows):
    y=len(rows)-1-i
    ax.barh(y, b-23, left=23, color=col, alpha=.85, height=.5)
    ax.barh(y, 158-b, left=b, color=col, alpha=.18, height=.5)
    ax.plot([b],[y],'v',color=col,ms=11)
    ax.text(24.5, y+0.34, nota, fontsize=8.5, color=col)
    ax.text(20.5, y, nom, ha='right', va='center', fontsize=10)
ax.axvline(158,color='black',lw=1.4)
ax.text(157, len(rows)-0.35, '  MARIO (fila 158)', ha='right', fontsize=10, fontweight='bold')
for x,lab in [(23,'horizonte'),(50,''),(80,''),(110,''),(140,'')]:
    ax.axvline(x,color='#dddddd',lw=.8)
ax.set_xlim(-2,166); ax.set_ylim(-0.7,len(rows)-0.1)
ax.set_yticks([]); ax.set_xlabel('fila en pantalla  (izquierda = lejos, derecha = pegado a Mario)')
ax.set_title('Tramo en el que los rivales ya han reducido (color) y primera fila donde reducen (▼)\n'
             'A la izquierda del triángulo los rivales son mas pequenos; a la derecha, del tamano de Mario', fontsize=10)
plt.tight_layout(); plt.savefig('docs/opciones_que_cambia_cada_una.png',dpi=110)
print('docs/opciones_que_cambia_cada_una.png')
