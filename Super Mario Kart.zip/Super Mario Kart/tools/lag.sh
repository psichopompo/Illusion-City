#!/bin/bash
# uso: lag.sh rom state frames
mkdir -p /tmp/lg; WLOG=100,4 /tmp/drive /home/user/smk_work/cores/bsnes_instr.so "$1" "$2" $3 /tmp/acc.txt /tmp/lg 0 >/dev/null 2>&1
python3 - <<PY
l=[x.split()[1:] for x in open('/tmp/lg/wlog.txt')]
print('$2'.split('/')[-1], sum(1 for i in range(1,len(l)) if l[i]!=l[i-1]),'cambios en',len(l)-1)
PY
