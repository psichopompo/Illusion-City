#!/usr/bin/env python3
"""make_patches.py clean.sfc patched.sfc out_basename  -> out.ips, out.bps (+ self-check by applying both)"""
import sys, zlib, struct
def enc(n):
    o=bytearray()
    while True:
        x=n&0x7f; n>>=7
        if n==0: o.append(0x80|x); return bytes(o)
        o.append(x); n-=1
def dec(b,p):
    n=0; s=1
    while True:
        x=b[p]; p+=1; n+=(x&0x7f)*s
        if x&0x80: return n,p
        s<<=7; n+=s
def make_ips(a,b):
    out=bytearray(b'PATCH'); i=0; n=len(b)
    while i<n:
        if i<len(a) and a[i]==b[i]: i+=1; continue
        j=i
        # extend record while differing (allow short equal gaps <6 to merge)
        while j<n:
            if j<len(a) and a[j]==b[j]:
                k=j
                while k<n and k<len(a) and a[k]==b[k] and k-j<6: k+=1
                if k-j>=6 or k>=len(a) or k>=n: break
                j=k
            else: j+=1
        j=min(j,n)
        while j>i and j<=len(a) and j>0 and a[j-1]==b[j-1] and j-1<len(a): j-=1
        seg=b[i:j]
        # emit: runs >=9 identical bytes as RLE records, the rest as plain records
        seg=bytes(seg); p=0; lit=0
        def flush(a0,a1):
            q=a0
            while q<a1:
                ch=seg[q:min(q+0xFFFF,a1)]; off=i+q
                assert off!=0x454F46
                out.extend(off.to_bytes(3,'big')+len(ch).to_bytes(2,'big')+ch); q+=len(ch)
        while p<len(seg):
            r=p
            while r<len(seg) and seg[r]==seg[p]: r+=1
            if r-p>=9:
                flush(lit,p)
                q=p
                while q<r:
                    l=min(0xFFFF,r-q); off=i+q
                    assert off!=0x454F46
                    out.extend(off.to_bytes(3,'big')+b'\0\0'+l.to_bytes(2,'big')+bytes([seg[p]])); q+=l
                lit=r
            p=r
        flush(lit,len(seg))
        i=j
    out+=b'EOF'; return bytes(out)
def apply_ips(a,ip):
    r=bytearray(a); p=5
    while ip[p:p+3]!=b'EOF':
        off=int.from_bytes(ip[p:p+3],'big'); ln=int.from_bytes(ip[p+3:p+5],'big'); p+=5
        if ln==0: ln=int.from_bytes(ip[p:p+2],'big'); v=ip[p+2]; p+=3; d=bytes([v])*ln
        else: d=ip[p:p+ln]; p+=ln
        if off+len(d)>len(r): r+=b'\0'*(off+len(d)-len(r))
        r[off:off+len(d)]=d
    return bytes(r)
def make_bps(a,b):
    o=bytearray(b'BPS1')+enc(len(a))+enc(len(b))+enc(0)
    i=0; n=len(b); tro=[0]
    def emit_sr(l): o.extend(enc(((l-1)<<2)|0))
    def emit_tr(data): o.extend(enc(((len(data)-1)<<2)|1)); o.extend(data)
    while i<n:
        j=i
        if i<len(a) and a[i]==b[i]:
            while j<n and j<len(a) and a[j]==b[j]: j+=1
            emit_sr(j-i)
        else:
            while j<n and not (j<len(a) and a[j]==b[j] and j+8<=len(a) and a[j:j+8]==b[j:j+8]): j+=1
            seg=b[i:j]; p=0; lit=0
            while p<len(seg):
                r=p
                while r<len(seg) and seg[r]==seg[p]: r+=1
                if r-p>=10:
                    if p+1>lit or True:
                        # literal up to and including the first byte of the run
                        emit_tr(seg[lit:p+1]); pos=i+p   # position of that first byte in target
                        l=r-p-1; offv=pos-tro[0]; o.extend(enc(((l-1)<<2)|3)); o.extend(enc((abs(offv)<<1)|(1 if offv<0 else 0))); tro[0]=pos+l
                    lit=r
                p=r
            if lit<len(seg): emit_tr(seg[lit:])
        i=j
    o+=struct.pack('<I',zlib.crc32(a))+struct.pack('<I',zlib.crc32(b))
    o+=struct.pack('<I',zlib.crc32(bytes(o))); return bytes(o)
def apply_bps(a,pt):
    assert pt[:4]==b'BPS1'; p=4
    sa,p=dec(pt,p); sb,p=dec(pt,p); m,p=dec(pt,p); p+=m
    assert sa==len(a)
    end=len(pt)-12; out=bytearray()
    assert struct.unpack('<I',pt[-4:])[0]==zlib.crc32(pt[:-4])
    sro=tro=0
    while p<end:
        v,p=dec(pt,p); mode=v&3; l=(v>>2)+1
        if mode==0: out+=a[len(out):len(out)+l]
        elif mode==1: out+=pt[p:p+l]; p+=l
        elif mode==3:
            v2,p=dec(pt,p); tro+= -(v2>>1) if v2&1 else (v2>>1)
            for _ in range(l): out.append(out[tro]); tro+=1
        else: raise SystemExit('unsupported')
    assert len(out)==sb and zlib.crc32(out)==struct.unpack('<I',pt[-8:-4])[0]
    return bytes(out)
if __name__=='__main__':
    a=open(sys.argv[1],'rb').read(); b=open(sys.argv[2],'rb').read(); base=sys.argv[3]
    ip=make_ips(a,b); bp=make_bps(a,b)
    assert apply_ips(a,ip)==b, 'IPS check failed'
    assert apply_bps(a,bp)==b, 'BPS check failed'
    open(base+'.ips','wb').write(ip); open(base+'.bps','wb').write(bp)
    print('ips',len(ip),'bps',len(bp),'crc32 target %08X'%zlib.crc32(b))
