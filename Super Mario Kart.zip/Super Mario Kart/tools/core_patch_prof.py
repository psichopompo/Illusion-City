#!/usr/bin/env python3
"""Perfilador sobre bsnes 0c2fa0d: uso: core_patch_prof.py /tmp/bsnes_src   (despues de core_patch.py)
Anade: histograma por PC (veces y ciclos de reloj maestro) -> smk_hist_dump(path, clear);
ultimo PC que escribe en WRAM $0100-$04FF -> smk_oamw_dump(path, clear)."""
import sys
ROOT = sys.argv[1]
p = f'{ROOT}/bsnes/processor/wdc65816/instruction.cpp'
s = open(p).read()
s = s.replace('extern "C" { uint32 smkPcRingC[65536];', 'extern "C" { uint32 smkHist[1<<24]; uint64 smkInstrN = 0; uint64 smkClk = 0; uint64 smkLastClk = 0; uint32 smkLastPC = 0; uint64 smkCyc[1<<24];\nuint32 smkPcRingC[65536];', 1)
s = s.replace('auto WDC65816::instruction() -> void {\n', 'auto WDC65816::instruction() -> void {\n  smkCyc[smkLastPC] += smkClk - smkLastClk; smkLastClk = smkClk; smkLastPC = PC.d & 0xFFFFFF;\n  smkHist[PC.d & 0xFFFFFF]++; smkInstrN++;\n', 1)
open(p, 'w').write(s)
p = f'{ROOT}/bsnes/sfc/cpu/timing.cpp'
s = open(p).read()
s = s.replace('auto CPU::stepOnce() -> void {\n  counter.cpu += 2;', 'extern "C" { extern uint64 smkClk; }\nauto CPU::stepOnce() -> void {\n  smkClk += 2;\n  counter.cpu += 2;', 1)
open(p, 'w').write(s)
p = f'{ROOT}/bsnes/sfc/cpu/memory.cpp'
s = open(p).read()
s = s.replace('auto CPU::write(uint address, uint8 data) -> void {\n  aluEdge();\n', 'extern "C" { extern uint32 smkLastPC; uint32 smkOamPC[0x400]; uint8 smkOamV[0x400]; uint32 smkOamN[0x400]; }\nauto CPU::write(uint address, uint8 data) -> void {\n  { uint a = address & 0xFFFFFF; uint bank = a >> 16; uint lo = a & 0xFFFF; if(((bank < 0x40) || (bank >= 0x80 && bank < 0xC0)) ? (lo >= 0x100 && lo < 0x500) : (bank == 0x7E && lo >= 0x100 && lo < 0x500)) { smkOamPC[lo-0x100] = smkLastPC; smkOamV[lo-0x100] = data; smkOamN[lo-0x100]++; } }\n  aluEdge();\n', 1)
open(p, 'w').write(s)
p = f'{ROOT}/bsnes/sfc/memory/memory.cpp'
s = open(p).read()
s += '''
extern "C" { extern uint64 smkCyc[1<<24]; extern uint32 smkHist[1<<24]; extern uint64 smkInstrN; extern uint32 smkOamPC[0x400]; extern uint8 smkOamV[0x400]; extern uint32 smkOamN[0x400]; }
extern "C" __attribute__((visibility("default"))) void smk_hist_dump(const char* path, int clear) {
  FILE* f = fopen(path, "w");
  if(f) { fprintf(f, "# total %llu\\n", (unsigned long long)smkInstrN);
    for(unsigned i = 0; i < (1u<<24); i++) if(smkHist[i]) fprintf(f, "%06x %u %llu\\n", i, smkHist[i], (unsigned long long)smkCyc[i]);
    fclose(f); }
  if(clear) { for(unsigned i = 0; i < (1u<<24); i++) smkHist[i] = 0, smkCyc[i] = 0; smkInstrN = 0; }
}
extern "C" __attribute__((visibility("default"))) void smk_oamw_dump(const char* path, int clear) {
  FILE* f = fopen(path, "w");
  if(f) { for(unsigned i = 0; i < 0x400; i++) fprintf(f, "%03x %06x %02x %u\\n", i + 0x100, smkOamPC[i], smkOamV[i], smkOamN[i]); fclose(f); }
  if(clear) for(unsigned i = 0; i < 0x400; i++) smkOamN[i] = 0;
}
'''
open(p, 'w').write(s)
print('perfilador aplicado')
