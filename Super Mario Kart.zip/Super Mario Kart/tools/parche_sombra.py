#!/usr/bin/env python3
"""Parche de la SOMBRA de la parrilla/salida (prototipo).

Uso:
  python3 tools/parche_sombra.py entrada.sfc salida.sfc --modo=s      (suma $7E:0A86)
  python3 tools/parche_sombra.py entrada.sfc salida.sfc --modo=88     (suma 88 fijo)
  python3 tools/parche_sombra.py entrada.sfc salida.sfc --modo=byte   (solo 5A->5C)

Hechos comprobados (2026-10-06):
  * La sombra de la salida (3 sprites, tiles $EB/$EC, x=38/44/50, Y=90) la escribe
    $85:E1D0: `09 00 5A` = ORA #$005A, seguido de LDY $CE y 3 STA a la página de OAM.
    (Localizado con el logger de escrituras a la OAM SIN filtro de banco:
     con filtro sólo $00/$7E/$80/$81 no se veía, porque el banco es $85.)
  * La vanilla USA dibuja la misma sombra en Y=90 en la parrilla (x=41/47) =>
    la altura NO es una regresión del hack: moverla es un cambio deliberado.
  * s = $7E:0A86 vale 0 durante la parrilla y 88 en carrera.

Modo 88:  hijack en $85:E1D0 (5 bytes: ORA #$005A ; LDY $CE) -> JSL $8B:8640 ; NOP
          rutina en $8B:8640: CLC / ADC #$0058 / LDY $CE / RTL   -> Y 90+88 = 178
Modo s:   igual, pero ADC $7E0A86 (durante la parrilla s=0 => no cambia nada)
Modo byte: file 0x5E1D2 = $5C (Y=92) - sólo válido si algo más la desplaza.
"""
import sys
rom = bytearray(open(sys.argv[1], 'rb').read()); dst = sys.argv[2]
modo = 'byte'
for a in sys.argv[3:]:
    if a.startswith('--modo='): modo = a.split('=', 1)[1]

if modo in ('88', 's'):
    R = ('18' + ('690058' if modo == '88' else '6f860a7e') + 'a4ce' + '6b')
    rom[0x8B8640:0x8B8640 + len(R)//2] = bytes.fromhex(R)
    assert rom[0x5E1D0:0x5E1D5] == bytes.fromhex('09005aa4ce'), 'patrón no encontrado'
    rom[0x5E1D0:0x5E1D5] = bytes.fromhex('2240868bea')      # JSL $8B:8640 + NOP
elif modo == 'byte':
    assert rom[0x5E1D0:0x5E1D3] == bytes.fromhex('09005a')
    rom[0x5E1D2] = 0x5C
else:
    raise SystemExit('modo desconocido')
open(dst, 'wb').write(bytes(rom))
print(f'escrito {dst} (modo={modo})')
