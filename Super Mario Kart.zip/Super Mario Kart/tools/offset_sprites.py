#!/usr/bin/env python3
"""Corrige/ajusta la tabla de offset vertical de sprites del banco $88 (tabla A).

Contexto (ver docs/INFORME_ESCALA_KARTS.md, quinta parte):
  La hack guarda en $7E:0A86 un offset vertical que se SUMA a la Y de todos los sprites:
      LDA #$FFD6 / CLC / ADC $7E0A86 / STA $1E      (vista de abajo, $88:8647)
      LDA #$FF66 / CLC / ADC $7E0A86 / STA $1E      (vista de arriba, $88:85E7)
  Ese offset sale de una tabla de 37 words en $88:8480 (file 0x88480) indexada 0..36,
  y va de 0 a 88 px (el máximo del ascenso al entrar en pista).

  Síntoma medido: los sprites quedan ~16 px por DEBAJO de la calzada respecto a vanilla
  (la marca blanca del suelo cruza al kart por el pecho en vez de por las ruedas).
  Prueba: llevar el máximo de la tabla de 88 a 72 px devuelve el kart a su sitio.

Uso:
  offset_sprites.py in.sfc out.sfc 72      # escala toda la tabla (0..88 -> 0..72)
  offset_sprites.py in.sfc out.sfc max=72  # fuerza solo el último valor a 72
"""
import sys

BASE = 0x88480      # file offset de la tabla A (22 words + remanente)
NMAX = 37           # nº de words usados (índices 0..36)


def leer(b):
    return [b[BASE + 2 * i] | (b[BASE + 2 * i + 1] << 8) for i in range(NMAX)]


def escribir(b, vals):
    for i, v in enumerate(vals):
        b[BASE + 2 * i] = v & 0xFF
        b[BASE + 2 * i + 1] = (v >> 8) & 0xFF


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return 2
    src, dst, arg = sys.argv[1], sys.argv[2], sys.argv[3]
    b = bytearray(open(src, 'rb').read())
    if len(b) < BASE + 2 * NMAX:
        print(f'ERROR: {src} no parece la ROM de 1 MB de la hack (faltan bytes)')
        return 3
    vals = leer(b)
    max_actual = max(vals)
    if arg.startswith('max='):
        nuevo = int(arg[4:])
        vals[-1] = nuevo
        modo = f'forzado el último valor a {nuevo}'
    else:
        nuevo = int(arg)
        vals = [round(v * nuevo / max_actual) for v in vals]
        modo = f'escalada la tabla entera 0..{max_actual} -> 0..{nuevo}'
    escribir(b, vals)
    open(dst, 'wb').write(bytes(b))
    print(f'{dst}: {modo}')
    print(f'  antes: {vals[0]} .. {max_actual}')
    print(f'  ahora: {vals[0]} .. {max(vals)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
