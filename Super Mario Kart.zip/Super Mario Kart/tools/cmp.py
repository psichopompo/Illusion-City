import subprocess,os
def run(rom,state,n,script,tag,snaps=True):
    d='/tmp/cm_%s'%tag; subprocess.run(['rm','-rf',d]); os.makedirs(d)
    env=dict(os.environ,OAMLOG='1')
    if snaps: env['SNAPS']=','.join(map(str,range(0,n)))
    subprocess.run(['timeout','280','/tmp/drive','cores/bsnes_prof.so',rom,state,str(n),script,d,'100000'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env)
    return d
