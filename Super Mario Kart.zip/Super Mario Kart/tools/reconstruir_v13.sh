#!/bin/bash
# Candidato v1.3 (experimental): roms/candidato_v1.2.sfc (CRC 8D91CAC9)
#   + Lakitu sin asomar por abajo (tools/lakitu_abajo.py)
#   + menos carga de CPU en 1P (tools/optim_lag.py)
#   + monedas de Lakitu/perdidas en 2P sin el desplazamiento de 88 px (tools/fix_monedas_2p.py).
# uso: bash tools/reconstruir_v13.sh [salida.sfc]
set -e
cd "$(dirname "$0")/.."
OUT="${1:-roms/candidato_v1.3.sfc}"
python3 tools/lakitu_abajo.py roms/candidato_v1.2.sfc /tmp/_v13a.sfc >/dev/null
python3 tools/optim_lag.py /tmp/_v13a.sfc /tmp/_v13b.sfc >/dev/null
python3 tools/fix_monedas_2p.py /tmp/_v13b.sfc "$OUT" >/dev/null
python3 -c "import zlib,sys;print('CRC32 %08X'%zlib.crc32(open(sys.argv[1],'rb').read()))" "$OUT"
