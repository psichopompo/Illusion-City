#!/usr/bin/env python3
"""Lakitu en el rescate (1P pantalla completa): Y > 127, destinos de descenso/subida y moneda.
uso: lakitu_y.py in.sfc out.sfc
El guion de Lakitu (banco $85) guarda su Y como palabra 8.8 y usa el bit 15 como signo ('por encima de la pantalla'). Con el coche 88 px mas abajo,
Lakitu llega a Y>=128 (palabra >= $8000) y el guion cree que ya salio por arriba (se acaba al empezar a subir: Lakitu desaparece sin moneda), y los
destinos de descenso (`85:DE59`, args $6000/$4800, coordenadas del coche vanilla) se cumplen 88 px antes de llegar al coche (salto de Lakitu).
En 1P (gate: $7E:00AA == $1000, o 88:8F00 para los guiones):
 - 85:DE59 (esperar Y>=arg): sin signo (negativa solo en $F000..$FFFF), arg+$5800 salvo el $4000 de espera inicial, y +2 px/fotograma extra
   mientras baja al coche (3 px/f: la bajada de 120 px dura ~40 fotogramas, como los ~32 de vanilla).
 - 85:DE68 (esperar salida por arriba): sale con Y en [$E000,$FF00) (-32..-2 px) y, en la subida de la liberacion (opcode en 85:DD44),
   -1 px/fotograma extra (2 px/f: 86 fotogramas, ~88 de vanilla; la moneda de Lakitu vive $60 fotogramas).
 - 85:DF69 (subir y borrar): igual criterio de salida.
 - 85:E5A9/E5D3 (moneda que sujeta Lakitu): kill con Y de Lakitu en [$E000,$F400); su Y vanilla = Y_Lakitu - 2 px - 88 px (E6F3 suma +88);
   la moneda encadenada (Y<$5000) se evalua con +$5800.
Fuera de 1P: codigo original."""
import sys
r = bytearray(open(sys.argv[1], 'rb').read())

def build(org, items):
    """items: lista de bytes | ('L','nombre') | ('B',opcode,'nombre') salto relativo"""
    out = bytearray(); lab = {}; fix = []
    for it in items:
        if isinstance(it, str) and it.endswith(':'): lab[it[:-1]] = len(out)
        elif isinstance(it, str): out += bytes.fromhex(it.replace(' ', ''))
        else: out.append(it[0]); out.append(0); fix.append((len(out) - 1, it[1]))
    for pos, name in fix:
        d = lab[name] - (pos + 1); assert -128 <= d <= 127, (name, d); out[pos] = d & 255
    return bytes(out), {k: org + v for k, v in lab.items()}

BNE, BEQ, BCC, BCS, BPL, BMI, BRA = 0xD0, 0xF0, 0x90, 0xB0, 0x10, 0x30, 0x80
A_ORG = 0x8E10
blkA, LA = build(A_ORG, [
 # --- DE59: esperar Y>=arg
 'A6B4', '20008F', (BNE, 'wy_van'),
 'B90200', 'C90040', (BEQ, 'wy_a'), '18', '690058', 'wy_a:', '48',
 'B520', 'C900F0', (BCS, 'wy_no'), 'C301', (BCC, 'wy_no'), '68', '5C86DE85',
 'wy_no:', '68', 'C900A0', (BCC, 'wy_ret'), 'B520', '18', '690002', '9520', 'wy_ret:', '5C67DE85',
 'wy_van:', 'B520', (BMI, 'wy_v2'), 'D90200', (BCC, 'wy_v2'), '5C86DE85', 'wy_v2:', '5C67DE85',
 # --- DE68: esperar salida por arriba
 'ot:', 'A6B4', '20008F', (BNE, 'ot_van'),
 'C044DD', (BNE, 'ot_a'), 'B520', '38', 'E90001', '9520', 'ot_a:',
 'B520', 'C900E0', (BCC, 'ot_no'), 'C900FF', (BCS, 'ot_no'), '5C88DE85', 'ot_no:', '5C76DE85',
 'ot_van:', 'B520', (BPL, 'ot_v2'), 'C900F0', (BCS, 'ot_v2'), '5C88DE85', 'ot_v2:', '5C76DE85',
 # --- DF69: subir y borrar (A = $20,x)
 'as:', '48', 'AFAA007E', 'C90010', (BEQ, 'as_1p'), '68', (BPL, 'as_keep'), 'C900F0', (BCS, 'as_keep'),
 'as_kill:', '5C70DF85', 'as_keep:', '5C75DF85',
 'as_1p:', '68', 'C900E0', (BCC, 'as_keep'), 'C900FF', (BCS, 'as_keep'), (BRA, 'as_kill'),
])
print('bloque A', len(blkA), 'fin', hex(A_ORG + len(blkA)))
assert A_ORG + len(blkA) <= 0x8F00
C_ORG = 0x9030
blkC, LC = build(C_ORG, [
 # --- E5A9: moneda de Lakitu (X = Lakitu, Y = moneda)
 'co:', 'B520', '48', 'AFAA007E', 'C90010', (BEQ, 'co_1p'), '68', (BPL, 'co_ok'), 'C900F4', (BCC, 'co_kill'),
 'co_ok:', '38', 'E90002', 'co_st:', '990400', '5CB9E585', 'co_kill:', '5CE0E585',
 'co_1p:', '68', 'C900E0', (BCC, 'co_1ok'), 'C900F4', (BCC, 'co_kill'), 'co_1ok:', '38', 'E9005A', (BRA, 'co_st'),
 # --- E5D3: moneda encadenada (A = Y)
 'ch:', '48', 'AFAA007E', 'C90010', (BEQ, 'ch_1p'), '68', 'C90050', (BCS, 'ch_skip'), 'ch_draw:', '5CD8E585', 'ch_skip:', '5CBCE585',
 'ch_1p:', '68', '18', '690058', 'C900A8', (BCS, 'ch_skip'), (BRA, 'ch_draw'),
])
print('bloque C', len(blkC), 'fin', hex(C_ORG + len(blkC)))
assert not any(r[0x80000 + A_ORG:0x80000 + 0x8F00]) and not any(r[0x80000 + C_ORG:0x80000 + C_ORG + 0x80])
jml = lambda a: bytes([0x5C, a & 255, (a >> 8) & 255, 0x88])
assert bytes(r[0x5DE59:0x5DE5B]) == bytes.fromhex('A6B4') and bytes(r[0x5DE68:0x5DE6A]) == bytes.fromhex('A6B4')
assert bytes(r[0x5DF69:0x5DF6D]) == bytes.fromhex('5C258D88')
assert bytes(r[0x5E5A9:0x5E5B2]) == bytes.fromhex('B5201005C900F4902E'.replace('1005C9', '1005C9')) and bytes(r[0x5E5D3:0x5E5D8]) == bytes.fromhex('C90050B0E4')
r[0x80000 + A_ORG:0x80000 + A_ORG + len(blkA)] = blkA
r[0x80000 + C_ORG:0x80000 + C_ORG + len(blkC)] = blkC
r[0x5DE59:0x5DE5D] = jml(A_ORG)
r[0x5DE68:0x5DE6C] = jml(LA['ot'])
r[0x5DF69:0x5DF6D] = jml(LA['as'])
r[0x5E5A9:0x5E5B9] = jml(LC['co']) + bytes([0xEA]) * 12
r[0x5E5D3:0x5E5D8] = jml(LC['ch']) + bytes([0xEA])
open(sys.argv[2], 'wb').write(r)
