#!/bin/bash
# Descarga los cores de libretro que usa el harness (buildbot nightly, linux x86_64).
# Uso:  bash tools/setup_cores.sh [destino]        (por defecto /tmp)
set -e
DEST="${1:-/tmp}"
ROOT_ABS="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$DEST"
for core in snes9x bsnes; do
  cd "$DEST"
  curl -sL -o "$core.zip" "https://buildbot.libretro.com/nightly/linux/x86_64/latest/${core}_libretro.so.zip"
  unzip -oq "$core.zip"
  rm -f "$core.zip"
  ls -la "$DEST/${core}_libretro.so"
done

# Compilar el harness (necesita zlib; drive.c usa libretro_vfs.h, imprescindible para bsnes)
gcc -O2 -I "$ROOT_ABS/user_upload" -o "$DEST/drive" "$ROOT_ABS/harness/drive.c" -ldl -lm -lz
echo "harness: $DEST/drive"

cat <<'EOF'

Ver un estado del usuario (formato RetroArch .state, core bsnes):
  PORTS=1 /tmp/drive /tmp/bsnes_libretro.so \
      "roms/candidato_v1.4.sfc" /home/user/states/Tuberia.state 300 script.txt outdir 10

  - PORTS=1  -> partida de 1 jugador (por defecto el harness activa también el mando 2)
  - el último número = volcar un PPM cada N fotogramas
  - el estado se carga tal cual (el harness quita la cabecera RASTATE y descomprime los chunks RZIP)
  - con el core bsnes NO hay acceso a WRAM (retro_get_memory_data = NULL): sólo capturas.
    Para leer OAM/WRAM del juego usa el core snes9x (pero tus .state no cargan ahí: son de bsnes).
EOF
