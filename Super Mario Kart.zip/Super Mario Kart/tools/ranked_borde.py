#!/usr/bin/env python3
"""Ranked Out (1P): oculta las 3 ultimas filas visibles (216..218) que dejaban un resto de color bajo el GRANDE.

usage: ranked_borde.py in.sfc out.sfc

El IRQ del modo 8 (80:8B8F, V=211) programa el siguiente IRQ en la linea $DB (219), donde el juego apaga la pantalla (forced blank).
Con la pantalla oscurecida del Ranked Out, las filas 216..218 mostraban un resto (fondo medio oscuro) fuera de las ventanas del digito.
Fix: en 1P ($00:00AB == $10) y con Lakitu en modo Ranked Out ($7E:1C30 == $08 y $016B == $AD) el IRQ se programa en $D8 (216) en vez de $DB.
Hook: 80:8B93 (`LDA #$DB ; STA $4209`) -> `JSL 88:9A40 ; NOP`. Stub 88:9A40 (RTL, A de 8 bits).
"""
import sys
r = bytearray(open(sys.argv[1], 'rb').read())
S = 0x89A40
H = 0x8B93
assert bytes(r[H:H + 5]) == bytes.fromhex('A9DB8D0942'), r[H:H + 5].hex()
assert not any(r[S:S + 0x40]), 'area no libre'
code = bytearray()
code += bytes([0xAF, 0xAB, 0x00, 0x00])        # LDA $00:00AB
code += bytes([0xC9, 0x10])                    # CMP #$10        (1P: $AA == $1000)
code += bytes([0xD0, 0x14])                    # BNE norm
code += bytes([0xAF, 0x30, 0x1C, 0x7E])        # LDA $7E:1C30
code += bytes([0xC9, 0x08])                    # CMP #$08        (Lakitu: Ranked Out)
code += bytes([0xD0, 0x0C])                    # BNE norm
code += bytes([0xAF, 0x6B, 0x01, 0x00])        # LDA $00:016B    (CGWSEL region inferior)
code += bytes([0xC9, 0xAD])                    # CMP #$AD        (pantalla oscura del Ranked Out/RETRY; la tabla LAP TIME gris usa $3D)
code += bytes([0xD0, 0x04])                    # BNE norm
code += bytes([0xA9, 0xD8])                    # LDA #$D8
code += bytes([0x80, 0x02])                    # BRA store
code += bytes([0xA9, 0xDB])                    # norm: LDA #$DB
code += bytes([0x8D, 0x09, 0x42])              # store: STA $4209
code += bytes([0x6B])                          # RTL
assert len(code) == 34
# comprueba saltos
assert 8 + code[7] == 28 and 16 + code[15] == 28 and 24 + code[23] == 28 and 28 + code[27] == 30 and code[28] == 0xA9 and code[29] == 0xDB
r[S:S + len(code)] = code
r[H:H + 5] = bytes([0x22, S & 0xFF, (S >> 8) & 0xFF, 0x88, 0xEA])
open(sys.argv[2], 'wb').write(r)
print('stub %d bytes' % len(code))
