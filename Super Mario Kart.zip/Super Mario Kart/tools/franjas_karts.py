#!/usr/bin/env python3
"""Ajusta el reparto de tamanos de sprite de los karts.

1) Tabla de umbrales en $80:DD35 (niveles 0-2 -> 32x32 ; 3-4 -> 23x24 ; 5-7 -> 16x16 ; 8-10 -> 9x9)
2) Escala de dibujo del JUGADOR: en $81:CEBE y $81:CEDE el juego hace
   LDA #$0108 (264) : STA $18 : STA $06,x  -> el jugador siempre se dibuja con la
   escala fija 264. Se puede subir para que el jugador quede siempre en el nivel maximo.

Uso: franjas_karts.py <in.sfc> <out.sfc> [A B C [JUGADOR]]
  A: 32->24 px ; B: 24->16 px ; C: 16->9 px ; JUGADOR: nueva escala fija (por defecto 264)
"""
import sys
from pathlib import Path
TAB=0xDD35
ref117=0xCEBE      # file offset: $81:CEBE
ref117b=0xCEDE     # file offset: $81:CEDE
def apply(src,dst,A=None,B=None,C=None,player=None):
    rom=bytearray(Path(src).read_bytes())
    if A is not None and B is not None and C is not None:
        for i,v in enumerate([A,A,A,B,B,C,C,C,0,0,0]):
            rom[TAB+2*i]=v & 0xFF; rom[TAB+2*i+1]=v>>8
    if player is not None:
        for off in (ref117,ref117b):
            assert rom[off:off+3]==bytes([0xA9,0x08,0x01]), f'patron inesperado en {off:#x}: {rom[off:off+3].hex()}'
            rom[off+1]=player & 0xFF; rom[off+2]=player>>8
    Path(dst).write_bytes(rom)
    return rom
if __name__=='__main__':
    s,d=sys.argv[1],sys.argv[2]
    A,B,C=(int(x) for x in sys.argv[3:6]) if len(sys.argv)>5 else (None,None,None)
    pl=int(sys.argv[6]) if len(sys.argv)>6 else None
    apply(s,d,A,B,C,pl)
    print(f'{d}: umbrales A={A} B={B} C={C} jugador={pl}')
