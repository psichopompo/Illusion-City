#!/usr/bin/env python3
"""Añade el hook de lectura de las tablas de escala/descriptores ($DC00-$DDEF) al core bsnes instrumentado.
Se ejecuta después de build_instrumented.sh. Idempotente."""
import sys
root = sys.argv[1] if len(sys.argv) > 1 else '/tmp/bsnes_src'

# 1) memory-inline.hpp: llamar al hook en Bus::read
p = f'{root}/bsnes/sfc/memory/memory-inline.hpp'
s = open(p).read()
if 'smkTraceRead' not in s:
    old = '''auto Bus::read(uint addr, uint8 data) -> uint8 {
  return reader[lookup[addr]](target[addr], data);
}'''
    new = '''extern "C" void smkTraceRead(unsigned addr);
auto Bus::read(uint addr, uint8 data) -> uint8 {
  smkTraceRead(addr);
  return reader[lookup[addr]](target[addr], data);
}'''
    assert old in s, 'Bus::read no encontrado'
    open(p, 'w').write(s.replace(old, new, 1))
    print('memory-inline.hpp: hook de lectura añadido')

# 2) memory.cpp: buffer + volcado
p = f'{root}/bsnes/sfc/memory/memory.cpp'
s = open(p).read()
if 'rdPC[' not in s:
    old = 'static uint16 trX[262144]; static uint32 trCount = 0;'
    assert old in s, 'trX no encontrado'
    new = '''static uint16 trX[262144]; static uint32 trCount = 0;
static uint32 rdPC[8192]; static uint16 rdA[8192]; static uint32 rdN = 0;
extern "C" void smkTraceRead(unsigned addr) {
  uint off = addr & 0xffff;
  if(off >= 0xdc00 && off < 0xddef) {
    if(rdN < 8192) { rdPC[rdN] = SuperFamicom::cpu.r.pc.d; rdA[rdN] = (uint16)off; rdN++; }
  }
}'''
    s = s.replace(old, new, 1)
    line = 'for(uint32 i = 0; i < trCount; i++) fprintf(f, "pc=%06x a=%04x d=%02x x=%04x'
    j = s.find(line)
    assert j >= 0, 'linea de traza no encontrada'
    # insertar el volcado de lecturas justo después de esa línea (que termina en ');\n')
    k = s.find('\n', j)
    ins = '\n    for(uint32 i = 0; i < rdN; i++) fprintf(f, "r=%06x a=%04x\\n", rdPC[i], rdA[i]);'
    s = s[:k] + ins + s[k:]
    s = s.replace('  trCount = 0; smkPcRingCN = 0;', '  trCount = 0; rdN = 0; smkPcRingCN = 0;', 1)
    open(p, 'w').write(s)
    print('memory.cpp: buffer de lecturas + volcado añadidos')
else:
    print('memory.cpp: ya estaba parcheado')
