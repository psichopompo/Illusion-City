#!/usr/bin/env python3
"""Convierte un .state RZIP de RetroArch en el payload crudo (RASTATE) que carga /tmp/drive.
Uso: rzip_to_payload.py in.state out.bin"""
import sys, zlib, struct
d = open(sys.argv[1], 'rb').read()
if d[:6] != b'#RZIPv':
    out = d
else:
    tot = struct.unpack('<Q', d[12:20])[0]
    pos, out = 20, b''
    while pos < len(d):
        n = struct.unpack('<I', d[pos:pos+4])[0]; pos += 4
        out += zlib.decompress(d[pos:pos+n]); pos += n
    assert len(out) == tot
open(sys.argv[2], 'wb').write(out)
print(sys.argv[2], len(out))
