import sys
from PIL import Image
d=sys.argv[1]; fr=[int(x) for x in sys.argv[2].split(',')]; out=sys.argv[3]; cols=int(sys.argv[4]) if len(sys.argv)>4 else 4
rows=(len(fr)+cols-1)//cols
W=Image.new('RGB',(cols*260,rows*228),(255,0,255))
for i,f in enumerate(fr):
    im=Image.open('%s/f%04d.ppm'%(d,f)).convert('RGB'); W.paste(im,((i%cols)*260,(i//cols)*228))
W.save(out)
