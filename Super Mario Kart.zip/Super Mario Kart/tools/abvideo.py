#!/usr/bin/env python3
"""abvideo.py romA romB state frames [paso]: compara la imagen de dos ROMs en el primer fotograma de video de cada valor del cronometro (alineado por logica, insensible al lag).
Imprime cuantas imagenes comparadas y cuantas difieren (y las 5 primeras)."""
import sys, os, subprocess, shutil
def log(rom, st, n):
    d = '/tmp/av_%d' % os.getpid(); shutil.rmtree(d, True); os.makedirs(d)
    subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(n), '/tmp/acc.txt', d, '0'], env=dict(os.environ, WLOG='100,4'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = [x.split()[1:] for x in open(d + '/wlog.txt')]; shutil.rmtree(d, True)
    seen = {}
    for i, k in enumerate(w):
        k = ''.join(k)
        if k not in seen: seen[k] = i
    return seen
def snaps(rom, st, n, fr, tag):
    d = '/tmp/avs_%s_%d' % (tag, os.getpid()); shutil.rmtree(d, True); os.makedirs(d)
    subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(n), '/tmp/acc.txt', d, '0'], env=dict(os.environ, SNAPS=','.join(map(str, fr))), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return d
def mask(b):
    # PPM P6 256x224 (o ancho/alto del encabezado): se ignora el cronometro del HUD (arriba a la derecha), que en el lag se actualiza un fotograma antes/despues
    hdr = b.split(b'\n', 3); w, h = map(int, hdr[1].split()); data = bytearray(hdr[3])
    for yy in range(0, 50):
        for xx in range(140, w): data[(yy * w + xx) * 3:(yy * w + xx) * 3 + 3] = b'\0\0\0'
    return bytes(data)
ra, rb, st, n = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]); step = int(sys.argv[5]) if len(sys.argv) > 5 else 1
fa, fb = log(ra, st, n), log(rb, st, n)
ks = sorted((k for k in fa if k in fb), key=lambda k: fa[k])[::step]
pa = [fa[k] + 1 for k in ks]; pb = [fb[k] + 1 for k in ks]
da = snaps(ra, st, n, pa, 'a'); db = snaps(rb, st, n, pb, 'b')
bad = []
for k, a, b in zip(ks, pa, pb):
    x = open('%s/f%04d.ppm' % (da, a), 'rb').read() if os.path.exists('%s/f%04d.ppm' % (da, a)) else None
    y = open('%s/f%04d.ppm' % (db, b), 'rb').read() if os.path.exists('%s/f%04d.ppm' % (db, b)) else None
    if x is None or y is None or mask(x) != mask(y): bad.append((a, b))
print('%s: imagenes comparadas %d, distintas %d %s' % (os.path.basename(st), len(ks), len(bad), bad[:5]))
shutil.rmtree(da, True); shutil.rmtree(db, True)
