#!/usr/bin/env python3
"""abtimer.py romA romB state frames [ignorar_hex_ini-fin ...]: compara WRAM[0..8K] de dos ROMs alineando por valor del cronometro ($0100..$0103)
en su primera aparicion (insensible al lag). Informa diferencias fuera de las direcciones ignoradas."""
import sys, os, subprocess, shutil
import numpy as np
def run(rom, st, n, tag):
    d = '/tmp/ab_%s_%d' % (tag, os.getpid()); shutil.rmtree(d, True); os.makedirs(d)
    subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(n), '/tmp/acc.txt', d, '0'], env=dict(os.environ, WLOG='0,8192'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    rows = []
    for l in open(d + '/wlog.txt'):
        q = l.split(); rows.append(np.frombuffer(bytes(int(x, 16) for x in q[1:]), dtype=np.uint8))
    shutil.rmtree(d, True); return np.array(rows)
A = run(sys.argv[1], sys.argv[4 - 1 + 0] if False else sys.argv[3], int(sys.argv[4]), 'a'); B = run(sys.argv[2], sys.argv[3], int(sys.argv[4]), 'b')
ign = np.zeros(8192, bool)
for s in sys.argv[5:]:
    a, b = s.split('-'); ign[int(a, 16):int(b, 16)] = True
def first(R):
    seen = {}; 
    for i in range(len(R)):
        k = R[i, 0x100:0x104].tobytes()
        if k not in seen: seen[k] = i
    return seen
fa, fb = first(A), first(B)
common = [k for k in fa if k in fb]
bad = 0; first_bad = None; addrs = set()
for k in common:
    x, y = A[fa[k]], B[fb[k]]
    dif = np.nonzero((x != y) & ~ign)[0]
    if len(dif):
        bad += 1
        addrs.update(int(a) for a in dif[:8])
        if first_bad is None: first_bad = (fa[k], fb[k], [hex(int(a)) for a in dif[:12]])
print('fotogramas de logica comunes %d, con diferencias %d' % (len(common), bad), first_bad if bad else '', sorted(hex(a) for a in addrs)[:20] if bad else '')
