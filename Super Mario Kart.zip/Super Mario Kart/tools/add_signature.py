#!/usr/bin/env python3
"""Title-screen signature + 2 px shift of Nintendo's "(c)1992 Nintendo" line (USA ROM, built on top of usa_camara_candidato).

usage: add_signature.py in.sfc out.sfc [signature.png]     (default PNG: tools/firma_psicopompo.png)

Signature PNG: max 8 px high, any width up to 256, transparent background, any opaque pixel = white ink.
It is centred horizontally on the 256 px screen; its first inked row is placed at screen row SIG_TOP.

How it works
  * NMI mode-dispatch entry of the title mode ($36=4, 80:81C3, was $8237) points to a small stub at 80:FFA0 which
        JSL draw ; JSR $8237 (original title handler) ; JSL cleanup ; RTS
  * draw    (8B:8800): every 4th frame, if the title text is in the 7F buffer ($7F:2654 == $0CAA) and our first tile is not
            in VRAM yet, DMAs our tiles to VRAM word $2200 (BG tile $220+, palette 3) and three tilemap pieces:
            the signature (tile rows 26 and 27) and the "(c)1992 Nintendo" row (25) rebuilt with 2 px right-shifted tiles.
  * cleanup (8B:8A00): runs right after the title handler; if the handler switched the mode away from 4 (title is being
            left) it zeroes our tiles and puts the original tilemap entries back, inside the same NMI, so loaders never see them.
Screen row s lives in tilemap row (s+1)//8, line (s+1)%8 (BG scroll quirk of the title).
"""
import sys, struct, os

SIG_TOP = 213        # first inked row of the signature (6 blank rows below the (c) line, whose last ink row is 206)
SHIFT = 2            # px to move Nintendo's line to the right
CROW = 25            # tilemap row of the "(c)1992 Nintendo" line
CCOL = 10            # first tile column of that line
TITLE_TEXT = [0xaa, 0xab, 0xac, 0xac, 0xad, 0x8f, 0xae, 0xaf, 0xb0, 0xb1, 0xb2, 0xb3]   # tile ids, as in $7F:2654
TITLE_TILES = {      # original 4bpp tile data (palette 3: ink = colour 15, background = colour 14)
    0xaa: bytes.fromhex("3cff42ff99ffa1ffa1ff99ff42ff3cffffffffffffffffffffffffffffffffff"),
    0xab: bytes.fromhex("0cff1cff0cff0cff0cff0cff0cff1effffffffffffffffffffffffffffffffff"),
    0xac: bytes.fromhex("3cff66ff66ff66ff3eff06ff66ff3cffffffffffffffffffffffffffffffffff"),
    0xad: bytes.fromhex("3cff66ff66ff0eff3cff70ff62ff7effffffffffffffffffffffffffffffffff"),
    0x8f: bytes.fromhex("00ff00ff00ff00ff00ff00ff00ff00ffffffffffffffffffffffffffffffffff"),
    0xae: bytes.fromhex("63ff73ff73ff6bff6bff67ff67ff63ffffffffffffffffffffffffffffffffff"),
    0xaf: bytes.fromhex("60ff60ff00ff6bff6dff6dff6dff6dffffffffffffffffffffffffffffffffff"),
    0xb0: bytes.fromhex("00ff30ff78ff33ffb6ffb7ffb6ffb3ffffffffffffffffffffffffffffffffff"),
    0xb1: bytes.fromhex("00ff00ff00ff96ffdbffdbff1bff9bffffffffffffffffffffffffffffffffff"),
    0xb2: bytes.fromhex("0cff0cff0cff3cff6dff6dff6dff3cffffffffffffffffffffffffffffffffff"),
    0xb3: bytes.fromhex("00ff00ff00ffe0ffb0ffb0ffb0ffe0ffffffffffffffffffffffffffffffffff"),
}
TM = 0x1000          # BG tilemap base (VRAM word)
TILES_W = 0x2200     # our tiles, VRAM word address (= tile $220)
TILE0 = 0x220
DATA = 0xB8000       # file offset of bank 8B:8000
A_DRAW, A_CLEAN = 0x8800, 0x8A00
ZERO_AT = 0x8F00     # two zero bytes (fixed DMA source)
S = 0xFFA0           # stub in bank 80 (16 bytes of 0x00 padding before the header; NOT 0x92F2: that is the $9292 frame table, whose 0xFFFF entries kart frames $60-$70 read)

def w16(x): return struct.pack('<H', x & 0xffff)

class Asm:
    def __init__(s, base): s.b = bytearray(); s.base = base; s.lab = {}; s.fix = []
    def c(s, *bs): s.b.extend(bs)
    def hx(s, h): s.b.extend(bytes.fromhex(h.replace(' ', '')))
    def L(s, n): s.lab[n] = len(s.b)
    def br(s, op, n): s.b.extend([op, 0]); s.fix.append((len(s.b) - 1, n, 'r'))
    def jmp(s, n): s.b.extend([0x4c, 0, 0]); s.fix.append((len(s.b) - 2, n, 'a'))
    def done(s):
        for pos, n, k in s.fix:
            if k == 'r':
                d = s.lab[n] - (pos + 1); assert -128 <= d <= 127, (n, d); s.b[pos] = d & 255
            else: s.b[pos:pos + 2] = w16(s.base + s.lab[n])
        return bytes(s.b)
    def dma(s, vaddr, src, size, fixed=False):
        """channel 0 -> VRAM word vaddr from 8B:src (VMAIN must be $80). Leaves A 8-bit."""
        s.c(0xc2, 0x20, 0xa9, *w16(vaddr), 0x8d, 0x16, 0x21)
        s.c(0xa9, *w16(0x1809 if fixed else 0x1801), 0x8d, 0x00, 0x43)
        s.c(0xa9, *w16(src), 0x8d, 0x02, 0x43)
        s.c(0xa9, *w16(0x8B | (size & 255) << 8), 0x8d, 0x04, 0x43)
        s.c(0xa9, *w16(size >> 8), 0x8d, 0x06, 0x43)
        s.c(0xe2, 0x20, 0xa9, 0x01, 0x8d, 0x0b, 0x42)

def load_png(path):
    from PIL import Image
    im = Image.open(path).convert('RGBA'); w, h = im.size
    assert h <= 8, 'PNG must be at most 8 px high (got %d)' % h
    cols = [[1 if im.getpixel((x, y))[3] >= 128 else 0 for y in range(h)] + [0] * (8 - h) for x in range(w)]
    while cols and not any(cols[0]): cols.pop(0)
    while cols and not any(cols[-1]): cols.pop()
    assert 0 < len(cols) <= 256, 'empty or too wide'
    return cols

def tile_bytes(rows):
    """rows: 8 lists of 8 ink flags (1 = white ink, 0 = transparent) -> 32 bytes of 4bpp (white = colour 5, transparent = 0)."""
    p01 = bytearray(); p23 = bytearray()
    for y in range(8):
        p0 = sum(1 << (7 - i) for i, v in enumerate(rows[y]) if v)
        p01 += bytes([p0, 0]); p23 += bytes([p0, 0])      # colour 5 = planes 0 and 2
    return bytes(p01 + p23)

def build_signature(cols):
    W = len(cols); x0 = (256 - W) // 2
    col0, left = x0 // 8, x0 % 8
    nt = (left + W + 7) // 8
    first = next(y for y in range(8) if any(c[y] for c in cols))
    y0 = SIG_TOP - first                          # screen row of PNG row 0
    rows = {}                                     # tilemap row -> canvas[8][nt*8]
    for k in range(8):
        s = y0 + k; r, y = (s + 1) // 8, (s + 1) % 8
        cv = rows.setdefault(r, [[0] * (nt * 8) for _ in range(8)])
        for x, c in enumerate(cols): cv[y][left + x] = c[k]
    assert len(rows) <= 2, rows.keys()
    out = {}
    for r, cv in sorted(rows.items()):
        out[r] = [tile_bytes([cv[y][t * 8:t * 8 + 8] for y in range(8)]) for t in range(nt)]
    return out, col0, nt, x0, W

def shifted_title():
    """Nintendo's line moved SHIFT px right: one extra tile; incoming pixels are transparent (colour 0)."""
    ids = TITLE_TEXT; n = len(ids)
    src = [TITLE_TILES[i] for i in ids] + [bytes(32)]
    out = []
    for k in range(n + 1):
        prev = src[k - 1] if k else bytes(32)
        out.append(bytes((((prev[i] << (8 - SHIFT)) & 255) | (src[k][i] >> SHIFT)) for i in range(32)))
    return out

def main():
    srcp, dst = sys.argv[1], sys.argv[2]
    png = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'firma_psicopompo.png')
    r = bytearray(open(srcp, 'rb').read())
    sig, col0, nt, x0, W = build_signature(load_png(png))
    tl = shifted_title()
    nct = len(tl)
    rws = sorted(sig)
    for rr in rws: tl = tl + sig[rr]
    tiles = b''.join(tl)
    ntiles = len(tiles) // 32
    # tilemap pieces
    ent_c = b''.join(w16(0x0C00 | (TILE0 + j)) for j in range(nct))
    ent_s = {}
    for i, rr in enumerate(rws): ent_s[rr] = b''.join(w16(0x0C00 | (TILE0 + nct + i * nt + t)) for t in range(nt))
    orig_c = b''.join(w16(0x0C00 | t) for t in TITLE_TEXT) + w16(0x00D9)
    blank = w16(0x00D9) * nt
    # data block in bank 8B
    assert len(r) >= 0x100000 and not any(r[DATA:DATA + 0x1000]), 'data area not free'
    off = 0; pos = {}
    for name, blob in (('tiles', tiles), ('ent_c', ent_c), ('orig_c', orig_c), ('blank', blank)) + tuple(('ent_s%d' % rr, ent_s[rr]) for rr in rws):
        pos[name] = 0x8000 + off; r[DATA + off:DATA + off + len(blob)] = blob; off += len(blob)
    assert off < 0x800
    r[DATA + (ZERO_AT - 0x8000):DATA + (ZERO_AT - 0x8000) + 2] = b'\0\0'
    first = struct.unpack('<H', tiles[0:2])[0]
    assert first != 0
    # ---- draw routine (RTL) ----
    a = Asm(A_DRAW)
    a.hx('e220 a534 2903'); a.br(0xf0, 'go'); a.jmp('out'); a.L('go')                     # SEP #$20 ; LDA $34 ; AND #3 ; BEQ go ; JMP out
    a.hx('af54267f c9aa'); a.br(0xf0, 'txt'); a.jmp('out'); a.L('txt')                    # title text buffer present?
    a.hx('a980 8d1521 c220 a90022 8d1621 ad3921 c9' + struct.pack('<H', first).hex() + ' e220')   # VMAIN ; VMADD=$2200 ; sentinel
    a.br(0xd0, 'draw'); a.jmp('out'); a.L('draw')
    a.dma(TILES_W, pos['tiles'], len(tiles))
    a.dma(TM + CROW * 32 + CCOL, pos['ent_c'], len(ent_c))
    for rr in rws: a.dma(TM + rr * 32 + col0, pos['ent_s%d' % rr], nt * 2)
    a.L('out'); a.hx('c230 6b')                                                           # REP #$30 ; RTL
    code_draw = a.done()
    # ---- cleanup routine (RTL) ----
    b = Asm(A_CLEAN)
    b.hx('e220 af360000 c904'); b.br(0xd0, 'doit'); b.hx('c230 6b'); b.L('doit')
    b.hx('a980 8d1521')                                                                   # VMAIN=$80
    b.dma(TILES_W, ZERO_AT, len(tiles), fixed=True)
    b.dma(TM + CROW * 32 + CCOL, pos['orig_c'], len(orig_c))
    for rr in rws: b.dma(TM + rr * 32 + col0, pos['blank'], nt * 2)
    b.hx('c230 6b')
    code_clean = b.done()
    assert len(code_draw) < 0x200 and len(code_clean) < 0x200, (len(code_draw), len(code_clean))
    r[DATA + (A_DRAW - 0x8000):DATA + (A_DRAW - 0x8000) + len(code_draw)] = code_draw
    r[DATA + (A_CLEAN - 0x8000):DATA + (A_CLEAN - 0x8000) + len(code_clean)] = code_clean
    # ---- bank 80 stub ----
    v = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'roms', 'Super Mario Kart (USA).sfc'), 'rb').read()
    assert all(x == 0 for x in r[S:S + 16]) and all(x == 0 for x in v[S:S + 16])
    stub = b'\xea' * int(os.environ.get('SIGNOPS', '0'))
    stub += bytes([0x22, A_DRAW & 255, A_DRAW >> 8, 0x8b])          # JSL draw
    stub += bytes.fromhex('c230 203782')                              # REP #$30 ; JSR $8237 (original title handler)
    stub += bytes([0x22, A_CLEAN & 255, A_CLEAN >> 8, 0x8b])        # JSL cleanup
    stub += bytes.fromhex('60')                                       # RTS
    r[S:S + len(stub)] = stub
    assert bytes(r[0x81C3:0x81C5]) == bytes.fromhex('3782')          # mode-4 NMI entry (title)
    r[0x81C3:0x81C5] = w16(S)
    open(dst, 'wb').write(r)
    print('signature %d px wide at x=%d..%d, tile col %d, %d tiles/row, rows %s; title line +%d px; tiles %d (%d bytes); draw %d B, cleanup %d B, stub %d B'
          % (W, x0, x0 + W - 1, col0, nt, rws, SHIFT, ntiles, len(tiles), len(code_draw), len(code_clean), len(stub)))

main()
