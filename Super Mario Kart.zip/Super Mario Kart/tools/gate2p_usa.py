#!/usr/bin/env python3
"""Post-proceso: hace que TODOS los parches del hack fullscreen solo actuen en 1 jugador.

Criterio de 1P: `$7E:00AA == $1000` (base del kart que sigue la vista inferior; la carga de carrera pone `$1000` en 1P y
`$1100` en 2P; en el arranque/menus vale 0 -> vanilla). En 2P (y en cualquier otro caso) el codigo ejecutado es el ORIGINAL
de la ROM USA.

Cada sitio parcheado se sustituye por `JSL/JML gate` y el gate elige, sin alterar registros ni flags:
  * 1P: los bytes del hack (o salto a su stub)   * resto: los bytes vanilla desplazados.

uso: gate2p.py entrada.sfc salida.sfc    (entrada = candidato sin gate; vanilla = roms/Super Mario Kart (Europe).sfc)"""
import sys
from pathlib import Path
R = Path(__file__).resolve().parents[1]
src = Path(sys.argv[1]); dst = Path(sys.argv[2])
C = bytearray(src.read_bytes())
V = (R / 'roms' / 'Super Mario Kart (USA).sfc').read_bytes()

def cpu(off): return (0x80 + (off >> 16), off & 0xFFFF)
def jsl(off): b, a = cpu(off); return bytes([0x22, a & 255, a >> 8, b])
def jml(off): b, a = cpu(off); return bytes([0x5C, a & 255, a >> 8, b])
def ofs(bank, addr): return (bank - 0x80) * 0x10000 + addr

class Area:
    def __init__(s, start, size): s.p = start; s.end = start + size
    def put(s, code):
        assert s.p + len(code) <= s.end, 'sin sitio'
        assert set(C[s.p:s.p + len(code)]) in ({0}, {0xFF}), 'area no libre %06X' % s.p
        a = s.p; C[a:a + len(code)] = code; s.p += len(code); return a
A88 = Area(0x88800, 0x700)           # banco $88 libre desde $8800
A80 = Area(0x092D9, 0x100)           # $80:92D9..93D8 (256 bytes FF de relleno en la ROM original)

# Criterio de 1P = $7E:00AA == $1000 Y NO creditos/THE END ($36 & $EF == $0C). En los creditos el kart seguido ($00AA) cambia y a ratos
# vale $1000: el gate activaba el hack en mitad de la pantalla de creditos (texto inferior perdido, silueta del mapa, escena final rota).
# Rutinas comunes en el banco $88 (devuelven Z=1 si hay que usar el hack). Ocupan lo mismo que el criterio antiguo (relleno NOP) para
# NO mover las direcciones de las puertas (hay states guardados dentro de ellas).
CHK16 = 0x88F00; CHK8 = 0x88F30
def put_at(off, code):
    assert set(C[off:off + len(code)]) == {0}, hex(off); C[off:off + len(code)] = code
# 1P = $00AA==$1000 Y estamos en CARRERA: modo $36 == $02, o en la carga de la carrera ($36 == $00 con modo pendiente $32 == $02).
# Lista blanca (antes se excluian solo los creditos): $00AA conserva el $1000 de la ultima carrera en los creditos, los menus de Time Trial, la clasificacion...
# y el hack ahi dejaba artefactos / parpadeos. Fuera de carrera el codigo ejecutado es el vanilla.
# M=16: LDA $7E00AA ; CMP #$1000 ; BNE no ; LDA $36&$FF ; CMP #2 ; BEQ yes ; CMP #0 ; BNE no ; LDA $32&$FF ; CMP #2 ; BNE no ; yes: LDA #0 ; RTS ; no: LDA #1 ; RTS   (Z=1 -> hack)
put_at(CHK16, bytes.fromhex('AF AA 00 7E C9 00 10 D0 21 AF 36 00 7E 29 FF 00 C9 02 00 F0 11 C9 00 00 D0 10 AF 32 00 7E 29 FF 00 C9 02 00 D0 04 A9 00 00 60 A9 01 00 60'))
# M=8:  LDA $AB ; CMP #$10 ; BNE no ; LDA $36 ; CMP #2 ; BEQ yes ; CMP #0 ; BNE no ; LDA $32 ; CMP #2 ; BNE no ; yes: LDA #0 ; RTS ; no: LDA #1 ; RTS
put_at(CHK8, bytes.fromhex('A5 AB C9 10 D0 13 A5 36 C9 02 F0 0A C9 00 D0 09 A5 32 C9 02 D0 03 A9 00 60 A9 01 60'))
def jsrchk(off): return bytes([0x20, off & 255, (off >> 8) & 255])
PRO = bytes.fromhex('08 C2 20 48') + jsrchk(CHK16) + bytes([0xEA] * 4)   # PHP REP#20 PHA JSR chk16 (BEQ -> 1P)
def gate(code_2p, code_1p, area=A88):
    """BEQ -> 1P. code_2p / code_1p incluyen su instruccion de salida. devuelve direccion (offset fichero)"""
    a2 = bytes.fromhex('68 28') + code_2p
    a1 = bytes.fromhex('68 28') + code_1p
    body = PRO + bytes([0xF0, len(a2)]) + a2 + a1
    return area.put(body)

sites = []   # para el informe
def inline(site, n, area=A88, same=False):
    """ventana de n bytes (>=4) con bytes distintos vanilla/hack, sin ramas ni JSR salvo area bank80"""
    assert n >= 4
    v = V[site:site + n]; h = bytes(C[site:site + n])
    assert same or v != h, hex(site)
    print('  inline %06X  van %s | hack %s' % (site, v.hex(' '), h.hex(' ')))
    g = gate(v + b'\x6B', h + b'\x6B', area)
    if same:   # vanilla == hack: el gate ya no hace nada. Se conserva el stub (direcciones) pero el sitio queda con los bytes vanilla: sin coste de ciclos en NMI/IRQ
        C[site:site + n] = v; sites.append(('same', site, n)); return
    C[site:site + n] = jsl(g) + bytes([0xEA] * (n - 4)); sites.append(('inline', site, n))

def jmlwin(site, n, area):
    """ventana de n bytes (fin de instruccion, 4 <= n) cuyo hack son bytes inmediatos distintos; el gate ejecuta las instrucciones (vanilla o hack) y vuelve con JML
    (sirve con PHA/PHY dentro de la ventana: no hay direccion de retorno en la pila)."""
    v = V[site:site + n]; h = bytes(C[site:site + n]); assert v != h, hex(site)
    g = gate(v + jml(site + n), h + jml(site + n), area)
    C[site:site + n] = jml(g) + bytes([0xEA] * (n - 4)); sites.append(("jmlwin", site, n))

def jslhook(site, n):
    """el hack tiene `JSL stub` en site (+NOPs). vanilla = bytes de la ventana."""
    assert C[site] == 0x22, hex(site)
    stub = ofs(C[site + 3], C[site + 1] | C[site + 2] << 8)
    v = V[site:site + n]
    g = gate(v + b'\x6B', jml(stub))
    C[site:site + 4] = jsl(g); sites.append(('jsl', site, n))

def retarget(site, vanilla_target):
    """`JSL hack` en site, vanilla era `JSL vanilla_target`"""
    assert C[site] == 0x22
    stub = ofs(C[site + 3], C[site + 1] | C[site + 2] << 8)
    g = gate(jml(vanilla_target), jml(stub))
    C[site:site + 4] = jsl(g); sites.append(('retarget', site, 4))

def jmlhook(site, v, back, other_1p=None):
    """el hack tiene `JML stub` en site; v = instrucciones vanilla desplazadas; back = donde continua el vanilla"""
    assert C[site] == 0x5C
    stub = ofs(C[site + 3], C[site + 1] | C[site + 2] << 8)
    g = gate(v + jml(back), jml(other_1p if other_1p is not None else stub))
    C[site:site + 4] = jml(g); sites.append(('jml', site, len(v)))

# ---------- NMI / PPU (base) ----------
# ---------- NMI / PPU (base) ----------
# (El banco $80 no tiene espacio libre: los 256 bytes FF de $80:92D9 son una TABLA que el juego lee -> no usarlos.)
# 0x8AC5 $420C HDMAEN: ahora $FE tambien en 1P (canal 7 = ventanas del digito de puesto). Las 3 puertas siguientes ya no cambian nada
# (vanilla = hack) pero se mantienen para no mover las direcciones de las demas puertas: los states guardados con el candidato
# anterior pueden estar parados dentro de ellas y se colgarian.
# (El bug de la pantalla negra al cambiar de vuelta se resuelve copiando los colores x=0 a x=1 en 1P: ver $88:9000 en build_eu_camara.py.)
inline(0x8AC5, 5, same=True)
inline(0x8B42, 6)                                  # STY $2100 ; STX $2101
inline(0x8B4D, 5)                                  # LDA $D6 ; STA $211A
inline(0x8BBF, 6, same=True); inline(0x8BD7, 6, same=True); inline(0x8BE0, 6, same=True)   # STA $212E / LDA $017A,x (ahora vanilla tambien en 1P; el gate se queda para no mover direcciones)
# $80:8B40 (11 bytes): vanilla = JSR $8709 ; LDX #1 ; JSR $8BA4 ; JSR $9461 ; hack = LDX #1 ; JSR $8BA4.
# Las JSR son del banco $80 y no hay sitio alli: el gate vive en el banco $88 y llama a las rutinas del $80 con PEA + JML;
# el retorno (RTS) cae en un rebote `JML K` de 4 bytes guardado en la propia ventana ($80:8B46). Selector apilado bajo el retorno.
assert bytes(C[0x8B67:0x8B72]) == bytes.fromhex('EA EA EA A2 01 20 BF 8B EA EA EA') and V[0x8B72] == 0x60
def pea(v): return bytes([0xF4, v & 255, v >> 8])
RET = 0x8B6C                                       # RTS -> $8B46 (rebote)
def call80(sel, target): return bytes([0xA9, sel, 0x48]) + pea(RET) + jml(ofs(0x80, target))
kA = bytes([0xA2, 0x01]) + call80(2, 0x8BBF)       # tras $8709 (2P): LDX #1 ; JSR $8BA4
kB = call80(3, 0x947A)                              # tras $8BA4 (2P): JSR $9461
# K: SEP #$20 ; PLA ; CMP #1 ; BEQ kA ; CMP #2 ; BEQ kB ; CMP #3 ; BNE fin ; REP #$30 ; fin: RTL
#   (tras $9461 el vanilla deja M=0,X=0 -> selector 3 restaura REP #$30; selector 4 = fin 1P, anchos del hack)
K = A88.put(bytes([0xE2, 0x20, 0x68, 0xC9, 0x01, 0xF0, 0x0B, 0xC9, 0x02, 0xF0, 7 + len(kA), 0xC9, 0x03, 0xD0, 0x02, 0xC2, 0x30, 0x6B]) + kA + kB)
g40 = A88.put(jsrchk(CHK8) + bytes([0xEA, 0xF0, 0x0A]) + call80(1, 0x8709) + bytes([0xA2, 0x01]) + call80(4, 0x8BBF))
# nota: 1P = LDX #1 ; JSR $8BA4 (selector 4 = fin) ; 2P = JSR $8709 (selector 1 -> kA -> kB)
C[0x8B67:0x8B72] = jsl(g40) + bytes.fromhex('80 05') + jml(K) + b'\xEA'
sites.append(('custom', 0x8B67, 11))

# ---------- bucle principal ----------
retarget(0x8056, ofs(0x81, 0xE067))                # barrido de OAM (Y=$E0 -> $F0, sombra)
assert C[0x805C] == 0x5C
g0 = A88.put(bytes.fromhex('A5 44 F0 FC') + jsrchk(CHK16) + bytes([0xEA] * 4) + bytes.fromhex('F0 04 5C 60 80 80') + jml(0x88004))
C[0x805C:0x8060] = jml(g0); sites.append(('main', 0x805C, 4))

# ---------- camara ----------
jslhook(0xACB6, 4)
jslhook(0xACC0, 6); jslhook(0xACC6, 6)
jslhook(0xAD0B, 5); jslhook(0xAD20, 5)
# ---------- sprites del kart y objetos ----------
jslhook(0xCEC5, 5); jslhook(0xCEE5, 5)
jslhook(0xD5BB, 24)                                # chispas de contacto
jmlhook(0xD67C, bytes.fromhex('A9 73 66'), ofs(0x80, 0xC930))   # LDA #$6673 ; RTS (RTS existente en $80:C955)
jmlhook(0xD680, bytes.fromhex('A9 8D 66'), ofs(0x80, 0xC930))
jslhook(0xDE7C, 5); jslhook(0xDEAA, 5)             # kart saltando/cayendo
retarget(0x1A9EA, ofs(0x80, 0xC056))               # explosion
# ---------- ventanas de descarte / escalas ----------
inline(0xC86E, 5)                                  # ADC $98 -> ADC $E0
jmlhook(0xC87C, bytes.fromhex('C9 00 03 85 18'), ofs(0x80, 0xC881))
inline(0xC887, 6)
jmlhook(0xC93A, bytes.fromhex('ED 00 60 85 1E 95 2E'), ofs(0x80, 0xC941))
inline(0xC998, 6); inline(0xC9C2, 6); inline(0xCA0D, 6)
inline(0xED81, 6); inline(0xEDAB, 6)
inline(0xD6DE, 6); inline(0xD753, 6)
inline(0x19702, 7)                                 # colision con obstaculos (clave de profundidad)
# Menu RETRY/END: constantes de posicion (Y,X) $3060->$6847, $4060->$7847, $2C9C->$6483 solo en 1P (en 2P cada jugador tiene su menu en su mitad: vanilla)
_AR = Area(0x88F60, 0xA0)
jmlwin(0x1A88C, 11, _AR); jmlwin(0x1A8CA, 6, _AR)
# ---------- HUD / OAM alta ----------
inline(0x1BC59, 5)                                 # $0406/$0626 = $55 (vanilla) / $00
inline(0x4EA2E, 5)                                 # $2123 = $FF / $00
jmlhook(0x1FAD6, bytes.fromhex('48 65 90 8D 44 06'), ofs(0x81, 0xFADC))
jmlhook(0x1FAE8, bytes.fromhex('65 90 8D 5E 06'), ofs(0x81, 0xFAED))
# $81:FAC0 (rutina de tablas de la vista P2): el hack la convirtio en RTS
assert C[0x1FAF6] == 0x60 and V[0x1FAF6] == 0xE2
g = gate(bytes.fromhex('E2 30 A9 40') + jml(0x1FAFA), jml(0x1FAF5))
C[0x1FAF6:0x1FAFA] = jml(g); sites.append(('jml', 0x1FAF6, 4))


# ---------- estaticos que quedaban: umbral de ocultar kart y datos de Lakitu ----------
def reserve(site, n):
    """hueco de puerta SIN instalar (mantiene las direcciones de las demas puertas) y el sitio vuelve a vanilla"""
    v = V[site:site + n]; h = bytes(C[site:site + n])
    gate(v + b'\x6B', h + b'\x6B'); C[site:site + n] = v
# CMP $0FBA (vanilla) / CMP #$0300 (hack): ahora $0FBA vale $0300 en 1P (lo escribe el barrido del bucle principal) y el codigo es vanilla
reserve(0xC714, 5)
reserve(0xC737, 5)
# Lakitu (bytes del hack revertidos a vanilla y aplicados en 1P desde el codigo que los lee)
for o, b in ((0x5DC03, 0xF0), (0x5DC2B, 0xF0), (0x5DC5F, 0xF0), (0x5DF6D, 0xF0)):
    assert V[o] == b and C[o] == 0xFF
    C[o] = b
assert V[0x5DD6C] == 0xA0 and C[0x5DD6C] == 0x90
C[0x5DD6C] = 0xA0
# handler $85:DDA0 (x/y de Lakitu): byte alto de Y $F0 -> $FF
assert bytes(C[0x5DDAB:0x5DDB0]) == bytes.fromhex('B9 03 00 95 21')
g = gate(bytes.fromhex('B9 03 00 95 21 6B'), bytes.fromhex('B9 03 00 C9 F0 D0 02 A9 FF 95 21 6B'))
C[0x5DDAB:0x5DDB0] = jsl(g) + b'\xEA'; sites.append(('inline', 0x5DDAB, 5))
# handler $85:DE30 (espera): la entrada de $DD6A espera $90 en vez de $A0 (M=0, X=0)
assert bytes(C[0x5DE32:0x5DE37]) == bytes.fromhex('B9 02 00 95 0C')
g = gate(bytes.fromhex('B9 02 00 95 0C 6B'), bytes.fromhex('B9 02 00 C0 6A DD D0 03 A9 90 00 95 0C 6B'))
C[0x5DE32:0x5DE37] = jsl(g) + b'\xEA'; sites.append(('inline', 0x5DE32, 5))
# $85:DF69: BPL ; CMP #$F000 (vanilla) / #$FF00 (hack) ; BCS  -> salida
assert bytes(C[0x5DF69:0x5DF70]) == bytes.fromhex('10 0A C9 00 F0 B0 05')
code = bytes.fromhex('10 1A 48 AF AA 00 7E C9 00 10 F0 06 68 C9 00 F0 80 04 68 C9 00 FF B0 04') + jml(0x5DF70) + jml(0x5DF75)
# comprobacion de saltos: BPL(0)->0x1C ; BEQ(0xA)->0x12 ; BRA(0x10)->0x16 ; BCS(0x16)->0x1C
assert len(code) == 0x20 and code[0x16] == 0xB0
a = A88.put(code)
C[0x5DF69:0x5DF70] = jml(a) + b'\xEA\xEA\xEA'; sites.append(('jml', 0x5DF69, 7))

# ---------- cobertura: lo que queda distinto de vanilla fuera del banco $88 debe ser la lista estatica ----------
left = []
i = 0
while i < len(V):
    if V[i] != C[i]:
        j = i
        while j < len(V) and V[j] != C[j]: j += 1
        left.append((i, j - i)); i = j
    else: i += 1
def ad(o): return '%02X:%04X' % (0x80 + (o >> 16), o & 0xFFFF)
STATIC = {0x8057: 'cabecera/relleno (hook 8056..805F)', 0xFFD7: 'cabecera tamano ROM', 0x1FAF6: 'jml'}
print('gates:', len(sites), ' bytes libres banco88: %d, banco80: %d' % (A88.end - A88.p, A80.end - A80.p))
print('diferencias vanilla restantes (deben ser solo JSL/JML a gates, relleno de aparcado y datos de ROUND 1):')
for o, l in left: print('  ', ad(o), '+%d' % l, V[o:o + l].hex()[:20], '->', bytes(C[o:o + l]).hex()[:30])
retarget(0x806E, ofs(0x84, 0xECC0))                # tabla HDMA del digito de puesto (1P: lineas 172..191, sin ventana completa)
inline(0xEC73, 5)                                  # sombra de Mario (MVN del buffer $7F:DF00 al OAM + s en 1P): al FINAL para no mover las demas puertas
# Creditos: "HIDEQUI KONNO" -> "HIDEKI KONNO " (mismo largo; tiles 16 bit: codigo par + atributo $0A)
_o = 0x3FA60
_old = b''.join(bytes([c, 0x0A]) for c in (0xAE,0xB0,0xA6,0xA8,0xC0,0xC8,0xB0,0x8F,0xB4,0xBC,0xBA,0xBA,0xBC))
_new = b''.join(bytes([c, 0x0A]) for c in (0xAE,0xB0,0xA6,0xA8,0xB4,0xB0,0x8F,0xB4,0xBC,0xBA,0xBA,0xBC,0x8F))
assert bytes(C[_o:_o+26]) == _old
C[_o:_o+26] = _new
dst.write_bytes(C)
print('escrito', dst)
