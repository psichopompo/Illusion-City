#!/usr/bin/env python3
"""Sombra de Lakitu en el rescate (1P pantalla completa).
uso: lakitu_sombra.py in.sfc out.sfc
La sombra de Lakitu son 3 sprites en los slots OAM 124-126 con Y fija = $5A (suelo de la camara original). Con la camara mas
cercana el suelo (y la ondulacion de Mario en el agua, la sombra de Mario...) queda 88 px mas abajo, pero esa Y no se movia:
la sombra se quedaba en el aire. Durante el rescate ($7E:1C30 == $0E) se suma $58 a esa Y al final del fotograma, dentro del
barrido ya existente (88:9197 'JSR $9400' -> 'JSR $9A00'). Es idempotente ($5A -> $B2)."""
import sys
r=bytearray(open(sys.argv[1],'rb').read())
S=0x89A00; SH=0x58
assert not any(r[S:S+0x80]), 'area no libre'
assert bytes(r[0x89197:0x8919A])==bytes([0x20,0x00,0x94])
code=bytearray([0x20,0x00,0x94, 0x08,0xE2,0x20,                       # JSR $9400 ; PHP ; SEP #$20
                0xAF,0x30,0x1C,0x7E, 0xC9,0x0E, 0xF0,0x03, 0x4C,0x00,0x00])   # LDA $7E1C30 ; CMP #$0E ; BEQ +3 ; JMP end (parcheado)
for y in (0x03F1,0x03F5,0x03F9):
    code+=bytes([0xAF,y&0xFF,y>>8,0x00, 0xC9,0x5A, 0xD0,0x06, 0xA9,0x5A+SH, 0x8F,y&0xFF,y>>8,0x00])
end=0x9A00+len(code)
code[15:17]=bytes([end&0xFF,end>>8])
code+=bytes([0x28,0x60])
r[S:S+len(code)]=code
r[0x89197:0x8919A]=bytes([0x20,0x00,0x9A])
open(sys.argv[2],'wb').write(r); print('bytes',len(code))
