#!/usr/bin/env python3
"""perfdiff.py romA stateA a0 a1 romB stateB b0 b1 [granularidad hex]: diferencia de ciclos por BLOQUE y por fotograma de logica (A - B)."""
import sys, os, subprocess, shutil
from collections import defaultdict
def run(rom, st, f0, f1):
    d = '/tmp/pd_%d' % os.getpid(); shutil.rmtree(d, True); os.makedirs(d)
    env = dict(os.environ, HIST='%d,%d' % (f0, f1), WLOG='100,4')
    subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(f1 + 2), '/tmp/acc.txt', d, '0'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    h = defaultdict(int)
    for l in open(d + '/hist.txt'):
        if l[0] == '#': continue
        a, k, c = l.split(); h[int(a, 16)] += int(c)
    w = [x.split()[1:] for x in open(d + '/wlog.txt')]
    stall = sum(1 for i in range(f0 + 1, f1 + 1) if w[i] == w[i - 1])
    shutil.rmtree(d, True)
    logic = (f1 - f0) - stall
    idle = sum(v for a, v in h.items() if 0x888900 <= a < 0x888940 or 0x808040 <= a < 0x808080)
    return {a: v / logic for a, v in h.items() if not (0x888900 <= a < 0x888940 or 0x808040 <= a < 0x808080)}, logic
A, la = run(sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))
B, lb = run(sys.argv[5], sys.argv[6], int(sys.argv[7]), int(sys.argv[8]))
m = int(sys.argv[9], 16) if len(sys.argv) > 9 else 0x100
def grp(D):
    g = defaultdict(float)
    for a, v in D.items(): g[a & ~(m - 1)] += v
    return g
ga, gb = grp(A), grp(B)
print('total A %.0f B %.0f clk/fotograma de logica (A %d, B %d fotogramas)' % (sum(ga.values()), sum(gb.values()), la, lb))
rows = sorted(((ga.get(k, 0) - gb.get(k, 0), ga.get(k, 0), gb.get(k, 0), k) for k in set(ga) | set(gb)), reverse=True)
print('A mayor que B'); [print('  %06X %+8.0f  (A %7.0f  B %7.0f)' % (k, d, a, b)) for d, a, b, k in rows[:18]]
print('B mayor que A'); [print('  %06X %+8.0f  (A %7.0f  B %7.0f)' % (k, d, a, b)) for d, a, b, k in rows[-8:]]
