#!/usr/bin/env python3
# barrido: pone a cero [lo,lo+st) de WRAM en cada fotograma y compara el fotograma 30 con /tmp/n0/f0030.ppm
import subprocess,re,os,sys
from PIL import Image
def rd(p):
    d=open(p,'rb').read(); m=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',d); return Image.frombytes('RGB',(int(m.group(1)),int(m.group(2))),d[m.end():])
a=rd('/tmp/n0/f0030.ppm')
lo0,hi0,st=int(sys.argv[1],16),int(sys.argv[2],16),int(sys.argv[3],16)
rom=sys.argv[4] if len(sys.argv)>4 else 'roms/usa_camara_candidato.sfc'
for lo in range(lo0,hi0,st):
    subprocess.run('rm -rf /tmp/sc; mkdir /tmp/sc',shell=True)
    env=dict(os.environ,LO=str(lo),HI=str(lo+st),ZERO='1',NEGALL='1',NEG='0,1',SNAPS='30')
    subprocess.run(['/tmp/drive','cores/bsnes_prof.so',rom,'states/MonedaDesp_payload.bin','31','/tmp/r.txt','/tmp/sc','1'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try: b=rd('/tmp/sc/f0030.ppm')
    except Exception: print(hex(lo),'crash'); continue
    ys=[y for y in range(224) if any(a.getpixel((x,y))!=b.getpixel((x,y)) for x in range(0,256,2))]
    if ys: print(hex(lo),len(ys),ys[0],ys[-1],flush=True)
