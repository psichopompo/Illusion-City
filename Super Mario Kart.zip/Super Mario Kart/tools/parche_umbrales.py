#!/usr/bin/env python3
"""Parchea la tabla de UMBRALES DE TAMAÑO de los karts (11 palabras en ROM, $81:$DD35 = file 0xDD35).

Mecanismo (medido):
  * Cada kart tiene una métrica de profundidad en +$06 (≈ 3.3·(fila_en_pantalla − 23);
    el jugador la tiene fija en 552).
  * El índice de banda = primera entrada de la tabla cuyo valor <= métrica (recorrido descendente).
  * Esa banda elige a la vez: (a) el registro de arte (offsets enteros de los 4 sprites)
    y (b) el propio valor (offset sub-píxel / ajuste fino del tamaño).
  * Con la tabla original los 11 umbrales se apiñan en las filas 33-91: la reducción
    arranca tarde y colapsa en 8 filas.
Escalar la tabla desplaza TODOS los escalones hacia filas más cercanas a Mario
(los mismos tamaños, usados más cerca), repartiendo la reducción.

Uso: python3 tools/parche_umbrales.py entrada.sfc salida.sfc [factor]
"""
import sys
V13=[224,192,160,128,112,96,80,64,48,32,0]
def main():
    src,dst=sys.argv[1],sys.argv[2]
    f=float(sys.argv[3]) if len(sys.argv)>3 else 1.5
    rom=bytearray(open(src,'rb').read())
    vals=[min(448,int(round(t*f))) for t in V13[:-1]]+[0]
    for i in range(1,len(vals)-1):
        if vals[i]>=vals[i-1]: vals[i]=vals[i-1]-8
    for i,t in enumerate(vals):
        rom[0xDD35+2*i]=t&0xff; rom[0xDD36+2*i]=t>>8
    open(dst,'wb').write(bytes(rom))
    print("origen :", V13)
    print("nuevo  :", vals)
    print("filas aprox. de cada escalon (3.3*(fila-23)):", [round(t/3.3+23) for t in vals])
if __name__=='__main__': main()
