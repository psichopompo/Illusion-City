import os
#!/usr/bin/env python3
"""Camara de carrera mas cercana + sprite de P1 coherente, con rampa (sin salto en el paso intro->carrera).

Idea (ingenieria inversa, USA/EU): la camara del DSP-1 tiene foco F = 4*posicion del kart (Fx=$88,Fy=$8C) y el punto
de suelo del foco cae en la fila $9C-1 (=101). Si se envia al DSP un foco desplazado R unidades-F hacia delante
(a lo largo de Aas=$94), el kart REAL queda mas abajo en pantalla y suelo, sombra, colisiones y rivales siguen
siendo coherentes (todo se proyecta respecto al mismo foco).
El desplazamiento se aplica SOLO a la copia que va al DSP y al calculo de centro Mode 7 (CODE_80ACB6: camara de
carrera), no a $88/$8C (en la intro F es acumulativo). Se aplica solo en modo seguimiento ($A4,x==2 o $AC,x<0,
misma condicion que $8086A0), con una rampa de N pasos; en cada paso el sprite de P1 baja S[n] filas y la camara
R[n] unidades-F, de modo que sprite y suelo bajan juntos.
WRAM scratch (libre en todas las fases probadas): $7E:0A80 dx, 0A82 dy, 0A84 n(paso*2), 0A86 s (desplazamiento Y del sprite).
"""
import sys, json
N = 36; S_MAX = 88; DELTA = 42.7
DF_MAX = float(os.environ.get('SMK_DF', '12'))   # v1.2: desplazamiento extra del centro Mode 7 (suelo) respecto al foco del DSP (sprites), en unidades de mundo   # pasos, filas de bajada del sprite, distancia barra->kart (unidades F)
BAR = {0:95,0x10:97,0x20:99,0x30:102,0x40:105,0x50:108,0x60:111,0x70:114,0x80:118,0x90:122,0xA0:126,0xB0:130,
       0xC0:135,0xD0:140,0xE0:146,0xF0:153,0x100:161,0x110:169,0x120:177,0x130:188,0x140:200}
def inv(row):
    xs = sorted(BAR)
    for a, b in zip(xs, xs[1:]):
        if BAR[a] <= row <= BAR[b]:
            return a + (row - BAR[a]) * (b - a) / (BAR[b] - BAR[a])
    raise ValueError(row)
# V(R): fila (respecto a la del kart en la intro) a la que proyecta el DSP la posicion REAL del kart al desplazar el foco R
# unidades-F (medida con el stub DBGKEY en USA; Project del propio kart, X=4*$18 Y=4*$1C). Hay que cumplir V(R[n]) == S[n].
VR = [(0,0),(20,3),(40,8),(60,13),(80,18),(100,25),(120,32),(140,40),(160,50),(180,62),(200,75),(210,83),(220,93),(230,102),
      (240,114),(250,126),(262,144),(300,225)]
def invV(v):
    for (r0, v0), (r1, v1) in zip(VR, VR[1:]):
        if v0 <= v <= v1: return r0 + (v - v0) * (r1 - r0) / (v1 - v0)
    raise ValueError(v)
def dtable():
    """D[n] (unidades F = 4*mundo): extra del centro Mode 7. Crece con el cuadrado de la rampa (el desajuste suelo/sprites crece asi)."""
    return [round(4 * DF_MAX * (n / N) ** 2) for n in range(N + 1)]
def tables():
    S, R = [], []
    for n in range(N + 1):
        s = round(S_MAX * n / N)
        S.append(s)
        R.append(round(invV(s)))
    return S, R
class A:
    def __init__(s): s.b = bytearray(); s.lab = {}; s.fix = []
    def raw(s, *v): s.b += bytes(v); return s
    def label(s, n): s.lab[n] = len(s.b); return s
    def br(s, op, n): s.b += bytes([op, 0]); s.fix.append((len(s.b) - 1, n)); return s
    def done(s):
        for p, n in s.fix:
            d = s.lab[n] - (p + 1); assert -128 <= d <= 127, (n, d); s.b[p] = d & 0xFF
        return bytes(s.b)
def jsl(a): return bytes([0x22, a & 0xFF, (a >> 8) & 0xFF, 0x88])
W = lambda a: (0x8F, a & 0xFF, a >> 8, 0x7E)        # STA long $7E:a
L = lambda a: (0xAF, a & 0xFF, a >> 8, 0x7E)        # LDA long $7E:a
NEG=(False,True)   # negar R*sin / R*cos (valores finales se fijan abajo)
RF_ADDR = 0x88D80; TD_ADDR = 0x88DC0   # rutina del extra del centro y su tabla (bloque libre de 0x180 bytes en el banco $88)
def build_rf(tabR, tabD):
    """JSL desde la rutina de camara (A,X de 16 bits; X = 2n): dxf,dyf = (R[n]+D[n]) * (sin,cos Aas) en $0A8C/$0A8E."""
    a = A()
    a.raw(0xE2, 0x20, 0xA9, 0x04, 0x8F, 0, 0x60, 0, 0xC2, 0x20)         # DSP cmd $04 (trig)
    a.raw(0xA5, 0x94, 0x8F, 0, 0x60, 0)                                 # angulo Aas
    a.raw(0xBF, tabR & 0xFF, (tabR >> 8) & 0xFF, 0x88)                  # LDA R[n]
    a.raw(0x18, 0x7F, tabD & 0xFF, (tabD >> 8) & 0xFF, 0x88)            # CLC ; ADC D[n]
    a.raw(0x8F, 0, 0x60, 0)                                             # radio R+D
    a.raw(0xAF, 0, 0x70, 0, 0x10, 0xFA)                                 # espera RQM
    for i in range(2):
        a.raw(0xAF, 0, 0x60, 0)
        if NEG[i]: a.raw(0x49, 0xFF, 0xFF, 0x1A)
        a.raw(*W(0xA8C + 2 * i))
    a.raw(0x6B)
    return a.done()
def build(tabS, tabR):
    a = A()
    a.raw(0x08, 0xC2, 0x30, 0x48, 0xDA)                 # PHP REP#30 PHA PHX
    a.raw(0xA9, 0, 0).raw(*W(0xA80)).raw(*W(0xA82)).raw(*W(0xA8C)).raw(*W(0xA8E))     # dx=dy=0 (y extra del centro)
    a.raw(0xE0, 0, 0).br(0xD0, 'out')                   # CPX #0 ; BNE out  (solo vista x=0)
    a.raw(0xB5, 0xA4, 0xC9, 2, 0).br(0xF0, 'follow')    # LDA $A4,x ; CMP #2 ; BEQ follow
    a.raw(0xB5, 0xAC).br(0x30, 'follow')                # LDA $AC,x ; BMI follow
    # no sigue: si el cronometro de carrera ($0100-$0102) es 0 (intro) -> n=0,s=0; si ya corre (fin de carrera: la camara deja
    # de seguir pero Mario sigue en pantalla: derrota, explosion, Lakitu) -> mantener la camara cercana.
    a.raw(*L(0x100)).raw(0x0F, 0x01, 0x01, 0x7E).br(0xD0, 'follow')        # LDA $0100 ; ORA $0101(+$0102 abajo) ; BNE follow
    a.raw(0xA9, 0, 0).raw(*W(0xA84)).raw(*W(0xA86)).br(0x80, 'out')   # intro: n=0,s=0
    a.label('follow')
    a.raw(*L(0xA84)).raw(0xC9, 2 * N, 0).br(0x90, 'inc')  # CMP #2N ; BCC inc
    a.raw(0xA9, 2 * N, 0).br(0x80, 'store')
    a.label('inc').raw(0x1A, 0x1A)
    a.label('store').raw(*W(0xA84))
    a.raw(0xAA)                                          # TAX (n*2)
    a.raw(0xBF, tabS & 0xFF, (tabS >> 8) & 0xFF, 0x88).raw(*W(0xA86))
    a.raw(0xBF, tabR & 0xFF, (tabR >> 8) & 0xFF, 0x88).raw(0x48)        # LDA R[n] ; PHA
    a.raw(0xE2, 0x20, 0xA9, 0x04, 0x8F, 0, 0x60, 0, 0xC2, 0x20)         # DSP cmd $04 (trig)
    a.raw(0xA5, 0x94, 0x8F, 0, 0x60, 0)                                 # angulo Aas ($94, x=0)
    a.raw(0x68, 0x8F, 0, 0x60, 0)                                       # radio R
    a.raw(0xAF, 0, 0x70, 0, 0x10, 0xFA)                                 # espera RQM
    for i in range(2):
        a.raw(0xAF, 0, 0x60, 0)
        if NEG[i]: a.raw(0x49, 0xFF, 0xFF, 0x1A)
        a.raw(*W(0xA80 + 2 * i))   # R*sin / R*cos
    a.raw(0x22, RF_ADDR & 0xFF, (RF_ADDR >> 8) & 0xFF, 0x88)           # JSL RF (extra del centro Mode 7)
    a.label('out')
    a.raw(0xFA, 0x68, 0x28, 0xE2, 0x20, 0xA9, 0x02, 0x6B)   # PLX PLA PLP SEP#20 LDA#02 RTL (repone lo parcheado)
    return a.done()
def stub_add(dp, scr):   # LDA dp,x ; CLC ; ADC long scr ; [CMP #$8000] ; STA DSP / RTL
    return bytes([0xB5, dp, 0x18, 0x6F, scr & 0xFF, scr >> 8, 0x7E])
def apply(rom, p_entry, p_sprite1, p_sprite2, code=0x88300, vanilla_consts=True):
    tabS_a, tabR_a = code + 0x180, code + 0x200
    S, R = tables()
    ent = build(tabS_a & 0xFFFF, tabR_a & 0xFFFF)
    assert len(ent) < 0xA0, len(ent)
    # sitios de parche (offsets de fichero); USA: DSP con direccionamiento largo; EU: absoluto
    chk = lambda p, b: rom[p:p+len(b)] == bytes(b)
    assert chk(p_entry, [0xE2, 0x20, 0xA9, 0x02])
    long_ = rom[p_entry+4] == 0x8F
    dsp = [0x8F, 0, 0x60, 0] if long_ else [0x8D, 0, 0x60]
    p_fx = p_entry + (0x0A if long_ else 0x09)
    p_fy = p_fx + 2 + len(dsp) + 0          # LDA $8C,x sigue a STA DSP
    assert chk(p_fx, [0xB5, 0x88] + dsp), rom[p_fx:p_fx+8].hex()
    assert chk(p_fy, [0xB5, 0x8C] + dsp), rom[p_fy:p_fy+8].hex()
    p_cx = rom.find(bytes([0xB5, 0x88, 0xC9, 0, 0x80, 0x6A]), p_entry, p_entry + 0x90)
    p_cy = rom.find(bytes([0xB5, 0x8C, 0xC9, 0, 0x80, 0x6A]), p_entry, p_entry + 0x90)
    assert p_cx > 0 and p_cy > 0
    assert chk(p_sprite1, [0xA9, 0x66, 0xFF, 0x85, 0x1E]) or chk(p_sprite1, [0xA9, 0xBE, 0xFF, 0x85, 0x1E])
    assert chk(p_sprite2, [0xA9, 0xD6, 0xFF, 0x85, 0x1E]) or chk(p_sprite2, [0xA9, 0x2E, 0x00, 0x85, 0x1E])
    assert set(rom[code:code+0x3E0]) == {0}
    fx = stub_add(0x88, 0xA80) + bytes([0x8F, 0, 0x60, 0, 0x6B])
    fy = stub_add(0x8C, 0xA82) + bytes([0x8F, 0, 0x60, 0, 0x6B])
    cx = stub_add(0x88, 0xA8C) + bytes([0xC9, 0, 0x80, 0x6B])
    cy = stub_add(0x8C, 0xA8E) + bytes([0xC9, 0, 0x80, 0x6B])
    sp = lambda c: bytes([0xA9, c & 0xFF, c >> 8, 0x18, 0x6F, 0x86, 0x0A, 0x7E, 0x85, 0x1E, 0x6B])
    def key(field, mult):
        """Clave de orden/colision de P1 = escala proyectada (DSP Project) de su posicion real. Usa X=$B4."""
        b = bytearray.fromhex('E220A9068F006000C220')
        for lo, hi in ((0x16, 0x18), (0x1A, 0x1C)):
            b += bytes([0xB5, lo, 0x85, 0x00, 0xB5, hi, 0x06, 0x00, 0x2A, 0x06, 0x00, 0x2A]) + bytes.fromhex('8F006000')
        b += bytes.fromhex('A900008F006000') + bytes.fromhex('AF007000' '10FA') + (bytes.fromhex('AF006000' '8F880A7E' 'AF006000' '8F8A0A7E' 'AF006000') if os.environ.get('DBGKEY') else bytes.fromhex('AF006000') * 3)
        b += bytes([0x85, 0x00]) + (bytes([0x4A, 0x18, 0x65, 0x00]) if mult else b'')
        b += bytes.fromhex('C90003' '9003' 'A9FF02') + bytes([0x95, field])
        return bytes(b)
    blobs = {0x00: ent, 0xA0: fx, 0xC0: fy, 0xE0: cx, 0x100: cy}
    for off, b in blobs.items(): rom[code+off:code+off+len(b)] = b
    # sprites (en 0x88300+0x1xx? usar zona propia tras tablas)
    sp1, sp2 = code + 0x290, code + 0x300            # stubs con clave de orden (+ tabla ya ocupa hasta 0x24A)
    k1, k2 = key(0x06, True) + sp(0xFF66), key(0x0E, False) + sp(0xFFD6)
    assert len(k1) < 0x70 and len(k2) < 0x70, (len(k1), len(k2))
    rom[sp1:sp1+len(k1)] = k1; rom[sp2:sp2+len(k2)] = k2
    rf = build_rf(tabR_a & 0xFFFF, TD_ADDR & 0xFFFF)
    assert len(rf) <= 0x40, len(rf)
    assert not any(rom[RF_ADDR:RF_ADDR+0x40]) and not any(rom[TD_ADDR:TD_ADDR+0x4A])
    rom[RF_ADDR:RF_ADDR+len(rf)] = rf
    for i, v in enumerate(dtable()): rom[TD_ADDR+2*i:TD_ADDR+2*i+2] = bytes([v & 0xFF, v >> 8])
    for i, v in enumerate(S): rom[tabS_a+2*i:tabS_a+2*i+2] = bytes([v & 0xFF, v >> 8])
    for i, v in enumerate(R): rom[tabR_a+2*i:tabR_a+2*i+2] = bytes([v & 0xFF, v >> 8])
    # chispas de pared: constantes Y=$66 (LDA #$6673 / #$668D; RTS) -> + s<<8 (stub + salto al RTS tras ADC #$7000)
    pat = bytes([0xA9, 0x73, 0x66, 0x60, 0xA9, 0x8D, 0x66, 0x60])
    p_sp = rom.find(pat); assert p_sp > 0 and rom.find(pat, p_sp + 1) < 0, 'chispas: patron no unico'
    p_rts = rom.find(bytes([0x18, 0x69, 0x00, 0x70, 0x60]), p_sp - 0x40, p_sp + 0x60); assert p_rts > 0
    rts80 = 0x800000 | (p_rts + 4)
    def spark(c):
        return bytes([0xAF, 0x86, 0x0A, 0x7E, 0xEB, 0x18, 0x69, c & 0xFF, c >> 8, 0x5C, rts80 & 0xFF, (rts80 >> 8) & 0xFF, 0x80])
    spA, spB = code + 0x160, code + 0x170
    assert set(rom[spA:spA+0x20]) == {0}
    rom[spA:spA+13] = spark(0x6673); rom[spB:spB+13] = spark(0x668D)
    # kart en estados de salto/caida: Y = ($7B,x | $FF00) (suelo vanilla $66) -> + s
    p_h1 = rom.find(bytes([0xB5, 0x7B, 0x29, 0xFF, 0x00, 0x09, 0x00, 0xFF, 0x95, 0x2E])); assert p_h1 > 0
    p_h2 = rom.find(bytes([0x29, 0xFF, 0x00, 0x09, 0x00, 0xFF, 0x95, 0x34, 0x95, 0x3A]), p_h1 + 1); assert p_h2 > 0
    hp1, hp2 = code + 0x1D0, code + 0x1E0   # zona libre tras la tabla S (S: 0x180..0x1CA) y antes de R (0x200)
    assert set(rom[hp1:hp1+0x20]) == {0}
    def hop(dst):
        return bytes([0x09, 0x00, 0xFF, 0x18, 0x6F, 0x86, 0x0A, 0x7E, 0x95, dst, 0x6B])
    rom[hp1:hp1+11] = hop(0x2E); rom[hp2:hp2+11] = hop(0x34)
    for p, h in ((p_h1 + 5, hp1), (p_h2 + 3, hp2)):
        rom[p:p+5] = jsl(h) + b'\xEA'
    rom[p_sp:p_sp+4] = bytes([0x5C, spA & 0xFF, (spA >> 8) & 0xFF, 0x88])
    rom[p_sp+4:p_sp+8] = bytes([0x5C, spB & 0xFF, (spB >> 8) & 0xFF, 0x88])
    # Explosion del kart (derrota / "Give up"): Y fijo de pantalla $58 (centro de la vista superior vanilla) -> + s<<8.
    # `A9 80 58 18 65 BA 22 <lista de partes>`: la rutina generica de partes (80:C07B) toma X=A&255, Y=A>>8.
    pe = bytes([0xA9, 0x80, 0x58, 0x18, 0x65, 0xBA, 0x22])
    p_ex = rom.find(pe); assert p_ex > 0 and rom.find(pe, p_ex + 1) < 0, 'explosion: patron no unico'
    tgt = rom[p_ex+7:p_ex+10]
    ex = code + 0x1F0
    assert set(rom[ex:ex+0x10]) == {0}
    rom[ex:ex+16] = bytes.fromhex('48AF860A7EEB1863018301685C') + tgt
    rom[p_ex+6:p_ex+10] = jsl(ex)
    # Chispas de contacto (80:D5E0..D5F7): 3 partes Y = tabla + base; las entradas "ocultas" (indices 6,7: Y offset $80) quedaban
    # fuera de pantalla con la base vanilla ($6E+$80=$EE) pero con base+s la suma de 8 bits da la vuelta (=$46) y salen arriba
    # como sombras. Se reescribe la secuencia con un stub que aparca esas partes en Y=$F0.
    import re as _re
    pat = _re.compile(rb'\xb9(..)\x18\x65\x00\x95\x00\xb9(..)\x18\x65\x00\x95\x04\xb9(..)\x18\x65\x00\x95\x08', _re.S)
    ms = list(pat.finditer(bytes(rom[:0x20000]))); assert len(ms) == 1, len(ms)
    m = ms[0]; p_sh = m.start()
    shs = code + 0x400
    assert set(rom[shs:shs+0x30]) == {0}
    stub = bytearray()
    for i, (col, dst) in enumerate(zip((m.group(1), m.group(2), m.group(3)), (0x00, 0x04, 0x08))):
        stub += bytes([0xB9]) + col + bytes([0x18, 0x65, 0x00, 0x95, dst])
    stub += bytes.fromhex('C00C0090' '0A' 'E220A9F095059509C2206B')
    rom[shs:shs+len(stub)] = stub
    rom[p_sh:p_sh+24] = jsl(shs) + b'\xEA' * 20
    # Ventanas de descarte vertical (ref. Y16 = fila-256; OAM guarda Y en 8 bits: fuera de [-32,224) da la vuelta y el sprite
    # reaparece arriba/abajo). Con la camara cercana Mario esta en la fila ~190 y los rivales llegan hasta el borde inferior,
    # asi que: limite inferior de pantalla fila 256 (Y16<0) y superior fila 8 (partes hasta -40 px) en todas las rutas.
    import re as _re
    src = bytes(rom[:0x20000])
    def sub(pat, new, n):
        hs = [m.start() for m in _re.finditer(pat, src, _re.S)]
        assert len(hs) == n, (pat.hex(), hs)
        for h in hs:
            rom[h:h+len(new)] = new
    sub(rb'\x69\x20\x01\xc9\xc0\x00', bytes.fromhex('69F800C9F800'), 2)
    sub(rb'\x69\xa0\x00\xc9\xc0\x00', bytes.fromhex('69A000C9A000'), 2)              # vista inferior: solo limite inferior
    sub(rb'\x69\xb0\x00\xc9\xc0\x00', bytes.fromhex('69B000C9B000'), 1)
    sub(rb'\x69\x20\x01\xc9\x80\x01', bytes.fromhex('69F800C9F800'), 1)              # objetos generales
    # Colision kart-obstaculo (81:9719): solo prueba objetos con clave de profundidad $06 en [$E0,$120) (centrada en la clave
    # vanilla de Mario). Con la camara cercana la clave de Mario es 552 y un objeto sobre el queda en ~548: ampliar a [$E0,$280).
    sub(rb'\x38\xe9\xe0\x00\xc9\x40\x00\xb0\x07\xda', bytes.fromhex('38E9E000C9A001B007DA'), 1)
    # bandas de proximidad en pantalla de la rutina de lados/rebote ($80:D6E0 y D755): subir 88 filas (s final)
    sub(rb'\x69\xc0\x00\xc9\x60\x00\xb0', bytes.fromhex('696800C96000'), 1)
    sub(rb'\x69\x50\x00\xc9\x60\x00\xb0', bytes.fromhex('69F8FFC96000'), 1)
    # limite de escala para dibujar karts ($0FBA=$200, `CMP $0FBA` en C716/C739): la escala de Mario con camara cercana ya es
    # ~$228, asi que cualquier rival a su altura se ocultaba. Subirlo a $300 (maximo que admite el dibujo: `CMP #$0300` en C98D/ED72).
    hb = [m.start() for m in _re.finditer(rb'\xcd\xba\x0f\xb0', bytes(rom[:0x20000]))]
    assert len(hb) == 2, hb
    for h in hb:
        rom[h:h+3] = bytes([0xC9, 0x00, 0x03])
    # escala de objetos (x1.5 del port): en vez de ocultar con M'>=$300, recortar a $2FF y ocultar solo >= $700
    pre = bytes.fromhex('8F5CDE7F186A186F5CDE7FC9000385189506' '5C')
    p_sc = rom.find(pre); assert p_sc > 0 and rom.find(pre, p_sc + 1) < 0, 'escala objetos: patron no unico'
    ret = rom[p_sc+len(pre):p_sc+len(pre)+3]
    scs = code + 0x380
    assert set(rom[scs:scs+0x40]) == {0}
    b = bytearray.fromhex('8F5CDE7F186A186F5CDE7F' 'C90003')       # STA tmp; M/2; +M ; CMP #$0300
    b += bytes([0x90, 0]); i1 = len(b)                              # BCC ok
    b += bytes.fromhex('C90007') + bytes([0xB0, 0]); i2 = len(b)    # CMP #$0700 ; BCS ok (ocultar)
    b += bytes.fromhex('A9FF0218')                                  # recorte a $02FF, carry limpio
    ok = len(b)
    b[i1 - 1] = ok - i1; b[i2 - 1] = ok - i2
    b += bytes.fromhex('85189506' '5C') + ret
    rom[scs:scs+len(b)] = b
    rom[p_sc:p_sc+4] = bytes([0x5C, scs & 0xFF, (scs >> 8) & 0xFF, 0x88])
    rom[p_entry:p_entry+4] = jsl(code)
    rom[p_fx:p_fx+2+len(dsp)] = jsl(code + 0xA0) + b'\xEA' * (2 + len(dsp) - 4)
    rom[p_fy:p_fy+2+len(dsp)] = jsl(code + 0xC0) + b'\xEA' * (2 + len(dsp) - 4)
    rom[p_cx:p_cx+5] = jsl(code + 0xE0) + b'\xEA'
    rom[p_cy:p_cy+5] = jsl(code + 0x100) + b'\xEA'
    rom[p_sprite1:p_sprite1+5] = jsl(sp1) + b'\xEA'
    rom[p_sprite2:p_sprite2+5] = jsl(sp2) + b'\xEA'
    return S, R, len(ent)
if __name__ == '__main__':
    S, R = tables(); print('S', S); print('R', [hex(x) for x in R])
