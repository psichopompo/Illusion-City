#!/usr/bin/env python3
"""Desensamblador 65816 con seguimiento de flags M/X.
Uso: dis816.py <rom> <bank:addr> [nbytes] [--m8] [--x8]
"""
import sys
from pathlib import Path
OPS={
0x00:('BRK',1),0x01:('ORA','(dp,x)',0),0x03:('ORA','sr',0),0x05:('ORA','dp',0),0x06:('ASL','dp',0),0x07:('ORA','[dp]',0),
0x08:('PHP',1),0x09:('ORA','imm',0),0x0A:('ASL','acc',1),0x0B:('PHD',1),0x0D:('ORA','abs',0),0x0E:('ASL','abs',0),0x0F:('ORA','long',0),
0x10:('BPL','rel',0),0x11:('ORA','(dp),y',0),0x13:('ORA','(sr),y',0),0x15:('ORA','dp,x',0),0x16:('ASL','dp,x',0),0x17:('ORA','[dp],y',0),
0x18:('CLC',1),0x19:('ORA','abs,y',0),0x1A:('INC','acc',1),0x1B:('TCS',1),0x1D:('ORA','abs,x',0),0x1E:('ASL','abs,x',0),0x1F:('ORA','long,x',0),
0x20:('JSR','abs',0),0x21:('AND','(dp,x)',0),0x22:('JSL','long',0),0x23:('AND','sr',0),0x25:('AND','dp',0),0x26:('ROL','dp',0),0x27:('AND','[dp]',0),
0x28:('PLP',1),0x29:('AND','imm',0),0x2A:('ROL','acc',1),0x2B:('PLD',1),0x2D:('AND','abs',0),0x2E:('ROL','abs',0),0x2F:('AND','long',0),
0x30:('BMI','rel',0),0x31:('AND','(dp),y',0),0x33:('AND','(sr),y',0),0x35:('AND','dp,x',0),0x36:('ROL','dp,x',0),0x37:('AND','[dp],y',0),
0x38:('SEC',1),0x39:('AND','abs,y',0),0x3A:('DEC','acc',1),0x3B:('TSC',1),0x3D:('AND','abs,x',0),0x3E:('ROL','abs,x',0),0x3F:('AND','long,x',0),
0x40:('RTI',1),0x41:('EOR','(dp,x)',0),0x43:('EOR','sr',0),0x45:('EOR','dp',0),0x46:('LSR','dp',0),0x47:('EOR','[dp]',0),
0x48:('PHA',1),0x49:('EOR','imm',0),0x4A:('LSR','acc',1),0x4B:('PHK',1),0x4C:('JMP','abs',0),0x4D:('EOR','abs',0),0x4E:('LSR','abs',0),0x4F:('EOR','long',0),
0x50:('BVC','rel',0),0x51:('EOR','(dp),y',0),0x53:('EOR','(sr),y',0),0x55:('EOR','dp,x',0),0x56:('LSR','dp,x',0),0x57:('EOR','[dp],y',0),
0x58:('CLI',1),0x59:('EOR','abs,y',0),0x5A:('PHY',1),0x5B:('TCD',1),0x5C:('JML','long',0),0x5D:('EOR','abs,x',0),0x5E:('LSR','abs,x',0),0x5F:('EOR','long,x',0),
0x60:('RTS',1),0x61:('ADC','(dp,x)',0),0x62:('PER','rel16',0),0x63:('ADC','sr',0),0x64:('STZ','dp',0),0x65:('ADC','dp',0),0x66:('ROR','dp',0),0x67:('ADC','[dp]',0),
0x68:('PLA',1),0x69:('ADC','imm',0),0x6A:('ROR','acc',1),0x6B:('RTL',1),0x6C:('JMP','(abs)',0),0x6D:('ADC','abs',0),0x6E:('ROR','abs',0),0x6F:('ADC','long',0),
0x70:('BVS','rel',0),0x71:('ADC','(dp),y',0),0x73:('ADC','(sr),y',0),0x74:('STZ','dp,x',0),0x75:('ADC','dp,x',0),0x76:('ROR','dp,x',0),0x77:('ADC','[dp],y',0),
0x78:('SEI',1),0x79:('ADC','abs,y',0),0x7A:('PLY',1),0x7B:('TDC',1),0x7C:('JMP','(abs,x)',0),0x7D:('ADC','abs,x',0),0x7E:('ROR','abs,x',0),0x7F:('ADC','long,x',0),
0x80:('BRA','rel',0),0x81:('STA','(dp,x)',0),0x82:('BRL','rel16',0),0x83:('STA','sr',0),0x84:('STY','dp',0),0x85:('STA','dp',0),0x86:('STX','dp',0),0x87:('STA','[dp]',0),
0x88:('DEY',1),0x89:('BIT','imm',0),0x8A:('TXA',1),0x8B:('PHB',1),0x8C:('STY','abs',0),0x8D:('STA','abs',0),0x8E:('STX','abs',0),0x8F:('STA','long',0),
0x90:('BCC','rel',0),0x91:('STA','(dp),y',0),0x92:('STA','(dp)',0),0x93:('STA','(sr),y',0),0x94:('STY','dp,x',0),0x95:('STA','dp,x',0),0x96:('STX','dp,y',0),0x97:('STA','[dp],y',0),
0x98:('TYA',1),0x99:('STA','abs,y',0),0x9A:('TXS',1),0x9B:('TXY',1),0x9C:('STZ','abs',0),0x9D:('STA','abs,x',0),0x9E:('STZ','abs,x',0),0x9F:('STA','long,x',0),
0xA0:('LDY','immx',0),0xA1:('LDA','(dp,x)',0),0xA2:('LDX','immx',0),0xA3:('LDA','sr',0),0xA4:('LDY','dp',0),0xA5:('LDA','dp',0),0xA6:('LDX','dp',0),0xA7:('LDA','[dp]',0),
0xA8:('TAY',1),0xA9:('LDA','imm',0),0xAA:('TAX',1),0xAB:('PLB',1),0xAC:('LDY','abs',0),0xAD:('LDA','abs',0),0xAE:('LDX','abs',0),0xAF:('LDA','long',0),
0xB0:('BCS','rel',0),0xB1:('LDA','(dp),y',0),0xB2:('LDA','(dp)',0),0xB3:('LDA','(sr),y',0),0xB4:('LDY','dp,x',0),0xB5:('LDA','dp,x',0),0xB6:('LDX','dp,y',0),0xB7:('LDA','[dp],y',0),
0xB8:('CLV',1),0xB9:('LDA','abs,y',0),0xBA:('TSX',1),0xBB:('TYX',1),0xBC:('LDY','abs,x',0),0xBD:('LDA','abs,x',0),0xBE:('LDX','abs,y',0),0xBF:('LDA','long,x',0),
0xC0:('CPY','immx',0),0xC1:('CMP','(dp,x)',0),0xC2:('REP','imm8',0),0xC3:('CMP','sr',0),0xC4:('CPY','dp',0),0xC5:('CMP','dp',0),0xC6:('DEC','dp',0),0xC7:('CMP','[dp]',0),
0xC8:('INY',1),0xC9:('CMP','imm',0),0xCA:('DEX',1),0xCB:('WAI',1),0xCC:('CPY','abs',0),0xCD:('CMP','abs',0),0xCE:('DEC','abs',0),0xCF:('CMP','long',0),
0xD0:('BNE','rel',0),0xD1:('CMP','(dp),y',0),0xD2:('CMP','(dp)',0),0xD3:('CMP','(sr),y',0),0xD4:('PEI','(dp)',0),0xD5:('CMP','dp,x',0),0xD6:('DEC','dp,x',0),0xD7:('CMP','[dp],y',0),
0xD8:('CLD',1),0xD9:('CMP','abs,y',0),0xDA:('PHX',1),0xDB:('STP',1),0xDC:('JML','(abs)',0),0xDD:('CMP','abs,x',0),0xDE:('DEC','abs,x',0),0xDF:('CMP','long,x',0),
0xE0:('CPX','immx',0),0xE1:('SBC','(dp,x)',0),0xE2:('SEP','imm8',0),0xE3:('SBC','sr',0),0xE4:('CPX','dp',0),0xE5:('SBC','dp',0),0xE6:('INC','dp',0),0xE7:('SBC','[dp]',0),
0xE8:('INX',1),0xE9:('SBC','imm',0),0xEA:('NOP',1),0xEB:('XBA',1),0xEC:('CPX','abs',0),0xED:('SBC','abs',0),0xEE:('INC','abs',0),0xEF:('SBC','long',0),
0xF0:('BEQ','rel',0),0xF1:('SBC','(dp),y',0),0xF2:('SBC','(dp)',0),0xF3:('SBC','(sr),y',0),0xF4:('PEA','abs',0),0xF5:('SBC','dp,x',0),0xF6:('INC','dp,x',0),0xF7:('SBC','[dp],y',0),
0xF8:('SED',1),0xF9:('SBC','abs,y',0),0xFA:('PLX',1),0xFB:('XCE',1),0xFC:('JSR','(abs,x)',0),0xFD:('SBC','abs,x',0),0xFE:('INC','abs,x',0),0xFF:('SBC','long,x',0),
}
for _k,_v in list(OPS.items()):
    if len(_v)==2: OPS[_k]=(_v[0],'implied',_v[1])

def dis(rom,bank,addr,n,m8=False,x8=False):
    fo=(bank-0x80)*0x10000+addr
    i=0; M=m8; X=x8
    while i<n:
        a=addr+i; op=rom[fo+i]
        if op not in OPS: print(f'${bank:02X}:{a:04X}  db ${op:02X}'); i+=1; continue
        name,mode,fix=OPS[op]
        if mode=='imm':      ln=2 if M else 3
        elif mode=='immx':   ln=2 if X else 3
        elif mode=='imm8':   ln=2
        elif fix:            ln=1
        elif mode=='rel':    ln=2
        elif mode=='rel16':  ln=3
        elif mode in ('dp','dp,x','dp,y','(dp,x)','(dp),y','[dp]','[dp],y','sr','(sr),y','(dp)'): ln=2
        elif mode in ('abs','abs,x','abs,y','(abs)','(abs,x)'): ln=3
        elif mode in ('long','long,x'): ln=4
        else: ln=1
        raw=rom[fo+i:fo+i+ln]
        arg=''
        if mode in ('imm','immx'):
            arg=f'#${raw[1]:02X}' if ln==2 else f'#${raw[2]:02X}{raw[1]:02X}'
        elif mode=='imm8': arg=f'#${raw[1]:02X}'
        elif mode=='rel':
            off=raw[1]; off=off-256 if off>127 else off
            arg=f'${(a+2+off)&0xFFFF:04X}'
        elif mode=='rel16':
            off=raw[1]|(raw[2]<<8); off=off-65536 if off>32767 else off
            arg=f'${(a+3+off)&0xFFFF:04X}'
        elif fix: arg=''
        elif ln==2: arg=f'${raw[1]:02X}' if mode.startswith('(') or mode.startswith('[') or mode=='sr' or mode=='(sr),y' or mode=='(dp)' else f'${raw[1]:02X}'
        elif ln==3: arg=f'${raw[2]:02X}{raw[1]:02X}'
        elif ln==4: arg=f'${raw[3]:02X}{raw[2]:02X}{raw[1]:02X}'
        if mode in ('long','long,x') and ln==4: pass
        if mode in ('long','long,x'): arg=f'${raw[3]:02X}{raw[2]:02X}{raw[1]:02X}'+ (',x' if mode.endswith(',x') else '')
        print(f'${bank:02X}:{a:04X}  {name} {arg}'.rstrip())
        if name=='REP' and raw[1]&0x20: M=False
        if name=='REP' and raw[1]&0x10: X=False
        if name=='SEP' and raw[1]&0x20: M=True
        if name=='SEP' and raw[1]&0x10: X=True
        i+=ln
if __name__=='__main__':
    rom=Path(sys.argv[1]).read_bytes()
    bank,addr=sys.argv[2].split(':'); bank=int(bank,16); addr=int(addr,16)
    n=int(sys.argv[3],16) if len(sys.argv)>3 else 0x60
    m8='--m8' in sys.argv; x8='--x8' in sys.argv
    dis(rom,bank,addr,n,m8,x8)
