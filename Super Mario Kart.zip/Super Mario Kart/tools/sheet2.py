import sys,re
from PIL import Image
def ld(d,f):
    x=open('%s/f%04d.ppm'%(d,f),'rb').read(); m=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',x); return Image.frombytes('RGB',(256,224),x[m.end():])
if __name__=='__main__':
    d=sys.argv[1]; out=sys.argv[2]; fr=[int(x) for x in sys.argv[3].split(',')]; cols=int(sys.argv[4]) if len(sys.argv)>4 else 4
    rows=(len(fr)+cols-1)//cols
    W=Image.new('RGB',(cols*256,rows*224))
    for i,f in enumerate(fr): W.paste(ld(d,f),((i%cols)*256,(i//cols)*224))
    W.save(out)
