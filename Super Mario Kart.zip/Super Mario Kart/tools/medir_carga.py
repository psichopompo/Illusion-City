#!/usr/bin/env python3
import sys,os,subprocess,shutil,glob
rom,sc,tag,fr,e0,e1=sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]),int(sys.argv[5]),int(sys.argv[6])
d='/tmp/ms2_'+tag; shutil.rmtree(d,True); os.makedirs(d)
env=dict(os.environ,HISTEACH='%d,%d'%(e0,e1),WLOG='100,4')
subprocess.run(['/tmp/drive','/tmp/cores/bsnes_prof.so',rom,'-',str(fr),sc,d,'0'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=[x.split()[1:] for x in open(d+'/wlog.txt')]
ch=[i for i in range(1,len(w)) if w[i]!=w[i-1]]
stall=sum(1 for i in range(e0+1,e1+1) if w[i]==w[i-1])
busy=[]
for f in range(e0,e1+1):
    tot=idle=0
    for l in open(d+'/he_%d.txt'%f):
        if l[0]=='#':continue
        a,k,c=l.split(); a=int(a,16); c=int(c); tot+=c
        if 0x888900<=a<0x888940 or 0x808040<=a<0x808080: idle+=c
    busy.append(100*(tot-idle)/tot if tot else 0)
    os.remove(d+'/he_%d.txt'%f)
b=sorted(busy); n=len(b)
print('%s: crono f%d | f%d-%d lag %d/%d | CPU media %.1f%% p95 %.1f%% max %.1f%% | fotogramas >90%%: %d'%(tag,ch[1] if len(ch)>1 else 0,e0,e1,stall,n,sum(b)/n,b[int(n*.95)],b[-1],sum(1 for x in b if x>90)))
open('/tmp/busy_%s.txt'%tag,'w').write("\n".join('%.1f'%x for x in busy))
