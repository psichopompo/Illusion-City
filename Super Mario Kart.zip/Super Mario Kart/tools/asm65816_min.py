"""Ensamblador minimo 65816 (solo las instrucciones que usan los parches del hack).
asm(text, org) -> bytes. Etiquetas 'nombre:' al inicio de linea; saltos relativos a etiquetas.
Operandos: '#$12' (8 bit, sufijo .b) / '#$1234' (16 bit, sufijo .w), '$7E0A90' (long), '$7F0002,x' (long,x), etiqueta (rel)."""
import re
IMP = dict(PHP=0x08, PLP=0x28, RTS=0x60, INX=0xE8, TAX=0xAA, TXA=0x8A, CLC=0x18, SEC=0x38, PHA=0x48, PLA=0x68, TAY=0xA8, TYA=0x98, ASL=0x0A, RTL=0x6B, PHX=0xDA, PLX=0xFA, NOP=0xEA)
IMM = dict(REP=0xC2, SEP=0xE2, LDA=0xA9, AND=0x29, CMP=0xC9, ADC=0x69, SBC=0xE9, LDX=0xA2, LDY=0xA0, CPX=0xE0)
LONG = dict(LDA=0xAF, STA=0x8F, ADC=0x6F, CMP=0xCF, SBC=0xEF)
LONGX = dict(LDA=0xBF, STA=0x9F, CMP=0xDF)
REL = dict(BPL=0x10, BMI=0x30, BEQ=0xF0, BNE=0xD0, BCC=0x90, BCS=0xB0, BRA=0x80)
def asm(text, org=0):
    out = bytearray(); lab = {}; fix = []
    for ln in text.splitlines():
        ln = ln.split(';')[0].strip()
        if not ln: continue
        m = re.match(r'^(\w+):$', ln)
        if m: lab[m.group(1)] = len(out); continue
        parts = ln.split(None, 1); op = parts[0].upper(); arg = parts[1].strip() if len(parts) > 1 else ''
        width = None
        if '.' in op: op, width = op.split('.')
        if op in IMP and not arg: out.append(IMP[op])
        elif op == 'JML': out.append(0x5C); out += int(arg.replace('$', ''), 16).to_bytes(3, 'little')
        elif width == 'd' and op == 'STA': out += bytes([0x85, int(arg.replace('$', ''), 16)])
        elif op in ('JMP', 'JSR') and arg.startswith('$'): out += bytes([0x4C if op == 'JMP' else 0x20]) + int(arg[1:], 16).to_bytes(2, 'little')
        elif op in ('JMP', 'JSR'): out += bytes([0x4C if op == 'JMP' else 0x20, 0, 0]); fix.append((len(out) - 2, '@' + arg))
        elif op in REL: out += bytes([REL[op], 0]); fix.append((len(out) - 1, arg))
        elif arg.startswith('#'):
            hx = arg[1:].replace('$', ''); v = int(hx, 16)
            two = (width == 'w') or (width is None and len(hx) > 2)
            if op in ('REP', 'SEP'): two = False
            out.append(IMM[op]); out += v.to_bytes(2 if two else 1, 'little')
        elif arg.lower().endswith(',x'):
            v = int(arg[:-2].replace('$', ''), 16); out.append(LONGX[op]); out += v.to_bytes(3, 'little')
        else:
            v = int(arg.replace('$', ''), 16); out.append(LONG[op]); out += v.to_bytes(3, 'little')
    for pos, name in fix:
        if name.startswith('@'):
            a = org + lab[name[1:]]; out[pos] = a & 0xFF; out[pos + 1] = a >> 8; continue
        d = lab[name] - (pos + 1); assert -128 <= d <= 127, (name, d); out[pos] = d & 0xFF
    return bytes(out)
