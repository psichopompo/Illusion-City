#!/usr/bin/env python3
"""abframes.py romA romB state frames [paso]: compara imagenes por indice de fotograma (para estados con cronometro parado). Imprime los distintos."""
import sys, os, subprocess, shutil
ra, rb, st, n = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]); step = int(sys.argv[5]) if len(sys.argv) > 5 else 3
fr = list(range(3, n, step)); out = []
for rom, tag in ((ra, 'a'), (rb, 'b')):
    d = '/tmp/abf_%s_%d' % (tag, os.getpid()); shutil.rmtree(d, True); os.makedirs(d)
    subprocess.run(['/tmp/drive', '/home/user/smk_work/cores/bsnes_prof.so', rom, st, str(n), '/tmp/acc.txt', d, '0'], env=dict(os.environ, SNAPS=','.join(map(str, fr))), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); out.append(d)
bad = [f for f in fr if open('%s/f%04d.ppm' % (out[0], f), 'rb').read() != open('%s/f%04d.ppm' % (out[1], f), 'rb').read()]
print('%s: comparadas %d, distintas %d %s' % (os.path.basename(st), len(fr), len(bad), bad[:8]))
for d in out: shutil.rmtree(d, True)
