#!/usr/bin/env python3
"""Lakitu asomando por abajo en el rescate (1P pantalla completa): caidas en Ghost Valley y en el agua.
uso: lakitu_abajo.py in.sfc out.sfc
Lakitu nace/aparca con Y negativa ("por encima de la pantalla", Y entera $E0..$FF) y sube/baja con ella. En el original esas filas caian
fuera de la ventana de vista de 112 lineas; con pantalla completa las filas 192..239 se ven (las 224..239 en PAL/overscan) y asoman
trozos de Lakitu (cabeza, nube, los tres pelos) por abajo, antes de empezar a bajar y al terminar de subir.
85:E139 (`JSL $80BDC8`, dibujo de Lakitu: reserva 8 slots OAM desde $CE+$20): en 1P, durante el rescate ($7E:1C30 == $0E) y con la Y entera
en [$E0,$FF] o [$00,$0F] (filas superiores en 192..239), se dibuja igual (mismos slots, nada se reordena) y despues se aparcan los 8
slots en Y=$F0. Fuera de 1P / del rescate: llamada original.
85:E185 (op que Lakitu ejecuta cada fotograma mientras no esta en rescate): barre los slots 8..15 y aparca en Y=$F0 las piezas sobrantes con atributo $6A
y Y en [$C0,$F0): el juego no reescribe esos slots cuando Lakitu termina, asi que el ultimo dibujo quedaba en el OAM (los tres pelos) para siempre,
y tambien en estados guardados con versiones anteriores."""
import sys

def asm(items):
    out = bytearray(); lab = {}; fix = []
    for it in items:
        if isinstance(it, str) and it.endswith(':'): lab[it[:-1]] = len(out)
        elif isinstance(it, str): out += bytes.fromhex(it.replace(' ', ''))
        else: out += bytes([int(it[0], 16), 0]); fix.append((len(out) - 1, it[1]))
    for pos, n in fix:
        d = lab[n] - (pos + 1); assert -128 <= d <= 127, (n, d); out[pos] = d & 255
    return bytes(out)

r = bytearray(open(sys.argv[1], 'rb').read())
S1, S2 = 0x8A200, 0x8A260
assert not any(r[S1:S1+0xE0]), 'area no libre'
assert bytes(r[0x5E139:0x5E13D]) == bytes.fromhex('22C8BD80') and bytes(r[0x5E185:0x5E189]) == bytes.fromhex('E220A955')
c1 = asm([
 '48 DA 5A', '20008F', ('D0','norm'), 'AF301C7E', 'C90E00', ('D0','norm'),
 'A301', 'EB', '29FF00', 'C9E000', ('B0','hide'), 'C91000', ('B0','norm'),
 'hide:', '7A FA 68', '22C8BD80', 'A5CE', '18 692000', 'AA', 'E220', 'A9F0', 'A00800',
 'loop:', '9F01007E', 'E8E8E8E8', '88', ('D0','loop'), 'C220', '6B',
 'norm:', '7A FA 68', '22C8BD80', '6B'])
assert len(c1) <= 0x60, len(c1)
c2 = asm([
 'DA', 'A5CE', 'AA', 'E220', 'BF33007E', 'C96A', ('D0','out8'),      # PHX ; X = $CE ; SEP #$20 ; atributo del slot 12 (siempre dentro de un juego de piezas de Lakitu) == $6A ?
 'BF31007E', 'C9C0', ('90','out8'), 'C9F0', ('B0','out8'),          # y su Y en [$C0,$F0) (aun sin aparcar)
 'C220', '20008F', ('D0','out'), 'AF301C7E', 'C90E00', ('F0','out'), # 1P y Lakitu fuera del rescate
 'A5CE', '18 692100', 'AA', 'E220', 'A00800',
 'lp:', 'BF02007E', 'C96A', ('D0','nx'), 'BF00007E', 'C9C0', ('90','nx'), 'C9F0', ('B0','nx'), 'A9F0', '9F00007E',
 'nx:', 'E8E8E8E8', '88', ('D0','lp'),
 'out8:', 'C220',
 'out:', 'C230', 'FA', 'E220', 'A955', '5C89E185'])
assert len(c2) <= 0x80, len(c2)
r[S1:S1+len(c1)] = c1; r[S2:S2+len(c2)] = c2
r[0x5E139:0x5E13D] = bytes([0x22, S1 & 255, (S1 >> 8) & 255, 0x88])
r[0x5E185:0x5E189] = bytes([0x5C, S2 & 255, (S2 >> 8) & 255, 0x88])
open(sys.argv[2], 'wb').write(r); print('stubs', len(c1), len(c2), 'bytes en 88:A200 / 88:A260')
