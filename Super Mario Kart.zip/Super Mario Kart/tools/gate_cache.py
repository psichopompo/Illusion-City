#!/usr/bin/env python3
"""Cache del gate 1P pantalla completa (88:8F00) en WRAM $7E:0A88.
uso: gate_cache.py in.sfc out.sfc
El gate `JSR $8F00` (LDA $AA/$36/$32 + comparaciones, ~40 ciclos) se llamaba ~45 veces por fotograma desde los ganchos de culling/dibujo
(PHP/PHA/JSR/RTS en cada gancho). Ahora el resultado (0 = pantalla completa, 1 = no) se calcula UNA vez por pasada del bucle principal
en los dos sitios que ya lo evaluaban en TODOS los modos:
  88:88FE (88FA: inicio de la espera de NMI, tras la logica) y 88:8917 (88913: salida de la espera de NMI),
sustituyendo `JSR $8F00; NOP x4` por `JSR $8F00; STA $7E0A88` (STA no toca flags: el BEQ posterior ve lo mismo que antes).
Solo los 4 ganchos de HOT (ventana de culling de sprites) pasan de `JSR $8F00; NOP x4` a `LDA $7E0A88; NOP x3` (mismo tamano, mismo Z). Los demas (1-2 llamadas por
fotograma, muchos en codigo de transicion de modo: HDMA, camara...) siguen con la llamada viva para no heredar un valor viejo en el fotograma del cambio de modo
(con la cache en todos, la prueba de arranque desde reset dio discrepancias de 1-2 fotogramas al entrar en carrera en 88:8C6E, 88:8842: escrituras a registros PPU)."""
import sys, re
r = bytearray(open(sys.argv[1], 'rb').read())
BANK = 0x80000
JN = bytes.fromhex('20008FEAEAEAEA'); STA = bytes.fromhex('20008F8F880A7E'); LDA = bytes.fromhex('AF880A7EEAEAEA')
for a in (0x88FE, 0x8917):
    assert bytes(r[BANK + a:BANK + a + 7]) == JN, hex(a)
    r[BANK + a:BANK + a + 7] = STA
# solo calculo de ventana de sprites (11+11+10 llamadas/fotograma) y 88:8BEE (4/f): aritmetica pura, sin efectos en registros de PPU
HOT = (0x8A9F, 0x8ABC, 0x8ADA, 0x8BF2)
n = 0
for m in list(re.finditer(re.escape(JN), bytes(r[BANK:BANK + 0x10000]))):
    c = BANK + m.start()
    if c - BANK not in HOT: continue
    r[c:c + 7] = LDA; n += 1
print('sitios con cache', n)
open(sys.argv[2], 'wb').write(r)
