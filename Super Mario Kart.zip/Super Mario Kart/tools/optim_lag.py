#!/usr/bin/env python3
"""Reduccion de carga de CPU del modo 1P pantalla completa (sobre v1.3).
uso: optim_lag.py in.sfc out.sfc
Paso 1: las envolturas puramente aritmeticas (proyeccion DSP, descartes de objetos) leian el modo 1P con `JSR $8F00` (~49 ciclos de CPU cada una,
unas 15 veces por fotograma). Se sustituyen por la lectura de la copia en caliente `$7E:0A88` (la actualiza el bucle principal en 88:8917 al
comienzo de cada iteracion): `LDA $7E0A88` (6 ciclos). Mismos bytes y mismas banderas (Z)."""
import sys
r = bytearray(open(sys.argv[1], 'rb').read())
OLD = bytes.fromhex('20008FEAEAEAEA'); NEW = bytes.fromhex('AF880A7EEAEAEA')
SITES = [0x88892C, 0x888946, 0x888962, 0x88897E, 0x888999, 0x8889B4, 0x8889EA, 0x888BB4, 0x888C4D, 0x888C6C, 0x888D49]
def off(a): return ((a >> 16) - 0x80) * 0x10000 + (a & 0xFFFF)
import os
if os.environ.get('SITES'): SITES=[int(x,16) for x in os.environ['SITES'].split(',')]
for a in SITES:
    o = off(a); assert bytes(r[o:o+7]) == OLD, hex(a); r[o:o+7] = NEW
open(sys.argv[2], 'wb').write(r); print('paso 1:', len(SITES), 'sitios')

# ---- Paso 2: descarte de objetos (80:C86E..C88D) fusionado en una sola rutina para 1P
# Antes: 3 envolturas (88:8A9B, 88:8AB8->88:8680, 88:8AD6), cada una con PHP/REP/PHA/PLA/PLP, y dos JML encadenados (~220 ciclos por objeto).
# Ahora: un JML en 80:C86E; si el modo en caliente ($7E:0A88) es 1P se ejecuta todo el tramo en linea con la misma aritmetica
# (A=$FF00 conocido -> no hace falta PHA/PLA); si no, se llama a la envoltura original y se continua en 80:C873 (vanilla/2P intactos).
def asm(items):
    out = bytearray(); lab = {}; fix = []
    for it in items:
        if isinstance(it, str) and it.endswith(':'): lab[it[:-1]] = len(out)
        elif isinstance(it, str): out += bytes.fromhex(it.replace(' ', ''))
        else: out += bytes([int(it[0], 16), 0]); fix.append((len(out) - 1, it[1]))
    for pos, n in fix:
        d = lab[n] - (pos + 1); assert -128 <= d <= 127, (n, d); out[pos] = d & 255
    return bytes(out)
M2 = 0x8A300
assert not any(r[M2:M2+0x80])
blk = asm([
 'AF880A7E', ('D0', 'van'),
 'A900FF', '65E0', '6D0060', '851E', '9538', '952E', 'AD0060',          # A=$FF00+$E0+DSP -> $1E,$38+x,$2E+x ; A=DSP2
 '8F5CDE7F', '18', '6A', '18', '6F5CDE7F', 'C90003', ('90', 'st'), 'C90007', ('B0', 'st'), 'A9FF02', '18',
 'st:', '8518', '9506', ('B0', 'cull'),
 'A51E', '69F800', 'C9F800', ('B0', 'rts'), '5C8FC880',
 'cull:', '5CABC880',
 'rts:', '5CB0C880',
 'van:', 'A900FF', '229B8A88', '5C73C880'])
o = off(0x80C86E); assert bytes(r[o:o+5]) == bytes.fromhex('229B8A88EA'), bytes(r[o:o+5]).hex()
r[M2:M2+len(blk)] = blk
r[o:o+4] = bytes([0x5C, M2 & 255, (M2 >> 8) & 255, 0x88])
open(sys.argv[2], 'wb').write(r); print('paso 2:', len(blk), 'bytes en 88:A300')
