#!/usr/bin/env python3
"""Figura de evidencia: reparto de umbrales y ley medida tamaño vs fila (v1.3 vs candidato)."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import sys, statistics
sys.path.insert(0,'tools')
from mide_curva_tamano import scan, curva
v13=[224,192,160,128,112,96,80,64,48,32,0]
new=[336,288,240,192,168,144,120,96,72,48,0]
f=lambda t: t/3.3+23
c13,_=scan('/tmp/m1'); c17,_=scan('/tmp/ver17')
cur13=curva(c13); cur17=curva(c17)
fig,ax=plt.subplots(1,2,figsize=(13,5.2))
for i,(vals,col,lab) in enumerate([(v13,'#b03030','v1.3 (original)'),(new,'#1f6fb2','v1.7 reparto (x1,5)')]):
    for t in vals[:-1]:
        ax[0].plot([f(t),f(t)],[0,1],color=col,lw=1.2+i,alpha=.45 if i else .9)
    ax[0].plot([],[],color=col,lw=2,label=lab)
ax[0].set_xlim(30,160); ax[0].set_ylim(0,1); ax[0].set_yticks([])
ax[0].set_xlabel('fila en pantalla (la fila 158 es la más cercana, la 30 el horizonte)')
ax[0].set_title('Dónde cambia cada escalón (umbrales de la tabla $DD35)')
ax[0].invert_xaxis(); ax[0].legend(loc='upper left'); ax[0].grid(alpha=.25)
ax[0].axvspan(91,158,color='#ffd98a',alpha=.35); ax[0].text(150,.5,'tramo muerto v1.3',rotation=90,va='center',fontsize=8)
for cur,col,lab in [(cur13,'#b03030','v1.3 (original)'),(cur17,'#1f6fb2','v1.7 reparto (x1,5)')]:
    xs=[k+5 for k in sorted(cur)]; ys=[cur[k][0] for k in sorted(cur)]
    ax[1].plot(xs,ys,'o-',color=col,label=lab)
ax[1].set_xlabel('fila en pantalla (y_bot)'); ax[1].set_ylabel('altura dibujada del kart rival (px)')
ax[1].set_title('Altura medida de los rivales según su fila')
ax[1].invert_xaxis(); ax[1].grid(alpha=.25); ax[1].legend()
ax[1].set_ylim(14,34)
plt.tight_layout(); plt.savefig('docs/curva_tamano_v13_vs_v17.png',dpi=110)
print("guardado docs/curva_tamano_v13_vs_v17.png")
