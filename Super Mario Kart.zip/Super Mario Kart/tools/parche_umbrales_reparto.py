#!/usr/bin/env python3
"""Escribe la tabla de UMBRALES DE TAMAÑO de los karts ($81:$DD35 = file 0xDD35, 11 palabras).
Uso: python3 tools/parche_umbrales_reparto.py entrada.sfc salida.sfc v0 v1 ... v10
  (11 valores decimales; v10 = 0). Reproduce exactamente el candidato B con:
  v0=264 240 200 160 140 120 100 80 60 40 0"""
import sys
src,dst=sys.argv[1],sys.argv[2]
vals=[int(x) for x in sys.argv[3:14]]
assert len(vals)==11
rom=bytearray(open(src,'rb').read())
for i,t in enumerate(vals):
    rom[0xDD35+2*i]=t&0xff; rom[0xDD36+2*i]=t>>8
open(dst,'wb').write(bytes(rom))
print("tabla escrita:", vals)
print("filas aprox:", [round(t/3.3+23) for t in vals])
