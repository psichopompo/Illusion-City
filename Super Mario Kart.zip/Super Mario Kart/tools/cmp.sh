#!/bin/bash
# uso: tools/cmp.sh romA romB state frames [script]   (desde smk_work; requiere /tmp/drive: bash tools/setup_tmp.sh)
A=$1; B=$2; S=$3; N=$4; SC=${5:-/tmp/b.txt}
rm -rf /tmp/cA /tmp/cB; mkdir /tmp/cA /tmp/cB
/tmp/drive cores/bsnes_instr.so "$A" "$S" $N $SC /tmp/cA 1 >/dev/null 2>&1 &
/tmp/drive cores/bsnes_instr.so "$B" "$S" $N $SC /tmp/cB 1 >/dev/null 2>&1 &
wait
python3 - $N <<'PY'
import sys,os
n=int(sys.argv[1]); d=[]
for f in range(n):
    a='/tmp/cA/f%04d.ppm'%f; b='/tmp/cB/f%04d.ppm'%f
    if not(os.path.exists(a) and os.path.exists(b)): d.append(('falta',f)); continue
    if open(a,'rb').read()!=open(b,'rb').read(): d.append(f)
print('frames',n,'distintos',len(d),d[:15])
PY
