#!/usr/bin/env python3
"""v1.1: los registros de color math/ventanas del IRQ V=107 (JSR $8BBF con X=1) se escribian a mitad de
linea 109 en pantalla activa (en vanilla ocurrian bajo forced blank). En hardware real eso pinta puntos.
Ahora, en el camino 'hack' (gate A=0) se esperan al H-blank antes de llamar a $8BBF.
uso: fix_banda_hblank.py in.sfc out.sfc"""
import sys
d = bytearray(open(sys.argv[1], 'rb').read())
hdr = len(d) & 0x7FFF
assert hdr == 0, hdr
def off(bank, addr): return ((bank & 0x3F) << 16) | (addr & 0xFFFF)   # mapeo estilo HiROM (banco 88 -> 0x88xxx)
# 88:88F6  JML $808BBF  ->  JML $88A140
o = off(0x88, 0x88F6)
assert d[o:o+4] == bytes([0x5C, 0xBF, 0x8B, 0x80]), d[o:o+4].hex()
d[o:o+4] = bytes([0x5C, 0x40, 0xA1, 0x88])
# bloque nuevo en 88:A140 (libre)
n = off(0x88, 0xA140)
assert all(b in (0x00, 0xFF) for b in d[n:n+96]), d[n:n+96].hex()
code = bytes.fromhex(
    "08"          # PHP
    "c220"        # REP #$20
    "48"          # PHA            (A de 16 bits intacto)
    "e230"        # SEP #$30
    "da" "5a"     # PHX PHY
    "ad7b01"      # LDA $017B      (2130, x=1)
    "eb"          # XBA
    "ad6b01"      # LDA $016B      (2131, x=1)
    "eb"          # XBA            A=2130 B=2131
    "ae6d01"      # LDX $016D      (2132 R)
    "ac6f01"      # LDY $016F      (2132 G)
    "2c1242" "70fb"   # w1: BIT $4212 / BVS w1   (salir del H-blank actual)
    "2c1242" "50fb"   # w2: BIT $4212 / BVC w2   (inicio del siguiente H-blank)
    "8d3021"      # STA $2130
    "eb"          # XBA
    "8d3121"      # STA $2131
    "8e3221"      # STX $2132 (R)
    "8c3221"      # STY $2132 (G)
    "ad7101"      # LDA $0171      (2132 B; se escribe en el H-blank siguiente)
    "ae0901"      # LDX $0109      (2125)
    "ac4f01"      # LDY $014F      (212E)
    "2c1242" "70fb"   # w3
    "2c1242" "50fb"   # w4  (H-blank de la linea siguiente)
    "8d3221"      # STA $2132 (B)
    "8e2521"      # STX $2125
    "8c2e21"      # STY $212E
    "7a" "fa"     # PLY PLX
    "c220" "68"   # REP #$20 / PLA
    "28"          # PLP
    "5ce98b80"    # JML $808BE9  (RTS de banco 80, como el original)
)
d[n:n+len(code)] = code
open(sys.argv[2], 'wb').write(d)
