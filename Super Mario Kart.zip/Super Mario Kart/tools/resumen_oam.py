#!/usr/bin/env python3
"""Resumen del sprite de cada kart en un fotograma: nº de sprites, tamaño, separacion y arte.
Uso: resumen_oam.py <dir> <frame> [--vram fichero]"""
import sys
def main():
    d=sys.argv[1]; fr=int(sys.argv[2])
    vram=None
    if '--vram' in sys.argv: vram=open(sys.argv[sys.argv.index('--vram')+1],'rb').read()
    o=open(f'{d}/oamlog.bin','rb').read()
    b=(fr-1)*544; low=o[b:b+512]; high=o[b+512:b+544]
    print(f'{d} f{fr}')
    print(f'{"kart":>4} {"nsp":>3} {"tam":>3} {"dx":>3} {"dy":>3} {"x":>4} {"y":>4} {"arte":>7}  tiles')
    for kk in range(8):
        base=28+4*kk
        sl=[]
        for i in range(base,base+4):
            j=i*4
            hb=(high[i>>2]>>((i&3)*2))&3
            x=low[j]|((hb&1)<<8); big=(hb>>1)&1
            sl.append(dict(x=x,y=low[j+1],t=low[j+2],a=low[j+3],big=big))
        vis=[s for s in sl if s['y']<224]
        if not vis:
            print(f'{kk:4d} {0:3d}   -   -   -    -    -        -')
            continue
        # agrupar por filas
        ys=sorted(set(s['y'] for s in vis))
        dy=(ys[1]-ys[0]) if len(ys)>1 else 0
        row0=[s for s in vis if s['y']==ys[0]]
        dx=(max(s['x'] for s in row0)-min(s['x'] for s in row0)) if len(row0)>1 else 0
        tam=16 if vis[0]['big'] else 8
        tiles=' '.join(f'{s["t"]:02X}' for s in vis)
        art=''
        if vram:
            C=112; OFF=40; cv=[[0]*C for _ in range(C)]
            x0=min(s['x'] for s in vis); y0=min(s['y'] for s in vis)
            for s in vis:
                n=2 if s['big'] else 1
                for ty in range(n):
                    for tx in range(n):
                        tno=(s['t']+(ty*16 if s['big'] else 0)+tx)&0x1FF
                        off=0x8000+32*tno
                        for r in range(8):
                            p=[vram[off+r*2+1],vram[off+r*2],vram[off+16+r*2+1],vram[off+16+r*2]]
                            for q in range(8):
                                b2=7-q
                                v=((p[0]>>b2)&1)|(((p[1]>>b2)&1)<<1)|(((p[2]>>b2)&1)<<2)|(((p[3]>>b2)&1)<<3)
                                if v:
                                    Y=s['y']-y0+ty*8+OFF; X=s['x']-x0+tx*8+OFF
                                    if 0<=Y<C and 0<=X<C: cv[Y][X]=v
            ys2=[y for y in range(C) if any(cv[y])]; xs2=[x for x in range(C) if any(cv[y][x] for y in range(C))]
            if ys2: art=f'{xs2[-1]-xs2[0]+1}x{ys2[-1]-ys2[0]+1}'
        print(f'{kk:4d} {len(vis):3d} {tam:3d} {dx:3d} {dy:3d} {min(s["x"] for s in vis):4d} {min(s["y"] for s in vis):4d} {art:>7}  {tiles}')
if __name__=='__main__': main()
