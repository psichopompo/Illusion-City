#!/bin/bash
# reconstruye el entorno de pruebas en /tmp (se borra entre sesiones)
cd /home/user/smk_work
gcc -O2 -I user_upload -o /tmp/drive harness/drive.c -ldl -lm
(cat harness/script_copa_a_parrilla.txt; echo "520 1000 0"; echo "700 718 6") > /tmp/sc_p.txt
python3 - <<'PY'
import sys; sys.path.insert(0,'/home/user/smk_work/tools')
import make_camera_ramp as m
r=bytearray(open('/home/user/smk_work/roms/t_vK58.sfc','rb').read())
m.apply(r,0xACB6,0xCEC5,0xCEE5); open('/tmp/ut_hb.sfc','wb').write(r)
PY
python3 tools/make_eu_state_compat.py eu_camara_candidato.sfc /tmp/eu_final_compat.sfc >/dev/null
echo "0 1500 0" > /tmp/b.txt; printf "0 300 0\n" > /tmp/s.txt
