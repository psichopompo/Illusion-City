#!/usr/bin/env python3
"""Parpadeo del marcador de monedas/vidas (1P): deja de reescribir la Y vanilla de las monedas en cada fotograma.

usage: hud_coin_y.py in.sfc out.sfc

Causa: el bucle de espera del NMI del juego (80:805C) esta redirigido a 88:8000; al salir de la espera llama a 88:8035, que escribe
Y=$BC (la Y vanilla) en los 4 sprites de las monedas (OAM 20..23) al empezar la logica de cada fotograma. El barrido de final de
fotograma (88:9100 -> 88:9900) los sube despues a Y=205. Si la logica dura mas de un fotograma (lag: arranque con Lakitu, etc.), la
DMA del OAM (IRQ de la linea 219) ocurre entre las dos cosas y ese fotograma las monedas salen 17 px mas arriba, pegadas a los coches.
Arreglo: 88:8035 salta a un stub nuevo (88:9AC0) que solo escribe $BC si NO es 1P ($AA != $1000); en 1P el barrido deja la Y
final (205) y nadie la vuelve a tocar. 2P queda igual que antes.
"""
import sys
r = bytearray(open(sys.argv[1], 'rb').read())
O = 0x88035; S = 0x89AC0
orig = bytes.fromhex('A9BC 8D5102 8D5502 8D5902 8D5D02 60')
assert bytes(r[O:O + len(orig)]) == orig, r[O:O + len(orig)].hex()
assert not any(r[S:S + 0x20]), 'area no libre'
code = bytes.fromhex('A5AB C910 F00E') + orig            # LDA $AB ; CMP #$10 ; BEQ fin (1P) ; (original) ; RTS
assert code[-1] == 0x60 and 6 + code[5] == len(code) - 1   # el BEQ cae en el RTS
r[S:S + len(code)] = code
r[O:O + 3] = bytes([0x4C, S & 0xFF, (S >> 8) & 0xFF])    # JMP $9AC0
open(sys.argv[2], 'wb').write(r)
print('stub %d bytes' % len(code))
