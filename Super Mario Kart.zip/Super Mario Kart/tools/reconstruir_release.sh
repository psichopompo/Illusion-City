#!/bin/bash
# Reconstruye la ROM de la release v1.1 desde la base del hack fullscreen y comprueba que coincide con la guardada.
# uso: bash tools/reconstruir_release.sh [salida.sfc]   (por defecto /tmp/release_reconstruida.sfc)
set -e
cd "$(dirname "$0")/.."
OUT="${1:-/tmp/release_reconstruida.sfc}"
python3 tools/build_usa_camara.py /tmp/_r0.sfc >/dev/null          # base fullscreen + camara + HUD + digitos + menus  (= roms/usa_camara_candidato.sfc)
python3 tools/add_signature.py /tmp/_r0.sfc /tmp/_r1.sfc >/dev/null # firma del titulo (stub en 80:FFA0)
python3 tools/lakitu_sombra.py /tmp/_r1.sfc /tmp/_r2.sfc >/dev/null # sombra de Lakitu en el rescate
python3 tools/ranked_borde.py /tmp/_r2.sfc /tmp/_r3.sfc >/dev/null  # resto bajo el digito GRANDE (Ranked Out)
python3 tools/hud_coin_y.py /tmp/_r3.sfc /tmp/_r4.sfc >/dev/null     # parpadeo del marcador de monedas
python3 tools/fix_banda_hblank.py /tmp/_r4.sfc "$OUT" >/dev/null     # v1.1: pixeles blancos de la banda (bloque de color en H-blank, 88:A140)
REF="roms/Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).sfc"
cmp "$OUT" "$REF" && echo "OK: identica a la release (CRC32 $(python3 -c "import zlib,sys;print('%08X'%zlib.crc32(open(sys.argv[1],'rb').read()))" "$OUT"))"
rm -f /tmp/_r0.sfc /tmp/_r1.sfc /tmp/_r2.sfc /tmp/_r3.sfc /tmp/_r4.sfc /tmp/_r4.sfc
