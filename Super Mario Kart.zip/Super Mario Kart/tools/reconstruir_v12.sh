#!/bin/bash
# Candidato v1.2 (experimental): v1.1 + centro del suelo (make_camera_ramp.py, DF_MAX=12) + Lakitu (lakitu_y.py).
# uso: bash tools/reconstruir_v12.sh [salida.sfc]
set -e
cd "$(dirname "$0")/.."
OUT="${1:-/tmp/candidato_v12.sfc}"
python3 tools/build_usa_camara.py /tmp/_s0.sfc >/dev/null
python3 tools/add_signature.py /tmp/_s0.sfc /tmp/_s1.sfc >/dev/null
python3 tools/lakitu_sombra.py /tmp/_s1.sfc /tmp/_s2.sfc >/dev/null
python3 tools/ranked_borde.py /tmp/_s2.sfc /tmp/_s3.sfc >/dev/null
python3 tools/hud_coin_y.py /tmp/_s3.sfc /tmp/_s4.sfc >/dev/null
python3 tools/fix_banda_hblank.py /tmp/_s4.sfc /tmp/_s5.sfc >/dev/null
python3 tools/lakitu_y.py /tmp/_s5.sfc /tmp/_s6.sfc >/dev/null
python3 tools/gate_cache.py /tmp/_s6.sfc "$OUT" >/dev/null
rm -f /tmp/_s?.sfc
python3 -c "import zlib,sys;print('CRC32 %08X'%zlib.crc32(open(sys.argv[1],'rb').read()))" "$OUT"
