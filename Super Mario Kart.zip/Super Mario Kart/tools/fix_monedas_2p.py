#!/usr/bin/env python3
"""Monedas de Lakitu por abajo en dobles (2P).
uso: fix_monedas_2p.py in.sfc out.sfc
Causa: el dibujo de las monedas (85:E700, `JSL $889C00`) suma `$7E:0A9C` (+$5800 = 88 px) a su Y. `$0A9C` solo lo refresca la rama 1P del
manejador de carrera (88:87E8 -> JSR 88:9B00). En 2P el manejador va por la rama original (88:8D52 -> JML $84ECC0) y nunca lo pone a cero,
asi que conserva el +$5800 de una carrera 1P anterior de la misma sesion y las monedas salen 88 px mas abajo (en la mitad del otro jugador).
Arreglo: en la rama no-1P del manejador de carrera se pone `$0A9C` = 0 antes de seguir con la rutina original. La rama 1P no cambia."""
import sys
r = bytearray(open(sys.argv[1], 'rb').read())
def off(a): return ((a >> 16) - 0x80) * 0x10000 + (a & 0xFFFF)
S = 0x8A400
assert not any(r[S:S+0x20])
o = off(0x888D52)
assert bytes(r[o:o+6]) == bytes.fromhex('68285CC0EC84'), bytes(r[o:o+8]).hex()
stub = bytes.fromhex('A90000' '8F9C0A7E' '68' '28' '5CC0EC84')     # LDA #0 ; STA $7E0A9C ; PLA ; PLP ; JML $84ECC0
r[S:S+len(stub)] = stub
r[o:o+4] = bytes([0x5C, S & 255, (S >> 8) & 255, 0x88])               # JML 88:A400 (4 bytes, pisa PLA PLP y 2 bytes del JML)
# quedan 2 bytes sueltos (EC 84) inalcanzables: el bloque 8D58 empieza justo despues
open(sys.argv[2], 'wb').write(r); print('fix monedas 2P:', len(stub), 'bytes en 88:A400')
