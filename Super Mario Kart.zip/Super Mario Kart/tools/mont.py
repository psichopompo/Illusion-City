import re,sys
from PIL import Image
def rd(p):
    d=open(p,'rb').read(); m=re.match(rb'P6\s+(\d+)\s+(\d+)\s+255\s',d); return Image.frombytes('RGB',(int(m.group(1)),int(m.group(2))),d[m.end():])
d,out=sys.argv[1],sys.argv[2]; fr=[int(x) for x in sys.argv[3:]]
cols=min(5,len(fr)); rows=(len(fr)+cols-1)//cols
W,H=256,224
im=Image.new('RGB',(W*cols,H*rows))
for i,f in enumerate(fr):
    try: im.paste(rd(f'{d}/f{f:04d}.ppm'),(W*(i%cols),H*(i//cols)))
    except Exception as e: print('falta',f)
if cols*W>1280: im=im.resize((1280,int(im.height*1280/im.width)))
im.save(out)
