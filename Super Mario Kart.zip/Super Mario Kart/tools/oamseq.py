# uso: SCR=script.txt python3 tools/oamseq.py rom state frames "filtro(i,x,y,t,a)"  -> lista por fotograma las entradas OAM que cumplen el filtro
import sys,subprocess,os,shutil
rom,state,n,flt=sys.argv[1],sys.argv[2],int(sys.argv[3]),sys.argv[4]
d='/tmp/oq'; shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
env=dict(os.environ,WLOG='200,512')
subprocess.run(['/tmp/drive','/home/user/smk_work/cores/bsnes_prof.so',rom,state,str(n),os.environ.get('SCR','/tmp/vacio.txt'),d,'0'],env=env,capture_output=True)
for l in open(d+'/wlog.txt'):
    p=l.split(); f=int(p[0]); b=bytes(int(x,16) for x in p[1:])
    ent=[]
    for i in range(128):
        x,y,t,a=b[i*4:i*4+4]
        if y<0xE0 and eval(flt): ent.append((i,x,y,hex(t),hex(a)))
    print(f,ent)
