#!/bin/bash
# reconstruye lo minimo de /tmp (se borra entre turnos): /tmp/drive, script vacio
cd /home/user/smk_work
gcc -O2 -I user_upload -o /tmp/drive harness/drive.c -ldl -lm
: > /tmp/e.txt
printf "0 5000 0\n" > /tmp/acc.txt   # B (acelerar) pulsado
printf "520 524 3\n" > /tmp/st.txt   # Start
