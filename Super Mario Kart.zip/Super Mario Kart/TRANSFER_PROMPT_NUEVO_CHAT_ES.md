# Prompt de transferencia — Super Mario Kart USA · Fullscreen Edition (by Psicopompo)

Responder siempre en español. Especialista en ROM hacking de SNES/65816, PPU/OAM/HDMA, Mode 7 y bsnes/libretro. Encadenar experimentos sin detenerse tras una captura; preguntar al usuario solo cuando la decisión no se pueda resolver técnicamente. Preferir pedir un state o ROM antes que perder tiempo intentando arrancar una carrera conduciendo menús.

## Estado
- **v1.1 (v1.0 publicada)** (romhacking.net, GitHub, elotrolado.net). Solo versión USA (la PAL recorta la pantalla).
- ROM: `roms/Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).sfc`, 1 MiB, CRC32 `17EFB04F`, SHA-1 `342150EB6D1FE2F3888510472F46F74624E6D932`. Parches en `release/` con el mismo nombre (`.ips`, `.bps`, `.zip`); textos en `release/posts/`.
- Reconstrucción: `bash tools/reconstruir_release.sh` (base `roms/Super Mario Kart USA Full Screen.sfc` → `build_usa_camara.py` → `add_signature.py` → `lakitu_sombra.py` → `ranked_borde.py` → `hud_coin_y.py`; comprueba que sale idéntica). Historial técnico completo: `docs/DOCUMENTACION_ES.md`. Cualquier cambio futuro = versión 1.1 con ROM/IPS/BPS/zip/CRC/SHA/textos regenerados y parches verificados desde la ROM USA limpia (`tools/make_patches.py`).
- El usuario sigue cazando bugs y puede enviar states nuevos.

## Entorno de pruebas
- `bash tools/env_rapido.sh` compila `/tmp/drive` (se borra entre turnos). Uso: `/tmp/drive cores/bsnes_prof.so ROM payload.bin NFRAMES script OUTDIR 100000`; script de entrada = líneas `inicio fin botón` (`0 5000 0` = mantener B/acelerar; 6 izq., 7 der., 8 A). Variables: `SNAPS` (fotogramas a guardar), `OAMLOG=1`, `WLOG=dir,len`, `STATEF=n`, `POKE=dir:hex`, `OAMW=n`, `HIST`, `TELEPORT`… (ver `harness/drive.c`).
- States: `states/` (ver `states/README_ES.md`); convertir `.state` RZIP con `tools/rzip_to_payload.py`. `tools/cmp.py`, `tools/sheet2.py`, `tools/oamseq.py`, `tools/dis65816.py`, `smk_disassembly/` (bank00/01/05.asm = bancos 80/81/85).
- Regresión: ROM anterior vs nueva sobre todos los states (mantener B), clasificando las diferencias por zona; no usar los states vanilla/EU para juzgar la ROM nueva.

## Reglas y decisiones del usuario (vigentes)
- No cambiar cámara, inclinación, rotación ni escala para arreglar problemas de prioridad OAM. No promover reordenamientos OAM ni tocar `$8094A1`/`oamPriority`/raster por orden OAM: esa rama está cerrada salvo captura nueva y distinta.
- No reescribir bytes del candidato por conjetura. No usar PPM de 0/1 fotograma (mínimo 2 tras `unserialize`). Slots 24–27 son `ROUND 1`, no restos de P1. La DMA de OAM sale de `$0200` (no `$0420`). `state_2p_payload.bin` no es 2P. No dar `$0406` por validado con una carrera avanzada.
- Terminología de dígitos: "grande" (minúscula) = dígito pequeño junto a los contadores; "GRANDE" = dígito grande de la pantalla final. El pequeño va ≈ −8 px a la izquierda; GRANDE sin mover. Tabla LAP TIME y caras del puesto 20 px más abajo que vanilla; centrada solo en Y. Banner Ranked Out ≈5 px más arriba (no bajar RETRY/END); Game Over y ROUND 1 centrados en Y.
- Aparición brusca de tuberías (pop-in): decisión final, se deja como está (también ocurre en vanilla USA). Para reproducir `apariciones.state`: cargar manteniendo acelerar y avanzar recto.
- No afirmar que un límite de objetos por pantalla hace desaparecer uno antiguo (rechazado por el usuario). Los mensajes de la plataforma pueden llegar tarde o repetidos: no tomarlo como impaciencia.
- Firma del título: `Fullscreen Edition · Psicopompo`, blanca, pequeña, sin números de versión, sin la palabra "hack", sin © propio; "© 1992 Nintendo" desplazado 2 px a la derecha. Stub de la firma en `80:FFA0` (no usar `80:92F2`: pisaba la tabla de fotogramas de kart y rompía a Luigi; no usar `FFB0+`).
- Textos públicos: foro en BBCode solo con negrita, cursiva, cita y lista; foro/RHDN no demasiado largos (GitHub puede ser largo); la noticia en tercera persona ("Psicopompo ha publicado…"). Hay que subrayar que no es como los hacks anteriores que solo quitaban el mapa y explicar por qué se eliminaron mapa y retrovisor. **No mencionar a Grego ni su parche, sin cláusula GPL.** No prometer en público tropiezos/hielo agrietado sin verificar. Nombre oficial de archivos: `Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).*`.

## Trampas técnicas conocidas
- No enganchar nada en la ruta del modo 0 (`81BF`): el NMI interrumpe la carga a mitad de subida. Un stub llamado con `JSR` debe volver con `REP #$30` antes de `RTS`; un stub `JSL` acaba en `RTL`; un `JML` no puede acabar en `RTS`.
- No hacer `STA` de 16 bits a `$420B`; DMA solo canal 0, HDMA canales 1–7.
- El IRQ de la línea 219 (`80:8B9C`..`8BBE`, hace la DMA del OAM) es muy sensible al tiempo: añadir 2 NOP a un stub corrompía gráficos. No poner trabajo extra ahí; corregir en el origen.
- Lag: el cronómetro `$0100` no avanza en los fotogramas con lag. Los sprites del HUD (OAM 16..23) los coloca el barrido de final de fotograma (`88:9100`/`88:9900`); el bucle de espera del NMI (`88:8000`) llamaba a `88:8035` (ahora con puerta 1P) que reescribía la Y vanilla.
- Resto bajo el dígito GRANDE: causa exacta del desenmascarado no identificada; se oculta apagando la pantalla en la línea 216 (`ranked_borde.py`) solo en 1P/Ranked Out/pantalla oscura (`$016B == $AD`).
- IPS: el offset `0x454F46` chocaría con "EOF"; la mitad alta de 512 KB es casi todo ceros.
