
/* descompresor zlib minimo (usamos zlib del sistema) */
#include <zlib.h>
static int uncompress_state(const unsigned char*in,size_t inlen,unsigned char*out,size_t outcap,size_t*outlen){
  uLongf dl=outcap; int r=uncompress(out,&dl,in,(uLong)inlen); if(r!=Z_OK) return 0; *outlen=dl; return 1;
}

// Harness de conducción: carga state, pulsa botones según script, registra por frame
// $0036 (modo), $0406, $0626, $0D28 y escrituras (PC) a 0400/0406/0600/0620/0626.
// uso: drive core rom state frames script.txt outdir [ppm_every]
// script: líneas "desde hasta botón" (botón = id retropad: A=8 B=0 START=3 UP=4 DOWN=5 LEFT=6 RIGHT=7)
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <dlfcn.h>
#include "libretro.h"
#include "libretro_vfs.h"
#ifndef RETRO_ENVIRONMENT_SET_MESSAGE_EXT
#define RETRO_ENVIRONMENT_SET_MESSAGE_EXT 66
#endif
static unsigned char *last_frame; static unsigned last_w,last_h,last_pitch; static enum retro_pixel_format pixfmt=RETRO_PIXEL_FORMAT_XRGB8888;
static bool env(unsigned cmd, void *data){
  switch(cmd){
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data="/tmp"; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: pixfmt=*(enum retro_pixel_format*)data; return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS: case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME: case RETRO_ENVIRONMENT_SET_MESSAGE: case RETRO_ENVIRONMENT_SET_MESSAGE_EXT: return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data=false; return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE:{struct retro_variable*v=data; if(v->key&&!strcmp(v->key,"bsnes_ppu_fast")){v->value=getenv("PPU_SLOW")?"OFF":"ON";return true;} return false;}
    case RETRO_ENVIRONMENT_GET_VFS_INTERFACE:{struct retro_vfs_interface_info*i=data; i->iface=&vfs_iface; return true;}
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:{struct retro_log_callback*cb=data; cb->log=core_log; return true;}
    case RETRO_ENVIRONMENT_GET_LANGUAGE: *(unsigned*)data=0; return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES: case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS: case RETRO_ENVIRONMENT_SET_MEMORY_MAPS: return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)data=0; return true;
    case RETRO_ENVIRONMENT_GET_FASTFORWARDING: *(bool*)data=false; return true;
    default: return false;
  }
}
static void video(const void*d,unsigned w,unsigned h,size_t p){static int once=0; if(!once){once=1; fprintf(stderr,"[drive] video %ux%u pitch %zu fmt %d\n",w,h,p,(int)pixfmt);} free(last_frame);last_frame=malloc(p*h);memcpy(last_frame,d,p*h);last_w=w;last_h=h;last_pitch=p;}
static void aud(int16_t l,int16_t r){(void)l;(void)r;} static size_t audb(const int16_t*d,size_t f){(void)d;return f;}
static void poll(void){}
static long gframe=0; static int ns=0; static long sf_[256],st_[256]; static int sb_[256]; static int sp_pad[256];
static int16_t input(unsigned p,unsigned d,unsigned i,unsigned id){(void)i;
  if(d!=1||id>=16) return 0; { const char*pp=getenv("PORTS"); int want=pp?atoi(pp):3; if(!((want>>p)&1)) return 0; }
  for(int k=0;k<ns;k++) if(gframe>=sf_[k]&&gframe<st_[k]&&sb_[k]==(int)id&&sp_pad[k]==(int)p) return 1; return 0;}

/* lee un píxel de la superficie y lo devuelve como R,G,B (tenga el formato que tenga el core) */
static void get_rgb(const unsigned char*base,unsigned x,unsigned char*r,unsigned char*g,unsigned char*b){
  if(pixfmt==RETRO_PIXEL_FORMAT_RGB565){
    const unsigned char*p=base+x*2; unsigned v=p[0]|(p[1]<<8);
    *r=((v>>11)&31)*255/31; *g=((v>>5)&63)*255/63; *b=(v&31)*255/31;
  } else if(pixfmt==RETRO_PIXEL_FORMAT_0RGB1555){
    const unsigned char*p=base+x*2; unsigned v=p[0]|(p[1]<<8);
    *r=((v>>10)&31)*255/31; *g=((v>>5)&31)*255/31; *b=(v&31)*255/31;
  } else {
    const unsigned char*p=base+x*4; *b=p[0]; *g=p[1]; *r=p[2];
  }
}

static void save_ppm(const char*path){
  FILE*f=fopen(path,"wb"); if(!f)return; fprintf(f,"P6\n%u %u\n255\n",last_w,last_h);
  for(unsigned y=0;y<last_h;y++)for(unsigned x=0;x<last_w;x++){unsigned char r,g,b; get_rgb(last_frame+y*last_pitch,x,&r,&g,&b); fputc(r,f);fputc(g,f);fputc(b,f);} fclose(f);}
int main(int argc,char**argv){
  if(argc<7){fprintf(stderr,"uso\n");return 2;}
  void*h=dlopen(argv[1],RTLD_NOW); if(!h){fprintf(stderr,"%s\n",dlerror());return 3;}
  #define S(n) dlsym(h,n)
  void(*setenv_)(retro_environment_t)=S("retro_set_environment"); void(*sv)(retro_video_refresh_t)=S("retro_set_video_refresh");
  void(*sa)(retro_audio_sample_t)=S("retro_set_audio_sample"); void(*sab)(retro_audio_sample_batch_t)=S("retro_set_audio_sample_batch");
  void(*sp_)(retro_input_poll_t)=S("retro_set_input_poll"); void(*si)(retro_input_state_t)=S("retro_set_input_state");
  void(*init)(void)=S("retro_init"); bool(*load)(const struct retro_game_info*)=S("retro_load_game");
  bool(*us)(const void*,size_t)=S("retro_unserialize"); void(*run)(void)=S("retro_run");
  void(*dbg)(const char*)=S("bsnes_debug_dump"); void*(*mem)(unsigned)=S("retro_get_memory_data");
  void(*cpd)(unsigned,unsigned)=S("retro_set_controller_port_device");
  setenv_(env);sv(video);sa(aud);sab(audb);sp_(poll);si(input);init();
  FILE*rf=fopen(argv[2],"rb");fseek(rf,0,SEEK_END);long n=ftell(rf);rewind(rf);void*rom=malloc(n);fread(rom,1,n,rf);fclose(rf);
  struct retro_game_info gi={argv[2],rom,(size_t)n,NULL}; if(!load(&gi))return 4; if(cpd){cpd(0,1);cpd(1,1);}
  bool want=strcmp(argv[3],"-")!=0;
  if(want){FILE*f=fopen(argv[3],"rb");fseek(f,0,SEEK_END);long sn=ftell(f);rewind(f);unsigned char*sp=malloc(sn);fread(sp,1,sn,f);fclose(f);
    if(sn>4 && sp[0]=='R' && sp[1]=='A' && sp[2]=='S'){                        /* .raw ya descomprimido */
      if(!us(sp,sn)){fprintf(stderr,"unserialize fail (raw)\n");return 5;}
    } else if(sn>24 && sp[0]=='#' && sp[1]=='R' && sp[2]=='Z' && sp[3]=='I'){    /* state RZIP de RetroArch: varios chunks zlib */
      unsigned char*real=malloc(1<<21); size_t rn=0, off=20; int ok=0, nch=0;
      while(off+4<=(size_t)sn){
        uint32_t sz=sp[off]|sp[off+1]<<8|sp[off+2]<<16|sp[off+3]<<24;
        if(off+4+sz>(size_t)sn) break;
        size_t got=0;
        if(!uncompress_state(sp+off+4,sz,real+rn,(1<<21)-rn,&got)){break;}
        rn+=got; nch++; off+=4+sz;
      }
      if(rn){ok=1;}
      fprintf(stderr,"state RZIP: %d chunks, %zu bytes\n",nch,rn);
      if(!ok){fprintf(stderr,"unzip fail\n");return 6;}
      /* RetroArch antepone cabecera RASTATE (16 bytes): el core debe recibir solo su payload */
      unsigned char* pay=real; size_t pn=rn;
      if(rn>16 && !memcmp(real,"RASTATE",7)){
        uint32_t decl=real[12]|real[13]<<8|real[14]<<16|real[15]<<24;
        pay=real+16; pn=(decl && decl<=rn-16) ? decl : rn-16;
        fprintf(stderr,"cabecera RASTATE: salto de 16 bytes, payload %zu\n",pn);
      }
      if(!us(pay,pn)){fprintf(stderr,"unserialize fail (RZIP)\n");return 5;}
    } else {
      uint32_t ln=sp[12]|sp[13]<<8|sp[14]<<16|sp[15]<<24; if(!us(sp+16,ln)){fprintf(stderr,"unserialize fail\n");return 5;}}
  }
  if(want && cpd){ cpd(0,1); cpd(1,0); fprintf(stderr,"[drive] puertos reasignados tras cargar el estado\n"); }
  int frames=atoi(argv[4]);
  FILE*sc=fopen(argv[5],"r"); if(sc){char line[128];while(fgets(line,sizeof line,sc)){long a,b;int k,pd=0;int nn=sscanf(line,"%ld %ld %d %d",&a,&b,&k,&pd);if(nn>=3&&ns<256){sf_[ns]=a;st_[ns]=b;sb_[ns]=k;sp_pad[ns]=pd;ns++;}}fclose(sc);}
  const char*out=argv[6]; int every=argc>7?atoi(argv[7]):0; char path[512];
  snprintf(path,sizeof path,"%s/trace.txt",out); FILE*tr=fopen(path,"w");
  snprintf(path,sizeof path,"%s/frames.txt",out); FILE*fl=fopen(path,"w");
  int prev406=-1; unsigned char lastmode=255;
  for(int fi=0;fi<frames;fi++){
    gframe=fi; run();
    unsigned char*w=mem?mem(2):0;
    { static unsigned char*wd=0; if(!w){ if(!wd){ wd=calloc(1,1<<16); fprintf(stderr,"[drive] core sin WRAM accesible: modo solo captura\n"); } w=wd; } }
    { const char*tp=getenv("TELEPORT"); if(tp){ int f0,k,dx,dy; if(sscanf(tp,"%d,%d,%d,%d",&f0,&k,&dx,&dy)==4 && fi==f0){ int s=0x1000+0x100*k, d=0x1000; for(int o=0x16;o<0x20;o++) w[d+o]=w[s+o]; short x=w[d+0x18]|w[d+0x19]<<8, y=w[d+0x1C]|w[d+0x1D]<<8; x+=dx; y+=dy; w[d+0x18]=x&255; w[d+0x19]=(x>>8)&255; w[d+0x1C]=y&255; w[d+0x1D]=(y>>8)&255; } } }
    { const char*fo=getenv("FOLLOW"); if(fo){ int f0=atoi(fo); const char*c=strchr(fo,','); int k=c?atoi(c+1):1; int bk=getenv("BEHIND")?atoi(getenv("BEHIND")):0;
      if(fi>=f0){ int s=0x1000+0x100*k, d=0x1000; for(int o=0x16;o<0x20;o++) w[d+o]=w[s+o]; w[d+0x94]=w[s+0x94]; w[d+0x95]=w[s+0x95]; w[d+0xA4]=w[s+0xA4]; w[d+0xA5]=w[s+0xA5]; (void)bk; } } }
    { const char*rs=getenv("RIVSET"); if(rs){ static int inited=0; static int seg[32][5]; static int nseg=0; if(!inited){ inited=1; char buf[1024]; snprintf(buf,sizeof buf,"%s",rs); char*tok=strtok(buf,";"); while(tok&&nseg<32){ sscanf(tok,"%d,%d,%d,%d,%d",&seg[nseg][0],&seg[nseg][1],&seg[nseg][2],&seg[nseg][3],&seg[nseg][4]); nseg++; tok=strtok(NULL,";"); } } for(int si=0;si<nseg;si++){ if(fi>=seg[si][3]&&fi<=seg[si][4]){ int k=seg[si][0]; int s=0x1000, d=0x1000+0x100*k; short x=w[s+0x18]|w[s+0x19]<<8, y=w[s+0x1C]|w[s+0x1D]<<8; int dy=seg[si][2]+((seg[si][2]!=seg[si][1])?(0):0); x+=seg[si][1]; y+=dy; w[d+0x18]=x&255; w[d+0x19]=(x>>8)&255; w[d+0x1C]=y&255; w[d+0x1D]=(y>>8)&255; w[d+0x16]=w[s+0x16]; w[d+0x17]=w[s+0x17]; w[d+0x1A]=w[s+0x1A]; w[d+0x1B]=w[s+0x1B]; } } } }
    { const char*rs=getenv("RIVSCAN"); if(rs){ int k,dx,dy0,dy1; if(sscanf(rs,"%d,%d,%d,%d",&k,&dx,&dy0,&dy1)==4){ int dyd=dy0+(int)((long)(dy1-dy0)*fi/(frames>1?frames-1:1)); int s=0x1000, d=0x1000+0x100*k; short x=w[s+0x18]|w[s+0x19]<<8, y=w[s+0x1C]|w[s+0x1D]<<8; x+=dx; y+=dyd; w[d+0x18]=x&255; w[d+0x19]=(x>>8)&255; w[d+0x1C]=y&255; w[d+0x1D]=(y>>8)&255; w[d+0x16]=w[s+0x16]; w[d+0x17]=w[s+0x17]; w[d+0x1A]=w[s+0x1A]; w[d+0x1B]=w[s+0x1B]; } } }
    { const char*ra=getenv("RIVALAT"); if(ra){ int k,dx,dy; if(sscanf(ra,"%d,%d,%d",&k,&dx,&dy)==3){ int s=0x1000, d=0x1000+0x100*k; short x=w[s+0x18]|w[s+0x19]<<8, y=w[s+0x1C]|w[s+0x1D]<<8; x+=dx; y+=dy; w[d+0x18]=x&255; w[d+0x19]=(x>>8)&255; w[d+0x1C]=y&255; w[d+0x1D]=(y>>8)&255; w[d+0x16]=w[s+0x16]; w[d+0x17]=w[s+0x17]; w[d+0x1A]=w[s+0x1A]; w[d+0x1B]=w[s+0x1B]; } } }
    { const char*pk=getenv("POKE"); if(pk){ char buf[512]; snprintf(buf,sizeof buf,"%s",pk); char*it=strtok(buf,";"); while(it){ char*e; unsigned ad=strtoul(it,&e,16); if(*e==':'){ e++; while(e[0]&&e[1]){ char t[3]={e[0],e[1],0}; w[ad++]=strtoul(t,0,16); e+=2; } } it=strtok(NULL,";"); } } }
    { const char*ng=getenv("NEG"); if(ng){ int a0,a1; if(sscanf(ng,"%d,%d",&a0,&a1)==2){ int bases[4]={0x4600,0xd600,0x6940,0xa600}; if(getenv("NEGALL")){ for(int o=(getenv("LO")?atoi(getenv("LO")):0x4000);o<(getenv("HI")?atoi(getenv("HI")):0x10000);o+=2){ short v=w[o]|w[o+1]<<8; v=getenv("ZERO")?0:-(v<0?-v:v); w[o]=v&255; w[o+1]=(v>>8)&255; } } else for(int t=0;t<4;t++) for(int k=a0;k<a1;k++){ int o=bases[t]+2*k; short v=w[o]|w[o+1]<<8; v=-(v<0?-v:v); w[o]=v&255; w[o+1]=(v>>8)&255; } } } }
    if(dbg) dbg("/tmp/dbg_frame.txt");
    if(getenv("DBGF")){ int df=atoi(getenv("DBGF")); if(fi>=df&&fi<df+3){ char cmd[300]; snprintf(cmd,sizeof cmd,"cp /tmp/dbg_frame.txt %s/dbg_%d.txt",out,fi); if(system(cmd)){} } }
    FILE*d=fopen("/tmp/dbg_frame.txt","r"); char ln[200];
    if(d){while(fgets(ln,sizeof ln,d)){ if(strncmp(ln,"pc=",3))continue; unsigned pc,a,dd,x; if(sscanf(ln,"pc=%x a=%x d=%x x=%x",&pc,&a,&dd,&x)==4){
        if(getenv("TR_LO")&&a>=(unsigned)strtol(getenv("TR_LO"),0,16)&&a<(unsigned)strtol(getenv("TR_HI"),0,16)) fprintf(tr,"f=%d pc=%06x a=%04x d=%02x x=%04x\n",fi,pc,a,dd,x); else if(a==0x0400||a==0x0406||a==0x0600||a==0x0620||a==0x0626||a==0x0426) fprintf(tr,"f=%d pc=%06x a=%04x d=%02x\n",fi,pc,a,dd);} } fclose(d);}
    { static void(*hd)(const char*,int)=0; static int hi=0; static int h0=-1,h1=-1; if(!hi){ hi=1; const char*hv=getenv("HIST"); if(hv){ sscanf(hv,"%d,%d",&h0,&h1); hd=S("smk_hist_dump"); } }
      if(hd&&fi==h0){ hd("/dev/null",1); } if(hd&&fi==h1){ snprintf(path,sizeof path,"%s/hist.txt",out); hd(path,0); } }
    { static void(*he)(const char*,int)=0; static int hei=0,e0=-1,e1=-1; if(!hei){ hei=1; const char*ev=getenv("HISTEACH"); if(ev){ sscanf(ev,"%d,%d",&e0,&e1); he=S("smk_hist_dump"); } }
      if(he&&fi>=e0&&fi<=e1){ snprintf(path,sizeof path,"%s/he_%d.txt",out,fi); he(path,1); } }
    { static void(*ow)(const char*,int)=0; static int oi=0; static int o0=-1; if(!oi){ oi=1; const char*ov=getenv("OAMW"); if(ov){ o0=atoi(ov); ow=S("smk_oamw_dump"); } }
      if(ow&&fi==o0-1) ow("/dev/null",1); if(ow&&fi==o0){ snprintf(path,sizeof path,"%s/oamw.txt",out); ow(path,0); } }
    if(getenv("WLOG")){ static FILE*wf=0; static int wa=0,wl=0; if(!wf){ sscanf(getenv("WLOG"),"%x,%d",&wa,&wl); snprintf(path,sizeof path,"%s/wlog.txt",out); wf=fopen(path,"w");} fprintf(wf,"%d",fi); for(int i=0;i<wl;i++) fprintf(wf," %02x",w[wa+i]); fprintf(wf,"\n"); fflush(wf);}
    if(getenv("STATEF")){ char sl[512]; strncpy(sl,getenv("STATEF"),sizeof sl-1); sl[sizeof sl-1]=0; char*tk=strtok(sl,","); int hit=0; while(tk){ if(fi==atoi(tk)){hit=1;break;} tk=strtok(0,","); } if(hit){ size_t(*ss)(void)=S("retro_serialize_size"); bool(*se)(void*,size_t)=S("retro_serialize"); size_t n=ss(); void*b=malloc(n); if(se(b,n)){ snprintf(path,sizeof path,"%s/st_%d.bin",out,fi); FILE*sf=fopen(path,"wb"); fwrite(b,1,n,sf); fclose(sf);} free(b); }}
    if(getenv("MEMPROBE")&&fi==1){ for(unsigned i=0;i<12;i++){ fprintf(stderr,"mem(%u)=%p\n",i,mem(i)); } }
    { const char*vd=getenv("VDENSE"); if(vd){ int a0,a1,st; if(sscanf(vd,"%d,%d,%d",&a0,&a1,&st)==3 && fi>=a0 && fi<=a1 && ((fi-a0)%(st?st:1))==0){ unsigned char*vr=mem(3); if(vr){ snprintf(path,sizeof path,"%s/vram_%d.bin",out,fi); FILE*vfp=fopen(path,"wb"); fwrite(vr,1,0x10000,vfp); fclose(vfp);} } } }
    if(getenv("VRAMF")){ const char*vf=getenv("VRAMF"); char key[16]; snprintf(key,sizeof key,",%d,",fi); char*hay=malloc(strlen(vf)+3); sprintf(hay,",%s,",vf); if(strstr(hay,key)){ unsigned char*vr=mem(3); if(vr){ snprintf(path,sizeof path,"%s/vram_%d.bin",out,fi); FILE*vfp=fopen(path,"wb"); fwrite(vr,1,0x10000,vfp); fclose(vfp);} } free(hay);}
    if(getenv("OAMLOG")){ static FILE*of=0; if(!of){snprintf(path,sizeof path,"%s/oamlog.bin",out); of=fopen(path,"wb");} fwrite(w+0x200,1,544,of); fflush(of);}
    if(getenv("WDUMP")){ static FILE*wd=0; static int wa=0,wl=0,wi=0; if(!wi){wi=1; sscanf(getenv("WDUMP"),"%x,%d",&wa,&wl); char p2[300]; snprintf(p2,sizeof p2,"%s/wdump_%x.txt",out,wa); wd=fopen(p2,"w");} fprintf(wd,"%d",fi); for(int i=0;i<wl;i++) fprintf(wd," %02x",w[wa+i]); fprintf(wd,"\n"); fflush(wd);}
    if(getenv("KARTS")){ static FILE*kf=0; if(!kf){snprintf(path,sizeof path,"%s/karts.txt",out); kf=fopen(path,"w");} fprintf(kf,"%d",fi); for(int k=0;k<8;k++){int o=0x1000+0x100*k; fprintf(kf," %d,%d,%d",(short)(w[o+0x18]|w[o+0x19]<<8),(short)(w[o+0x1C]|w[o+0x1D]<<8),(short)(w[o+0x20]|w[o+0x21]<<8));} fprintf(kf,"\n"); fflush(kf);}
    if(getenv("BYTES")){ static FILE*by=0; static int bk=0,bo=0,bl=0,ini=0; if(!ini){ini=1; sscanf(getenv("BYTES"),"%d,%x,%d",&bk,&bo,&bl); snprintf(path,sizeof path,"%s/bytes_%d.txt",out,bk); by=fopen(path,"w");} fprintf(by,"%d",fi); for(int i=0;i<bl;i++) fprintf(by," %02x",w[0x1000+0x100*bk+bo+i]); fprintf(by,"\n"); fflush(by);}
    if(getenv("LEVELS")){ static FILE*lv=0; if(!lv){snprintf(path,sizeof path,"%s/levels.txt",out); lv=fopen(path,"w");} fprintf(lv,"%d",fi); for(int k=0;k<8;k++){int o=0x1000+0x100*k; fprintf(lv," %d:%d,%d,%d",k,w[o+0x92]|w[o+0x93]<<8,w[o+0x06]|w[o+0x07]<<8,w[o+0x18]|w[o+0x19]<<8);} fprintf(lv,"\n"); fflush(lv);}
    if(getenv("KARTSX")){ static FILE*kx=0; if(!kx){snprintf(path,sizeof path,"%s/kartsx.txt",out); kx=fopen(path,"w");} fprintf(kx,"%d",fi); for(int k=0;k<8;k++){int o=0x1000+0x100*k; fprintf(kx," %d,%d,%d",(short)(w[o+0x06]|w[o+0x07]<<8),(short)(w[o+0x0E]|w[o+0x0F]<<8),(short)(w[o+0x1E]|w[o+0x1F]<<8));} fprintf(kx,"\n"); fflush(kx);}
    int v=w[0x406];
    fprintf(fl,"f=%d mode36=%02x d28=%02x 0406=%02x 0626=%02x 0600=%02x 0400=%02x 0620=%02x p1x=%d p1y=%d,%d,%d,%d\n",fi,w[0x36],w[0xd28],w[0x406],w[0x626],w[0x600],w[0x400],w[0x620],w[0x270],w[0x271],w[0x275],w[0x279],w[0x27d]);
    bool snap=(every&&(v!=prev406||w[0x36]!=lastmode||fi%every==0)); if(!getenv("SNAPS")==0) snap=false;
    { const char*sn=getenv("SNAPS"); if(sn){ char key[16]; snprintf(key,sizeof key,",%d,",fi); char*hay=malloc(strlen(sn)+3); sprintf(hay,",%s,",sn); if(strstr(hay,key)) snap=true, every=every?every:1; free(hay);} }
    if(snap&&every){snprintf(path,sizeof path,"%s/f%04d.ppm",out,fi);save_ppm(path);}
    if(getenv("FRAMEHASH")){ static FILE*hf=0; if(!hf){ snprintf(path,sizeof path,"%s/fh.txt",out); hf=fopen(path,"w"); } unsigned long long hh=1469598103934665603ULL; for(unsigned y=0;y<last_h;y++)for(unsigned x=0;x<last_w;x++){unsigned char r,g,b; get_rgb(last_frame+y*last_pitch,x,&r,&g,&b); hh=(hh^r)*1099511628211ULL; hh=(hh^g)*1099511628211ULL; hh=(hh^b)*1099511628211ULL;} fprintf(hf,"%llx\n",hh); fflush(hf); }
    prev406=v; lastmode=w[0x36];
  }
  { unsigned char*w=mem?mem(2):0; if(w){snprintf(path,sizeof path,"%s/wram.bin",out);FILE*f=fopen(path,"wb");fwrite(w,1,0x20000,f);fclose(f);} }
  fclose(tr);fclose(fl);return 0;}
