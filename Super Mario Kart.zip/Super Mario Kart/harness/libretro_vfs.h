/* Implementación mínima de la interfaz VFS de libretro sobre stdio.
   Necesaria para que el core `bsnes` arranque: pide GET_VFS_INTERFACE (45|EXPERIMENTAL)
   antes de init() y si el frontend responde false aborta.
   Incluir este header SOLO desde drive.c (usa `libretro.h` ya incluido). */
#ifndef LIBRETRO_VFS_H
#define LIBRETRO_VFS_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>

struct retro_vfs_file_handle { FILE *f; char path[1024]; };
struct retro_vfs_dir_handle  { void *d; char name[512]; bool isdir; };

static const char *vfs_get_path(struct retro_vfs_file_handle *h){ return h ? h->path : NULL; }
static struct retro_vfs_file_handle *vfs_open(const char *path, unsigned mode, unsigned hints){
  (void)hints;
  const char *m = (mode == RETRO_VFS_FILE_ACCESS_READ) ? "rb" :
                  (mode == RETRO_VFS_FILE_ACCESS_WRITE) ? "wb" : "r+b";
  FILE *f = fopen(path, m);
  if(!f && mode == RETRO_VFS_FILE_ACCESS_READ_WRITE) f = fopen(path, "w+b");
  if(!f) return NULL;
  struct retro_vfs_file_handle *h = malloc(sizeof *h);
  h->f = f; snprintf(h->path, sizeof h->path, "%s", path); return h;}
static int vfs_close(struct retro_vfs_file_handle *h){ if(!h) return -1; fclose(h->f); free(h); return 0; }
static int64_t vfs_size(struct retro_vfs_file_handle *h){ if(!h) return -1; long p = ftell(h->f); fseek(h->f,0,SEEK_END); long n = ftell(h->f); fseek(h->f,p,SEEK_SET); return n; }
static int64_t vfs_tell(struct retro_vfs_file_handle *h){ return h ? ftell(h->f) : -1; }
static int64_t vfs_seek(struct retro_vfs_file_handle *h, int64_t off, int pos){
  if(!h) return -1; int w = pos == RETRO_VFS_SEEK_POSITION_START ? SEEK_SET : pos == RETRO_VFS_SEEK_POSITION_CURRENT ? SEEK_CUR : SEEK_END;
  if(fseek(h->f,off,w)) return -1; return ftell(h->f); }
static int64_t vfs_read(struct retro_vfs_file_handle *h, void *s, uint64_t len){ return h ? (int64_t)fread(s,1,len,h->f) : -1; }
static int64_t vfs_write(struct retro_vfs_file_handle *h, const void *s, uint64_t len){ return h ? (int64_t)fwrite(s,1,len,h->f) : -1; }
static int vfs_flush(struct retro_vfs_file_handle *h){ return h ? fflush(h->f) : -1; }
static int vfs_remove(const char *p){ return remove(p); }
static int vfs_rename(const char *a, const char *b){ return rename(a,b); }
static int64_t vfs_truncate(struct retro_vfs_file_handle *h, int64_t len){ return h ? (int64_t)ftruncate(fileno(h->f), len) : -1; }
static int vfs_stat(const char *p, int32_t *size){
  struct stat st; if(stat(p,&st)) return 0; if(size) *size = (int32_t)st.st_size;
  return RETRO_VFS_STAT_IS_VALID | (S_ISDIR(st.st_mode) ? RETRO_VFS_STAT_IS_DIRECTORY : 0); }
static int vfs_mkdir(const char *d){ return mkdir(d,0755); }
static struct retro_vfs_dir_handle *vfs_opendir(const char *d, bool hid){ (void)hid; DIR *dir = opendir(d); if(!dir) return NULL;
  struct retro_vfs_dir_handle *h = malloc(sizeof *h); h->d = dir; h->name[0] = 0; h->isdir = false; return h; }
static bool vfs_readdir(struct retro_vfs_dir_handle *h){ if(!h) return false; struct dirent *e = readdir((DIR*)h->d); if(!e) return false;
  snprintf(h->name, sizeof h->name, "%s", e->d_name); h->isdir = (e->d_type == DT_DIR); return true; }
static const char *vfs_dirent_get_name(struct retro_vfs_dir_handle *h){ return h ? h->name : NULL; }
static bool vfs_dirent_is_dir(struct retro_vfs_dir_handle *h){ return h ? h->isdir : false; }
static int vfs_closedir(struct retro_vfs_dir_handle *h){ if(!h) return -1; closedir((DIR*)h->d); free(h); return 0; }

static struct retro_vfs_interface vfs_iface = {
  vfs_get_path, vfs_open, vfs_close, vfs_size, vfs_tell, vfs_seek, vfs_read, vfs_write,
  vfs_flush, vfs_remove, vfs_rename, vfs_truncate, vfs_stat, vfs_mkdir, vfs_opendir,
  vfs_readdir, vfs_dirent_get_name, vfs_dirent_is_dir, vfs_closedir,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL };

/* log del core -> stderr (bsnes avisa por aquí de por qué rechaza un estado) */
static void core_log(enum retro_log_level lvl, const char *fmt, ...){
  (void)lvl; va_list ap; va_start(ap,fmt); fputs("[core] ",stderr); vfprintf(stderr,fmt,ap); fputc('\n',stderr); va_end(ap); }
#endif
