# Super Mario Kart (USA) — Fullscreen Edition (by Psicopompo)

Proyecto de ROM hacking sobre la ROM USA HiROM. **Estado: v1.1 (v1.0 publicada)** (romhacking.net, GitHub y elotrolado.net).

- ROM de la release: `roms/Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).sfc` — 1 MiB, CRC32 `17EFB04F`, SHA-1 `342150EB6D1FE2F3888510472F46F74624E6D932`.
- Parches y textos publicados: `release/` (`.ips`, `.bps`, `.zip`, README/LÉEME y `release/posts/`).
- Para regenerar la ROM desde la base: `bash tools/reconstruir_release.sh` (comprueba que sale idéntica).

## Estructura

- `roms/`: ROM USA limpia (referencia), base del hack fullscreen (`Super Mario Kart USA Full Screen.sfc`) y la ROM de la release. (La ROM Europe y el candidato intermedio se eliminaron: el candidato se regenera con `build_usa_camara.py`.)
- `tools/`: constructor y parches (ver `tools/README_ES.md`).
- `states/`: states de regresión y de bugs reportados (ver `states/README_ES.md`).
- `cores/`: cores bsnes para el harness (`bsnes_prof.so` es el habitual; ver `cores/README_ES.md`).
- `harness/`: `drive.c` (arnés libretro; se compila con `bash tools/env_rapido.sh`) y guiones de entrada.
- `user_upload/`: `libretro.h` y los arneses originales del usuario (necesarios para compilar).
- `smk_disassembly/`: desensamblado del juego (bancos 80/81/85, etiquetas).
- `originalgrego_repo/`: fuente del hack fullscreen original, solo referencia (no se cita en los textos públicos).
- `patches/`: IPS histórico de la base fullscreen portada a Europe (huérfano: la ROM Europe ya no está en el workspace; no se publica).
- `docs/`: `DOCUMENTACION_ES.md` (historial técnico completo) y el prompt de transferencia antiguo archivado.
- `TRANSFER_PROMPT_NUEVO_CHAT_ES.md`: instrucciones para continuar en un chat nuevo.

Las capturas, volcados y ROMs de prueba se generan en `/tmp` y se descartan; no se acumulan aquí.

## Limpieza del workspace (v11 de Chiki)
Se eliminaron los núcleos bsnes instrumentados, los estados convertidos, las carpetas `prueba/`, `originalgrego_repo/`, `user_upload/`, las ROM intermedias (v1.1 y la antigua «Full Screen») y las capturas. `smk_disassembly/` está comprimido en `smk_disassembly.tar.xz`. Se conservan la release v1.3 (v1.2 y v1.1 en `release/anteriores/`), `roms/candidato_v1.2.sfc`, `roms/candidato_v1.3.sfc` (= v1.3 publicada; se reconstruye con `tools/reconstruir_v13.sh`) y la ROM original.
