# Parches

(vacío: el `.ips` histórico para la ROM Europe se borró junto con esa ROM.)

Los parches publicados (IPS/BPS sobre la ROM USA) están en `release/`.
