**Hack title:** Super Mario Kart – Fullscreen Edition
**Author:** Psicopompo
**Base game:** Super Mario Kart (SNES) – USA
**Required ROM:** Super Mario Kart (USA), headerless, CRC32 `CD80DB86`
**Patch formats:** BPS (recommended), IPS
**File names:** `Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).ips` / `.bps`
**Output ROM:** 1 MB (expanded), CRC32 `17EFB04F`
**Category:** Graphics / Gameplay / Other

## Description

Super Mario Kart finally gets a **real full-screen single-player view**. The original game draws the race in a cropped part of the screen and reserves the lower area for a map and rear-view mirror, a leftover from its split-screen design. This hack fills the whole 256×224 picture with the Mode 7 track.

Simply filling the screen is only the first step: the picture gets bigger, while the kart, its shadow, the collisions and the HUD stay pinned to the old layout. **This patch moves the camera itself.** The projection focus fed to the DSP-1 is shifted forward, so the kart sits lower on screen with the same perspective and rotation, and the floor, shadow, objects, rivals and collisions all stay consistent. At the start, Mario sits on the floor mark of his grid spot.

Then came the consequences, and they took most of the work: every banner, table, counter and effect that depended on the old geometry had to be rebuilt, and almost every fix exposed another problem. The result was verified by replaying dozens of save states against every change, frame by frame.

## Features

* Full-screen 1P race view with the camera closer to the kart (same perspective and rotation).
* HUD relocated: for example, the big finishing-rank digit no longer overlaps the small rank digit next to the counters, something the original kept for lack of room.
* LAP TIME table and rank faces (20 px lower), Game Over, ROUND 1 and the Ranked Out banner re-centered for the taller view.
* Bananas, squash smoke, moles and lost coins repositioned for the new camera.
* 2P split screen kept working, with menus, effects, objects and artifacts patched individually.
* Fixes for credits flicker, 2P retry text, Time Trial / 2P artifacts a stray ball at the Time Trial start and Lakitu's shadow during the rescue.
* Small "Fullscreen Edition · Psicopompo" line on the title screen; Nintendo's © line moved 2 px to be exactly centered.

## Not included

The map and rear-view mirror were removed on purpose. The original idea was to keep them as a small inset, but both are secondary Mode 7 renders, and fitting them in meant splitting the frame again and kept breaking other things.

## Notes

* USA only (PAL crops the screen).
* The 50cc and 100cc cups were played through with the final patch; 150cc, Mirror mode and the other modes had less testing.
* Tested in emulation (bsnes accuracy). v1.1 fixes a few stray white pixels seen on real hardware (confirmed by a tester) and moves the results table 5 px lower.
* Track objects appear and disappear by zones, as in the original game; with the closer camera it is slightly more noticeable.
* Developed in collaboration with an AI assistant, which did the technical work under the author's direction and testing.
* Patch the clean ROM listed above; BPS verifies the input.
