# Psicopompo releases Super Mario Kart: Fullscreen Edition

Psicopompo has released **Super Mario Kart – Fullscreen Edition**, a patch for the USA version that gives single-player races a genuinely full-screen view, and that goes well beyond simply hiding the map.

In the original game, single-player races are drawn in a cropped part of the screen, with the lower area reserved for a map and rear-view mirror inherited from the two-player split. Filling the picture is only the first step. The difference is the camera: left in place, the kart, its shadow and the collisions stay tied to the old layout, so this release moves the projection focus fed to the console's DSP-1 chip. The kart sits lower on screen, with the same perspective and rotation, while the floor, shadow, objects, rivals and collisions stay consistent.

Moving the camera meant reworking everything that depended on it. The HUD has been relocated, which also resolves layout quirks the original kept for lack of space, such as the big finishing-rank digit overlapping the small one. The LAP TIME table, rank faces, Game Over, ROUND 1 and Ranked Out screens have been re-centered, effects such as bananas, squash smoke, moles and lost coins have been repositioned, and the 2P split-screen mode keeps working. Almost every fix exposed a new problem, so the author checked each change by replaying dozens of save states frame by frame against the previous build.

The map and rear-view mirror are intentionally gone. The author first planned to keep them as a small inset, but both are secondary Mode 7 renders, and fitting them in meant splitting the frame again and caused artifacts elsewhere. The title screen gains a discreet "Fullscreen Edition · Psicopompo" line under Nintendo's copyright.

The project was developed in collaboration with an AI assistant, which carried out the technical work under the author's direction and testing. The 50cc and 100cc cups have been played through with the final patch; other modes have had less testing.

The patch applies to the clean USA ROM (CRC32 CD80DB86) and is available in BPS and IPS formats. The PAL version is not supported because it crops the screen.
