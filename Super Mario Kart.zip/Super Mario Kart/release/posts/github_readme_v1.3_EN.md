# Super Mario Kart: Fullscreen Edition

**Super Mario Kart – Fullscreen Edition** transforms the 1-player race view into a true fullscreen experience, using the entire 256×224 display area instead of reserving the lower portion for the map and rear-view mirror.

This is not simply a matter of hiding the lower screen or moving Mario downward. **The camera reference has been changed, bringing the projected scenery closer to the kart while keeping the kart itself in its new screen position.** The game's projection, object placement, collisions, effects, HUD, and numerous other systems have been adapted to work correctly with the new perspective.

## What changes?

At the beginning of each race, the camera progressively moves into its new position instead of switching instantly. **The kart remains in its new screen position while the projected scenery moves toward it**, similar to the visual effect produced when accelerating in the original game. This brings the starting grid, rivals, and road back into the correct relationship with the player while making use of the full 224-line display.

The underlying Mode 7 projection has been adjusted accordingly, so the road, shadows, rivals, objects, and collision checks remain consistent with the new camera reference. As of v1.2, the point of the track under the kart matches where the kart is drawn, so collisions with walls, track edges, and pits happen where the kart actually touches them.

The HUD has also been redesigned for the additional space. Position digits, coins, car counters, LAP TIME, standings faces, and several end-of-race and status messages have been repositioned to fit the new layout. A number of effects that were tied to the original player position — including lost coins, bananas, crush smoke, and Monty Moles — were likewise adapted. Lakitu's rescue after falling off the track also works in fullscreen: he comes into view, picks up the kart with the coin, and lifts it back onto the track, as in the original game. As of v1.3, no part of Lakitu (his head, his cloud, or the leftover "three hairs") peeks out at the bottom of the screen during a rescue or after his appearance at the start.

The hack is restricted to 1-player mode. The original 2-player logic is preserved through dedicated gates, allowing the split-screen mode to continue running with the game's original behavior. As of v1.3, this includes the height of Lakitu's coin and of lost coins in 2-player mode, which could be drawn too low after playing a 1-player race in the same session.

Performance has been profiled and tuned for the USA/NTSC version. In v1.2, the check that decides whether the fullscreen logic applies is computed once per frame instead of dozens of times. In the heaviest scene tested (Lakitu's rescue), lagged frames dropped from 18% to practically zero compared with the build before this optimization. Normal driving, race starts with all eight karts, and full races on Donut Plains showed no lag. v1.3 trims the load further, with cheaper checks in the projection and object-culling code: in the heaviest race start tested, the peak CPU load dropped from 95.7% to 90.5% (vanilla: 89%), and no lagged frames were measured in the first 1,061 frames of the Mushroom, Flower, and Star Cup starts (50cc).

## Behind the scenes

What began as a relatively simple idea quickly became a much deeper reverse-engineering project.

The first approach involved fixing the many problems caused by simply moving the player down the screen. Every fix exposed another system still relying on the original coordinates. A major breakthrough came from realizing that some of the logic already used by Player 2 could be reused for Player 1, providing a much better starting point for the new layout.

From there, the project involved extensive investigation of the DSP-1 projection system, OAM and sprite ordering, HDMA, Mode 7, collision routines, object visibility limits, screen wrapping, and various CPU/PPU interactions.

Several problems only appeared after seemingly unrelated changes: rivals passing through Mario, pipes failing to collide, objects disappearing too early, sprites wrapping from the bottom to the top of the screen, Lakitu appearing in the wrong place, effects remaining 88 pixels above the kart, and even performance problems caused by overly expensive solutions on the USA/NTSC version.

The final result is therefore much more than a graphical layout change. **It is a substantial reworking of the game's 1-player camera, presentation, and the logic that supports the new viewpoint.**

The development relied heavily on reproducible emulator states, instrumentation, regression testing, and frame-by-frame comparisons to ensure that fixes did not introduce new problems.

## Version history

* **v1.3** – Lakitu no longer peeks out at the bottom of the screen: his head and cloud are hidden while he comes down from above or leaves upward (Ghost Valley, the water falls), and the leftover pieces (the "three hairs") that stayed behind at the start and after a rescue are cleaned up. In 2-player mode, Lakitu's coin and lost coins are drawn at the right height instead of 88 pixels too low. Lower CPU load in 1-player mode (peak load in the heaviest start tested: 95.7% → 90.5%). Includes all v1.2 fixes.

* **v1.2** – The ground projection is realigned with the kart's on-screen position, so the track under the kart matches where the kart is drawn: collisions with walls, edges, and pits now happen at the right place (they used to trigger too early). Fixed Lakitu's rescue after falling off the track. Reduced slowdowns by computing the fullscreen check once per frame. Includes all v1.1 fixes.

* **v1.1** – Fixed a few stray white pixels that appeared on real hardware in the transition band of the picture (confirmed on real hardware by a tester; not visible in most emulators). The LAP TIME table and standings faces were moved 5 pixels further down.

* **v1.0** – First release.

## Compatibility

* **Region:** USA only

* **Video:** NTSC, 224 visible lines / 60 Hz

* **Input ROM:** Super Mario Kart (USA), no header, 524,288 bytes, CRC32 CD80DB86

* **ROM size:** 1 MiB after patching (CRC32 3CB1596A)

* **Tested with:** bsnes and RetroArch

* **Real hardware:** the v1.1 white-pixel fix was confirmed on real hardware by a tester; v1.2 and v1.3 have not been tested on real hardware yet

* **2-player mode:** original logic preserved

This is an unofficial fan project and is not affiliated with or endorsed by Nintendo. You must provide your own legally obtained ROM.

**Super Mario Kart © Nintendo.**

**Author:** Psicopompo
