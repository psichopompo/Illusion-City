# Super Mario Kart – Fullscreen Edition (USA)

Un hack que convierte la vista de carrera de **1 jugador de Super Mario Kart** en una pantalla completa de verdad.

La pista ocupa las **256×224 píxeles** disponibles, la cámara se acerca al kart y todo lo que dependía de la distribución original —HUD, textos, efectos, objetos, colisiones y demás elementos de pantalla— se adapta a la nueva perspectiva.

Hecho por **Psicopompo**.

## Por qué existe

Super Mario Kart reserva en 1 jugador una parte de la pantalla para el mapa y el retrovisor, como consecuencia del diseño a pantalla partida del modo 2P.

Eliminar esa zona parece sencillo, pero en realidad es sólo el principio. Si simplemente ocultas el mapa y bajas el kart, la cámara, el suelo, la sombra, los rivales, las colisiones y buena parte de la lógica del juego siguen creyendo que Mario está donde estaba originalmente.

**Este hack no se limita a quitar el mapa: mueve la propia cámara y adapta todo lo que depende de ella.**

## La idea que hizo avanzar el proyecto

Al principio se intentó solucionar uno por uno cada problema provocado por mover el kart hacia abajo. El resultado fue una colección interminable de parches: cada cosa que se arreglaba descubría otra que seguía utilizando las coordenadas antiguas.

Hasta que surgió una idea mucho más útil: **aprovechar en 1P parte de la lógica que el juego ya utiliza para el Player 2**, cuyo kart se dibuja aproximadamente en la posición que necesitábamos.

Aquello no resolvía el hack por sí solo, pero permitió reutilizar una parte de la lógica existente en lugar de reconstruirla desde cero y ahorró muchísimo trabajo. A partir de ahí fue posible centrarse en hacer que la nueva cámara, la posición real del kart y el resto de la lógica del juego encajaran entre sí.

## Qué hace

* **Pantalla completa real en 1P.** La vista de carrera utiliza las 224 líneas de imagen completas y la cámara se acerca al kart de forma progresiva al comenzar la carrera.
* **Cámara coherente con la proyección.** El DSP-1 recibe un nuevo punto de enfoque adelantado en la dirección de la vista, de forma que el kart, el suelo, los rivales, los objetos, las sombras y las colisiones siguen utilizando la misma perspectiva y rotación.
* **HUD recolocado.** Se reorganizan los contadores, monedas y posiciones para aprovechar el nuevo espacio. El dígito grande de la posición final deja de pisar el dígito pequeño; este último se desplaza 8 píxeles hacia la izquierda.
* **Tablas y carteles recolocados.** La tabla de LAP TIME y las caras de clasificación se desplazan 25 píxeles hacia abajo. También se adaptan GAME OVER, ROUND, RANKED OUT y los menús RETRY / END.
* **Efectos y objetos adaptados a la nueva posición.** Se corrigen, entre otros, monedas perdidas, plátanos, humo de aplastamiento, topos y otros efectos que seguían utilizando la posición vertical original.
* **Colisiones ajustadas a la nueva proyección.** Se adaptan las comprobaciones contra rivales y obstáculos para que sigan funcionando cuando Mario ocupa una zona de pantalla mucho más baja.
* **Modo 2P conservado.** El hack queda limitado a 1P mediante puertas específicas; en 2P se ejecuta la lógica original de la ROM. Se revisaron y neutralizaron los efectos secundarios que podían contaminar esa rama.
* **Numerosos efectos secundarios corregidos.** Durante el desarrollo aparecieron problemas con sprites que reaparecían por la parte superior o inferior, rivales que desaparecían demasiado pronto, cabezas de Lakitu que asomaban fuera de pantalla, efectos que seguían apareciendo en la posición original, parpadeos y otros artefactos. Se fueron localizando y corrigiendo a medida que aparecían.
* **Rendimiento ajustado.** Una primera solución provocaba ralentizaciones en escenas cargadas de la versión USA. Se perfiló el código y se redujo el coste de las rutinas más pesadas hasta recuperar el ritmo normal del juego.

## Una pequeña odisea de ingeniería inversa

Casi ningún problema se resolvió simplemente cambiando una coordenada.

El juego utiliza el **DSP-1**, Mode 7, HDMA, ventanas de color, OAM y varias capas de lógica de proyección y ordenación de objetos. Al modificar la cámara empezaron a aparecer problemas que a primera vista no parecían tener relación alguna con ella: rivales que atravesaban a Mario, tuberías que no colisionaban, objetos que desaparecían demasiado pronto, sprites que se partían o reaparecían arriba al superar el rango de una coordenada Y de 8 bits, efectos que seguían naciendo 88 píxeles por encima del kart o sombras que utilizaban las coordenadas de la posición antigua.

También fue necesario investigar el orden de dibujado de los karts, la construcción de la OAM y los criterios de profundidad utilizados por el juego. Algunas soluciones experimentales funcionaban visualmente, pero costaban demasiados ciclos de CPU y provocaban ralentizaciones en NTSC, así que hubo que descartarlas y buscar puntos de intervención mucho más baratos.

Cada corrección se volvió a probar contra las anteriores con estados reproducibles y comparaciones fotograma a fotograma para evitar que un arreglo rompiera otra parte del juego.

En otras palabras: **no se trataba de mover a Mario 88 píxeles hacia abajo; había que convencer a Super Mario Kart de que ahora la carrera ocurría en otra geometría de pantalla.**

## ¿Por qué no hay mapa ni retrovisor?

La idea inicial era conservarlos como pequeños recuadros sobre la vista completa.

El problema es que el mapa y el retrovisor no son simplemente imágenes que puedan colocarse en una esquina. Ambos utilizan Mode 7, HDMA y cálculos específicos para dividir la pantalla. Reintroducirlos significaba volver a partir el fotograma y complicar de nuevo la lógica que precisamente se había eliminado.

Al final se optó por una **pantalla de carrera limpia y completa**, que es el objetivo principal del hack.

## Cómo se ha hecho

El proyecto se ha desarrollado mediante ingeniería inversa de la ROM, instrumentación y pruebas reproducibles con estados de emulación.

Se han utilizado trazas de CPU/PPU, análisis de OAM y DMA, inspección de tablas y estructuras de memoria, herramientas específicas para desensamblado y perfilado y numerosas regresiones sobre estados de carrera, salida, colisiones, efectos, menús, resultados y situaciones especiales.

El proyecto se ha desarrollado **en colaboración con una IA**. La IA se ha encargado de buena parte de la implementación técnica —análisis del código, escritura de herramientas, parches y automatización de pruebas—, mientras que Psicopompo ha llevado la dirección del proyecto: investigar el funcionamiento del juego, plantear y descartar estrategias, interpretar los resultados, detectar problemas, decidir qué camino seguir y validar cada cambio.

## ROM y parche

Necesitas una ROM limpia de **Super Mario Kart (USA)**, sin cabecera:

|        | Valor                                      |
| ------ | ------------------------------------------ |
| Tamaño | 524.288 bytes                              |
| CRC32  | `CD80DB86`                                 |
| MD5    | `7f25ce5a283d902694c52fb1152fa61a`         |
| SHA-1  | `47e103d8398cf5b7cbb42b95df3a3c270691163b` |

Hay disponibles parches **IPS** y **BPS**. Se recomienda **BPS**, ya que comprueba la ROM de entrada antes de aplicar el parche.

* `Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).bps`
* `Super Mario Kart - Fullscreen Edition (v1.1) (by Psicopompo).ips`

La ROM resultante pasa a ocupar **1 MiB**:

|       | Valor                                      |
| ----- | ------------------------------------------ |
| CRC32 | `17EFB04F`                                 |
| MD5   | `5032204fb373ab28c5948bc94e8d7e28`         |
| SHA-1 | `342150eb6d1fe2f3888510472f46f74624e6d932` |

Aplica el parche sobre una copia de tu ROM limpia.

## Historial de cambios

* **v1.1** – Corrige unos píxeles blancos sueltos que aparecían en consola real en la banda de transición de la imagen (en la mayoría de emuladores no se ven). La tabla de LAP TIME y las caras de clasificación bajan 5 píxeles más. El parche se aplica directamente sobre la ROM USA limpia.
* **v1.0** – Primera versión.

## Notas y limitaciones

* **Solo versión USA** (224 líneas / 60 Hz). La versión PAL no está soportada.
* Probado en **bsnes** y **RetroArch**.
* **Hardware real:** la corrección de píxeles blancos de la v1.1 se confirmó en hardware real por un probador. Los flashcarts no se han probado.
* Se han completado pruebas de las copas de **50cc y 100cc** con el parche final. Otros modos tienen un nivel de validación menor.
* Los objetos y efectos de pista siguen las reglas del juego original; al disponer de una cámara mucho más cercana, algunos límites de aparición y descarte pueden resultar más visibles.
* El modo 2P conserva la lógica original del juego y no utiliza la cámara de pantalla completa de 1P.

## Pantalla de título

El título incluye una pequeña línea blanca:

*Fullscreen Edition · Psicopompo*

situada bajo el copyright de Nintendo.

Además, el texto de copyright original, que estaba ligeramente desplazado, ha sido recentrado.

## Créditos y aviso

**Psicopompo** — dirección del proyecto, investigación, análisis, diseño de las soluciones, pruebas y validación.

**IA** — análisis de código, implementación de los parches, herramientas auxiliares y automatización de pruebas, bajo dirección de Psicopompo.

Super Mario Kart © Nintendo. Proyecto de aficionado no oficial, sin relación con Nintendo ni respaldado por ella.

Debes aportar tu propia ROM obtenida legalmente. Este parche no distribuye datos de la ROM original.

Si encuentras algún fallo, lo ideal es enviar un **save state** que permita reproducirlo.
