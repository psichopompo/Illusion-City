# ROMs

- `Super Mario Kart (USA).sfc` (CRC32 `CD80DB86`): ROM limpia de referencia. Los parches se aplican sobre ella.
- `Super Mario Kart USA Full Screen.sfc`: base del hack fullscreen; entrada de `tools/build_usa_camara.py`.
- `Super Mario Kart - Fullscreen Edition (v1.0) (by Psicopompo).sfc`: ROM publicada (CRC32 `1FA9C82B`). `bash tools/reconstruir_release.sh` la regenera desde la base.

Eliminadas (decisión del usuario): la ROM Europe (no se usa) y `usa_camara_candidato.sfc` (se regenera con `build_usa_camara.py`; sin firma ni arreglos posteriores).
No se guardan variantes de prueba: se generan en `/tmp` y se descartan.
