# PROMPT — ¿CUÁNDO EXACTAMENTE deben cambiar de tamaño los karts rivales?

*Documento autosuficiente: no necesitas nada más para responder. Versión 1 · 5 de octubre de 2026.
Todos los números están medidos con emulador (bsnes/snes9x) y volcado de memoria del juego, no estimados.*

---

## 0. Qué te pido (y qué NO)

**La pregunta es una sola: en qué fila de pantalla debe cambiar cada kart de tamaño, y qué conjunto
de arte hace falta para que ese cambio "acompañe a la perspectiva".**

Lo que ya está resuelto y **no** hace falta que me expliques:

* El criterio de reparto con tamaños discretos (media geométrica `s = √(s_i·s_{i+1})`). Ya está
  calculado; te lo doy abajo.
* La ley de perspectiva del juego. Ya está medida; te la doy.
* La traducción a bytes de ROM. **No la necesito**: respóndeme en **filas de pantalla y tamaños en
  píxeles**, que además evita el problema de unidades de la ROM (explicado en el apéndice).

### El problema, en palabras del autor de la modificación

> «Los rivales **sí** cambian de tamaño, ese no es el problema. El problema es **cuándo**: los
> cercanos no cambian hasta que se han alejado bastante. Las franjas hay que aplicarlas **a la
> perspectiva**, no repartirlas a partes iguales.»

Y la crítica original que puso esto en marcha:

> «La perspectiva parece invertida: el más cercano se ve más pequeño.»

Es decir: hace falta decidir **dónde caen las fronteras** y **cuántos escalones** hay en el campo
cercano. Eso es un problema de reparto en profundidad, no de fórmulas exóticas.

---

## 1. Contexto técnico

* *Super Mario Kart* (USA), SNES, **256×224** NTSC, modo 7 para el suelo + sprites (OBJ) para karts.
* **La SNES no escala sprites por hardware**: cada tamaño debe existir como **arte pre-escalado**.
  El juego trae 4 tamaños de arte para los karts: **32×32, 23×24, 16×16 y 9×9** px. Una tabla de 11
  umbrales decide cuál usa cada kart.
* **Tres vías de dibujo distintas** (importante para no confundir problemas):
  1. **Karts** (jugador + 7 rivales): arte escalado por la tabla. Es el objeto de este documento.
  2. **Objetos y enemigos sueltos**: tamaño **fijo**, no escalan.
  3. **Tuberías, monedas, cajas**: también **sprites de tamaño fijo** (verificado: una tubería se
     reproduce idéntica píxel a píxel al acercarse; no es Mode-7 y no escala).
  4. **Suelo, carretera y decorado**: **Mode-7**, con escala continua (matriz afín por scanline).
* El **jugador** no usa la tabla: su escala está fijada por una constante y siempre dibuja el arte
  de 32×32. Su posición en pantalla es fija toda la carrera (el kart no se mueve de su fila).

---

## 2. Geometría medida (esto es lo que hay que respetar)

| Magnitud | Juego original (vanilla) | Modificación actual (v1.4) |
|---|---|---|
| Fila de los pies del jugador | 101 (fija) | **190 (fija)** |
| Escala interna del jugador | 264 | **549** |
| **Línea del horizonte** | y ≈ **23** | y ≈ **27** |
| Ley de perspectiva medida | escala ≈ 3.29·(y−23) | escala ≈ **3.34·(y−27)** |
| Filas donde se dibujan karts (pies) | 46 … 230 | 62 … **202** |
| Borde superior más alto de un kart | y = 30 | y = 46 |
| Carretera (asfalto) en pantalla | filas 32-208 | filas 39-218 |

Cómo se midió: 3000 fotogramas registrando la escala interna de los 8 karts y el bbox de sus sprites
en el OAM, emparejados por profundidad. Ajuste lineal sobre ~3600 pares: **error medio 3.1-3.4**
unidades. El horizonte es el cero de esa recta.

**Ancla de tamaño (el dato clave):** en vanilla, el arte de 32 px se usa para la escala del jugador,
264 ⇒ **0.1212 px de arte por unidad de escala**. De ahí la ley del tamaño "ideal":

```
ideal_px(y) = 0.1212 · escala(y)
vanilla:  ideal_px(y) = 0.399 · (y − 23)
v1.4:     ideal_px(y) = 0.405 · (y − 27)
```

Valores que salen de ahí (v1.4): ideal **14.2 px** en la fila más lejana donde se dibuja un kart
(y=62), **66.0 px** en la fila del jugador (y=190) y **70.8 px** en la más cercana observada
(y=202). Es decir, el kart del jugador **dibuja 32 px cuando le corresponderían 66**.

---

## 3. El problema, medido (esto es lo que hay que arreglar)

### 3.1 Dónde están hoy las fronteras, en filas de pantalla

| Versión | 32 → 23 | 23 → 16 | 16 → 9 |
|---|---|---|---|
| **Vanilla** (umbrales 160/112/64) | y = **71.6** | y = 57.0 | y = 42.5 |
| **v1.4 actual** (umbrales 255/170/90) | y = **103.3** | y = 77.9 | y = 53.9 |

(Lectura: por encima de la frontera va el tamaño mayor. Un kart "sube" de fila al acercarse.)

### 3.2 La franja más cercana es demasiado ancha — y esa es la queja

| | v1.4 actual |
|---|---|
| Filas que ocupa la tarjeta de 32 | **103.3 → 202 = 99 filas** |
| Tamaño ideal dentro de esa franja | **30.9 → 70.8 px = ×2.29 sin cambiar de arte** |
| Filas que ocupa la tarjeta de 23 | 78 → 103 = 25 filas (ideal ×1.50) |
| Filas que ocupa la tarjeta de 16 | 54 → 78 = 24 filas (ideal ×1.89) |
| Filas de la tarjeta de 9 | por debajo de 54, donde ya no se dibujan karts |

Y la misma cuenta medida en el recorrido de un rival que se aleja del jugador:

| | Filas que recorre hasta el primer cambio de tamaño | Fracción del camino al horizonte |
|---|---|---|
| Vanilla | ~29 filas | 38 % |
| v1.4 actual | ~87 filas | 53 % |
| Reparto por medias geométricas con sólo 4 tarjetas (fronteras 94/74/57) | ~96 filas | **59 %** |

**Conclusión que hay que asumir:** con las 4 tarjetas actuales, la tarjeta de 32 está obligada a
cubrir del ideal 27 al 71 px (un factor **×2.6**). Ninguna colocación de umbrales arregla eso: mover
la frontera arriba hace que la tarjeta de 23 se use cuando es un 40 % demasiado pequeña. **El
"cambio tardío" sólo se arregla con más escalones en el campo cercano**, es decir con arte mayor que
32 px.

---

## 4. Qué arte hay y qué se puede fabricar (con coste medido)

* Tamaños existentes: **32×32, 23×24, 16×16, 9×9** (los 8 personajes tienen su arte propio).
* **Doblar por bloques de píxeles (×2) es exacto y no deforma** (método ya validado en este
  proyecto): de aquí salen **64×64** (de 32) y **46×46** (de 23) sin dibujar nada nuevo.
  Un ×1.5 **sí** deforma (filas impares) y está descartado.
* **Coste de arte** (4 bits/píxel, 32 B por celda de 8×8):
  * 32×32 = 512 B por fotograma de animación; **64×64 = 2 KB (×4)**; 46×46 ≈ 1 KB.
  * El kart del jugador usa **≥11 fotogramas de arte distintos**: 5,5 KB en 32×32 → **22 KB en 64×64**.
* **Presupuesto real de VRAM medido**: el área donde vive el arte de sprites son **~10 KB** (bloques
  52-62 KB de la VRAM). El resto de la VRAM no cambia **nada** entre fotogramas y **ningún bloque de
  2 KB baja del 19 % de ocupación**.
* El motor **transfiere arte de forma incremental**: escribe **~220 B por fotograma** en esa área
  (≈7 celdas). No tiene todo el arte residente; lo va sirviendo desde la ROM (que en la modificación
  tiene 1 MB, así que hay sitio *en ROM* para arte nuevo).
* **Cuántos karts coinciden a la vez en el campo cercano** (pies y ≥ 122), medido en una carrera:
  1 kart el 12 % del tiempo, 2 el 28 %, **3 el 41 %**, 4 el 13 %. **Máximo 4 simultáneos.**
* Restricción de rendimiento: la modificación ya se optimizó para **no perder fotogramas**
  (de 18 % de lag a ≈0). Cualquier plan que multiplique por 4 el tráfico de arte por fotograma
  tiene que justificar que no lo devuelve.

---

## 5. Restricciones duras (no negociables en este encargo)

1. **No se toca la cámara** (ni altura, ni inclinación, ni zoom). Las filas del §2 son fijas.
2. **No se cambia la X de los sprites.** Sólo Y y tamaño.
3. **No se escribe la ROM por conjetura**: cualquier propuesta debe poder verificarse midiendo.
4. Las tuberías y los objetos de escenario se quedan **como están** (tamaño fijo; el original hace
   lo mismo).
5. El objetivo no es "que se vea perfecto", es **que no se vea ni constante ni a saltos bruscos**:
   el autor rechaza explícitamente las dos cosas («ni de un modo ni de otro»).

---

## 6. Nuestra hipótesis, para que la valides o la rompas

Repartir las fronteras por **media geométrica del tamaño ideal** (error relativo simétrico ±18 %
en cada frontera). Resultado medido en filas (v1.4):

| Conjunto | Fronteras (filas de los pies) |
|---|---|
| **{32, 23, 16, 9}** (4 tarjetas, sin arte nuevo) | 94 / 74 / 57 |
| **{64, 46, 32, 23, 16, 9}** (con vistas ×2) | **161 / 122 / 94 / 75 / 57** |

Con el conjunto de 6, un rival que se aleja desde la fila del jugador cambia de tamaño a las 29, 68,
96, 115 y 133 filas — es decir, **cambia desde el principio**, en vez de 87 filas después.

**Su debilidad, que es donde te necesito:** el conjunto de 6 exige arte ×2, y el ×2 choca con el
presupuesto de arte del §4. Y hay un efecto colateral: si el jugador pasa a 64 y los rivales no,
un rival a la misma profundidad que el jugador se verá **la mitad de grande** (hoy ambos dibujan 32
y son coherentes entre sí).

---

## 7. Preguntas concretas

1. **¿Es la media geométrica el criterio correcto aquí?** Teniendo en cuenta que la queja medida no
   es "el error máximo es grande" sino "el kart tarda demasiado en cambiar", ¿conviene otro
   objetivo (p. ej. repartir las **filas** por bandas iguales, o ponderar el campo cercano, que
   ocupa más pantalla y más atención)? Si propones otro criterio, dame las fronteras en filas.
2. **Dame la tabla cerrada** de fronteras en filas para (a) el conjunto de 4 tarjetas y (b) el de 6,
   con el tamaño ideal y el error relativo en cada frontera.
3. **El campo cercano:** un kart justo al lado del jugador (filas 190-202) tiene un ideal de 66-71
   px. ¿Qué se hace? Opciones que veo: (a) aceptar que el 32/64 no llega y que el más cercano se vea
   pequeño; (b) ×2 sólo para el jugador, asumiendo la incoherencia con los rivales de al lado;
   (c) ×2 para jugador **y** rivales, con 3-4 rivales a la vez en el campo cercano = 6-8 KB de arte
   (¿cabe en los ~10 KB, sabiendo que además hay que servir a los karts lejanos y a los objetos?);
   (d) otra. Recomienda una y di **cómo verificarla**.
4. **Si sólo hubiera presupuesto para UNA mejora**, ¿cuál da más? ¿Subir el jugador a 64 (arregla la
   crítica del revisor, pero deja a los rivales de al lado a la mitad), o repartir mejor
   {32,23,16,9} entre los rivales (mejora el "cuándo cambia" sin arte nuevo)?
5. **¿Cómo se mide objetivamente que el resultado es correcto?** Propón una métrica que capture la
   queja del autor —"no cambia hasta que se ha alejado bastante"— y no sólo el error de tamaño.
   Mi candidata: *filas recorridas desde la fila del jugador hasta el primer cambio de tamaño*, y su
   versión continua: **error relativo del tamaño dibujado respecto al ideal, en función de la fila**.
   ¿Es suficiente? ¿Añadirías algo (p. ej. cuánto dura visualmente cada escalón en segundos)?
6. **Recomendación final:** conjunto de tamaños + fronteras en filas + qué arte hay que fabricar, si
   alguno + qué se gana y qué se pierde respecto a la situación actual. En una página, sin código.

---

## 8. Apéndice A — Cómo funciona hoy el mecanismo (para que tu respuesta sea implementable)

* La tabla está en la ROM en `$DD35`: **11 palabras de 2 bytes**, seguidas en `$DD4B` de **11
  punteros** a descriptores de sprite (`$DD6F`-`$DDED`). Los **punteros no han cambiado** entre
  versiones; lo que cambió (10 bytes) son los umbrales.
  * vanilla/v1.3: `224, 192, 160, 128, 112, 96, 80, 64, 48, 32, 0` (**todos múltiplos de 16**).
  * v1.4: `255, 255, 255, 170, 170, 90, 90, 90, 0, 0, 0` (**rompe la granularidad de 16**).
* **Unidades sin resolver, y por eso te pido filas de pantalla:** con la tabla entera puesta a un
  valor uniforme y midiendo en carrera, resulta: valores **1-16 → todos los karts con tarjeta
  grande**; valores **64-160 → todos con tarjeta pequeña**; 224 y 412 dan el mismo resultado que
  160. Es decir, la magnitud con la que se compara esta tabla está **entre 16 y 64** — un número
  pequeño, no la escala del kart (que vale 264-1010). La granularidad de 16 en vanilla apunta a que
  la tabla está en dieciseisavos de algo. La traducción a bytes la haré yo una vez decididas las
  fronteras en filas.
* El **jugador** está fijado por una constante (`$81:CEBE/CEDE`: `LDA #$0108 → STA $18 → STA
  $06,x/$0E,x`); por eso nunca cambia de tamaño.
* Existe además una **rampa vertical** de sprites (`$7E:0A86`, de 0 a 88, sumada a la Y en 9
  puntos): **no tiene nada que ver con el tamaño**, es el desplazamiento que coloca los sprites
  sobre la calzada. No la mezcles con este problema.

## 9. Apéndice B — Qué NO mirar (ya descartado, para que no pierdas tiempo)

* Las tuberías **no** son Mode-7: son sprites de tamaño fijo, idénticos píxel a píxel al acercarse.
  Quedan fuera del encargo.
* Los objetos y enemigos sueltos **no** escalan (tamaño fijo en el original y en la modificación).
* La ley de perspectiva **no** hay que re-deducirla: está medida (§2).
* El lag del juego ya está resuelto; la única preocupación de rendimiento es el tráfico de arte (§4).

---

### Qué haré con tu respuesta

Cogeré tu tabla de fronteras y tu recomendación de arte, la traduciré a la tabla de 11 palabras,
la implementaré en un ROM de prueba y la verificaré con la métrica del §7.5 sobre una carrera
completa. Si la métrica mejora y no hay regresión de lag, se queda.

---

# CORRECCIÓN 3 (tras medir, 5-oct) — tres datos que cambian el encargo

1. **El juego no cambia de arte para cambiar de tamaño: re-solapa las mismas 4 tarjetas.**
   El kart se dibuja con 4 tarjetas de 16×16; al cambiar de tamaño el motor **mueve** esas tarjetas
   (acercándolas), no carga arte nuevo. Medido en 4 400 fotogramas de carrera: **3 079 de 3 561
   cambios de tamaño (86 %) conservan exactamente los mismos tiles**. Tamaños típicos: 32×32
   (tarjetas a 16 px) y ~23×24 (tarjetas a 7-8 px). Consecuencia: **los tamaños intermedios entre 23
   y 32 podrían ser gratis** (sin arte nuevo), si el motor acepta offsets intermedios. Hay que
   confirmarlo antes de contar con ello.

2. **En el campo cercano hay 3-4 karts a la vez, no 1-2.** Medido en carrera (hack, pies y ≥ 161,
   que es la franja donde se usaría el arte ×2): 1 kart (normalmente sólo el jugador) el 35 % del
   tiempo, 2 el 2 %, **3 el 40 %, 4 el 14 %**. Cualquier plan de arte ×2 tiene que servir a 3-4 karts
   simultáneos, no a uno.

3. **El límite de celdas por línea de barrido ya está cerca.** Medido en el OAM: máximo **30 celdas
   de 8 px por scanline en vanilla** y **28 en el hack**. Simulando arte ×2 para los karts del campo
   cercano sube a **~38**. Si el límite de hardware es 34 celdas (a confirmar según el bpp de los
   OBJ de este juego), **×2 en varios karts a la vez se pasa**. Es el bloqueador más probable, por
   delante de la VRAM y del DMA.

**Y una advertencia sobre las 4 tarjetas de la tabla:** en una carrera de 1 jugador, las apariencias
de kart que se ven son **32×32 y ~23×24**; no se ha visto ninguna de 16×16 ni 9×9 en la carrera.
Es decir: la escalera real puede tener sólo **dos apariencias**, y las de 16/9 existir en la tabla no
significa que se usen. Conviene confirmarlo antes de diseñar sobre "4 tamaños".
