# La escalera de tamaños REAL de los karts (v1.3) — medida sobre el state del usuario

Fecha: 2026-10-06.  Método: core bsnes instrumentado (WRAM + VRAM + OAM), state del usuario
(`v13_psicopompo.state`), 2200 fotogramas, arte compuesto reconstruido desde VRAM/OAM.
Ficheros de evidencia: `escalera_real_28_modos.png`, `escalera_franjas_arte.png`, `escalera_por_tamanos.png`.

## 1. Corrección de mi medición anterior

Mi informe decía "4 tamaños (32/23/16/9) + marcas". **ERA INCORRECTO.** Yo contaba el **bit de tamaño
del OAM** (`big`: 16x16 o 8x8 por celda) y de ahí deduje 4 escalones. Pero el juego **compone el kart con
4 sprites** cuyas posiciones se solapan a voluntad, así que el arte VISIBLE tiene muchas más medidas.

Medido en 2200 fotogramas (modos de dibujo distintos encontrados):

| nº sprites | dy | dx | arte visible | filas (y_top) |
|---|---|---|---|---|
| 4 | 16 | 16 | 32x32 (y variantes 30x31, 29x28, 32x27, 32x25, 32x16) | 40 – 98 |
| 4 |  8 |  7 | 23x17 / 21x23 / 21x24 / 22x24 / 20x22 / 23x8 | 47 – 49 |
| 4 |  3 |  2 | recortes | 28 |
| 4 |  1 | 16 | 34x6 (recorte) | 24 – 30 |
| 1 |  0 |  0 | 16x16 / 16x15 / 16x14 / 16x11 / 16x9 / 12x15 / 11x16 / 14x9 / 10x14 | 40 – 43 |
| 1 |  0 |  0 | 8x3 / 4x7 / 2x5 (marcas) | 24 – 32 |
| 4 | 16 | 16 | 32x28 (parrilla) | 152 – 158 |

**Tamaños de arte distintos contados: ~28.** El usuario tiene razón: no son cuatro.

## 2. La ley por filas (esto es lo que importa)

- `y_top` 158 → **49** (~109 filas): el arte es **32x32 y NO cambia**. (Mario está en y_top≈158.)
- `y_top` 49 → 41 (**8 filas**): colapsa 32x32 → 20-23 → 10-16. **Todo el cambio ocurre aquí.**
- `y_top` < 40: marcas (2-8 px).

O sea: tramo larguísimo sin cambio + colapso brusco. El problema que el usuario describió
("los más cercanos no cambian hasta alejarse bastante") está **medido y confirmado**.

## 3. Mecanismo (desensamblado en la ROM)

- `$80:CF0C` rutina de dibujo de kart:
  `LDX $B4 / LDA $92,X / ASL A / TAY / LDA $DD35,Y / STA $06,X / STA $18`
  → **$DD35 no son umbrales: son 11 ESCALAS de dibujo** (224,192,160,128,112,96,80,64,48,32,0),
  una por nivel. El nivel lo pone el resto del código.
- Descriptores por nivel en `$DD6F` (11 entradas × 4 bytes, 2 punteros cada una):
  - nivel 0 → `$DD97` (especial) + `$DD9D`
  - niveles 1-9 → `$DCD5` (posiciones de los 4 sub-sprites: 0020,0060,2020,2060…) + tabla de offsets
  - nivel 10 → `$DCD5` + `$E7DA`
  → el **nivel controla la POSICIÓN/solape de los 4 sprites** (dy=16 → 8 → …) además de la escala.
- El arte (tiles) se elige en los selectores `$D874-$D8D2`.

## 4. Consecuencia para el arreglo

- Tocar `$DD35` (escalas) ya se probó: mueve la frontera de 80 a ~100 y **se topa**. Coherente: el arte no
  cambia con cada escala, cambia por **umbrales** sobre la escala.
- Para que la reducción empiece cerca de Mario (fila ~140) hay que tocar:
  (a) los **umbrales del selector de arte** (`$D874-$D8D2`), o
  (b) las **tablas de posición/solape por nivel** (`$DD6F` → `$DD4B`), forzando solape antes.
