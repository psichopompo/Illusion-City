# Mecanismo real del escalado de rivales en SMK — y el mando para repartirlo

Documento de trabajo. Todo lo de aquí está **medido** sobre la ROM `candidato_v1.3.sfc`
(carrera 1P del state `v13_psicopompo.state`), no deducido.

---

## 1. Resumen en una frase

Los rivales **no** tienen "cuatro tamaños de arte": tienen una **métrica de profundidad**
que se compara contra una **tabla de 11 umbrales** (11 palabras en ROM, `$81:$DD35`); cada
umbral selecciona a la vez *el registro de arte* (offsets enteros de los 4 sprites) y *su
propio valor* (ajuste fino sub-píxel). Esa tabla es **el mando**: mover sus valores mueve
**cuándo** cambia cada escalón. En v1.3 los 11 umbrales se apiñan entre las filas 33 y 91
→ de ahí el "tramo muerto" de 109 filas sin cambios y el colapso final.

## 2. La métrica: qué se compara

* Cada objeto/kart lleva en **`+$06`** (word) su métrica de tamaño.
* Ley medida: **métrica ≈ 3,3·(fila_en_pantalla − 23)** (la fila 23 es el punto de fuga).
  * kart a fila 190 (pegado a cámara) → métrica ≈ 552; a fila 80 → ≈ 188; a fila 40 → ≈ 56.
  * El **jugador** la lleva fija en **552** (su sprite no se re-escala: siempre al máximo).
* Comprobación cruzada: la tabla original produce transiciones en filas 91/81/72/62/57/52/47/42/38/33
  y la medición visual del colapso dio 49→41. Encaja.

## 3. El despachador (código, ROM `$81`)

```
$80:C30E  LDA $0002,X / STA $04     ; puntero a la lista de umbrales
          LDY #$0000
  loop:   LDA $18                   ; métrica (DP $18)
          CMP ($04),Y               ; comparación de 16 bits contra el umbral
          INY / INY
          BCC loop                  ; avanza mientras métrica < umbral
          TYA / ADC $02 / TAY       ; índice de banda
```
Es un recorrido **descendente**: la banda = *primera* entrada cuyo valor ≤ métrica.
El mismo despachador existe en `$C316` (con salto por tabla), `$C3D6` y `$C470`.
Lecturas de `$DD35/$DD36` confirmadas en las tres (el registro **A** del 6502 en ese
instante *es* la métrica: 31, 33, 34, 36, 39, 42, 46, 61, 108, 163, 295, 552…).

Y en `$81:$CF1E`:
```
          LDA $92,X / ASL / TAY / LDA $DD35,Y    ; ← el VALOR de la banda
          STA $06,X / STA $18                     ;    se guarda como tamaño/ajuste
```
Es decir: **el mismo número sirve de frontera y de valor de tamaño de la banda**.

## 4. La tabla (ROM, file `0xDD35`, 22 bytes)

```
v1.3 : 224 192 160 128 112  96  80  64  48  32   0
filas:  91  81  72  62  57  52  47  42  38  33  23
```
11 valores = 11 bandas = 11 registros de arte (`$DC23, $DC2D, $DC37, $DC41, $DC4B,
$DC55, $DC5F, $DC69, $DC73, $DC7D, $DC87`; los guiones/deltas por banda están en
`$DD4C-$DDE5`, y el puntero por banda en la lista de 11 palabras de `$DD6F`).
Los 4 sprites por kart (2×2) se componen en `$81:$BC06+` con los offsets del registro;
por eso el tamaño compuesto varía de forma **casi continua**: 11 bandas × carácter ×
recortes (los ~28 "modos" contados antes).

**El tramo muerto sale de aquí:** las bandas 0-4 (métrica ≥ 96) cubren las filas 52-158,
y las bandas 0-4 usan registros que rinden ≈32×32. Traducción: 109 filas sin cambio
apreciable y luego 32 → 21 → 16 en 8 filas.

## 5. El parche: repartir la tabla

`tools/parche_umbrales_reparto.py entrada.sfc salida.sfc v0 v1 ... v10` escribe las 11
palabras a mano (reproduce el candidato exacto con `264 240 200 160 140 120 100 80 60 40 0`).
`tools/parche_umbrales.py ... [factor]` es la variante automática (factor ×1,25 / ×1,5).

**Candidato elegido — `roms/candidato_v1.8_reparto_suave.sfc`:**

```
v1.3 : 224 192 160 128 112  96  80  64  48  32   0   (filas 91...33, tramo muerto 91-158)
v1.8 : 264 240 200 160 140 120 100  80  60  40   0   (filas ~103...35)
```
Regla: cada umbral pasa de 3,3·(fila−23), es decir se escalan los valores existentes para
que el juego use **los mismos tamaños, pero a distancias más cercanas**.

**El primer valor es el que fija el ajuste sub-píxel del jugador** (su métrica es fija 552
y cae siempre en la banda 0). Barrido medido:

| primer valor | Mario (caja) | fila del sprite |
|---|---|---|
| 224 (v1.3) | 32×32 | 158 |
| 256 - 264 | 32×32 | **158 (idéntico a v1.3)** |
| 268 - 312 | 32×32 | 159 (+1 px) |
| ≥ 336 (p.ej. el ×1,5 ⇒ 336) | 32×32 | 160 (+2 px) |
| forzar 110/125 en bandas medias | **23×24 (ROTO)** | 164 |

Por eso v1.8 lleva `264` como primer valor: la reducción empieza antes **y** Mario queda
exactamente donde estaba.

## 6. Medición (oamlog, 700 fotogramas, misma carrera)

Altura media dibujada de los rivales por fila (`tools/mide_curva_tamano.py`):

| fila | v1.3 | v1.8 |
|---|---|---|
| 130-139 | 32 | 32 |
| 120-129 | 32 | 32 |
| 110-119 | 32 | 32 |
| 100-109 | 32 | 32 |
| 90-99 | 32 | **32** |
| 80-89 | 32 | **24** |
| 70-79 | 26,7 | **24** |
| 60-69 | 24 | 24 |
| 50-59 | 24 | **24** (el escalón de 24 se extiende hasta la 50) |
| 40-49 | 17,1 | 17,1 |

Datos crudos: `docs/curva_v13_vs_v18.csv` (incluye nº de muestras por franja).
Figuras: `docs/curva_tamano_v13_vs_v18.png`, `docs/comparativa_v13_vs_v18.png`,
`docs/zoom_rival_v13_vs_v18.png` (mismo kart, mismo fotograma, zoom ×7).

**Jugador:** caja y fila **idénticas a v1.3** (32×32 en la 158) con el primer valor 256-264.
Límite del mando escalando la tabla entera: ×1,6 (a partir de ahí, +2 px); ×1,7 lo degrada
a 23×24 y ×2 a 16×16. Los repartos "lineales" con valores altos en bandas medias también
lo degradan: el conjunto de la tabla, no solo la primera entrada, decide su composición.

## 7. Qué queda por hacer (si hay que apretar más en el tramo cercano)

Con la tabla sola el techo está en el apartado 6, porque las bandas 0-5 comparten registros
de ≈32×32. Para reducir de verdad las filas 100-158 hay que tocar **qué registro usa cada
banda** (la lista de 11 punteros de `$DD6F` y/o la tabla por kart de `$DA60`, leída en
`$80:C359`/`$C466`), o los registros mismos — eso ya es escribir arte/offsets, y conviene
hacerlo solo con la ley de cada registro medida una a una.

## 8. Instrumentación usada (para reproducir)

* Core bsnes instrumentado: `bash tools/build_instrumented.sh /tmp` + `python3 tools/core_patch_reads.py /tmp/bsnes_src`
  + `cd /tmp/bsnes_src/bsnes && make target=libretro -j`. Este turno se amplió el hook de
  **lectura a `$DA00-$DDEF`** y se le añadió el **registro A** (el valor comparado).
  **Aviso de entorno:** en esta sesión `/tmp` se vacía cada pocos minutos; el core compilado
  está cacheado en `build_cache/bsnes_libretro.so.gz` (6,2 MB) y se restaura con
  `gunzip -c build_cache/bsnes_libretro.so.gz > /tmp/bsnes_src/bsnes/out/bsnes_libretro.so`.
* Aviso de formato: en las trazas, el campo `pc=` es **banco_de_datos<<16 | PC** (aquí casi siempre
  `0x80xxxx`), así que la dirección real de código/datos es el `pc & 0xFFFF` (que es *file offset*
  para todo lo que cae en el banco `$81`, es decir `$8000-$FFFF`). Confundir esto lleva a leer
  el banco equivocado.
* Escrituras a `$7E:DB00-$DEFF`: **ninguna** en 300 fotogramas → los registros de sprite son
  ROM estática, no WRAM.
* Harness: `WDUMP=<addr_hex>,<len>` (nuevo) vuelca WRAM por fotograma; `LEVELS=1` da
  (`+$92`, `+$06`, `+$18`) por kart; `OAMLOG=1` da el OAM crudo.
* Medición de la curva: `python3 tools/mide_curva_tamano.py /tmp/run1 /tmp/run2 ...`
  (agrupa rivales por proximidad, descarta grupos >4 sprites y copias por wrap).
