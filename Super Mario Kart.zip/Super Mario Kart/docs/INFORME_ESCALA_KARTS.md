# Escala del kart del jugador — informe técnico (2026-10-05)

Petición (a raíz de la review de romhacking.net #2243): probar que el kart del jugador (y los que
están a su altura) se dibujen más grandes — 48×48 pedido, 64×64 aceptado — con transición gradual.
ROMs analizadas: `roms/Super Mario Kart (USA).sfc` (vanilla) y `roms/candidato_v1.3.sfc` (hack actual).

## 1. Lo que el hardware permite

El SNES sólo dibuja sprites de **8×8, 16×16, 32×32 o 64×64** (dos juegos de tamaños a la vez, según
OBSEL `$2101`). **48×48 no existe**: o se compone con varios sprites (p. ej. 3×3 de 16×16) o hay que
redibujar el arte a 48 px.

Valores de OBSEL:
| sss | pequeño | grande |
|-----|---------|--------|
| 000 | 8×8     | 16×16  |
| 001 | 8×8     | 32×32  |
| 010 | 8×8     | 64×64  |
| 011 | 16×16   | 32×32  |
| 100 | 16×16   | 64×64  |
| 101 | 32×32   | 64×64  |

SMK escribe **`$02`** en `$2101` en siete puntos (ficheros `0x08ABD`, `0x08BEF`, `0x1E50F`, `0x4F482`,
`0x4FF60`, `0x582A4`, `0x5BC4F`; además `STX $2101` en `0x08B45` y `STZ $2101` en `0x597F6`). Según la
tabla oficial, `$02` = *8×8 y 64×64*; la nota antigua del proyecto (“$02 = 16×16 y 32×32”) es
**incorrecta** (ese valor es `3`). Queda como hipótesis fuerte pendiente de confirmar en ejecución.

## 2. Cómo dibuja el juego cada kart (verificado con OAM + VRAM)

Cada kart = 4 sprites de 16×16 contiguos en OAM (slots `28-31` el jugador, `32-35`, `36-39`… los
rivales; hasta `59`). En pantalla cada kart ocupa ~32×28 px de arte real.

* Bloques de arte observados en el fotograma 1620 (captura 1P, ambos casos):
  * vanilla: P1 tiles `$80/$A0`; rivales `$84/$94`, `$88/$98`, `$8C/$9C`, `$86/$A4/$A6/$C0`…
  * hack v1.3: P1 tiles `$80/$A0` (**igual que vanilla**); rivales `$84/$A4`, `$88/$A8`,
    `$8C/$8E/$AC/$AE`, `$C0/$D0`…
* El juego **tiene arte de kart pre-escalado en varios tamaños** en VRAM (área OBJ `$8000-$BFFF`):
  desde 32×32 hasta ~14×9 px, varias poses y varios personajes. **No hay ningún bloque mayor de 32×32.**
* En VRAM quedan libres, en carrera, los caracteres **`$0FF-$17F`** (medido sobre 240 fotogramas;
  ~2 KB) más huecos sueltos. Es el único sitio disponible para arte nuevo.
* El suelo de la pista (Mode 7) vive en `$0000-$3FFF` y **no se puede tocar**.

## 3. El hallazgo que explica la review

Con la cámara de la hack (más adelantada), la escala proyectada `$06` de cada kart sube ~×1,9
(P1: 264→549; rivales: 130→231, 113→195, 96→162, 84→139, 75→124, 68→109, 62→100), y **los rivales
pasan a usar bloques de arte más grandes** (`$88/$A8`, `$C0/$D0`…) mientras el sprite del jugador
`sigue con el bloque `$80/$A0` de siempre**: los parches de la hack sustituyen la escala de P1 sólo
para el orden/colisión (`$06,x`) y para su sombra, pero **no cambian el bloque de arte con el que se
dibuja**. Resultado: el rival cercano se ve con arte de mayor zoom que Mario → “perspectiva invertida”.

Comprobado además:
* Forzar por software `$18` (escala de dibujo de P1) en `$80:CEBE`/`CEDE` a `$02FF` → **la imagen no cambia**
  (0 píxeles de diferencia). Los dos `LDA #$0108` de `$80:CEC5`/`CEE5` son sólo las constantes de **Y** del
  sprite (`LDA #$FF66`, `LDA #$FFD6`) combinadas con `STA $1E`; la constante `$0108` no manda el zoom de dibujo.
* La tabla de umbrales `$80:DD35` (`E0 00 C0 00 A0 00 80 00 70 00 60 00 50 00 40 00 30 00 20 00 00 00`) **sí afecta a
  los rivales** (bajando los umbrales, un rival cambió de tamaño), pero **forzar a todos los karts al
  mismo nivel (0,1,2,3,4) NO cambió ningún tile de P1**: el jugador no pasa por ese selector.
* Cambiar los 7 valores de OBSEL de `$02` a `$00`/`$01`/`$05` tampoco cambió el arte de P1
  (sí una zona de la izquierda, donde se dibujan rivales).

**Conclusión**: el bloque de arte del kart del jugador lo fija una ruta distinta (probablemente la del
“tipo de cuadro” que se salta con `BVS`/`BEQ` en la cabecera de `$80:C730`, o la lógica de salto de P1
en `$80:CE97`), que aún no está localizada.

## 4. Cómo se vería (mockup)

`docs/mockup_tamano_kart.png`: tres paneles del mismo tramo con el kart del jugador a tamaño actual,
×1,5 (48×48) y ×2 (64×64), escalando el arte real y manteniendo los pies en su sitio.

## 5. Opciones y coste

| # | Idea | Qué implica | Coste |
|---|------|-------------|-------|
| A | **Ampliar el arte del jugador ×2 en tiempo de ejecución** (32×32 → 64×64 duplicando píxeles) y dibujarlo con 4 sprites de 32×32 | Escribir ~2 KB de VRAM por fotograma desde una rutina propia (cabe en los chars libres `$0FF-$17F`), + parchear el compositor de P1 | Medio-alto. Estilo “pixelado ×2” |
| B | **Redibujar a 48×48** el arte de los 8 pilotos (todas las poses) | Trabajo de arte manual; después, mismo problema de sitio en VRAM | Alto |
| C | **Igualar hacia abajo**: que los rivales usen el mismo nivel de arte que el jugador (o uno menor) | Tocar la escala de dibujo de los rivales (aquí sí funciona la tabla `$DD35`) | Bajo |
| D | Dejarlo como está | La sensación de perspectiva invertida viene de que la cámara acercada agranda a los rivales | Nulo |

**Recomendación**: hacer primero **C** (barato, ataca exactamente lo que dice la review) y, si se
quiere el efecto “más grande” del jugador, abordar **A** como prueba de concepto.

## 6. Pendiente

1. Localizar la ruta que fija el bloque de arte del jugador (candidatos: `$80:C730` cabecera,
   `$80:CE97`/`$CEBB`/`$CEDB`, `$80:B0D6`).
2. Confirmar en ejecución el valor real de OBSEL durante la carrera.
3. Medir qué personaje/pose corresponde a cada bloque de arte de la escalera de VRAM.

---

# Segunda parte: ¿están las franjas de tamaño bien repartidas? (2026-10-05)

Medido sobre capturas reales de carrera (OAM + VRAM del mismo fotograma, 60 muestras por ROM).

## 1. Cómo cambia el tamaño un kart (mecanismo, verificado)

El kart son **4 sprites de 16×16** en OAM. El juego **no** reescala el dibujo: cambia
**la separación** entre esos 4 sprites (y, con ella, el bloque de arte que vuelca en VRAM).

Escalera medida en carrera:

| separación (dx, dy) | escala $06 a la que aparece | arte resultante |
|---------------------|-----------------------------|-----------------|
| 16, 16 | >= 159 | 32x32 (el más grande) |
| 7, 8   | 114 - 158 | 20x22 |
| 7, 0   | ~105 - 113 | ~16x11 |
| 4, 0   | ~94 - 104 | ~14x9 |
| 2, 0   | ~87 - 93 | ~11x9 |
| 0-1, 0 | < 87 | ~8x9 (el más pequeño) |

**Umbrales exactos: 159 (escalón grande) y 114 (escalón medio).**

## 2. Cuánto ocupan esas franjas en pantalla

| | vanilla | hack v1.3 |
|---|---------|-----------|
| rango de escala de los karts | 73 - 264 | 100 - 549 |
| rango vertical de pantalla (Y) | 30 - 70 = 40 px | 39 - 158 = 119 px |
| karts con arte grande (>=159) | 3 | 2 (549 y 364) -> banda de 52 px |
| karts con arte medio (114-158) | 3 | 5 (154, 133, 124, 118, 109) -> banda de 10 px |
| karts con arte pequeño (<114) | 2 | 1 |

**Conclusión**: no, no está repartido en franjas iguales. En la hack hay **dos karts** usando el arte
grande (en una banda vertical de 52 px) y **seis karts** amontonados en una banda de ~10-14 px usando
entre todos arte casi idéntico. Es exactamente lo que dicen los comentarios: "los rivales son
demasiado pequeños" / "el sprite de Mario no escala con la nueva perspectiva".

En vanilla los 8 karts se reparten en 40 px de pantalla con **tres** escalones de tamaño que van
cambiando progresivamente (franjas de 19-32 px, mucho más equilibradas).

## 3. Por qué pasa

La tabla de umbrales `$80:DD35` (`E0 C0 A0 80 70 60 50 40 30 20 00`) se compara contra la **escala
proyectada** (`$06`), que es una magnitud de mundo (profundidad), no la posición en pantalla.
En vanilla el mapeo profundidad -> Y comprime todo en 40 px, así que los escalones quedan apretados
y el ojo los lee como graduales. Al acercar la cámara (hack), la misma escala se reparte en 119 px
de pantalla, y entonces se ve que **los umbrales están mal espaciados para la nueva perspectiva**:
el salto de 114 a 159 deja a 5 de 8 karts con el mismo tamaño.

## 4. Arreglo propuesto (franjas de altura parecida)

Repartir los umbrales **por posición en pantalla**, no por escala de mundo:

| franja (de abajo arriba) | escala en la hack | escala en vanilla |
|--------------------------|-------------------|-------------------|
| 1 (grande)  | >= 280 | >= 150 |
| 2           | 200 - 279 | 120 - 149 |
| 3           | 155 - 199 | 95 - 119 |
| 4 (pequeño) | < 155 | < 95 |

Con eso, en la hack las cuatro franjas caerían en Y ~ 41-70 / 70-100 / 100-130 / 130-158
(~30 px cada una) en vez de 52 px + 10 px + 4 px.

## 5. Sobre el mockup estirado

`docs/mockup_escalado_limpio.png` es la versión corregida: escalado **por bloques de píxeles**
(múltiplos enteros = píxeles como puños, sin deformación ni interpolación). El anterior (x1,5)
deformaba porque el arte real es 32x28 y 28 no se divide por 1,5 -> filas impares estiradas y
huecos. Regla: múltiplos enteros (x2, x3), nunca fraccionarios.

## 6. Medidas de las capturas (vanilla vs v1.3)

| elemento | vanilla | v1.3 |
|---|---|---|
| marca del suelo (Mario) | 97 px | 101 px |
| Mario (8º) | 28 px | 28 px |
| Koopa (7º) | 22 px | 22 px |
| Bowser (6º) | 21 px | 28 px |
| Toad (5º) | 17 px | 24 px |
| Luigi (4º) | (tapado) | 22 px |
| Yoshi (3º) | 12 px | 19 px |
| Peach (2ª) | (tapada) | 19 px |
| Donkey (1º) | 10 px | ~19 px |
| Lakitu | 35 px | 35 px |
| franja de carrera (alto) | ~110 px | ~156 px |
| asfalto en la fila 200 | 73 px | 239 px |
| asfalto en y=60 | 162 px | 87 px |

El asfalto es **más estrecho en la parte lejana** (87 vs 162) y **mucho más ancho en la cercana**
(239 vs 73): la fuga está más acentuada, y la pista arranca en y≈41 (vs y≈33 en vanilla).
Concuerda con la crítica de "la carretera ocupa demasiado y falta fondo": la vista de carrera ha
crecido de ~110 a ~156 px y el asfalto cercano llega a los bordes de la pantalla.

---

# Tercera parte: MECANISMO COMPLETO y candidato v1.4 (2026-10-05)

## 1. Descubrimiento principal: teníamos mal documentado el mecanismo

El **tamaño lo fija la escala proyectada de cada kart**, no una "separación de sprites" aparte, y
la tabla `$80:DD35` reparte **8 disfraces** (composiciones de 4 sprites) segun esa escala.

`$80:DD35` son **dos tablas consecutivas**:

| tabla | contenido | valores |
|-------|-----------|---------|
| umbrales (11 words) | compara contra `$18` (escala de dibujo) | `E0 C0 A0 80 70 60 50 40 30 20 00` (**descendente**) |
| punteros (11 words) | offset+0x8000 del disfraz | `$DDED $DD6F $DD73 $DD77 $DD7B $DD7F $DD83 $DD87 $DD8B $DD8F $DD93` |

Cada disfraz = 4 words (offset X, offset Y, tile derecho?, tile izquierdo?):

| nivel | escala `$18` | disfraz (bytes) | geometría | arte |
|-------|--------------|-----------------|-----------|------|
| 0 | >= 224 | `00E0 C000 0000 0000` | dx=16 dy=16 | 32x32 |
| 1 | 192-223 | `A000 0000 0000 0080` | dx=16 dy=16 | 32x32 |
| 2 | 160-191 | `0000 0000 8000 0000` | dx=16 dy=16 | 32x32 |
| 3 | 128-159 | `0080 0000 8000 8000` | dx=7 dy=8 | 23x24 |
| 4 | 112-127 | `8000 8000 8000 0000` | dx=7 dy=8 | 23x24 |
| 5 | 96-111 | `8000 0000 0000 0300` | dx=8 dy=0 | 16x16 |
| 6 | 80-95 | `0000 0000 0300 0700` | dx=8 dy=0 | 16x16 |
| 7 | 64-79 | `0000 0300 0700 0900` | dx=8 dy=0 | 16x16 |
| 8 | 48-63 | `0300 0700 0900 0200` | dx=0 dy=8-9 | 16x16 |
| 9 | 32-47 | `0200 ...` | dx=4 dy=0 | 16x16 |
| 10 | < 32 | `0000 ...` | dx=4 dy=0 | 9x9 |

Verificado forzando cada nivel (umbrales a `$FFFF`/0) y leyendo el OAM: los niveles 0-4 usan
4 sprites de 16x16; los niveles 5+ usan 4 sprites de 8x8 con los tiles ya "pre-escalados" en VRAM.

## 2. POR QUÉ el jugador nunca cambiaba: su escala es CONSTANTE

```
$81:CEBE:  LDA #$0108 (264) → STA $18 ; STA $06,x     (jugador, vista normal)
$81:CEDE:  LDA #$0108 (264) → STA $18 ; STA $0E,x     (jugador, vista inferior)
```
Comprobado en ejecución: la escala del jugador vale **549** en `$06` (la hack la subió) pero
**264 exactos y constantes** en `$18` (la que manda para el dibujo). Por eso da igual la cámara:
su arte no cambia nunca. Y por eso mi parche anterior de `$18` en `$80:CEBE` no hacía nada
(**estaba en el banco $81**, no en $80).

## 3. Candidato v1.4

10 bytes cambiados respecto a v1.3 (solo la tabla de umbrales en `0xDD35-0xDD47`):

| | 32px | 23px | 16px | 9px |
|---|------|------|------|-----|
| v1.3 (actual) 224/160/48 | 2 karts, banda 34 px | 2 karts, banda 20 px | **5 karts**, banda 28 px | 0 |
| **v1.4** 255/170/90 | 2 karts, banda 25 px | 3 karts, banda 24 px | 4 karts, banda 19 px | 3 karts, banda 26 px |
| vanilla (referencia) | 1 kart | 2 karts | 2 karts | 3-4 karts |

Comprobación en ejecución — **altura del arte por kart (0 = jugador) en 7 fotogramas**:

```
 frame | VANILLA                        | v1.3                           | v1.4 (candidato)
  1500 |  25   9  17  17   9   9   9   9 |  25   9  25  25  25  17  17  17 |  25   9  25  17  17   9   9   9
  1550 |  25   9  17  17   9   9   9   9 |  25   9  25  25  25  17  17  17 |  25   9  25  17  17   9   9   9
  1600 |  25   9  17   9   9   9   9   9 |  25   9  25  25  25  17  17   9 |  25   9  17  17   9   9   9   9
  1650 |  25   0   9   9   9   9   9   9 |  25   1  17  17   9   9   9   9 |  25   0   9   9   9   9   9   9
  1750 |  25   0   9   9   9   9   1   1 |  25   0   9   9   9   9   9   9 |  25   0   9   9   9   9   9   9
  1800 |  25   0   1   1   1   1   1   1 |  25   0   9   9   9   9   9   9 |  25   0   9   9   9   9   9   9
```

**v1.4 reproduce la progresión de vanilla** (idéntico en 1600/1650/1750) mientras la v1.3
amontonaba 3-4 karts en el tamaño máximo. El jugador (kart 0) es **byte a byte idéntico**
entre v1.3 y v1.4 en los 1600 fotogramas comparados: cero regresión.

Archivos: `roms/candidato_v1.4.sfc`, generador `tools/franjas_karts.py`
(`franjas_karts.py in.sfc out.sfc A B C [escala_jugador]`).
Evidencia gráfica: `docs/comparativa_tamanos.png` (parrilla) y `docs/comparativa_f1600.png`.

## 4. Lo que queda pendiente (con la causa ya identificada)

1. **El jugador sigue con escala fija 264** → con la cámara acercada queda 2,1x por debajo de los
   rivales cercanos. Con las franjas ya corregidas el efecto es mucho menor, pero la crítica
   "el sprite de Mario no escala" se arregla subiendo esa constante (p. ej. 400-500) o sustituyendo
   `LDA #$0108` por `LDA $06,x` en `$81:CEBE`/`CEDE`. **Probado**: bajando la constante a 100 el
   jugador pasa a 8x8 (2 sprites), o sea que la constante manda de verdad.
2. **Arte de 48x48/64x64**: sigue haciendo falta arte nuevo (no hay nada mayor de 32x32 en VRAM).
   El mockup limpio está en `docs/mockup_escalado_limpio.png` (escalado por bloques, sin deformar).
3. **Fondo**: la crítica de "la carretera ocupa demasiado" se confirma (asfalto 239 px vs 73 en la
   fila 200); es cuestión de la vista de carrera, independiente de las franjas.

---

# Cuarta parte — reproducción fiel en 1 jugador, y por qué se ven descuadrados

## 1. Un error de lectura que invalidaba TODAS las capturas anteriores

El harness leía el búfer del core como XRGB8888 (4 bytes/píxel). El core lo entrega en
**RGB565 (2 bytes/píxel)**. Consecuencias de ese error:

* La imagen salía **comprimida a la mitad de ancho** (256 px reales ocupaban 128 columnas) y
  con **colores falsos** (asfalto verdoso, cielo morado).
* El resto de la anchura (columnas 128-255) era negro: por eso "media captura salía negra".
* Todas las comparativas hechas hasta ahora estaban sesgadas; cualquier medida horizontal
  (anchos, márgenes, "el kart está a X píxeles del borde") era falsa.

Corregido en `harness/drive.c` con un lector de píxel consciente del formato
(`get_rgb()`: RGB565 / 0RGB1555 / XRGB8888, según lo que declare `SET_PIXEL_FORMAT`) aplicado
a `save_ppm` y a `FRAMEHASH`. Recompilar con `-ldl -lm -lz`.

## 2. Cómo reproducir exactamente una partida de 1 jugador

* Los guiones del harness se lanzaban con el mando 2 activo por defecto (`PORTS=3`), así que
  **el juego entraba en modo 2 jugadores** (pantalla partida, dos relojes).
* Con **`PORTS=1`** y `harness/script_boot_a_carrera.txt` se llega a una partida de 1 jugador
  idéntica a la de las capturas del usuario (vista de carretera arriba + minimapa abajo).
  La parrilla/arranque cae sobre los fotogramas **1600-2000**.

`docs/comparativa_tamanos.png` (parrilla, f1600 y f1700) y `docs/comparativa_f1600.png`
(carrera, f1800) están **regeneradas con colores reales** — las anteriores ya no valen.

## 3. Los karts SÍ se desplazan respecto a sus marcas (medido)

Comparando los mismos fotogramas con el mismo guion (vanilla | v1.3 | v1.4) y leyendo el OAM
y la rejilla blanca pintada en el asfalto (fondo Mode-7, la "marca" del suelo):

| objeto | vanilla | v1.3 / v1.4 | desplazamiento |
|---|---|---|---|
| sprite de P1 (kart), fila superior | y = 70 | y = 158 | **+88 px** (constante en f1700-f2600) |
| marca de rejilla bajo P1 | y = 90 | y = 162 | +72 px |
| Lakitu + semáforo (x=36/63) | y = 5/21 | y = 20/36 | +15 px |
| HUD del panel de objetos | x 182-214, y 84-92 | x 11-43, y 196-205 | recolocado abajo-izquierda |

Lo importante: **los karts bajan 88 px pero su marca de suelo sólo baja 72 px**, así que el kart
queda **~16 px por debajo de su marca** (en vanilla la marca cruza a la altura de las ruedas;
en v1.3/v1.4 cruza a la altura del pecho/cara). Eso es exactamente lo que el usuario describe:
personajes corridos respecto a su marca del suelo. Y como el desplazamiento es *constante*, no
se trata de un efecto de perspectiva: es un desfase de dibujo.

Lateralmente también cambian: el kart más a la izquierda pasa de x=15 a x=7 (se pega al borde),
coherente con la carretera más ancha, pero la proporción kart/marca no es la misma →
"los de la izquierda pegados al borde de su marca".

## 4. El tamaño del jugador es constante también en vanilla

En vanilla, P1 dibuja siempre **4 sprites 16×16 (arte 32×32)** con los mismos tiles
(`80 80 A0 A0`), mientras los rivales usan el escalón 32/24/16/9 px. Es decir: **el jugador no
cambia de tamaño en el juego original** (la cámara va pegada a él; su escala `$18` es la
constante 264 que se escribe en `$81:CEBE`/`$81:CEDE`). Que Mario no cambie de tamaño no es un
defecto introducido por la hack: es el comportamiento de serie. Cambiarlo es una decisión de
diseño (escala del jugador), no un arreglo de regresión.

## 5. Pendiente inmediato

1. Localizar de dónde salen los desplazamientos por objeto (+88 karts, +15 Lakitu, recolocación
   del HUD): revisar las rutinas de dibujo nuevas del banco `$88`
   (`$88:8AD6/8B15/8B34/8B53/8BB0/8BCF/8BEE`) y sus desplazamientos `#+$0120`, `#+$01A0`,
   `#+$00C0/$0068`, `#+$0050/$−$0008`, `#−$00E0`.
2. Decidir si el jugador debe escalar (constante 264 → valor que siga la profundidad) sabiendo
   que sin arte nuevo el máximo es 32×32.
3. Repetir la medida con objetos de decorado (tuberías) para cuantificar el "encoge/crece".

---

# Quinta parte — los estados del usuario (bsnes v115) ya cargan

## 1. Qué fallaba

* Los `.state` de RetroArch son **RZIP con 3-8 chunks zlib** (no uno solo): cabecera `#RZIP` de 20
  bytes y luego `[uint32 tamaño][bloque zlib]` repetido. El harness sólo descomprimía el primero.
* El payload descomprimido empieza por la cabecera **`RASTATE`** (16 bytes: `"RASTATE"`, versión,
  tamaño declarado) y **el core bsnes rechaza esos 16 bytes de cabecera**: hay que pasarle el
  payload desde el offset 16 y con la longitud declarada. Ahí estaba todo el problema.
* Extra: al cargar un estado, bsnes deja el mando sin asignar; hay que volver a llamar a
  `retro_set_controller_port_device(0,1)` después de `unserialize` o el juego se queda quieto.

Comandos reproducibles en `tools/setup_cores.sh`. El harness necesita además `harness/libretro_vfs.h`
(implementación mínima de la interfaz VFS sobre stdio): **bsnes pide `GET_VFS_INTERFACE` antes de
`init()` y si el frontend no la da, no arranca**. `snes9x` no la usa.

## 2. Un estado que NO es de bsnes

`TEST_BL_V114_CARGAR.state` lleva en su interior **`GENPLUS-GX 1.7.6`**: se guardó con el core
Genesis Plus GX cargado, no con bsnes. Por eso no carga ni en bsnes ni en snes9x. Hay que volver a
guardarlo con bsnes v115 seleccionado. (`Tuberia.state` y `Curva.state` sí son bsnes `115.1`.)

## 3. Lo que ya se ve en tus escenas

`docs/estado_tuberia_vanilla_vs_hack.png`: el **mismo estado** cargado en vanilla (izquierda) y en
v1.4 (derecha). El estado está donde lo dejaste (vuelta 1, 1'26, puesto 6, 3 vidas, 20 monedas) y
las tuberías están en el mismo punto del mundo; la hack simplemente las pinta distintas.

`docs/estado_curva.png`: la salida de la curva con los rivales acercándose (f+0/f+20/f+60).

## 4. Medida del ciclo de tamaño de los rivales (v1.4, carrera de 1 jugador)

Escala interna `$18` de cada rival registrada fotograma a fotograma (snes9x, 3200 fotogramas,
WRAM `$1000+$100*k` + `$18`). Los umbrales de v1.4 (255/170/90) dan 4 tamaños: 32/24/16/9 px.

| kart | escala $18 (carrera) | cambios de tamaño | rebotes <30 f |
|---|---|---|---|
| P1 (Mario) | 951-1016 (constante) | 0 | 0 |
| rival 1 | 75-933 | 6 | 0 |
| rival 3 | 77-933 | 6 | 0 |
| rival 7 | 72-941 | 9 | 0 |

Ejemplo (rival 1): f2293 32→24, f2351 24→16, f2447 16→9, y al acercarse otra vez f2629 9→16,
f2750 16→24, f2795 24→32. Es decir: **el escalado es monótono (no baila), pero cada cambio es un
salto de un fotograma y sólo hay 4 escalones**, separados ~40-100 fotogramas (0,7-1,7 s).
El "cambio brusco" que ves es eso: cuantización a 4 artes, no un error de cálculo.

## 5. Por qué el kart va "adelantado" respecto a su marca

Comparado en los mismos fotogramas (mismo guion, vanilla vs v1.4):

| | vanilla | v1.4 | desplazamiento |
|---|---|---|---|
| sprite del kart de P1 | y 70-102 | y 158-190 | **+88** |
| fila de marcas blancas bajo él | y 90 | y 162 | **+72** |
| Lakitu + semáforo | y 5/21 | y 20/36 | +15 |

Los sprites bajan 88 px y la calzada sólo 72 → **los sprites quedan ~16 px por debajo de la
calzada**. Consecuencia visible (`docs/marca_vs_kart.png`): en vanilla la marca blanca cruza el
kart a la altura de las ruedas (20 px bajo su borde superior, 62 % de su altura) y en v1.4 cruza a
4 px del borde superior (12 %). Lo mismo con el Lakitu (+15). Es un desfase **sistemático de
sprites contra Mode-7**, no un efecto de perspectiva.

## 6. Dónde está el mecanismo (banco nuevo `$88`)

El diff vanilla↔v1.4 son **84 runs / 387 bytes**, y el ROM pasa de 512 KB a **1 MB**: hay un banco
`$88` nuevo (file 0x80000) con 43 rutinas sustituidas por `JSL`.

Patrón encontrado: donde vanilla hacía, por ejemplo, `LDA #$FF66 / STA $1E` (Y del sprite del
objeto), la hack pone `JSL $88:89B0 / NOP`. La rutina nueva es:

```
$88:89B0  PHP / REP #$20 / PHA
$88:89B4  LDA $7E0A88      ; flag de modo
$88:89BB  BEQ $89C5
$88:89BF  LDA #$FF66       ; <- MISMA constante que vanilla
$88:89C2  STA $1E
$88:89C4  RTL
$88:89C5  PLA / PLP / JML $88:8590   ; <- el OTRO camino (el que hace distinto Y)
```

O sea: la hack tiene **dos caminos de dibujo** según `$7E:0A88`; uno repite las constantes de
vanilla y el otro salta a código nuevo que recalcula la posición. El desfase de 16 px tiene que
estar en ese segundo camino (`$88:8590`, `$88:8600`, y las ventanas `$88:8Axx/8Bxx`).
Es el punto exacto donde hay que mirar para el arreglo.

## 7. Siguiente paso

1. Desensamblar `$88:8590` y `$88:8600` completos (los dos destinos de los `JML`) y localizar la
   constante/operación que suma los 16 px de más a la Y de los sprites.
2. Con eso, decidir el arreglo en dos frentes:
   - sprites (karts, Lakitu, objetos): quitar el desplazamiento sobrante;
   - decorado Mode-7 (tuberías, monedas, cajas): comprobar si el recorte/escalado de las ventanas
     `$88:8Axx` explica el "grande→pequeña→grande".
3. Sin arte nuevo sólo hay 4 tamaños de kart (32/24/16/9). Si se quieren más escalones hay que
   *dibujar* arte intermedio; lo que sí se puede es repartir los umbrales para que cada salto
   ocurra más lejos (menos visible) y que el paso 16→9 no sea tan brusco.

## 8. Dónde se calcula la Y de los sprites (rutinas nuevas)

Los dos caminos de `$88:89B0`/`$88:89CB` acaban en `$88:8590` y `$88:8600`. Ambas rutinas hacen
lo mismo (una para la vista de arriba, otra para la de abajo):

```
$88:8590  SEP #$20
          LDA #$06 / STA $006000     ; comando a un "buzón" en $6000 (SRAM/registro)
          REP #$20
          LDA $16 / STA $00
          LDA $18 / ASL $00 / ROL / ASL $00 / ROL   ; desplaza 2 bits (x4) el par ($00,$18)
          STA $006000                ; envía el parámetro
          LDA $1A / STA $00
          LDA $1C / ASL $00 / ROL / ASL $00 / ROL   ; ídem con ($1A,$1C) -> escala
          STA $006000
          ... LDA $007000 / BPL ...  ; espera (handshake por el bit 7 de $7000)
          LDA $006000 x3             ; recoge 3 words de resultado
          STA $00
          LSR / CLC / ADC $00        ; = valor * 1,5
          CMP #$00 / ORA $90 / ORA $A9 / SBC $069502,x   ; resta una tabla indexada por X
          LDA #$66 / SBC ...         ; y otra constante/tabla
          ASL / ROR $1E85            ; <- escribe la Y del sprite ($1E)
```

Puntos clave para el arreglo:

* La Y del sprite sale de **una multiplicación por 1,5** y **una resta contra una tabla indexada
  por X** (`$069502,x` en la vista de arriba, `$0E9502,x` en la de abajo).
* Las constantes de partida son las de vanilla (`#$66` y `#$D6`), pero el resultado se recalcula con
  ese factor 1,5 y esa tabla: ahí está el desplazamiento sistemático (karts −16 px, Lakitu −15).
* `$006000`/`$007000` se usan como **buzón con handshake** (escribir comando, esperar flag). Ese
  mecanismo es el mismo que usan las ventanas de descarte del banco `$88`, así que el "encoge" del
  decorado y el desfase de los sprites probablemente comparten esta calculadora.

Siguiente paso concreto: volcar la tabla `$069502` (`$88:9502` en el ROM de 1 MB) y compararla con
la equivalente de vanilla, y comprobar si el factor 1,5 es el correcto para cada franja de
profundidad. Con esa tabla en la mano el arreglo es cambiar una tabla, no tocar código.

## 9. MECANISMO COMPLETO del desplazamiento vertical (y candidato a arreglo)

### 9.1 La variable maestra `$7E:0A86`

La hack añade una variable **que no existe en vanilla** (0 coincidencias de `$7E:0A86` en el ROM
original). Se escribe en `$88:8339` y `$88:8358`, y se suma a la Y de todos los sprites al final de
las rutinas de dibujo:

```
$88:8647  LDA #$FFD6      ; −42  (vista de abajo; $FF66 = −154 en la de arriba, $88:85E7)
$88:864D  CLC
$88:864E  ADC $7E0A86     ; <-- offset global
$88:8652  STA $1E         ; Y del sprite
```

Los 9 `ADC $7E0A86` del ROM (posiciones 0x884D4, 0x884E4, 0x885E7, 0x88653, 0x89219, 0x89230,
0x89247, 0x8925E, 0x8A10D) son los puntos donde se aplica.

### 9.2 Cómo se calcula

```
$88:8332  LDA #$0000
$88:8335  STA $7E0A84          ; contador a 0
$88:8339  STA $7E0A86          ; offset a 0
...
$88:833F  LDA $7E0A84
$88:8343  CMP #$0048           ; tope 72
$88:8346  BCC $834D
$88:8348  LDA #$0048           ; 72
$88:834B  BRA $834F
$88:834D  INC / INC            ; avanza de 2 en 2
$88:834F  STA $7E0A84
$88:8353  TAX
$88:8354  LDA $888480,x        ; tabla A -> OFFSET VERTICAL de sprites
$88:8358  STA $7E0A86
$88:835C  LDA $888500,x        ; tabla B -> (PHA) se apila
```

* **Tabla A** (`$88:8480`, 37 words): 0,2,5,7,10,12,15,17,20,22,24,27,29,32,34,37,39,42,44,46,
  49,51,54,56,59,61,64,66,68,71,73,76,78,81,83,86,**88** → el offset de sprites, 0→88 px.
* **Tabla B** (`$88:8500`, 37 words): 0,13,28,36,48,56,68,76,86,91,97,106,111,120,125,132,138,
  144,148,152,158,162,167,170,175,178,183,186,189,194,197,201,204,208,210,213,**215** → un
  movimiento de hasta 215 px, coherente con el desplazamiento longitudinal del escenario.

Es decir: al entrar en pista la hack **baja todo 88 px** (sprites y escenario a la vez). La caída
dura unos 40 fotogramas y es monótona de 0 a 88.

### 9.3 Medido en la parrilla (registro por fotograma)

| fotograma | `$7E:0A84` | `$7E:0A86` | Y del sprite de P1 |
|---|---|---|---|
| 1400 | 0 | 0 | 56 (el mismo 56 de vanilla en ese instante) |
| 1410 | 14 | 17 | 85 |
| 1420 | 34 | 42 | 109 |
| 1430 | 54 | 66 | 134 |
| 1440- | 72 | **88** | **158** |
| hasta 2600 | 72 | 88 | 158 (constante) |

Y durante toda la carrera: `$7E:0A84`=72, `$7E:0A86`=88, `$7E:0A88`=1 (sin fluctuación).

### 9.4 El desajuste

El escenario (Mode-7) sólo baja **72 px** en el mismo arranque (fila de la marca de P1: 90 en
vanilla → 162 en la hack = +72), mientras los sprites bajan **88 px** → sobran **16 px**.

* Vanilla: marca blanca a 20 px del borde superior del kart (cruza a la altura de las ruedas).
* Hack v1.4: marca a 4 px (cruza por el pecho).
* Lakitu/semáforo: +15 px de error (su rutina usa otra constante).

### 9.5 Arreglo probado

`tools/offset_sprites.py in.sfc out.sfc 72` escala la tabla A de 0..88 a 0..72. Probado
(`roms/_prueba_offset72.sfc`): en la parrilla el sprite de P1 baja a y=142 en vez de 158 y **la caja
blanca de salida vuelve a caer sobre las ruedas, igual que en vanilla**.
Evidencia: `docs/arreglo_offset_sprites.png` (vanilla | v1.4 | v1.4+offset 72).

Nota: el tope del contador (`CMP #$0048`, es decir 72) coincide con el movimiento del escenario, lo
que sugiere que la intención original era 72 y que el 88 de la tabla es el error.

Pendiente antes de dar por bueno el arreglo: comprobar (a) que en carrera la marca queda igual que
en vanilla para todos los rivales, (b) el Lakitu tiene su propio desajuste de 15 px, (c) revisar la
tabla B (215) contra el movimiento real del fondo.

---

# Sexta parte — ¿el análisis sirve para objetos, enemigos y escenario? (NO para todo)

Comprobado en código y en 25 000 fotogramas de Donut Plains (1 jugador):

1. **La tabla de tamaños es sólo para karts.** `$80:CF22` indexa la tabla con `LDA $92 / ASL / TAY`
   → índice = nº de kart × 2 → la tabla está dimensionada para **8 entradas**. En todo el ROM existe
   **una sola** copia del patrón de umbrales (`E0 00 C0 00 A0 00 ...`) y un solo lector.
2. **Los objetos/enemigos que son sprite no escalan**: medido, se dibujan a 8×8 o 16×16 px con
   independencia de su posición (y de 20 a 43 px), y con el **mismo tamaño en vanilla y en el hack**
   (posición ≤1 px de diferencia en el caso medido). La hack sí les suma el offset vertical
   `$7E:0A86`, pero **con condiciones**: sólo si `$7E:B0AB == $10` (`$88:A100`) y sólo si el valor
   cae entre `$5C` y `$60` (`$88:920F-9263`).
3. **Las tuberías son sprites de tamaño fijo** (corrección de la 1ª medición, que era defectuosa:
   los recuadros verdes que se midieron como "tuberías" eran bordillos, hierba y karts de Yoshi).
   Pruebas de la 2ª revisión:
   * la tubería del estado del autor (22×31 px) reaparece **idéntica píxel a píxel —0 de 912 px de
     diferencia—** entre f0 y f400 tras aplicarle su desplazamiento entero (dx=−2, dy=+4): una
     tarjeta de sprite, no un plano re-muestreado por scanline;
   * mantiene 22×31 constante mientras su base cruza de y=107 a y=218 (acercándose);
   * hace **pop-in** (aparece y desaparece entera), contorno negro incluido.
   Lo que **sí** es Mode-7 es el **suelo, la carretera y el decorado del plano**: el ancho de la
   carretera crece ~1,2 px por línea de barrido (matriz afín por scanline, escala casi continua,
   sin límite de 4 tamaños), controlado por el flag `$7E:0A88` y las ventanas `$88:8Axx/8Bxx`.

Consecuencia para el plan de trabajo:
* El reparto geométrico (media geométrica) se aplica **sólo a los karts**.
* Para los sprites sueltos (objetos, enemigos, tuberías), lo que hay que revisar es la **condición
  de aplicación del offset** (¿por qué sólo unas clases?) y su desfase; escalarlos exigiría arte
  nuevo y es una decisión aparte.
* Para el suelo, la ley `escala ∝ (y − y_h)` **también vale**, pero se puede cumplir con mucha
  más precisión (no hay arte discreto): ahí el trabajo es de reparto de ventanas y de continuidad
  entre ellas.
* Consecuencia perceptiva (la que reporta el autor): **la calzada y los karts se re-escalan con la
  profundidad y las tuberías no** → al acercarse, la tubería mantiene su tamaño mientras la calzada
  se ensancha, así que *parece* que encoge y que "cambia de golpe" al entrar o salir de pantalla.
  Ocurre lo mismo en el original; no lo introduce la modificación.
