# Revisión del informe de Gemini — escalado por perspectiva de los karts

Fecha: 5 de octubre de 2026. Revisado contra medidas propias.

**Veredicto en una línea:** el criterio matemático es correcto y la tabla de tamaños es la misma que
la nuestra, pero **sus números no se pueden escribir en la ROM tal cual** (la constante de anclaje
está mal elegida y, sobre todo, la tabla real de la ROM no está mapeada todavía), y **omite el coste
real del plan** (el motor va justo de presupuesto de arte de sprites por fotograma).

---

## 1. Lo que acierta (validado)

| Afirmación de Gemini | Veredicto |
|---|---|
| Media geométrica `s = √(s_i·s_{i+1})` para colocar el cambio | **Correcto.** Error relativo simétrico ±(√(s_{i+1}/s_i)−1), criterio estándar en cuantización perceptual. |
| Conjunto {64, 46, 32, 23, 16, 9} | **Correcto** y coincide con nuestra propuesta. 64 = ×2 de 32 y 46 = ×2 de 23: doblado por bloques, sin dibujar arte nuevo. |
| El jugador debe ir fijo en el tamaño mayor | **Correcto**, aunque su razón no aplica: el jugador ya está fijo hoy (escala constante toda la carrera). El cambio real es **darle arte ×2**, no "bloquearlo". |
| Histéresis para evitar parpadeo | **Innecesaria:** medido en v1.4, 6-9 cambios de tamaño por rival y **0 rebotes < 30 fotogramas**. El reparto ya es monótono. |
| El escalón de 9 px apenas se usa en el hack | **Consistente con nuestros datos** (7 000 fotogramas de Mario Circuit a 1 jugador). |
| Tuberías: no escalarlas; corregir el desplazamiento vertical | **Coincide con nuestra vía** y con el arreglo ya probado (`roms/_prueba_offset72.sfc`, offset 88→72). |
| "Verificad midiendo la distribución de escalas de los rivales" | Mismo método que usamos nosotros. |

## 2. Lo que no se puede usar tal cual

### 2.1 La tabla real de la ROM (y el experimento que hice hoy)

Lo que hay en la ROM es **una tabla de 11 palabras de 2 bytes en `$DD35`** (banco `$80`, file
0x0DD35), **seguida de una tabla de 11 punteros** en `$DD4B` que apuntan a descriptores de
`sprite` en `$DD6F`–`$DDED`:

| ROM | 11 palabras de `$DD35` |
|---|---|
| vanilla / v1.3 | `E000 C000 A000 8000 7000 6000 5000 4000 3000 2000 0000` |
| v1.4 (tu hack) | `FF00 FF00 FF00 AA00 AA00 5A00 5A00 5A00 0000 0000 0000` |

Todo lo que la hack cambió de v1.3 a v1.4 son **10 bytes** justo aquí (los bytes bajos de las 10
primeras palabras). Los 11 punteros de `$DD4B` están **intactos**: los descriptores de sprite no
cambian; lo que cambió son los **umbrales que deciden a qué descriptor cae cada kart**.

**Experimento de hoy (2700 fotogramas, misma carrera, tres ROM):**

| ROM | resultado a f2600-2700 |
|---|---|
| v1.4 sin tocar | karts con arte 32×32 y otros menores, como siempre |
| tabla de 11 palabras = `0000` | **exactamente igual** |
| tabla de 11 palabras = `FFFF` | **no se dibuja ni un kart** |

Lectura: la tabla está **en la ruta crítica del dibujo de los karts** y no admite valores
arbitrarios. Escribir ahí los números de Gemini (`01D2/0149/00E9/…`) sin conocer la semántica
puede desde no hacer nada hasta **hacer desaparecer los karts**. No es una zona para "probar".

Lo que falta para poder escribirla: localizar la rutina que **lee** la tabla y ver qué hace con el
valor (y contra qué lo compara). Hoy sólo sabemos que el único lector directo en todo el ROM es
`$80:CF22` (`LDA $DD35,y`), y que el desensamblador propio (`tools/dis65816.py`) **misparsea las
instrucciones de 3 bytes**, así que hay que arreglarlo antes de fiarse de esa lectura.

### 2.2 La constante de anclaje: 4 % de diferencia

Gemini usa `K = 64 / 549 = 0,1165` (arte *objetivo* sobre escala del jugador). El dato **medido**
en vanilla es **32 px a escala 264 → 0,1212**. Dos anclas distintas:

| | 64→46 | 46→32 | 32→23 | 23→16 | 16→9 |
|---|---|---|---|---|---|
| Nuestra tabla (ancla vanilla) | **448** | 317 | 224 | 158 | 99 |
| Tabla de Gemini (ancla 64@549) | 466 | 329 | 233 | 165 | 103 |
| Diferencia | +4 % | | | | |

No es grave (≈4-5 px de pantalla), pero hay que **elegir a conciencia**: el ancla vanilla conserva
la proporción con la que el juego original "se ve bien"; la de Gemini fija al jugador en 64 px
exactos y sube todo lo demás un 4 %. Recomendación: ancla vanilla.

Además, hay una **segunda ambigüedad de unidades** sin resolver: los umbrales que maneja el motor
parecen vivir en una escala cuyo valor en el kart del jugador es 549 ($06) **o** 1010 ($18), es
decir, un factor **×1,84** entre ambas. Según cuál sea la buena, nuestra tabla se escribe como
448/317/224/158/99 o como ~824/583/412/291/182. **Es el experimento que falta.**

### 2.3 "×2 es gratis" es gratis en calidad, no en VRAM ni en tiempo por fotograma

Esto es lo que Gemini despacha con un "hay que justificar cada tamaño nuevo". Medido hoy en el hack:

* **Área de arte de sprites: ~10 KB de VRAM** (52-62 KB). El resto de la VRAM (0-52 KB y 62-64 KB)
  no cambia **nada** entre fotogramas: mapa y tiles de Mode-7, HUD, fuente.
* El motor reescribe **~220 bytes por fotograma** en esa área (≈7 tiles de 8×8): va **transfiriendo
  el arte de forma incremental**, no lo tiene todo residente. En una carrera entera, el OAM
  referencia sólo ~107 tiles distintos de art de kart (≈3,4 KB).
* Coste por fotograma y kart: arte 32×32 = **512 B**; arte 64×64 = **2 KB** (×4); 46×46 ≈ 1 KB.
* La VRAM está **llena** (ningún bloque de 2 KB por debajo del 19 % de ocupación).

Consecuencia: pasar el jugador (o los rivales cercanos) a arte ×2 multiplica por 4 el tráfico de
arte de ese kart en la ruta que ya estaba optimizada para **no perder fotogramas** (el trabajo de
lag 18 %→≈0). No es imposible, pero es *el* problema de ingeniería del plan y no aparece en el
informe: antes de dibujar nada hay que medir cuántos fotogramas de animación distintos necesita el
kart del jugador y cuánto ocupa su tier ×2 dentro de esos ~10 KB.

### 2.4 Menores

* Supone que el jugador cambiaría de tamaño "al acelerar o frenar": su escala es **constante** toda
  la carrera. El argumento no aplica; la conclusión sí.
* Su verificación del sesgo de profundidad ("el valor rara vez baja de 90") es sobre la escala;
  nosotros lo hemos confirmado además en pantalla: la franja del escalón de 9 px queda casi siempre
  fuera del área donde el juego dibuja karts (pies y ≥ 62 en el hack).

## 3. Los dos experimentos que cierran esto (ambos de minutos)

1. **Unidades.** Parchear la tabla con una rampa descendente de **un solo escalón conocido**
   (p. ej. `X` cinco veces y `0` seis veces) para X=100 y X=300, y medir en qué **y de pantalla**
   cambia el tamaño del kart. Si la frontera se desplaza ~30 px al subir X en 200 → unidades de
   escala `$18` (×1,84); si se desplaza ~60 px → unidades `$06`. Sólo entonces se traduce nuestra
   tabla a bytes.
2. **Presupuesto de arte.** Contar los fotogramas de animación reales del kart del jugador (por
   contenido de VRAM, no por número de tile) y cuántos KB pide su tier ×2 en el área de 10 KB. Si
   no cabe: ×2 sólo el jugador y rivales en {32,23,16,9} repartidos por media geométrica.

## 4. Resumen para decidir

* Método: **válido**; tamaños: **los mismos que proponíamos**.
* Tabla numérica: **no escribir la suya**; usar la nuestra (448/317/224/158/99) y sólo después el
  experimento 1 para traducirla a bytes.
* Plan de arte: su "×2 gratis" **no está justificado**; el cuello de botella es el flujo de arte por
  fotograma.
* Tuberías: coincide con nuestra vía (offset vertical ya probado).

---

# Anexo — Respuestas al contraanálisis (medidas del 5-oct, misma sesión)

## A1. Experimento 1 (unidades): **no se puede ejecutar como está planteado**

Su diseño (Prueba A = 224 en las 11 palabras; Prueba B = 412) parte de que la tabla compara contra
la escala del kart (`$06` ≈ 264-549 o `$18` ≈ 1000). **Es falso.** Lo medido:

1. **La tabla se lee en vivo.** Parcheando sólo esas 11 palabras (22 bytes) el OAM de la carrera
   cambia fotograma a fotograma: 5,6 % de bytes distintos frente al control (v1.3 → 3,7 %). Y en
   todo el ROM **sólo hay una copia** de la tabla (buscada por patrón completo).
2. **Barrido de tabla uniforme** (las 11 palabras = V, misma partida, 3000 fotogramas):

| V | resultado en f2400 y f2800 |
|---|---|
| 1, 4, 16 | todos los karts con tarjeta grande (celdas 16×16) |
| 64, 100, 160 | todos los karts con tarjeta pequeña (celdas 8×8) |

   El escalón está **entre 16 y 64**. O sea: la magnitud que compara la tabla es un número
   **pequeño (decenas)**, no la escala del kart (cientos). Por eso 224 y 412 dan lo mismo: **las dos
   pruebas de Gemini caen del mismo lado** y no discriminan nada. (Probado: con V=224 y con V=412,
   todos los karts a tarjeta pequeña.)
3. **La tabla no admite valores arbitrarios:** con una tabla uniforme el contenido del OAM deja de
   ser una carrera normal (aparecen celdas 8×8 a y≈28-30, que no es dónde se dibujan los karts);
   con todo a `FFFF` no se dibuja ningún kart. No es una zona para experimentar a ciegas.
4. Dato que hay que resolver antes de escribir nada: la rutina lectora escribe el valor de la tabla
   en `$06` y `$18` (`STA $06` / `STA $18`), pero los valores de la tabla son 0-224 mientras que en
   `$7E:0018` medimos 549-1010. **O la escritura va a otro banco/dirección, o el campo se
   sobrescribe después, o la variable que llevamos usando como "escala" no es la que consume esta
   tabla.** Es el cabo suelto que hay que atar antes de traducir 448/317/224/158/99 a bytes.

## A2. Presupuesto de arte ×2 (64×64): **no cabe como bloque residente**

Medido hoy:

* El kart del jugador usa **≥11 fotogramas de arte distintos** de 32×32 (contados por conjuntos de
  tiles en el OAM durante una carrera; posiblemente más, porque el motor reasigna tiles al hacer
  *streaming*). A 512 B por fotograma → **5,5 KB** de arte de 32×32.
* El mismo recuento en ×2 (64×64, 64 celdas de 8×8 = 2 KB por fotograma) → **22 KB**.
* Área total de arte de sprites en VRAM: **~10 KB** (bloques 52-62 KB). El resto de la VRAM no
  cambia entre fotogramas y **no hay ningún bloque de 2 KB con menos del 19 % de ocupación**.
* Tráfico actual: **~220 B por fotograma** en esa área. Un cambio de fotograma de animación del
  jugador en ×2 pide **2 KB** (×4 respecto a hoy), dentro de la ruta que ya está optimizada para el
  lag (18 % → ≈0).

Veredicto: la propuesta de Gemini de "×2 con los frames residentes en un bloque fijo" **no cabe**:
sólo el jugador pediría 22 KB en un área de 10. Y el ×2 "gratis" en calidad cuesta ×4 en VRAM y en
tráfico. Opciones realistas, por orden de coste:

1. **No escalar el jugador** (dejarlo en 32) y aplicar el reparto geométrico sólo a los rivales con
   las tarjetas existentes {32, 23, 16, 9}. Coste de arte: **cero**.
2. Dar ×2 **sólo** al jugador y **medir** el tiempo de fotograma con el nuevo tráfico antes de
   decidir; exige streaming de 2 KB por cambio de animación (el V-blank da margen, pero el
   presupuesto de VRAM no).
3. Arte nuevo dibujado a mano de 48 px: fuera de la restricción acordada (sólo múltiplos enteros).

## A3. ¿Por qué los rivales quedaban fuera de sus marcas en `_prueba_offset72.sfc`?

**La rampa `$7E:0A86` no puede ser la causa.** v1.3 y v1.4 sólo se diferencian en esos 10 bytes: la
rampa (+88) es idéntica en las dos. Si en v1.3 los rivales están bien sentados sobre sus marcas y en
v1.4 no, entonces lo que los mueve es **la tabla de umbrales**, no el desplazamiento vertical.

Medido (misma partida, mismos fotogramas, v1.3 vs v1.4):

* El tamaño de celda de todos los karts visibles es el mismo (16×16) en las dos versiones.
* Pero los rivales r3-r7 usan **tiles distintos** de forma persistente (22 de 70 comparaciones
  kart-fotograma difieren, todas en r3-r7). Es decir: los 10 bytes cambian **qué arte** usa cada
  rival. (Caveat: el motor reasigna tiles al hacer streaming; hay que confirmar con VRAM que es arte
  distinto y no reasignación, pero la persistencia apunta a lo primero.)

Consecuencia práctica: **no aplicar el offset 72 a la ROM oficial**. El arreglo correcto hay que
buscarlo en la asignación de arte de los rivales (descriptor/anclaje de cada tarjeta), no en el
desplazamiento global de sprites.

Pendiente de medir para cerrarlo: en la parrilla de salida (fotograma fijo), distancia desde el
borde inferior del sprite de cada kart hasta la marca blanca que tiene debajo, en vanilla / v1.3 /
v1.4. Si esa distancia depende del arte asignado, el fallo está en la tarjeta; si es constante y
sólo aparece en v1.4, está en la selección.

## A4. Y el desplazamiento horizontal ("los de la izquierda, demasiado a la izquierda")

Es un eje distinto (X, no Y) y hay que medirlo aparte: comparar el centro X del sprite de cada kart
con el centro X de su marca, para karts de la izquierda, el centro y la derecha, en vanilla / v1.3.
Si el error crece con la distancia al centro de la pantalla → es un desajuste de proyección
(el suelo y los sprites no comparten la misma escala lateral, y el arreglo va en la X de los
sprites). Si es constante → es un desplazamiento fijo.
