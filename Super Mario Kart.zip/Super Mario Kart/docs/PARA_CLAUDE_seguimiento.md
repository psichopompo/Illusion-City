# PARA CLAUDE — Datos nuevos que cambian el encargo (léelo antes de responder)

Cinco datos medidos desde tu último informe. **Invalidan tres de tus supuestos**, así que la tabla
que diste (161/122/94/74 con {64,46,32,23,16}) ya no es aplicable tal cual: asume cinco tarjetas de
arte distintas y eso no es como funciona el juego.

---

## 0. RECTIFICACIÓN IMPORTANTE (leer antes que nada)

La sección 1 de este documento, tal como la escribí primero, **es errónea** y queda retirada: dije
que el juego encoge los karts re-solapando las mismas tarjetas y que por tanto los tamaños
intermedios salían gratis. **Es falso.** Lo he medido forzando la escala del jugador
(constante en `$80:CEBE`/`$80:CEDE`, `LDA #$0108; STA $18`) a siete valores:

| Escala forzada | Lo que dibuja el juego |
|---|---|
| 132 | **16×16**, con tiles {128} |
| 176 / 200 / 232 | **23×24**, con tiles {128,144} |
| 264 / 300 / 340 | **32×32**, con tiles {128,160} |

Los tamaños están **cuantizados** y **cada uno tiene su propio juego de tiles**: no hay manera de
obtener un tamaño intermedio sin arte nuevo. La observación de "86 % de cambios de tamaño con los
mismos tiles" era un artefacto de mi agrupación de sprites por proximidad, no un hecho.

**Consecuencia:** la escalera de tamaños es discreta (16 / 23 / 32, y presumiblemente 9), y subir
por encima de 32 exige arte ×2. Lo que sí es gratis es **repartir las fronteras** de los tamaños
que ya existen.

---

## 1. (Retirado) Los tamaños del juego son SINTÉTICOS

El kart se dibuja con **4 tarjetas de 16×16**. Al cambiar de tamaño, el motor **no cambia el arte:
mueve las mismas tarjetas** (las re-solapa). Evidencia:

* En 4 400 fotogramas de carrera, **3 079 de 3 561 cambios de tamaño (86 %) conservan exactamente los
  mismos tiles**.
* El jugador en su tamaño grande usa las tarjetas a 16 px; en el tamaño siguiente, los **mismos
  tiles** a 7-8 px.
* En la ROM existen **tablas de offsets (dx,dy)** para esas tarjetas (`$DCF0-$DD35`), y un selector
  que elige una tabla por nivel (`$DD4B` → descriptores en `$DD6F`, con el código en
  `$80:D858-$D8D2`). Las tablas traen valores como 0, −16 (la colocación de 32×32) y −12, −5, −24,
  −19 (colocaciones menores).

**Consecuencia dura:** re-solapar sólo puede **encoger**. Se pueden fabricar todos los tamaños
intermedios que se quieran **entre 23 y 32 px gratis** (sin dibujar nada), pero **no existe forma de
pasar de 32 px sin arte nuevo ×2**. En una carrera de 1 jugador las apariencias que se ven son
**32×32 y ~23×24**; las tarjetas de 16 y 9 de la tabla no se han visto.

## 2. Tus tres [hipótesis] del campo cercano: dos son falsas, una es peor de lo que creías

| Tu hipótesis | Medición |
|---|---|
| «Sólo habrá 1-2 karts en y ≥ 161» | **Falso.** En carrera: 1 kart el 35 % del tiempo, 2 el 2 %, **3 el 40 %, 4 el 14 %**. Es decir, 3-4 karts el **54 %** del tiempo. |
| «El OAM quizá roce el límite de 34 celdas/línea» | **Hay margen en carrera:** el máximo medido en la ventana de carrera es **22 celdas por scanline** (los 28-30 de una medición anterior venían de fotogramas con los rótulos gigantes "ROUND"/"LAP"). Simulando el jugador a 64×64 sube a **28**, por debajo de 34. Rectificado: el OAM **no** es el bloqueador. |
| «VRAM justa será el riesgo» | Sí, es el riesgo real junto con el lag: el área de arte de sprites son ~10 KB con ~220 B/fotograma de tráfico; el jugador en ×2 pediría ~2 KB en cada cambio de animación. |

## 3. Lo que esto cambia en el plan

| Zona de pantalla | Tamaño ideal | ¿Hace falta arte? | Vía |
|---|---|---|---|
| Filas ~78-122 | 20-38 px | **No** | Escalones sintéticos entre 23 y 32 (reutilizando el arte actual) |
| Filas ~122-202 | 38-71 px | **Sí** | ×2 — y va contra el límite de celdas/línea (§2) |

Es decir: **la mitad del problema se puede resolver gratis** (los escalones del campo medio, que es
justo donde está la queja de "no cambia hasta que se ha alejado bastante"), y la otra mitad es la
cara y la que tiene un bloqueador de hardware medido.

---

## 4. Preguntas nuevas (sustituyen a las del encargo anterior)

1. **Escalera sintética.** Sabiendo que sólo se puede **encoger** (tamaños fabricables de 23 a 32 px
   moviendo tarjetas, sin arte), dame la escalera óptima de separaciones entre tarjetas (en px) y sus
   fronteras en filas de pantalla. Objetivo: minimizar el error respecto al ideal (0.405·(y−27)) y,
   sobre todo, que el primer cambio de tamaño ocurra mucho antes de las 87 filas actuales.
2. **Presupuesto de celdas por línea.** Con 28-30 de 34 celdas ya ocupadas y 3-4 karts en el campo
   cercano, ¿qué política reparte mejor el presupuesto? Propón una regla concreta (p. ej. sólo el
   jugador a ×2; o ×2 al kart más cercano y 32 al resto; o ×2 por turnos), y di qué se gana y qué se
   pierde en cada caso.
3. **Si sólo se puede hacer UNA cosa:** ¿escalones sintéticos en el campo medio (gratis) o ×2 del
   jugador (necesita arte y roza el límite de celdas)? Justifica con la métrica, no con la intuición.
4. **Métrica:** mantén las tuyas, y añade **coherencia entre karts adyacentes** (razón de tamaños
   entre karts con |Δy| pequeño debe acercarse a 1) — porque con escalones sintéticos el riesgo nuevo
   es que dos karts a la misma profundidad usen escalones distintos.
5. **No hace falta** que traduzcas nada a bytes de ROM: sigue sin resolverse la unidad de la tabla
   `$DD35`, y además ahora sabemos que el tamaño se decide en la tabla de offsets, no sólo en los
   umbrales. Responde en **tamaños (px) y filas de pantalla**.

## 5. Lo que NO quiero que propongas

* Esa tabla de cinco tarjetas de arte (no existen).
* La opción (d) de anclar los rivales al jugador: todos los karts quedarían a la mitad de la
  proporción con la calzada, y hoy la coherencia entre karts ya es perfecta (0 inversiones de
  perspectiva en 7 800 fotogramas medidos).
* Cambiar la cámara o el horizonte.
