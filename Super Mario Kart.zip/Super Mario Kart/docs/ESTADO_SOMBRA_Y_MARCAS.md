# Estado: sombra de Lakitu y "marcas" de los karts (2026-10-06)

## 1. Sombra — qué está comprobado

* **Composición**: el juego mantiene un búfer de sombras en `$7F:DF00` con 3 grupos
  (grande 4 sprites Y=$5F; copia con Y=$CF; pequeña 2 sprites Y=$5C).
* **Desplazamiento**: el hack sustituyó `MVN $7F,$80` en `$80:EC73` por `JSL $88:8D5E`
  → `JSR $8F00`; y hay un ayudante (`$88:9200` / `$91:9200`) que recorre 4 sprites y
  **suma `s` (=$7E:0A86, 88 en carrera) solo si la Y está en `[$5C,$60)`**.
  Prueba de que funciona: la sombra grande pasa de 95 a **183** (bajo Mario, ruedas 174-190) ✔
* **El fallo**: en la salida de carrera la sombra visible son **3 sprites con tile `$EB/$EC`
  y Y=`$5A` (90)** — p. ej. slots 124-126 en x=38/44/50 — **fuera de la ventana `[$5C,$60)`**,
  así que **no reciben el desplazamiento** y se quedan a la altura del 5.º de parrilla
  (justo lo que describes: Toad, a la izquierda).
* **Origen de esos sprites**: se escriben una sola vez en la transición a la parrilla
  (≈f1625 en mis corridas) y persisten. El log de escrituras a la OAM ($7E:0200-$047F,
  188 k líneas, todas las PCs) **no captura esa escritura**: llega por MVN/DMA.
* **Intentos de arreglo (descartados, no reintentar tal cual)**:
  1. Enganchar el barrido al NMI en `$80:FFA0` → rompía el NMI (no salvaba X/Y). Con
     `PHX/PHY` ya no rompía, pero la sombra seguía sin moverse (el juego la reescribe después).
  2. Enganchar la cola en `$80:FFA4` → **rompió el pipeline de sprites** (OAM casi vacía):
     esa cola no admite un `JSL` extra (flujo de pila distinto).
* **Vía correcta (siguiente paso)**: localizar el escritor real (MVN/DMA) del sprite con
  Y=`$5A` y **cambiar ese `$5A` por `$5C`**: entraría en la ventana del ayudante existente
  y la sombra caería sola a la altura de Mario, sin código nuevo. Alternativa: ampliar la
  ventana a `[$58,$60)` **en el ayudante que realmente se ejecuta**.

## 2. Marcas — qué está comprobado

* Comparando el mismo kart y fotograma: **B se desvía +1/+2 px** (los karts se dibujan algo
  por delante de la marca); la línea blanca de la calzada cruza a la altura de las ruedas
  como en v1.3.
* Causa: **el anclaje vertical lo pone cada banda de arte** (registros
  `$DC23,$DC2D,$DC37,$DC41,$DC4B,$DC55,$DC5F,$DC69,$DC73,$DC7D,$DC87`), uno por escalón.
* **Descartada** la propuesta A (v1.9): movía a Mario 2 px y le recortaba el arte
  (de ahí los 22 px que mediste). A borrada; **B (v1.8) es el candidato**.
* Para el arreglo falta un paso: localizar los offsets verticales de cada registro
  (el dibujante los lee como pares `(dx,dy)` de 16 bits desde su registro de arte,
  `$80:BC06-$BC2B` y compañía) y re-anclar cada banda para que el kart caiga en la misma
  fila antes y después de cada cambio.

## 3. Corrección importante de instrumentación (afecta a todo lo anterior)

**La ROM es HiROM**: los bancos `$80-$BF` corresponden 1:1 a los ficheros
`0x000000-0x3FFFFF`. Ejemplo: `$80:BC00` = file `0xBC00`, y `$88:8D5E` = file `0x88D5E`.
Durante parte de la sesión asumí LoROM (mitad alta → file = 0x40000+offset), lo que me
llevó a leer bancos equivocados (de ahí rutinas que "no se ejecutaban"). Ya corregido.
---

## 4. Actualización (misma sesión): el escritor de la sombra está LOCALIZADO

* **Quién escribe la sombra de la salida**: **`$85:E1D0`: `09 00 5A` (`ORA #$005A`)** →
  Y = 90 (=$5A). Escribe 3 sprites (slots 124-126, x=38/44/50, tiles $EB/$EC) con
  `STA $01F0,Y / $01F4,Y / $01F8,Y` (DP base $0200 = página de OAM). Verificado con el
  logger de escrituras a la OAM ampliado a `$03E0-$047F` **sin filtro de banco**
  (con el filtro antiguo no se veía: el banco es `$85`, el de Lakitu).
* **Cambio probado (1 byte)**: file **0x5E1D2**: `5A` → `5C` ⇒ la sombra pasa a Y=92,
  **ya dentro de la ventana `[$5C,$60)`** del ayudante del hack. Pero sigue sin caer:
  ese ayudante sólo procesa el búfer `$7F:DF00` (la sombra de Mario), no la OAM general.
* **Barrido propio (en pruebas)**: enganchado antes de la subida de OAM
  (`$80:948F`, `9C 00 43 A9 04` → `JSL $8B:8640` + NOP) recorre los 128 slots y suma `s`
  (`$7E:0A86`=88) a la Y de los sprites con tile `$EB/$EC` y Y en `[$5C,$60)`.
  **Resultado: pantalla negra** en la parrilla ⇒ el enganche rompe la subida de OAM
  (probablemente la ruta/flags con que se entra a `$948F`, o el punto no es el de la
  subida principal). Reproducible con `tools/parche_sombra.py --sweep` (no usar aún).
* **Siguiente paso concreto**: (a) comprobar a cuál de las dos rutas de subida pertenece
  `$80:948F` y con qué M/X se entra (dump de flags) antes de enganchar; o (b) más simple:
  que la propia rutina `$85:E1D0` sume `s` al formar la Y (tiene sitio: el `ORA` va seguido
  de `LDY $CE`), evitando tocar la subida de OAM.
* En **carrera** la sombra (2 sprites, x=62/68, Y=90) la escribe **otra** ruta: el cambio
  de `$5A` no la afecta (sigue en 90) ⇒ hay que localizar su escritor igual que hicimos
  con el de parrilla (logger OAM sin filtro, en el state de carrera).

---

## 5. Cierre del tramo: ruta del arreglo y método de verificación

**Vía 2 implementada** (`tools/parche_sombra.py --modo=88|s|byte`): hijack de 5 bytes en
`$85:E1D0` (`ORA #$005A ; LDY $CE` → `JSL $8B:8640 ; NOP`) y rutina en `$8B:8640` que
**suma a la Y de la sombra** el desplazamiento (fijo 88, o el de cámara `$7E:0A86`).

**Por qué aún no está verificado**: el arranque por menú **no es determinista** entre
corridas (la fase del semáforo cambia y en varias corridas la sombra no llega a dibujarse
en los fotogramas muestreados). Además, durante la parrilla `s=0`, así que el modo `s` no
cambia nada ahí por diseño.

**Método correcto para el próximo intento (determinista)**:
1. Correr el arranque con `STATEF=<f>` hasta un fotograma **donde la sombra exista**
   (se ve en el oamlog: 3 sprites x=38/44/50, Y=90) y guardar ese estado.
2. A partir de ahí, comparar vanilla / candidato / parche con el mismo estado — sin
   depender del arranque.

**Dato clave para decidir**: la vanilla USA también dibuja esa sombra en Y=90 en la
parrilla ⇒ subirla/bajarla es un cambio **deliberado** (el usuario quiere que caiga a la
altura de Mario, ≈178), no una restauración.

---

## 6. SOMBRA: prototipo funcionando (verificado en OAM) — 2026-10-06

**El cambio (3 bytes, sin saltos ni código nuevo):**
```
file 0x5E1D0  ($85:E1D0):  09 00 5A   (ORA #$005A)      ->   A9 00 B2   (LDA #$00B2)
```
`$85:E1D0` es la rutina que **forma la sombra de la parrilla**: `ORA #$005A` → `LDY $CE`
→ `STA $01F0,Y` / `+6` / `+6` (las tres Y) y luego los tiles desde `$0001,X`.

**Por qué antes no funcionaba el hijack**: esa rutina **se ejecuta una sola vez**, en el
momento en que se forma la cuadrícula (no cada fotograma) — por eso parchearla no cambiaba
nada al cargar un estado posterior. Se comprobó con un marcador (`STA $7E:1F00`): no se
ejecutaba ni una vez en 160 fotogramas desde el estado f2250.

**Verificación determinista (nuevo método, ya operativo):**
1. `STATEF` del harness ahora acepta **lista** (`STATEF=2000,2050,...`) → varios estados por corrida.
2. Los estados libretro crudos (`BST1...`) se envuelven con una cabecera de 16 bytes
   (longitud en bytes 12-15) y el harness los carga.
3. Estados guardados: `states/pre_parrilla.st` (f2150, **antes** de la sombra) y
   `states/parrilla_con_sombra.st` (f2250, con la sombra ya formada).

**Resultado medido (desde `states/pre_parrilla.st`, 150 fotogramas):**

| versión | sombra al aparecer (f17) | a f57 |
|---|---|---|
| B (candidato) | x=41/47, **y=90** | x=38/44/50, y=90 |
| `_prueba_sombra178` | x=0/6, **y=178** | x=0/6/12, y=178 |

⇒ **cae a la altura de Mario (178)** ✔ — pero **la X se desplaza** (0/6/12 en vez de 38/44/50),
efecto lateral que hay que resolver: la posición horizontal de esos sprites se fija en otro
sitio (probablemente el llamador, o una tabla indexada por el mismo registro), y al cambiar
el valor de A cambia el índice/posición. **Siguiente paso**: localizar quién escribe
`$01F1,Y` (la X) en ese mismo grupo de 3 sprites.

**Nota de alcance**: la vanilla USA también dibuja esta sombra en y=90 en la parrilla, así que
moverla es un cambio **deliberado** (a petición del usuario), no una restauración.

**Prototipo listo para probar en emulador real**: `roms/_prueba_sombra178.sfc`
(es el candidato B + los 3 bytes; conviene verlo en pantalla: si la sombra aparece bajo el
kart correcto, sólo falta confirmar la X).

---

## 7. SOMBRA: RESUELTA (prototipo verificado)

**El cambio definitivo es 1 byte** (no 3, no rutinas nuevas):
```
file 0x5E1D2  ($85:E1D2):  5A  ->  B2
```
La instrucción es `ORA #$5A00`: **el registro del sprite es de 16 bits y va en el formato
`$01F0,Y` = [byte bajo = X][byte alto = Y]**. Por eso:
* `5A` → Y=90 (altura del 5.º de parrilla: el defecto que reportaste).
* `B2` → Y=178 (**la altura de Mario**), **con la X intacta** (38/44/50).
* Mi primer intento (`A9 00 B2`) puso X=0 porque metía el valor en el byte bajo: descartado.

**Prueba (estado determinista `states/pre_parrilla.st`, 150 fotogramas):**

| versión | sombra (slot, x, y) en f57 |
|---|---|
| candidato v1.8 | (124, 38, **90**), (125, 44, 90), (126, 50, 90) |
| parche 1 byte | (124, 38, **178**), (125, 44, **178**), (126, 50, **178**) |

**Prueba de píxeles (mismo estado, f60):** en la zona y=85-105 / x=30-70 había
**116 píxeles oscuros** (la mancha negra flotando en la calzada, visible en la captura);
con el parche: **0**. La mancha ya no está en mitad de la pista.

**Prototipo para probar en emulador real**: `roms/_prueba_sombra178.sfc`
(candidato v1.8 + 1 byte). Capturas de la comparación: `docs/sombra_fix_comparativa.png`.

**Pendiente / honestidad:**
* En las capturas del harness no he podido **confirmar a simple vista** que la sombra
  aparezca justo bajo las ruedas del kart en la parrilla: los sprites llevan atributo
  `$3A/$6A` (prioridad 3) y en algunas zonas pueden quedar tapados por la carretera.
  Hay que verlo en pantalla real.
* El cambio afecta **sólo a la ruta de la parrilla** (`$85:E1D0`). En **carrera** los
  sprites de sombra (x=62/68) siguen en y=90: los escribe **otra** ruta y siguen pendientes.
* Si la altura correcta no fuese 178 para tu gusto, se cambia el mismo byte
  (p. ej. `A0` = 160, `B2` = 178) — es un parámetro, no hace falta reconstruir nada.

---

## 8. Ronda cerrada: candidato con sombra + estado de las MARCAS (2026-10-06)

### Candidato de la ronda
**`roms/candidato_v1.10_reparto_suave_sombra.sfc`** = reparto suave (B) **+** la sombra de
parrilla a la altura de Mario (1 byte en `$85:E1D2`: `5A`→`B2`). Es el ROM a probar.

### Sombra en carrera: comprobada, NO es un defecto visible
Los sprites de sombra de la carrera (x=62/68) no producen mancha: en la captura sólo hay
**4 píxeles oscuros** en su zona (frente a 116 en la parrilla antes del arreglo). Se cierra
ese frente sin cambios.

### Marcas: hipótesis probada y REFUTADA (con dato)
Se probó si el desfase provenía del *valor* de la tabla `$DD35` (que sirve a la vez de umbral
y de ajuste fino). Para ello se añadió una **tabla espejo** con los valores originales de v1.3
en `$80:B8C0` y se redirigió la única lectura de esa tabla (`file 0xCF22: b9 35 dd` →
`b9 c0 b8`), manteniendo los umbrales nuevos.

**Resultado: idéntico** (marcas y curva, mismo número exacto de casos). ⇒ El desfase **no**
viene de los valores de la tabla ni de esa lectura.

**Conclusión medida**: el desfase (±0..4 px según el caso, media ≈0) viene del **cambio de
registro de arte**: el arte pequeño (24 px) tiene su borde inferior ~4 px más alto que el de
32 px, así que **al cambiar de escalón el kart salta ~4 px**. En v1.3 ese salto ocurre lejos
(fila 80, apenas visible); en el reparto suave ocurre delante de Mario (filas 80-100) y por
eso se nota.

**Dónde se arregla**: en el anclaje vertical del registro de arte pequeño. Se han localizado
**cuatro rampas candidatas** en ROM (valores de 16 bits decrecientes, misma forma que la
tabla que lee el dibujante):

| file | CPU | contenido inicial |
|---|---|---|
| 0x93F40 | $80:93F40 | 87 ff 8a ff 8d ff 90 ff 93 ff 96 ff 98 ff ... |
| 0x944A0 | $80:944A0 | 93 ff 95 ff 97 ff 99 ff 9b ff 9d ff 9e ff ... |
| 0x94630 | $80:94630 | 98 ff 9a ff 9c ff 9e ff 9f ff a1 ff a2 ff ... |
| 0xA34C0 | $80:A34C0 | 7e ff 82 ff 85 ff 88 ff 8b ff 8e ff 91 ff ... |

**Siguiente paso (marcas)**: identificar cuál de esas rampas alimenta el anclaje del arte
pequeño (comparándolas con la tabla que lee el dibujante en `$80:BC06-$BC2B`) y desplazar sus
entradas ~4 px para que el cambio de escalón no salte. Es un ajuste de datos, no de código.
