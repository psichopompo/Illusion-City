# PROMPT PARA OTRAS IAs — Escalado por perspectiva de los karts en Super Mario Kart (SNES)

> **Versión 3 — 5 de octubre de 2026.** Si tu copia dice en el ANEXO (sección C) que *las tuberías
> son Mode-7 con escalado continuo*, es la **versión antigua y contiene un error de medición**:
> descártala y usa esta. En esta versión las tuberías están correctamente medidas como **sprites de
> tamaño fijo**, con las tres pruebas incluidas en el propio anexo.

## 0. Qué te pido

Necesito **una solución técnica concreta** (fórmula + tabla de umbrales) para repartir los
**tamaños discretos de sprite** de los karts de *Super Mario Kart* (SNES) de forma que el escalado
se vea **coherente con la perspectiva** del escenario, sabiendo que **el número de tamaños
disponibles es muy limitado**. Al final del documento tienes la lista exacta de preguntas.

Todo lo que sigue son **medidas hechas sobre el juego** (no estimaciones) con emulador y volcado de
memoria. Se indica cómo se obtuvo cada número para que puedas verificarlo.

> **Antes de responder, lee el ANEXO del final**: el juego usa tres vías de dibujo distintas
> (karts con arte escalado por tarjetas, sprites de tamaño fijo —incluidas las tuberías— y suelo/decorado en Mode-7 con escala continua).
> Este documento trata **sólo de los karts**; el anexo explica qué NO aplica a lo demás y qué
> preguntas hacer para cada caso.

---

## 1. Contexto técnico

* Juego: *Super Mario Kart* (USA), SNES. Modo 7 para el suelo + sprites (OBJ) para karts, objetos
  y Lakitu. **Resolución 256×224** (NTSC).
* La SNES **no escala sprites por hardware**: cada tamaño tiene que existir como **arte
  pre-escalado** en la ROM. El juego ya trae un sistema de niveles: una tabla de **11 umbrales**
  compara la *escala interna* del kart y elige uno de **11 disfraces**, que a su vez dan **4
  tamaños de arte distintos**: **32×32, 23×24, 16×16 y 9×9 px**.
* **El jugador no usa esa tabla**: su escala está fijada por una constante y siempre dibuja el arte
  de 32×32.
* La escala interna por kart (`$06` en la WRAM, 16 bits) **es proporcional a 1/profundidad**, es
  decir, es la escala de perspectiva que el juego ya calcula. Es el valor contra el que se comparan
  los umbrales.

---

## 2. Geometría de cámara MEDIDA (lo que pedías: posiciones, horizonte, límites)

Se midió con dos configuraciones distintas: **el juego original (vanilla)** y **la modificación
(nuestro hack, cámara más baja/inclinada)**. En ambos casos: carrera de 1 jugador, cámara fija
siguiendo al jugador.

| Magnitud | Vanilla | Nuestro hack |
|---|---|---|
| Posición del kart del jugador (arte 32×32) | arriba y=70, pies y≈101 | arriba y=158, pies y=**190** |
| Escala interna del jugador (`$06`) | **264** | **549** |
| **Línea del horizonte** (ver §3) | **y ≈ 23** (10 % de 224) | **y ≈ 27** (12 %) |
| Ley de perspectiva medida | escala ≈ 3.29·(y_pies − 23) | escala ≈ 3.34·(y_pies − 27) |
| Rango de y de los pies de karts dibujados | 46 … 230 | 62 … 202 |
| Borde **superior** más alto al que se dibuja un kart | **y = 30** (nunca por encima) | **y = 46** |
| Carretera (asfalto) en pantalla | filas ~32–208 | filas ~39–218 |

Cómo se midió la ley: se registraron, fotograma a fotograma (3000 fotogramas), la escala `$06` de
los 8 karts (WRAM `$1000+$100·k`) y el bbox de sus sprites en el OAM, emparejando por orden de
profundidad. Ajuste lineal sobre 3592 muestras con los 8 karts en pantalla: **error medio 3.4** (vanilla)
y **3.1** (hack). El horizonte es el cero de esa recta.

**Consecuencia clave:** el tamaño aparente **es lineal con la posición en pantalla**, no con la
distancia:

```
tamaño_ideal_px(y) ∝ (y − y_horizonte)
```

Mientras que la **distancia** a un objeto del suelo va como `1/escala`:

```
profundidad_relativa = escala_jugador / escala_objeto = (y_jugador − y_h) / (y_objeto − y_h)
```

Por eso repartir los umbrales "a partes iguales" (en distancia o en la tabla) **no** da franjas
iguales en pantalla: la relación profundidad↔pantalla es hiperbólica.

---

## 3. Cómo se ve el reparto actual (los dos casos)

Los umbrales se comparan contra la escala `$06`; los niveles se agrupan así:

| Tamaño de arte | Umbrales **vanilla** | Umbrales **hack actual (v1.4)** |
|---|---|---|
| 32×32 | escala ≥ 160 | escala ≥ 255 |
| 23×24 | 112 – 159 | 170 – 254 |
| 16×16 | 64 – 111 | 90 – 169 |
| 9×9 | < 64 | < 90 |

Traducido a **pantalla** con la ley de §2 (pies del kart, hack):

| Frontera | Umbral (escala) | y_pies equivalente | Franja de pantalla |
|---|---|---|---|
| 32 → 23 | 255 | y = 103 | 32 px: y > 103 |
| 23 → 16 | 170 | y = 78 | 23 px: y 78–103 (25 px) |
| 16 → 9 | 90 | y = 54 | 16 px: y 54–78 (24 px) |

Observaciones:
1. Las franjas son **casi iguales en pantalla** (25 y 24 px) — es decir, ese reparto ya respeta la
   linealidad… pero **los tamaños no**: el salto 16→9 es un factor **1.78** (78 % de cambio),
   mientras que 32→23 y 23→16 son **1.39** y **1.44**.
2. El problema de fondo es que **el máximo disponible (32 px) es demasiado pequeño** para la
   posición del jugador: aplicando la proporción con la que vanilla se ve bien
   (32 px a escala 264 ⇒ 0.121 px por unidad de escala), en el hack, a escala 549, el kart del
   jugador debería medir **≈ 66 px**. Ahora mide 32 px: **está a la mitad de su tamaño correcto**.
   Esto es exactamente lo que motivó la crítica de que "la perspectiva parece invertida: el más
   cercano se ve más pequeño".
3. Por eso **usar sólo los 4 tamaños existentes no puede cubrir bien el rango**: en el hack, del
   kart más cercano (y=190) al más lejano dibujado (y=62) el tamaño aparente debe variar
   (190−27)/(62−27) = **4.6×**, y el arte disponible sólo cubre 32/9 = **3.6×**.

---

## 4. Restricciones reales (importantes para la solución)

1. **No hay escalado por hardware.** Todo tamaño intermedio debe existir como arte.
2. **Ampliar arte es "gratis" sólo en múltiplos enteros**: duplicar un sprite por bloques de
   píxeles (×2) es exacto y **no deforma** (método ya validado en este proyecto). Un ×1.5 **sí**
   deforma (filas impares) y está descartado.
   Con eso, de los tamaños actuales salen gratis: **×2 de 32 = 64**, **×2 de 23 = 46**, ×2 de 16 = 32,
   ×2 de 9 = 18.
3. **Presupuesto de VRAM**: el arte de kart se reparte en el banco de objetos. Cada tamaño nuevo
   consume espacio; hay que justificar cada tamaño añadido. (La SNES tiene 64 KB de VRAM para BG+OBJ.)
4. **Sin arte nuevo dibujado a mano** no se puede bajar del conjunto {9, 16, 23, 32, 46, 64}.
5. El jugador puede usar un arte distinto al del resto (de hecho ya lo hace).

---

## 5. Nuestra hipótesis (a validar o refutar)

**Regla de reparto óptimo con tamaños discretos:** si el tamaño ideal es continuo y sólo tenemos
tamaños disponibles `{s_1 < s_2 < ... < s_n}`, el cambio entre dos tamaños consecutivos debería
ocurrir **cuando el tamaño ideal sea la media geométrica de ambos**: `s = √(s_i · s_{i+1})`.
Así el error relativo antes y después del salto es simétrico y mínimo (±√(s_{i+1}/s_i)).

Aplicado al hack (con `tamaño_ideal_px = 0.121 · escala`, que es la proporción con la que vanilla
se ve correcto) y al conjunto **{64, 46, 32, 23, 16, 9}** (64 y 46 = ×2 del arte existente):

| Frontera | Media geométrica | Escala equivalente | y_pies equivalente | Profundidad relativa (jugador = 1.00) |
|---|---|---|---|---|
| 64 → 46 | 54.3 | 448 | **y = 161** | 1.00 – 1.23 |
| 46 → 32 | 38.4 | 317 | **y = 122** | 1.23 – 1.73 |
| 32 → 23 | 27.1 | 224 | **y = 94** | 1.73 – 2.45 |
| 23 → 16 | 19.2 | 158 | **y = 75** | 2.45 – 3.47 |
| 16 → 9 | 12.0 | 99 | **y = 57** | 3.47 – 5.53 |

Fíjate en la última columna: las franjas **no** son iguales ni en píxeles de pantalla ni en
distancia; crecen **geométricamente** (~1.4× cada una). Es justo el efecto que se intuía: al
inclinar el plano, las divisiones "equitativas" dejan de serlo.

---

## 6. Preguntas concretas

1. **¿Es correcta esa ley de reparto?** ¿La media geométrica es el criterio óptimo para minimizar el
   "salto" percibido con un conjunto discreto de tamaños, o hay un criterio mejor (p. ej. minimizar
   el error en área, o en el ángulo visual)?
2. **¿Qué conjunto de tamaños conviene** teniendo en cuenta que ×2 es gratis y dibujar arte nuevo
   cuesta? ¿Merece la pena {64,46,32,23,16,9} (5 saltos, máximo ratio 1.78) o es mejor
   {64,32,16,9} (3 saltos, ratios 2.0 — más saltos, pero menos arte)? ¿Hay una regla tipo "no más
   de X % de salto por paso"?
3. **¿Qué hacer con el 16→9**, que es el peor salto (1.78)? ¿Merece la pena un arte de 12 px
   (nuevo, a mano) o se puede dejar porque a ese tamaño (9-16 px) el error absoluto es pequeño?
4. **¿Dónde poner el kart del jugador?** Si el jugador va a 66 px (el valor que pide la
   perspectiva), ¿conviene que use el arte ×2 (64 px) y deje de escalar (su profundidad es fija),
   o hay una razón para que también recorra los escalones?
5. **Transición**: además de elegir bien los umbrales, ¿hay técnicas baratas en SNES para disimular
   el salto de tamaño (p. ej. cambiar de tamaño cuando el kart cruza una fila concreta de pantalla,
   coincidiendo con el parpadeo de daño, o con el cambio de estado del sprite)? ¿O el salto es
   inevitable y lo único que se puede hacer es optimizar su posición y el número de pasos?
6. **Sesgo de profundidad**: en el hack, los karts nunca se dibujan por encima de y=46, mientras
   que en vanilla llegan a y=30. ¿Eso indica que la cámara nueva recorta el campo lejano, y por
   tanto que **sobran** escalones pequeños (9 px casi no se usa) y **faltan** grandes?
   Aporta cómo verificarlo.
7. **Formulación final**: dame la regla en pseudocódigo y la tabla de umbrales resultante
   (valores de escala de 16 bits, tal como se escriben en la ROM: 2 bytes por umbral), más el
   criterio de cómo recalcularla si algún día cambia la cámara (posición del jugador u horizonte).

---

## 7. Datos brutos por si quieres rehacer los cálculos

* Resolución: 256×224. Pantalla llena en el hack (sin bandas negras).
* Horizonte medido por dos vías independientes: (a) ajuste escala↔y de los karts → y≈23/27;
  (b) el borde superior del arte nunca baja de y=30 (vanilla) / y=46 (hack).
* Posición del jugador: fija toda la carrera (pies en y=101 vanilla, y=190 hack).
* Proporción de referencia: en vanilla, el arte de 32 px corresponde a escala 264
  ⇒ **1 px de arte ≈ 8.3 unidades de escala**. En el hack, el jugador tiene escala 549, luego su
  kart "correcto" sería de 549/8.3 ≈ **66 px**.
* Franjas actuales del hack en pantalla: 32 px para y>103, 23 px para y 78–103, 16 px para y 54–78,
  9 px para y<54.
* Los karts se dibujan como 4 sprites de 16×16 (arte 32), 4 de 8×8 con offset (23×24), 4 de 8×8
  (16×16) y 2-4 de 8×8 (9×9). Cualquier tamaño nuevo multiplica el número de sprites por el
  cuadrado del factor de escala.
* Ejemplo de arte ×2: el arte de 32×32 (4 sprites de 16×16) pasa a 4 sprites de 32×32, que en
  SNES son 16 celdas de 16×16 en vez de 4 (4× el espacio de VRAM/tiles por tamaño nuevo).

---

## 8. Qué espero de tu respuesta

1. Validación o corrección de la ley de reparto (media geométrica) y, si procede, la fórmula
   correcta.
2. Una recomendación **cerrada**: conjunto de tamaños + umbrales numéricos (en unidades de escala
   de 16 bits) + justificación.
3. Si crees que el problema no se puede resolver bien sin dibujar arte nuevo, di **qué tamaños
   exactos** habría que dibujar y por qué esos.
4. Cómo verificar objetivamente que el resultado es monótono y sin saltos perceptibles
   (métrica propuesta, p. ej. error relativo máximo del tamaño dibujado respecto al ideal en
   función de la posición en pantalla).

---

# ANEXO — Importante: NO todo se dibuja igual (karts, sprites sueltos y escenario)

Antes de que apliques la fórmula de §5 a "todo", ten en cuenta que el juego tiene **tres vías de
dibujo distintas**, y el problema de tamaños sólo existe en la primera:

## A) Karts (8 objetos) — sprites con escala por distancia

* Únicos que usan la **tabla de 11 umbrales → 4 tamaños de arte** (`$80:DD35`). El índice de esa
  tabla se calcula multiplicando el número de kart por 2 (`$80:CF22`), o sea que **está dimensionada
  para 8 entradas: sólo karts**.
* Aquí aplica todo §2–§5 (ley de perspectiva, media geométrica, límite de 4 tamaños).

## B) Sprites sueltos: objetos, caparazones, Lakitu, y los enemigos que sean sprite

* En el juego original **NO escalan con la distancia**: tienen tamaño de arte **fijo**.
  Medido en 25 000 fotogramas de Donut Plains (2 vueltas, 1 jugador): los sprites de objeto se
  dibujan a 8×8 o 16×16 px con independencia de su posición en pantalla (y de 20 a 43 px), y el
  **mismo objeto sale del mismo tamaño en vanilla y en el hack** (diferencia de posición ≤1 px en
  ese caso concreto).
* Por tanto: sin tabla de tamaños, sin problema de "cuatro escalones". Lo único que la modificación
  les hace es **sumarles el desplazamiento vertical** `$7E:0A86`, y lo hace **con condiciones**:
  * `$88:A100`: sólo si `$7E:B0AB == $10` (tipo de objeto concreto);
  * `$88:920F-9263`: sólo si el valor está entre `$5C` y `$60` (92–95).

  Consecuencia práctica: **si ves objetos desplazados respecto a su sitio, es este camino y su
  condición, no el reparto de tamaños.**
* Pregunta para la IA: ¿tiene sentido escalar también los sprites sueltos por distancia (sería
  coherente, pero obliga a arte nuevo y a tocar sus rutinas), o es mejor dejarlos a tamaño fijo
  (como el original) y limitarse a corregir su desplazamiento vertical?

## C) Escenario: tuberías, monedas, paneles de objetos, suelo, vallas, bloques

> **CORRECCIÓN (2ª revisión).** Un primer borrador de este anexo afirmaba que las tuberías eran
> Mode-7 con escalado continuo. **Es falso y queda retirado.** El chequeo que lo sostenía
> ("sin entradas de OAM sobre las tuberías") era defectuoso: los recuadros verdes medidos eran
> bordillos, hierba y karts de Yoshi, no tuberías. Las tuberías son **sprites de tamaño fijo**.

* **Las tuberías son sprites, y su tamaño no cambia con la distancia.** Tres pruebas:
  1. Autocorrelación de píxeles: la tubería del estado del autor (22×31 px) reaparece en f400
     **idéntica píxel a píxel (0 de 912 px de diferencia)** tras aplicarle su desplazamiento entero
     (dx=−2, dy=+4). Un plano Mode-7 re-muestrea por scanline y no da residuo cero; una tarjeta de
     sprite sí.
  2. Seguimiento: la misma tubería mantiene **22×31 constante** mientras su base cruza de y=107 a
     y=218 (acercándose en profundidad). Cero escalado.
  3. Contorno negro y **pop-in**: aparecen/desaparecen enteras al cruzar un umbral de distancia,
     comportamiento imposible en el fondo (que está siempre dibujado).
* Lo que **sí** es Mode-7 es el **suelo/carretera y el decorado del plano**: medido sobre la
  carretera, su ancho crece ~1,2 px por línea de barrido (matriz afín por scanline, resolución de
  fracciones de píxel, sin límite de "4 tamaños").
* Consecuencia, y es la clave de la impresión visual del autor: **la carretera y los karts se
  re-escalan con la profundidad, pero la tubería no**. Al acercarse, la tubería conserva sus 22×31
  mientras la calzada se ensancha a su alrededor → *parece* que la tubería encoge al acercarse y que
  cambia "de golpe" al entrar/salir de pantalla. **Ocurre igual en el juego original** (verificado:
  en el original la tubería tampoco escala).
* Preguntas para la IA: (1) ¿conviene dibujar las tuberías (y demás objetos de escenario con
  sprite) con **tarjetas de varios tamaños elegidas por profundidad**, para que acompañen a la
  calzada, o dejarlas a tamaño fijo como el original y limitarse a corregir su posición vertical?
  (2) Si se escalan: ¿cuántas tarjetas hacen falta para no repetir el problema de los karts
  (§5), y cómo se casan con la ley `escala ∝ (y − y_h)` para que un objeto y la calzada de su misma
  fila den la misma escala? (3) Si no se escalan: ¿basta con corregir el desplazamiento vertical
  (`$7E:0A86`, §B) para que la tubería vuelva a "apoyarse" en su sitio de la calzada?
* Aparte, el **suelo** sí es Mode-7 y se controla con el **flag `$7E:0A88`** y una batería de
  ventanas nuevas en el banco `$88` (`$88:8AD6`, `$88:8B15`, `$88:8B34`, `$88:8B53`, `$88:8BB0`,
  `$88:8BCF`, `$88:8BEE`), que sustituyen a las de vanilla (`$80:C887`, `$80:C998`, `$80:C9C2`,
  `$80:CA0D`, `$80:D6DE`, `$80:D753`, `$80:19702`).
* Pregunta añadida para la IA: si el suelo es Mode-7 y los objetos de encima son sprites de tamaño
  fijo, **la misma fila de pantalla contiene dos escalas distintas** (una continua, otra constante).
  ¿Cuál debe mandar para que un kart, una tubería y la calzada de la misma fila midan lo mismo?

## D) Resumen de qué sirve para qué

| Elemento | ¿Usa la tabla de 4 tamaños? | ¿Se puede repartir por perspectiva? | Límite real |
|---|---|---|---|
| Karts (incluido el jugador) | **Sí** | Sí, con §5 | Sólo 4 artes (o 6 con ×2) |
| Objetos y enemigos-sprite | No (tamaño fijo) | No aplica | Ninguno: ya son fijos |
| Tuberías y objetos de escenario (sprites) | No (tamaño fijo) | Sólo con arte nuevo por franja | Depende del arte que se quiera dibujar |
| Suelo / carretera / decorado (Mode-7) | No | **Sí, y mejor** (escala continua) | Nº de ventanas y CPU |
