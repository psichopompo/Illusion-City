# Diagnóstico: los karts y sus "marcas" (anclaje al suelo)

Medido sobre `candidato_v1.3` (referencia), `candidato_v1.9_A_reparto_x15` (A) y
`candidato_v1.8_reparto_suave` (B), misma carrera de 700 fotogramas.

## 1. Qué se midió

* **Apoyo**: borde inferior (y1) del sprite compuesto de cada rival, emparejando el mismo
  kart por su centro en el mismo fotograma en las tres versiones (620 emparejamientos).
* **Salto de escalón**: en las transiciones de banda, cuánto se mueve el borde inferior
  respecto al avance normal del kart (4 px/fotograma en esa recta).

## 2. Resultados

**Sesgo de apoyo respecto a v1.3** (mismo kart, mismo fotograma):

| versión | -4px | -3px | +0 | +1px | +2px | +10px |
|---|---|---|---|---|---|---|
| A | 14 | 82 | 72 | 109 | 114 | 19 |
| B | 53 | 11 | 134 | 160 | 36 | 0 |

* **A tiende a dibujar 3-4 px por encima** de la marca de v1.3 (y tiene 19 casos de +10 px:
  un kart que aún no ha reducido en A y sí en v1.3).
* **B se queda +1/+2 px por debajo** (nunca +10).
* El caso visible: **fotograma 35**, mismo kart → v1.3 32 px apoyando en la fila 97,
  A 24 px apoyando en la 95, B 32 px apoyando en la 99. Figura:
  `docs/comparativa_A_vs_B_marcas.png`.

**Saltos en la transición de banda** (borde inferior, ya descontado el avance del kart):

| versión | -5 | -4 | -3 | -2 | -1 | 0 | +8 | +9 |
|---|---|---|---|---|---|---|---|---|
| v1.3 | – | 4 | 1 | 4 | – | 1 | – | – |
| A | – | 7 | 3 | – | 4 | 1 | 2 | 3 |
| B | 1 | 4 | – | – | 1 | 4 | – | 4 |

## 3. Interpretación (lo importante)

1. **Dentro de cada banda, el kart deriva poco a poco** (1-4 px/fotograma): eso es correcto,
   es el propio movimiento de la perspectiva.
2. **La causa del "no queda en su marca" es el anclaje por banda**: cada registro de arte
   (`$DC23, $DC2D, $DC37, $DC41, $DC4B, $DC55, $DC5F, $DC69, $DC73, $DC7D, $DC87`) trae sus
   propios offsets verticales (+`$00` y +`$06` del registro, ver `$81:BC06-$BC2B`) y no
   coinciden entre bandas: el kart salta 3-4 px al cambiar.
3. **v1.3 disimula este defecto** porque los rivales no reducen hasta la fila 80: los saltos
   ocurren lejos y con sprites chicos. **Al reducir antes (A y B), los saltos se ven más**:
   en A además el sesgo va hacia "flotar" (arriba), que es lo que canta a la vista.
   El defecto es del original, no del reparto de umbrales.
4. En A aparece un caso extra: kart que ya ha reducido en A mientras en v1.3 sigue a 32 px
   → +10 px de diferencia. Es esperable por definición (reduce antes), pero refuerza que A
   se nota **más** que B.

## 4. Cómo se arregla (plan)

**Dónde**: tabla de registros de arte, uno por banda (11 registros de 32 bytes en ROM, banco `$81`).
**Qué**: para cada banda, medir el borde inferior que produce y ajustar los offsets +`$00`
y +`$06` (16 bits, con signo) del registro para que la transición no salte; el objetivo es
que el kart se apoye en la misma fila **antes y después** de cada cambio.
**Cómo se calcula**: con el harness ya se puede medir el borde por banda fotograma a fotograma
(sin tocar la ROM); el delta necesario para cada transición sale de esas series.
**Coste**: 10 transiciones × 2 filas de sprites; es una tabla pequeña y determinista, sin
prueba y error.

**Orden recomendado**: primero elegir A o B; luego ajustar los offsets sobre la elegida
(si se hace antes, el ajuste se tira al cambiar de versión).

---

# 2ª parte — mediciones del 2026-10-06 (tras probar A y B en juego)

## 1. Ancho de Mario: A queda descartada

Medido en OAM (composición de los 4 sprites de Mario, mismo state y fotograma):

| versión | OAM de Mario (2 filas de 2 sprites) | arte |
|---|---|---|
| v1.3 | y=158 / y=174 | 32×32, filas 158..190 |
| **v1.8 (B)** | **y=158 / y=174 (idéntico)** | **32×32, filas 158..190** |
| v1.9 (A) | y=160 / y=176 (**+2 px**) | 32×32, filas 160..192 |

El usuario mide 28 px en v1.3 y v1.8 y **22 px en A**: coincide — en A el ajuste sub-píxel
del jugador (primer valor de la tabla, 336) desplaza su composición 2 px y le recorta el arte.
**A queda descartada. B es el candidato.**

## 2. "Los personajes están por delante de sus marcas" (confirmado y medido)

Comparando el **mismo kart en el mismo fotograma** contra v1.3 (620 emparejamientos),
diferencia del borde inferior del sprite compuesto:

| versión | -4 | -3 | -2 | -1 | 0 | +1 | +2 | +10 |
|---|---|---|---|---|---|---|---|---|
| A | 14 | 82 | 13 | – | 72 | 109 | 114 | 19 |
| **B** | 53 | 11 | – | 29 | 134 | 160 | 36 | 0 |

* B se queda en **+1/+2 px** (los karts se dibujan un pelín más abajo = "por delante de su marca").
* A se desvía hasta ±4 px y tiene 19 casos de +10 px.
* La línea blanca de la calzada cruza a la altura de las ruedas igual que en v1.3 en B
  (filas 182-187 sobre arte 158-190); en A, 2 px más arriba respecto a Mario.

**Causa**: cada banda de arte trae su propio anclaje vertical (offsets de los registros
`$DC23,$DC2D,$DC37,…`). **Arreglo**: ajustar esos offsets por banda para que el kart caiga
en la misma fila antes y después de cada cambio (tabla pequeña y determinista).

## 3. Sombra: sistema localizado (y por qué no cae a la altura de Mario)

**Composición (medida):** el juego escribe en el búfer **`$7F:DF00`** tres grupos de sprites
(estático, no se reescribe por fotograma):

```
[0..3]  70 5f eb 3a | 78 5f ec 3a | 80 5f ec 3a | 88 5f eb 6a   ← sombra GRANDE (4 sprites, Y=$5F=95)
[4..7]  70 cf eb 3a | 78 cf ec 3a | 80 cf ec 3a | 88 cf eb 6a   ← copia con Y=$CF (=$5F+$70)
[8..9]  78 5c eb 3a | 80 5c eb 7a                                ← sombra PEQUEÑA (2 sprites, Y=$5C=92)
```

**Desplazamiento del hack:** el sitio de copia al OAM (file `0xEC73`) fue parcheado:
vanilla `LDA #$000F / MVN $7F,$80 / STY $3C` → v1.3 `LDA #$000F / JSL $88:8D5E / NOP`.
El ayudante recorre 4 sprites y **suma `s` a la Y solo si está en `[$5C,$60)`**:

```
$91:9210  CMP #$5C / BCC +12 / CMP #$60 / BCS +8 / ADC $7E0A86 / STA $0000,X
```
`s` = `$7E:0A86` = **88** en este state ⇒ la sombra grande pasa de 95 a **183** y la pequeña
de 92 a 180 = justo bajo Mario (su arte ocupa 158..190, las ruedas 174..190) ✔

**El problema:** los únicos sprites con tiles de sombra (`$EB/$EC`) que se ven en la OAM
están en **(x=62, y=90) y (x=68, y=90)** → su Y=$5A(=90) queda **fuera de la ventana [$5C,$60)**
por 2 px, así que **no se les suma `s`** y la sombra se queda arriba (~90) en vez de caer
a la altura de Mario (~178-183). En los fotogramas analizados esos dos sprites no pintan
nada (la zona es tierra lisa), así que hay que confirmar cuál es la sombra que se ve.

**Pendiente inmediato:** ampliar la ventana (p. ej. `[$58,$60)`) **en el ayudante que
realmente se ejecuta**. Probado y **sin efecto** el ayudante de file `0x89200`
(`$91:9200`) → el camino vivo es otro (hay más sitios que suman `s`: `0x884D4, 0x884E4,
0x885E7, 0x88653` y `0x8A10D`, y un dibujante en `$91:A010-$91:A070`). Siguiente paso:
traza de escritura/lectura sobre el destino del MVN para ver quién copia la sombra al OAM.
**Ayuda útil:** un estado o captura del momento exacto en que se ve la sombra descentrada
(salida, salto o rescate de Lakitu) para no perseguir al sprite equivocado.
