# Documentación actual — SMK USA Full Screen

## Candidato activo

- Base: `roms/Super Mario Kart USA Full Screen.sfc`
- Candidato: `roms/t_vK58.sfc`
- State de validación de meta: `states/t_vK58.state`
- Payload equivalente para el harness: `states/t_vK58_payload.bin`

La ROM base es HiROM USA de 1 MiB y el candidato difiere actualmente solo en los dos valores de cámara/posición de sprites y en la corrección del banner `ROUND 1`.

## Validado

- Perspectiva del escenario conservada según v14.
- Rotación de la pista estable.
- Kart del jugador en la mitad inferior.
- Reescalado con profundidad.
- El state de meta carga correctamente en bsnes (`serialize_size = 286469`, `unserialize = 1`).
- La cámara gira al cruzar la meta sin reproducir el shrink inconsistente observado en la lógica anterior.

## Pendiente

### Orden de dibujado

El solapamiento ocasional de un rival con el jugador apunta al orden de emisión OAM/prioridad de sprites, no a una colisión. El arreglo debe trabajar en el punto común posterior a la composición OAM, manteniendo juntos los cuatro subsprites de cada kart y ordenando los karts por profundidad. No se deben reintroducir los hooks por objeto dentro del camino rasterizado de v14.

### HUD y textos

Mover el bloque de coches y monedas a la disposición objetivo, comprobando específicamente `$0406` durante `ROUND 1`, sin afectar el texto ni el mapa/escenario.

### Colisiones

Las colisiones con el escenario y con rivales todavía no están validadas. Se abordarán después de estabilizar la proyección, la escala y el orden de dibujado.

### 2P y entrega

Quedan por validar el intercambio de pantallas en dobles, con P1 abajo, y la reproducción final en RetroArch/bsnes. No se debe emitir un IPS final hasta que un candidato único pase esas pruebas.

## Investigación OAM en curso

Se ha confirmado que los karts ocupan quads contiguos de cuatro entradas en OAM, normalmente en los slots `$28-$3B`, y que el índice OAM determina qué sprite queda delante cuando se solapan.

Se probó de forma experimental un ordenamiento completo en la rutina de DMA de OAM (`$8094A1`). Queda **descartado**: el coste temporal rompe la ventana de raster/HDMA y produce corrupción visible del escenario. No se conserva esa ROM. El arreglo deberá ejecutarse en un punto de composición anterior y no crítico, o limitarse a una operación constante muy pequeña.

### Resultado de la instrumentación PPU/DMA

La instrumentación del PPU rápido y de la transferencia DMA, usando el state reproducible y sin modificar `t_vK58.sfc`, cierra la hipótesis de rotación de prioridad:

- `oamBaseAddress = $000`, `oamPriority = 0`, `firstSprite = 0` y `rangeOver/timeOver = 0` al terminar el frame. No hay rotación del punto inicial OAM ni desbordamiento de objetos.
- Se observa una sola transferencia OAM de 544 bytes, en modo fijo hacia `$2104`, desde `$000200-$00041F`: los 512 bytes bajos y la tabla alta `$0400-$041F` llegan al PPU en orden.
- Los quads de carrera llegan como cuatro entradas completas por kart en los slots OAM `$28-$3B`; los atributos y la tabla alta acompañan a cada grupo. El índice fijo de composición es, por tanto, la causa relevante del solapamiento, no una reordenación interna del PPU/DMA.
- La prioridad OBJ de los karts es la misma (`2` en este estado), así que tampoco hay una prioridad de atributo que pueda corregirlo sin alterar la lógica visual aceptada.

Conclusión operativa: la próxima solución debe identificar los quads dinámicamente durante la composición (manteniendo los 16 bytes bajos y la entrada alta asociada como unidad) y ajustar solo el orden de los karts cuando el orden de profundidad lo requiera. No se autoriza un intercambio fijo de slots ni tocar cámara, escala, posición o raster.

### Validación de `$0406` y entrada en carrera

Se añadió una traza de escrituras con frame y PC a `$0400`, `$0406`, `$0600` y `$0620`, y se condujo el state de selección hasta la parrilla de carrera. El resultado no debe confundirse con la validación de `ROUND 1`:

- En el state de selección, `$0406` parte en `$AA`; durante la transición se observa el borrado a `$00` (frame 113) y una escritura transitoria `$AA` desde el compositor de quads (frame 123). En la parrilla/carrera de esa reproducción queda en `$00`, con `$0600=$80` y la tabla alta general en `$FF`.
- En `states/t_vK58_payload.bin`, que ya es un state de carrera avanzado, `$0406=$55` permanece estable durante 80 frames; no hubo una escritura posterior que permita atribuir ese valor a la entrada en `ROUND 1`.
- El desensamblado identifica la rutina de carga que escribe el valor constante en `$81BC5B` (`STA $0406`, acompañada de `STA $0626`). En la base el inmediato es `$55`, mientras que `t_vK58` contiene `$00` en el byte anterior (`$81BC5A`). Por tanto, todavía hay que capturar la ejecución real desde el arranque/carga de pista hasta el texto `ROUND 1`; no se aprueba todavía `$0406` ni se revierte ese byte por conjetura.

### Criterio de profundidad encontrado

El punto de composición ya permite separar profundidad de identidad del sprite:

- `$80CA64-$80CA83` obtiene el resultado de proyección del DSP1 (`$6000`), calcula las coordenadas proyectadas en `$32,x` y `$34,x`, y guarda el bucket de profundidad en `$0E,x`.
- `$80BB9F-$80BBA5` ordena la lista de objetos comparando `$0E` antes de llamar a los renderizadores en `$80BB6C-$80BBB5`. Es el orden que termina alimentando los quads consecutivos en `$0490-$0500` y, después, la OAM.
- En la traza de `t_vK58`, `$14` llega como A a `$80C128`, pero identifica el tipo/variante que selecciona la ruta de render; no debe utilizarse como profundidad.
- En la parrilla, los siete rivales comparten `$0E=$000C`; P1 queda en `$0E=$000D`. El orden restante de los rivales es el de la lista (`$1100,$1200,...,$1700`) y en el state válido ya resulta monotónico en `$34`. No se debe sustituir ese orden por `$14` ni por un intercambio fijo de OAM.

Esto acota el próximo experimento a un desempate local en la lista/composición, no a `$8094A1`, `oamPriority`, cámara, escala ni raster. El criterio secundario aún debe validarse con dos frames de solapamiento antes de tocar la ROM.

### Cierre de la rama de solapamiento inicial

La comparación completa de la carrera válida (`states/state_payload.bin`, 2/10/30/60/120 frames) separa el problema que se estaba mezclando:

- Entre la ROM base fullscreen y `t_vK58.sfc` solo cambian los cuatro bytes Y de P1 en `$0271/$0275/$0279/$027D`; los grupos de rivales y sus atributos permanecen idénticos en `$0200-$041F`.
- Los rivales están en los nodos `$1100-$1700`, todos con el bucket `$0E=$000C`. Su orden de lista ya es monotónico por la coordenada proyectada `$34` (`-111,-113,...,-123` en el frame inicial), y alimenta los quads consecutivos de OAM de los slots 32, 36, 40, 44, 48, 52 y 56 (`$20,$24,...,$38` como índices hexadecimales).
- Los slots 28–31 (`$0270-$027F`) siguen siendo el quad de P1; los slots 24–27 (`$0260-$026F`) son `ROUND 1`, no un rival. No hay que intercambiar esos slots.
- La secuencia OAM inicial es coherente con la prioridad SNES: el quad con mayor Y de pantalla ocupa el índice menor y queda delante. La aparente superposición de la parrilla es geométrica por la cercanía/proyección de los karts, no una inversión de prioridad.

Se hicieron tres pruebas temporales desde `t_vK58.sfc`, sin conservar ninguna ROM:

1. invertir únicamente el desempate de igualdad: imagen y OAM idénticos;
2. desempatar por `$34` ascendente: imagen y OAM idénticos;
3. desempatar por `$34` descendente: cambia los rivales, devuelve P1 a `$46/$56` y altera toda la imagen aceptada.

Resultado: no se promueve un arreglo OAM en esta rama. Cualquier reordenamiento fijo o desempate inverso empeora la lógica de v14; la estabilidad de rivales debe conservarse como está y las colisiones quedan fuera de esta fase.

### Resultado del diagnóstico del hook `$81:82B5`

Se probó únicamente en una ROM temporal, sin modificar `roms/t_vK58.sfc`: el `JSL` de `$81:82B5` llama a `$88:8900`, el helper conserva el estado de CPU/DBR, llama al `$80BB6C` original y escribe una marca fuera del área usada por el juego.

- Con `states/state_payload.bin` y el harness sin entrada, la marca confirma una invocación por frame (1, 10, 50, 100 y 400 frames); la imagen de 400 frames es idéntica a la base.
- En el retorno del compositor, el puntero de trabajo observado fue `$3C=$0500`. El snapshot de `$0200-$03FF` todavía cambia en las rutinas posteriores de construcción OAM; por tanto, el retorno de `$80BB6C` no es todavía una prueba de que los bloques dinámicos `$0260-$02EF` estén definitivamente listos.
- Las permutaciones mínimas de 16 bytes probadas en esa ROM temporal no se promueven: las de `$04xx` no alteraron la imagen visible y las que cambiaron `$0200-$025F` afectaron datos auxiliares, no demostraron corregir la superposición de karts.
- En `states/state_2p_payload.bin` con 400 frames sin entrada, `$0D28=0` y la marca de `$81:82B5` permanece en cero: la ruta 2P no pasa por este caller. Esto impide usarlo como solución común para 1P/2P sin localizar el caller de la otra rama.

Conclusión: el hook queda validado como punto de instrumentación para la ruta 1P, pero no como solución OAM. No se conserva ninguna ROM temporal ni se altera la ROM base.

## Harness

```bash
user_upload/run_bsnes_state \
  cores/bsnes_clean.so \
  roms/t_vK58.sfc \
  states/t_vK58_payload.bin 1
```

`cores/bsnes_instr.so` añade las trazas usadas para depurar input, PPU/OAM y WRAM. Los resultados temporales del harness se escriben en `user_upload/` y pueden borrarse después de cada investigación.

## Sesión 2026-09-29 (nuevo entorno): auditoría, `$0406` y `ROUND 1`

### Entorno
- `gcc -O2 -Iuser_upload -o /tmp/run_bsnes_state user_upload/run_bsnes_state.c -ldl` compila sin cambios; `bsnes_instr.so` carga; `unserialize=1` (`state_size=286469`).
- Hashes verificados: base `6f9110e2…53d1`, candidato `c5bedb81…211c`, diferencias solo en 0xCEC6, 0xCEE6, 0xCEE7, 0x1BC5A.
- Carrera 1P (`state_payload.bin`, 2 frames): base y `t_vK58` solo difieren en los Y de P1; WRAM difiere únicamente en `$0271/$0275/$0279/$027D` y en 2 bytes de 0x100F. Captura: `diagnostics/base_vs_t_vK58_carrera1p.png`.

### Nuevo harness: `harness/drive.c`
Conduce un state con un guion de botones (`desde hasta id_botón`, A=8) y registra por frame `$0036`, `$0D28`, `$0406`, `$0626`, `$0600`, `$0400`, `$0620` y las escrituras a esas direcciones con PC (frame incluido). Guarda PPM en cambios de `$0406`/modo o cada N frames y `wram.bin` final.
Uso: `gcc -O2 -Iuser_upload -o /tmp/drive harness/drive.c -ldl && /tmp/drive cores/bsnes_instr.so ROM states/state2_payload.bin 600 harness/script_copa_a_parrilla.txt /tmp/out 12`
Con `harness/script_copa_a_parrilla.txt` (A cada 40 frames) el state del menú de copas (`state2_payload.bin`, 50cc) llega a una **carrera 1P real** sin intervención: frame 113 carga de pista (`$0036=00`, `$0D28=02`), ~frame 127 fundido de entrada, ~298 `ROUND 1`, ~542 semáforo/salida.

### `$0406` durante la carga real (base vs `t_vK58`, mismo guion, frames 0-600)
| frames | base | t_vK58 |
|---|---|---|
| 0-112 (menú) | `$AA` | `$AA` |
| 113-122 | `$00` | `$00` (borrado masivo desde `$8195BD`) |
| 123-297 | `$55` (`$0626=$55`) | `$00` (`$0626=$00`) |
| 298-541 (`ROUND 1` visible) | `$AA` | `$AA` |
| 542+ | `$55` | `$55` |

- En el tramo 123-297 la imagen completa es **idéntica** entre base y candidato (diferencia PPM = vacía en los frames 124/130/144/156/180/204/240/288): el byte `0x1BC5A` no tiene efecto visible en la ruta 1P.
- Desde 298 (`ROUND 1`) `$0406=$AA` en ambas ROM; lo escribe el compositor de quads, no la rutina `$81BC5B`. La banda del texto es idéntica píxel a píxel entre base y candidato; solo difiere P1.
- OAM en f=310 (ambas ROM): slots 24-27 `x=100,116,132,148`, `y=48`, tiles `00/02/04/06`, attr `$39`, tamaño grande (tabla alta `$AA`). Slots 28-31 (P1): Y `70/86` en la base, `158/174` en `t_vK58`.
- **Hallazgo abierto**: en `ROUND 1` las letras `R` y `O` aparecen cortadas horizontalmente (filas superiores sustituidas por rayas), tanto en la base como en `t_vK58` (`diagnostics/round1_t_vK58_f310.png`). No lo causa `$0406` (su valor es correcto y el mismo en ambas). Es un defecto heredado de la base fullscreen, pendiente de diagnosticar (candidatos: contenido VRAM de los tiles del texto, o interacción con el HDMA/ventana del hack). No se ha tocado ninguna ROM.
- El filtro de la traza del core solo cubre escrituras con banco `$00/$7E`; las escrituras de los frames 298 y 542 no aparecen en `trace.txt`. Localizar su PC requiere ampliar el filtro y reconstruir el core (bsnes `0c2fa0d`).

### Estado
- Sin cambios en `roms/`. No se ha generado IPS.
- Pendiente: causa del corte de `R`/`O`; `$0626` y 2P (aún sin state 2P auténtico: `state_2p_payload.bin` sigue cargando el menú de copas); HUD; meta; colisiones.

## Sesión 2026-09-29 (2): ROM Europe limpia + state 2P auténtico

### Archivos nuevos (aportados por el usuario)
- `roms/Super Mario Kart (Europe).sfc` (512 KiB, CRC32 56410E5E; SHA-256 1bdf4226…99e2). Es la misma que espera `tools/port_fullscreen_europe.py`.
- `states/eu_2p_precarrera.state` (+ `_payload.bin`): state RetroArch/bsnes **con la ROM Europe vanilla**, en el menú de copas 50cc/Mushroom Cup justo antes de cargar la carrera. La carrera resultante **es 2P real**: P1 (Mario) arriba y P2 (Luigi) abajo, cada mitad con su cielo, HUD y `ROUND 1`.
- En esta ROM **confirman B o Start** (ids 0 y 3); A (id 8) no hace nada en ese menú. Con B en los frames 10, 40, 70…: carga de pista en f≈114, carrera (`$0036=02`) en f≈125, `ROUND 1` visible en f≈250.
- `patches/base_fullscreen_europe_portado.ips` y `roms/Super Mario Kart Europe Full Screen (ported).sfc`: salida de `port_fullscreen_europe.py` (hack fullscreen base de grego portado a Europe; NO es el candidato final ni lleva los cambios de `t_vK58`).

### Por qué el state 2P "cargaba el menú de copas" (discrepancia resuelta)
Un state hecho con la ROM **vanilla** no puede reanudar en la ROM fullscreen: la CPU está girando en el bucle de espera de NMI `$80805C: LDA $44 / BEQ` y el hack sustituye esos bytes por `JML $888000`; si la CPU reanuda en `$80805E` ejecuta mitad de una instrucción y el juego queda atascado en el menú (`$0036=08` para siempre, animación del menú sí corre). Bisección automática (`tools/bisect_port_europe.py`): de todos los parches del portado, **solo el `NMI hook`** produce el bloqueo; sin él, el state avanza.
- Solución de prueba (`tools/make_eu_state_compat.py`, genera una ROM temporal, no se conserva): dejar `LDA $44` intacto y colocar el `JML` en `$80805E`, con `BNE +4 / JML $80805C` (seguir esperando) y, al final del cuerpo de `main`, `LDX $36 / JML $808062`. Con esa ROM el state avanza a la carrera igual que con la vanilla.
- Consecuencia: los states `state_2p*` del paquete USA se hicieron sobre la ROM vanilla/otra build, por eso no servían con las ROM fullscreen. Para ROMs fullscreen hay que generar los states con la propia ROM fullscreen, o usar el enganche compatible anterior.

### Comportamiento 2P con el hack fullscreen base (Europe portado)
Con la ROM compatible la carrera 2P se dibuja **una sola vista a pantalla completa (P1, kart a media altura)**; P2 no se muestra (el hack anula la carga de la tabla OAM inferior). `$0406` y `$0626`: `$55` hasta el frame ≈250 y `$AA` durante `ROUND 1`, igual que en la vanilla; en 2P cada mitad usa su tabla alta (`$0406` arriba, `$0626` abajo), por lo que el byte `0x1BC5A` de `t_vK58` (que fija ambos a `$00`) **sí afecta a la mitad de P2** y debe validarse aquí.

### Pendiente inmediato
Decidir región objetivo (USA vs Europe); portar los 4 bytes de `t_vK58` (constantes Y `$FF66/$FFD6` +`$58`, inmediato de `$81BC5A`) a los offsets equivalentes de Europe y validar con este state 2P.

## Sesión 2026-09-29 (3): portado de `t_vK58` a Europe

Decisión del usuario: región objetivo **Europe** (ROM limpia y state 2P auténtico son Europe).

### Candidato europeo: `roms/eu_tvk58_candidato.sfc`
Generado por `tools/port_tvk58_europe.py` desde `Super Mario Kart Europe Full Screen (ported).sfc` (que sale de `tools/port_fullscreen_europe.py`). SHA-256 `43f316b5865dad2f7f49fd7089bd2e9cc5f9d031b0c1a180a2d73f1b559b87f1`. Cuatro bytes, localizados por contexto de código idéntico al de USA (coincidencia única):

| USA | Europe | antes → después | qué es |
|---|---|---|---|
| 0x00CEC6 | 0x00CEEB | 66 → BE | `LDA #$FF66` (Y kart, vista superior) → `$FFBE` (+$58) |
| 0x00CEE6 | 0x00CF0B | D6 → 2E | `LDA #$FFD6` (vista inferior) lo |
| 0x00CEE7 | 0x00CF0C | FF → 00 | … hi → `$002E` (+$58) |
| 0x01BC5A | 0x01BAF6 | 55 → 00 | inmediato de `STA $0406 / STA $0626` |

El script comprueba el contexto de cada sitio antes de escribir. No hay IPS del candidato todavía.

### Validación en la carrera 2P europea (state `eu_2p_precarrera`)
Para cargar el state vanilla se usa una variante temporal con el hook NMI reubicado (`tools/make_eu_state_compat.py <rom> <salida>`; la ROM real lleva el hook original de grego).
- Comparación base portada vs candidato, mismas entradas, 700 frames: `$0406/$0626` = `$00` en f≈120-250 (base `$55`), `$AA` durante `ROUND 1` y `$55` después, igual que la base. Imágenes **idénticas** en los frames 130/150/200 y en `ROUND 1`; solo cambia el kart de P1 (bbox x114-142, y65-182).
- Zigzag de 1200 frames en carrera (acelerar con B + izq/der alternando, `harness/script_2p_zigzag.txt`): comparando base y candidato frame a frame, **X idéntica y desplazamiento Y uniforme de +88 en los 4 subsprites del quad de P1 en todos los frames donde el slot 28 contiene el kart (889)**; 0 frames con X distinta o Y no uniforme. En los 311 frames restantes (ráfagas de 8-17 frames, p. ej. f779-786, f1124-1140) el slot 28 tiene otro contenido y las capturas base/candidato muestran al kart completo y desplazado igual (incluidos polvo y chispas de derrape). No aparecen saltos ni descomposición. Captura: `diagnostics/eu_zigzag_bursts.png`, `diagnostics/eu_2p_base_vs_cand.png`.

### Pendiente
- Validar en **1P Europe** (no hay state 1P europeo): ROUND 1 idéntico a base, meta, HUD.
- `$0626`/`$0406` en 2P: confirmado que solo se ve una vista (la de P1) a pantalla completa; P2 no tiene pantalla propia. Confirmar con el usuario si eso es lo deseado en 2P.
- HUD (disposición 2P: coches sobre monedas), corte horizontal de `R`/`O` en `ROUND 1`, meta, choques contra escenario/rivales.
- IPS final solo cuando todo lo anterior pase.

## 2026-09-30: camara de carrera mas cercana con rampa (sustituye a t_vK58 "solo sprite")

**Por que fallaba t_vK58 en juego real.** Solo movia el sprite de P1 (+$58 en `$FF66/$FFD6`). El punto de suelo real del kart seguia en la fila ~101, asi que la sombra, las colisiones y los rivales quedaban en su sitio original y el sprite "flotaba" 88 filas por debajo. Ademas, en el paso intro->carrera el kart pasaba de estar proyectado a ser sprite fijo: salto visible.

**Ingenieria inversa (USA; Europa equivalente).**
- La camara de carrera es `CODE_80ACB6` (USA) / `$80ACBB` (EU): comando DSP-1 `$02` (Parameter) con `Fx=$88,x`, `Fy=$8C,x`, `Lfe=$7C,x*4`, `Les=$84,x`, `Aas=$94,x`, `Azs=$80,x`. Despues calcula el centro Mode 7 como `F/4` (`$80AD0B`, `$80AD20` en USA) y `$52,x = Cy - $9C + 1`.
- `F` = 4 x posicion del kart (`$8086A0`, solo se recalcula cuando `$A4,x==2` o `$AC,x<0`; en la intro `F` es acumulativo).
- El punto de suelo del foco (= kart) cae en la fila `$9C-1` = 101. Todo (suelo, objetos por Project `$06`, sombra) se proyecta respecto a ese foco.
- Por tanto, si se manda al DSP un foco desplazado **R unidades-F hacia delante** (a lo largo de `Aas`), el kart real queda mas abajo y suelo, sombra, colisiones y rivales siguen coherentes. No se toca `$88/$8C`.

**Calibracion.** Curva medida barra-de-casilla(R) en USA: 95@0, 99@$20, 105@$40, 118@$80, 135@$C0, 153@$F0, 169@$110, 188@$130, 200@$140. La barra de la casilla esta ~$2B unidades-F por delante del kart; fila del kart = barra(R+$2B). Para llevar los pies del kart a la fila 189 (= 101+88, donde queda el sprite) hace falta **R ~ $107**. Escala de suelo ~2x abajo (como pedia el objetivo).

**Implementacion (`tools/make_camera_ramp.py`).**
- Entrada de `ACB6`: rutina en banco `$88` que, solo para la vista x=0 y solo en modo seguimiento, avanza un contador `n` (0..36) y calcula `dx,dy = R[n]*(sin,cos)(Aas)` con el comando DSP `$04` (antes de empezar el `$02`). Si no hay seguimiento (intro), `n=0`.
- `Fx`, `Fy` (al DSP) y los dos calculos de centro suman `dx/dy` (solo la copia, no la variable).
- Sprite de P1: `LDA #$FF66` y `LDA #$FFD6` pasan a `constante_vanilla + s[n]` (s = 0..88 filas). Sprite y suelo bajan juntos.
- Resultado: la intro es la de vanilla; al empezar el seguimiento (~f297) la camara se acerca suavemente (36 frames) y Mario sigue dentro de su casilla hasta quedar abajo. Sin salto.
- WRAM scratch: `$7E:0A80` dx, `0A82` dy, `0A84` n*2, `0A86` s (cero en todas las fases probadas; sin referencias en el codigo).
- Codigo en `$88:8300-$88:8420` (hueco de ceros). Puntos de parche Europa: `0xACBB` (entrada), `+9`/`+14` (Fx/Fy, acceso absoluto `8D 00 60`), centros por busqueda de `B5 88/8C C9 00 80 6A`, sprites `0xCEEA`, `0xCF0A`.

**Basura en el borde inferior (PAL).** Venia de la base, no del candidato: rutinas de OAM aparcan los sprites sobrantes de cada objeto con `Y=$E0` (224). En NTSC no se ve, en PAL (RetroArch muestra las lineas 8..231) cae en las ultimas 8 filas (y~215-222, X visible). Parche: `A9 E0` -> `A9 F0` en `0xBC96, 0xBDD0, 0xBE0D, 0xBE49, 0xD607` (Europa). En las capturas del harness no hay diferencia de imagen, y el OAM ya no tiene entradas con Y 224-239 visibles.

**Pruebas hechas.**
- USA (estado menu -> parrilla con `script_copa_a_parrilla.txt`): intro identica a vanilla, rampa suave, Mario dentro de su casilla; fin de carrera y pantalla de resultados OK (`states/t_vK58_payload.bin`).
- Europa (estado 2P, hook de compat, vista de P1): cuenta atras, `ROUND 1`, zigzag 1800 frames OK; `diagnostics/eu_camara_2p.png`.
- No probado: carrera 1P europea real en RetroArch (falta estado), colisiones con tuberias/rivales en juego, sombra en salto largo, HUD 2P, `R`/`O` de `ROUND 1`, linea de meta.

**Build.** `python3 tools/build_eu_camara.py` -> `roms/eu_camara_candidato.sfc` (SHA-256 `88ed3069...25fa`, 295 bytes distintos de la base portada). Sin IPS final todavia.

### 2026-09-30 (2): correccion tras la prueba en RetroArch (colisiones, humo, chispas)

La prueba del usuario (vista muy buena, pero humo marroncito sobre asfalto, sin choques con rivales y chispas arriba) dio tres hallazgos:

1. **Signo del desplazamiento.** El propio juego mueve el kart con `pos += (+R*sin(A), -R*cos(A))` (`$22,x`=R*sen, `$24,x`=-R*cos, sumados a `$18,x`/`$1C,x` en `$80879A`). La primera rampa negaba ambos terminos, lo que solo es correcto con `Aas≈0` (por eso paso todas las pruebas en recta). Medicion en USA con giro (`Aas=-48°`): `F` avanza en direccion `atan2(dx,-dy) = -48.8°`, es decir `(+sen, -cos)`. Con el signo antiguo el kart real quedaba desplazado lateralmente `2*R*sen(A)` (~100 texels a 48°) respecto al sprite: de ahi el humo fuera de pista y los choques fantasma. Correccion: `NEG=(False,True)` en `tools/make_camera_ramp.py`. Verificacion: el suelo bajo los pies de Mario (fila ~188, escala x2 en X) coincide con el suelo bajo el kart real de la base (fila 101) en un 94 % de las muestras (con el signo antiguo, 0 %).
2. **Chispas de pared/bordillo** (el sprite naranja de `(140,85)` de la captura): las emite `$80:D580` con un ancla de constantes vanilla `LDA #$6673` / `LDA #$668D` (Y=`$66`=centro vanilla del kart) en `$80:D67C` y `$80:D680` (Europa: busqueda por patron). Ahora saltan a un stub que suma `s<<8` y retornan al `RTS` de `$80:D694`. Las chispas entre karts usan el punto medio de los campos `$2C/$2E` de los sprites reales y ya siguen al kart. Comprobado en USA: Y de 85-94 a 173-182.
3. **Estados de salto/caida** (listas `$80:D86E..D898`, handlers `$80:DE61`/`DE8B`): fijan `Y=($7B,x|$FF00)` con el suelo vanilla `$6600`. Se les suma `s` con el mismo mecanismo (stubs en `+0x1D0/+0x1E0`). El salto con R (`$80:D930`) y su trayectoria no cambian en la prueba (identico al salto previo).
4. **La "sombra" negra** de las capturas antiguas es un objeto de pista (charco/elipse negra de asfalto): se ve en el asfalto y, lejos, en la hierba; se proyecta con el mismo foco, asi que no necesita parche. No aparece sombra de salto en OAM en la prueba de salto 1P (hop R de 13 px).

Regresiones tras el cambio: pantalla de resultados USA (`t_vK58_payload.bin`, 620 frames) identica a `t_vK58.sfc`; Europa 2P zigzag 1810 frames estable (`roms/eu_camara_candidato.sfc`, SHA-256 `fa70de79...`, 355 bytes distintos de la base portada). Herramientas nuevas: `tools/dis65816.py` (desensamblador 65816 minimo) y variables `TR_LO/TR_HI` en `harness/drive.c` para volcar el PC que escribe un rango de OAM/WRAM.

## 2026-09-30 (tarde): colisiones con rivales, clave de orden de P1

**Feedback de RetroArch (candidato `fa70de79…`)**: bien: colisión con muros/bordes, monedas, objetos. Mal: sin colisión con tuberías; rivales desaparecen por abajo/lados; Mario atraviesa rivales; al explotar Mario salta arriba; Lakitu y la nube asoman la cabeza por abajo al salir por arriba; HUD pendiente.

**Causa del atravesado de rivales (confirmada en USA, portada a Europa):**
- La lista de karts (`$02,x` desde `$B2` hasta `$B0`) se reordena cada frame en `$81:82E8` con clave **`$06,x`** (escala proyectada; vista inferior: `$0E,x`). La colisión kart–kart (`$81:9755`) solo prueba pares **adyacentes** de esa lista.
- Mario tenía `$06,x` = `$0108` fija (vanilla). Con la cámara acercada, un rival en la misma posición mundial tiene escala ~`$2DD`, así que quedaba a varios puestos de Mario y nunca se probaba el par.
- Arreglo (`tools/make_camera_ramp.py`, función `key`): el stub de sprite de P1 proyecta con el DSP (comando `$06`, X=4·`$18,x`, Y=4·`$1C,x`, Z=0) la posición real de Mario y guarda su escala en `$06,x` (×1,5 como los objetos del port, recortada a `$2FF`); en vista inferior `$0E,x` sin ×1,5. La escala de dibujo (`$18`) no cambia.
- Recorte de escala de objetos: el port ocultaba objetos con M'≥`$300`; ahora se recorta a `$2FF` y solo se oculta a partir de `$700` (stub en `$88:8650`).
- Prueba USA (`/tmp/sc_p.txt`, rival 3 en f876): ahora el rival es desviado (x 812→815) y Mario pierde una moneda con chispas junto a él.
- Europa: build `161ac85b…`; 2P compat zigzag 1810 frames estable (P1 y≈181–184).

**Pendiente:** tuberías (código de colisión con obstáculos no localizado; no se encontró en `$80:AE00`, `$80:AF5F` ni `$81:B2xx`, que son IA/posición), explosión de Mario, cabeza de Lakitu/nube por abajo, HUD 2P, línea de meta, `ROUND 1`, otros llamadores de `$ACB6`. Sin IPS final.

Herramienta: `harness/drive.c` admite `FOLLOW=f0,k` (teletransporta a Mario a la posición del kart k; solo para inspección).

## 2026-09-30 (noche): rivales invisibles a la altura de Mario, sprite vs posición real

**Feedback:** «a veces choca con enemigos, otras los atravieso; chispas más arriba; tuberías como si no estuvieran».

**Causas encontradas (USA, reproducidas con `/tmp/sc_p.txt` = `script_copa_a_parrilla` + `520 1000 0` + `700 718 6`, rival 3 en f874–f878) y portadas a Europa:**
1. **Un rival a la altura de Mario no se dibujaba ni se procesaba.** El manejador de la lista de karts (`$80:C730`, y `C70D` en vista inferior) oculta (`$30,x=$0140`, salta el resto del hilo) cualquier objeto con `$06,x >= $0FBA` (=`$200`). Con la cámara cercana la escala de Mario ya es ~`$228`, así que cualquier objeto a su altura o más cerca se ocultaba. Se ocultaban rivales, y muy probablemente también las tuberías y su colisión (comparten manejador). Parche: `CMP $0FBA` → `CMP #$0300` (máximo que admite el dibujo, `CMP #$0300` en `C98D/ED72`).
2. **Descarte vertical de karts rivales** (`C998`, `ED81`: `$38+$120 < $C0`, filas < 160): ampliado a `CMP #$0108` (filas < 232).
3. **Clave de orden de Mario** (`$06,x`/`$0E,x`) = escala proyectada real de su posición (ver sección anterior); recorte de escala de objetos a `$2FF`.
4. **Sprite de Mario no coincidía con su posición real.** Con el stub `DBGKEY=1` se midió la proyección DSP de la posición de Mario: a rampa completa caía en la fila 251 (fuera de pantalla) mientras el sprite se dibujaba en la 190 (S=88). Una rival a 3 unidades de Mario se dibujaba en la fila 250. Causa: la tabla de R se calculó con la barra de salida y `DELTA=42,7`, que no era la distancia real. Se midió V(R) (tabla `VR` en `make_camera_ramp.py`) y ahora R[n] cumple V(R[n]) = S[n]: a rampa completa R=215 (antes 263) y V=88. La cámara está algo menos adelantada que antes, pero sprite, suelo, sombra, colisiones y rivales coinciden en la misma fila.

**Resultado USA:** el rival entra al lado de Mario, se solapa, hay choque con chispas en el punto de contacto, pierde una moneda y el rival es desviado. **Europa** build `0c726791…`, zigzag 2P 1810 frames estable (P1 y≈181–184).

**Sin verificar:** tuberías (no hay escenario reproducible; se espera que las arregle el punto 1), explosión, Lakitu/nube, HUD 2P, meta, `ROUND 1`.

## 2026-09-30 (madrugada): salto de sprites arriba/abajo, bandas en pantalla

**Feedback RetroArch (candidato `0c726791…`):** cámara bien; choques con rivales mucho mejor; el sprite del rival (y de objetos: tuberías, bloques con cara, suelo agrietado) salta a la parte superior o se descompone al acercarse a Mario; tuberías, bloques con cara y suelo agrietado no afectan; bloques de hielo, monedas, ítems, plátanos y setas de rivales sí; ondulación en el suelo de la parte inferior.

**Causa del salto (reproducido en Europa 2P con `TELEPORT=640,1,0,-14`):** la OAM guarda la Y en 8 bits. Las ventanas de descarte vertical (`$80:C998, C9E7, CA32, ED81, EDAB, C8AC`) dejaban pasar filas hasta 288 (vista inferior) o 352 (objetos generales); por encima de la fila 256 la Y da la vuelta y el sprite reaparece arriba (y las partes por encima de la fila -32 reaparecen abajo: cabeza de Lakitu/nube). Las tres rutas de dibujo de kart/objeto usan ahora ventana de filas [8, 256) (vista inferior: solo límite inferior <256). `make_camera_ramp.py`, bloque «Ventanas de descarte vertical».
**Bandas de proximidad en pantalla** (`$80:D703`, `D778`: determinan el lado/rebote entre karts; usaban la fila original de Mario): desplazadas 88 filas (`ADC #$0068`, `ADC #$FFF8`).
**Resultado:** rival junto a Mario y detrás de él sin saltos (Europa 2P), colisión USA sigue OK, zigzag 2P 1810 frames estable. Build Europa `25aa4959…`.

**Ondulación inferior (sin arreglar):** los parámetros Mode 7 por línea son 8.8; al ampliar más las filas inferiores (cámara cercana) el error de redondeo por línea se ve más (escalones de ~2 px). No apareció en `t_vK58` (sin cámara cercana). Compromiso cámara cercana vs precisión; reducir `S_MAX`/R lo atenúa.

**Sin resolver:** colisión con tuberías, bloques con cara (Thwomp) y suelo agrietado: no hay escenario reproducible (la 50cc Mushroom Cup de `state2_payload.bin` solo da el primer circuito). Hace falta un state cerca de cada uno.

## 2026-09-30 (mañana) — colisión con tubos (obstáculos)

- Síntoma: Mario atravesaba los tubos (estado `states/eu_tuberia_payload.bin`, hecho por el usuario sobre el candidato).
- Causa: `81:9719–9722` (colisión kart–obstáculo, lista `$1DA0`) solo prueba objetos cuya clave de profundidad `$06` está en `[$E0,$120)`, ventana centrada en la clave vanilla de Mario. Con la cámara cercana la clave de Mario es 552 y un objeto sobre él proyecta a ~548 (medido f32–f33 en el estado), fuera de la ventana.
- Arreglo (`tools/make_camera_ramp.py`, `sub()`): `CMP #$0040` → `CMP #$01A0` (ventana `[$E0,$280)`). El test posterior de caja mundo |dx|,|dy|<4 sigue decidiendo el golpe.
- Verificado: Mario rebota en el tubo con chispas (frames 30–44 del estado). Candidato Europa SHA `809b716b…`.
- Pendiente: P2/vista inferior (misma rutina, clave de `sp2` sin validar), thwomps, hielo agrietado.

## 2026-09-30 (tarde) — estados de Mario (`states/mario_sep30/*.bin`, RZIP → crudo con `tools/rzip_to_payload.py`)

Candidato Europa actual: `roms/eu_camara_candidato.sfc` (`python3 tools/build_eu_camara.py`).

1. **Explosión (retirada y derrota) arriba.** La explosión usa `81:AA62` con Y fija `$58` (centro de la vista superior vanilla) → `A9 80 58 18 65 BA 22 <80:C07B>`. Parche: `JSL` a un stub (`code+0x1F0`) que suma `s<<8` (`$7E:0A86`) y salta a `80:C07B`.
2. **La cámara volvía a vanilla al terminar la carrera.** La condición de seguimiento (`$A4,x==2` o `$AC,x<0`) se apaga al acabar la carrera y la rampa ponía `n=s=0`: Mario y la explosión saltaban arriba (Derrota). Ahora, sin seguimiento, solo se reinicia `n,s` si el cronómetro de carrera (`$7E:0100–0102`) es 0 (intro); si ya corre (fin de carrera), se mantiene la cámara cercana. RETRY verificado: la intro nueva vuelve a empezar con `n=s=0`.
3. **Sombra de Mario arriba al saltar (CORREGIDO: el primer diagnóstico era erróneo).** La sombra real es un óvalo negro de 4 sprites 8x8 (tiles `$EB/$EC`, attr `$3A/$6A`, X=`$70..$88`) con Y=`$5F` (o `$5C` la variante pequeña) tomado de la plantilla de `80:EBE4/EBF6`, es decir, la posición vanilla de Mario; se reescribe en cada fotograma y parpadea un fotograma sí y otro no (igual que vanilla). Arreglo: el barrido de final de fotograma (punto 4) suma `s` a los sprites con tile `$EB/$EC` y Y en `[$5C,$60)`. Comprobado en el state: a Y=183 bajo Mario en los saltos. (Los sprites "ocultos" de las chispas `80:D5E0` con Y=`$46` que se forzaban a `$F0` eran partes ocultas por diseño, no la sombra; el stub de chispas se mantiene porque solo toca esas entradas 6/7. Se probó parchear `80:EC08`, que construye un búfer `$7F:DF00` que no se lee como OAM: no hace falta y se quitó.)
4. **Tiras abajo (artefactos).** Sprites aparcados en Y=`$E0` (224): en NTSC quedan fuera, pero la imagen PAL del harness/RetroArch muestra las líneas 8..231 (fila de imagen = línea−8), es decir, Y=224..231 asoma unas 7 filas (se veía un trozo de tubo/rival/Mario abajo al centro, X=128). Se reescriben cada fotograma, así que el barrido va al final del fotograma: `80:8056 JSL $81E067` → `JSL $88:8740` (en los 128 sprites: Y==`$E0` → `$F0`; sombra → Y+=s; luego `JML $81E067`). La rutina compat (`make_eu_state_compat.py`) no cambia.
- Comprobado: tubos (rebote intacto), 2P zigzag 1810 frames estable, sombra (0 fotogramas con partes en Y=46), retirada y derrota.
- Pendiente: 2 jugadores (pantalla partida con la lógica original), HUD (tabla de clasificación centrada), retrovisor/mapa con botón.

## 2026-09-30 (noche) — Puertas 1P/2P: estado y lección del espacio «libre»

**Criterio:** el hack solo actúa si `$7E:00AA == $1000` (1P). En 2P (`$AA=$1100`), menús y arranque (`$AA=0`) se ejecuta el código original de la ROM Europa. `tools/gate2p.py` (lo llama `tools/build_eu_camara.py`) sustituye cada parche por `JSL/JML` a un *gate* en el banco `$88` que elige vanilla o hack sin alterar registros ni flags. 44 sitios; quedan 453 bytes libres en el banco `$88` y ninguno usado en el banco `$80`.

**Resultados (bsnes, comparación fotograma a fotograma):**
- 2P: ROM Europa vanilla frente a candidato con puertas, estado `eu_2p_precarrera_payload.bin` + `harness/script_2p_zigzag.txt`, **1800 fotogramas: 0 diferencias** (pantalla partida, HUD, Lakitu, cronómetros).
- 1P: candidato con puertas frente al mismo sin puertas (`Sombra_Mario` con giro y 900 fotogramas, `Artefactos_abajo`, `Derrota`, `eu_tuberia`): **0 diferencias**.

**Errores encontrados y corregidos en este paso**
1. Los datos de Lakitu parcheados por el hack (`85:DC03/DC2B/DC5F/DF6D` y espera `DD6C`) y el umbral de ocultar kart (`80:C73B/C75E`) cambiaban la 2P. Ahora los datos están en vanilla y los lee un gate (`85:DDAB`, `85:DE32`, `85:DF69`, `80:C739/C75C`).
2. **`80:92D9..93D8` (256 bytes `FF`) NO es espacio libre: es una tabla que el juego lee** (se nota con un rival lejano: su cabeza sale rayada). Además, en el banco `$80` los huecos `00/FF` de `$2000–$7FFF` son datos gráficos. Todo el código nuevo va en el banco `$88`.
3. La ventana `80:8B40` contiene `JSR` del banco `$80`: se resuelve con `PEA $8B45 + JML` y un rebote `JML K` de 4 bytes dentro de la propia ventana (selector apilado bajo el retorno; tras `JSR $9461` el vanilla deja M=0, X=0 y K lo restaura).
4. Los retrasos de ciclos no influyen (probado con hasta 100 NOP en el bucle principal), así que el margen de V-blank no era el problema.

**Herramientas de depuración añadidas a `harness/drive.c`:** `STATEF=f` (serializa el estado en ese fotograma a `outdir/st_f.bin`; WRAM empieza en el desplazamiento `0xA84`), `DBGF=f` (copia el anillo de escrituras PPU/PC de los fotogramas f..f+2), `VRAMF` y `MEMPROBE` (VRAM no está expuesta por el núcleo).

**Pendiente:** confirmar que una carrera 2P completa llega a la tabla de resultados y vuelve al menú (por igualdad con vanilla no debería colgarse; no se ha probado hasta el final), HUD (coches×3 sobre monedas×N, tabla centrada), ajuste final de meta, USA, `.ips` final.

## 2026-09-30 (madrugada) — Barrido de OAM: rival partido/mutilado, cabeza de Lakitu, parpadeo inicial

Estados nuevos del usuario en `states/mario_oct/`. Causas y arreglos (solo en el barrido `$88:8740`, `tools/build_eu_camara.py`):

1. **Rival partido / mutilado (`donkey_*`)**: el barrido trataba como "sombra de Mario" cualquier sprite con tile `$EB/$EC` e Y en `[$5C,$60)` y le sumaba `s` (+88). Las piezas inferiores de un rival a media distancia (tile `$EC`, Y `$5F`) cumplen ese test por casualidad y salian despedidas 88 px hacia abajo. La sombra real son 4 sprites de 8x8 con atributo `3A/3A/3A/6A` (paleta 5, nombre 0); las piezas del rival llevan `27/67`. Ahora ademas se exige `(attr & $0F) == $0A`. Comprobado: `donkey_partido` f1-3, `donkey_mutilado` f13-17, `donkey_mutilado_1` f6-15 distintos antes/despues y completos ahora; la sombra de `Sombra_Mario` sigue en Y=183.
2. **Cabeza de Lakitu abajo / parpadeo a la izquierda al inicio**: los sprites que salen por arriba se envuelven por abajo (p. ej. Y=223/225, tiles `$42/$40`, x=36..52). En PAL las lineas 224..239 son visibles, asi que asoman. Antes solo se aparcaba Y==`$E0`. Ahora se aparca en `$F0` todo sprite con Y en `[$DF,$F0)` (un sprite de 16 px ahi tiene su primera linea >=224, nunca se ve en la zona de 224 lineas). Comprobado en `nube_abajo_semaforo` (700 fotogramas) y `parpadeo_raro`: ningun sprite queda en `$DF..$EF`. OJO: el harness solo guarda 224 lineas; estas lineas extra solo se ven en el core del usuario, por eso se verifico con el OAM y no con la imagen.
3. Regresion: 1P con/sin puerta 0 diferencias (`Sombra_Mario` 900, `Artefactos_abajo` 500, `Derrota` 500); 2P identico al candidato anterior en 1800 fotogramas (cero diferencias).

Pendiente: numero de puesto en 1P (en 2P lo dibuja la rutina generica de 4 cuartos `80:BC41..BD4F` en los slots 28-31, que en 1P ocupa el kart), HUD, final, IPS.

## 2026-10-01 — Dígito de puesto en 1P

- El dígito NO es sprite ni BG: es el canal 7 de HDMA (`$4370=$44`, indirecto, destino `$26`, tabla en `$7F:E500`) que escribe las ventanas `$2126–2129` línea a línea, más mates. de color (`$2125=$A0`, `$2130=$10`, `$2131=$3D`). El init (`$84:E933`) es común a 1P y 2P.
- La tabla vanilla de 1P acaba con punteros a `$7F:E528` (ventana completa): al restaurar el mate. de color aclara toda la parte baja. Además el juego reescribe la tabla cada fotograma con `JSL $84:EBDC` (`80:806E`), por lo que el parche debe ir justo después de esa llamada.
- Solución (solo 1P; en 2P todo es vanilla por el gating): `80:806E` → `JSL $88:87E8` (envoltorio: llama a `$84EBDC` y luego al stub `$88:87A0`). El stub copia los 4 primeros tramos de la tabla a `$7E:0AC0`, precedidos de un tramo en blanco de `$60` líneas, añade fin de tabla y apunta el canal 7 (`$4372/3/4`) a ese buffer. El dígito queda en las líneas 176–195 (abajo a la derecha, junto a las monedas; medido contra capturas del juego original: de −17 a +3,6 líneas respecto al centro de la fila de monedas) y conserva las animaciones nativas del juego (cambio de puesto, dígito grande al acabar la carrera).
- Restauraciones sin gating: `0x8A9F` 7E→FE, `0x8BA7`/`0x8BBF` 9C→8D, `0x8BCA` 30→10. Los gates de `0x8A9E`, `0x8BA4`, `0x8BBC` se mantienen como no-ops (`same=True`) para no mover las direcciones de los gates posteriores: los estados guardados por el usuario pueden estar aparcados dentro de código de bank 88 y se cuelgan si esas direcciones cambian. El gate de `0x806E` es el último. Se pueden eliminar en la versión final.
- Validación: 1P idéntico al candidato anterior fuera de la zona del dígito (x≥170, y≥90) en 6 estados × 500 fotogramas; 2P (zigzag 1800 fotogramas, `adelantamiento`, `derrota_numeros`) 0 diferencias. Buffer `$7E:0AC0–0ACF`: a cero en todos los estados probados.

### Bug: mitad inferior negra al cambiar de vuelta + dígito "como el original" (2026-10-01, versión final de esta ronda)

- Estado: `states/mario_oct/cambio_vuelta_negro.bin` (acelerar ~45 fotogramas; pantalla negra desde la línea 102 durante el cartel LAP / FINAL LAP).
- Causa: la rutina `80:8B9x` aplica el mate. de color dos veces por fotograma, con el juego de valores x=0 (NMI) y x=1 (IRQ de la línea ~102 = mitad "mapa" del 1P vanilla). El dígito (líneas 176–195) cae en la zona x=1, que en 1P vanilla no lleva dígito y recibe valores propios (al cambiar de vuelta `$2131=$AD` resta, color fijo blanco, `$2125=$FB` = ventana llena) → resta blanco a todo el Mode 7.
- Solución definitiva: el 1P ejecuta ahora **el código vanilla** de `$2131/$2132/$2125/$212E/$2130` (se retiraron los parches de 1P `$212E=0` y `$2130=$10`, que eran la causa del dígito "blanco opaco"), y la rutina `$88:9000` (llamada desde el stub del dígito, tras `JSL $84EBDC`) copia cada fotograma los valores x=0 (`$016A,$016C,$016E,$0170,$0108,$014E,$017A`) a los huecos x=1 (`+1`). Así el dígito usa en todo momento los colores y la mezcla originales de la mitad superior: suma de color fijo (translúcido), parpadeos de fin de carrera (azul/rojo según circuito, ver `84:EF40..F050`, selección por `$0D6E`/`$2C`) y fundido a negro tras acabar con el dígito recortado por la ventana (`$2131=$AD`, `$2130=$20`: mate. fuera de la ventana).
- Posición medida contra capturas del vanilla 1P: dígito grande x 192–241, parte baja a +2 líneas del centro de las monedas; el nuestro x 192–238 (el 7 es más estrecho), parte baja +2,5. Dígito pequeño: −17…+3,6 líneas respecto a las monedas, igual que el original.
- Regresión: 2P 0 diferencias (zigzag 1200 f, `adelantamiento` 300 f); 1P idéntico al candidato anterior fuera de la zona del dígito en `Sombra_Mario`, `nube_abajo_semaforo`, `donkey_mutilado_1`, `cambio_vuelta_negro` (400 f c/u). Los gates de `0x8BA4/0x8BBC/0x8BC5` quedan como `same=True` solo para conservar direcciones.
- HUD superior: el vanilla EU en RetroArch (224 líneas de 240) muestra el cronómetro pegado arriba; la captura NTSC de referencia (`Super_Mario_Kart_screen_shot.jpg`) lo tiene ~5–8 líneas más abajo. Pendiente de ajustar junto al resto del HUD.

### PAL (239 líneas) vs NTSC (224 líneas) — investigación 2026-10-01

- El vanilla EU escribe `$2133=$04` (overscan, 239 líneas) en `80:8BF5` y `81:E533` (`A9 04 8D 33 21`); el USA hace `STZ $2133` (`9C 33 21`, 224 líneas) en `80:8C0F` y `81:E545`. RetroArch/bsnes recorta 8 líneas arriba y 8 abajo de las 240 del EU → el HUD se ve pegado arriba (el cronómetro termina ~5–8 líneas más arriba que en NTSC).
- Prueba: escribir `$2133=0` cada fotograma en el candidato EU (hack de laboratorio en el stub del dígito): la imagen se corrompe (bandas verdes en la mitad inferior, tablas HDMA/raster y NMI pensados para 240 líneas). No es un cambio de una constante; haría falta revisar el timing de NMI/HDMA/IRQ.
- Aunque funcionase, el EU seguiría a 50 Hz; el motivo para preferir NTSC es sobre todo 60 Hz.

## 2026-10-01 — Rama NTSC (USA) y coches ×N sobre las monedas

- Decisión: la base pasa a ser **USA** (224 líneas, 60 Hz, margen superior como la captura NTSC). La Europe queda como rama aparte (`tools/build_eu_camara.py`, `roms/eu_camara_candidato.sfc`).
- ROM limpia USA: `roms/Super Mario Kart (USA).sfc` (CRC32 `CD80DB86`). El `USA Full Screen.sfc` original tiene exactamente las mismas 23 tandas de cambios que la base Europe portada, y la región nueva ($80000+) es idéntica salvo 4 bytes de continuación.
- Mapa de direcciones EU→USA por alineación de k-gramas únicos (`tools/mapregion.py`); casi todos los sitios coinciden bytes a bytes (los códigos USA y EU son casi iguales). Tabla usada (EU→USA, offsets de fichero): `8A9E→8AC5, 8B1B→8B42, 8B26→8B4D, 8B40→8B67, 8BA4→8BBF, 8BBC→8BD7, 8BC5→8BE0, ACBB→ACB6, ACC4→ACC0 (6 bytes, DSP largo), ACC9→ACC6, AD04→AD0B, AD18→AD20, CEEA→CEC5, CF0A→CEE5, D5E0→D5BB, D6A1→D67C, DEA1→DE7C, DECF→DEAA, C893→C86E, C8A1→C87C, C8AC→C887, C95F→C93A, C9BD→C998, C9E7→C9C2, CA32→CA0D, EDA6→ED81, EDD0→EDAB, D703→D6DE, D778→D753, 1971B→19702, 1AA62→1A9EA (explosión llama a 80:C056), 1BAF5→1BC59, 4E94A→4EA2E, 1FAA0→1FAD6, 1FAB2→1FAE8, 1FAC0→1FAF6, C739→C714, C75C→C737, 84:EBDC→84:ECC0`; el banco $85 (Lakitu) coincide.
- Scripts: `tools/build_usa_camara.py [salida]` (por defecto `roms/usa_camara_candidato.sfc`) + `tools/gate2p_usa.py` (derivados de los EU con esa tabla; la rampa de cámara `make_camera_ramp.py` ya soportaba DSP largo de USA).
- Validación hecha: `state_payload.bin` y `t_vK58_payload.bin` (USA) corren 120 fotogramas; kart abajo, rival/escena coherentes, dígito de puesto abajo a la derecha. **Sin validar en USA aún**: 2P (no hay state 2P USA), derrota/explosión/Give Up, cambio de vuelta, colisiones con tubos/charcos, tabla de clasificación.
- HUD: los sprites del contador de coches (Y=$54, atributo $28, X 182..207) se suben al final de cada fotograma (barrido de OAM, ahora en `$88:9100`) a Y=$B3, 9 filas sobre las monedas (Y=$BC), con la `×` en la misma columna (X=198). El barrido solo actúa en 1P. También aplicado a la rama EU (2P idéntico, 0 diferencias en `adelantamiento` 300 f).

## 2026-10-01 — Ralentizaciones en NTSC: perfilado y reducción de coste

**Síntoma:** el candidato USA iba ralentizado (~75 % de velocidad en el estado `usa_lento`, a ratos 30 fps) aunque el emulador marcaba 60 fps. Medida: el cronómetro de carrera (`$0100`) debe cambiar en cada fotograma; en `usa_lento` cambiaba 450 de 600 veces.

**Causa:** NTSC tiene ~19 % menos tiempo de CPU por fotograma que PAL (357 366 vs ~ 440 000 ciclos de reloj maestro). Las puertas de 2P, las rutinas de cámara y sobre todo el barrido de OAM (128 sprites cada vuelta, ~11 k ciclos de reloj maestro) hacían que una escena pesada pasara de 1 a 2 fotogramas por vuelta del bucle principal.

**Herramienta nueva (perfilador):** `cores/bsnes_prof.so` (bsnes `0c2fa0d` + `tools/core_patch.py` + histograma por PC con ciclos de reloj maestro y registro del último PC que escribe en `$0200–$05FF`). `harness/drive.c`: `HIST=f0,f1` (escribe `hist.txt` con `pc veces ciclos`) y `OAMW=f` (escribe `oamw.txt`: último PC que escribió cada byte del OAM). `tools/histrep.py hist.txt frames [n]` resume (ocioso, % por bloque, por banco). `tools/lag.sh rom estado frames` cuenta los cambios del cronómetro. Fuente del core: `/tmp/bsnes_src` (se borra; se reconstruye bajando `github.com/bsnes-emu/bsnes/archive/0c2fa0d.tar.gz` y aplicando `core_patch.py` + los añadidos de histograma).

**Cambios (todos solo 1P; 2P sigue ejecutando el código vanilla):**
1. Barrido de OAM: de 128 sprites a **4** (slots 16..19 = contador de coches, que está siempre ahí y se escribe una vez). Sigue en `88:9100`.
2. Sombra de Mario: el juego la copia al OAM cada fotograma con `80:EC73 MVN $7F,$80` (EU `80:EC98`; buffer `$7F:DF00..`). Se sustituye `MVN ; STY $3C` por `JSL 88:9200` (puerta 1P nueva, al final de la lista) que hace el MVN y suma `s` a la Y de esos 4 sprites si está en `$5C..$5F`. Validado en EU (`Sombra_Mario`, 200 fotogramas): OAM idéntico al antiguo barrido. En USA no hay estado con sombra: pendiente de ver.
3. Umbral de ocultar por escala (`CMP $0FBA` vs `CMP #$0300`, ~8 lecturas por vuelta): ahora `$0FBA` vale `$0300` en 1P (lo escribe el barrido) y los dos sitios `80:C714/C737` vuelven a vanilla (puertas reservadas sin instalar para no mover direcciones).
4. Se retira el aparcado Y=`$E0..$EF → $F0` (solo era necesario en PAL).

**Resultado (cambios del cronómetro en 600 frames, `acc.txt`):** `usa_lento` 450 → 599; `state_payload` y `t_vK58_payload` 599/599. Margen: inyectando retardo artificial, `usa_lento` aguanta ~+10 k ciclos de reloj maestro por vuelta (≈3 %) antes de perder fotogramas; los otros estados, >20 k.

**Estados guardados:** los guardados con el candidato anterior pueden colgarse si se guardaron *dentro* del barrido antiguo (como `usa_lento`); hay que volver a guardarlos con el candidato nuevo.

## 2026-10-01 (noche) — Observaciones: bloque negro en pausa y tabla STANDINGS (sin cambios en la ROM)

- Estados nuevos: `states/usa_tabla_payload.bin` (fin de carrera 1, pulsando START llega a RESULTS y STANDINGS hacia el fotograma 700) y `states/usa_bloque_payload.bin` (pausa con bloque negro). Ambos solo cargan en el candidato `1b79…`/`842d…`.
- **Bloque negro (pausa):** en ese estado `$1E8A=$10` y `$0174=2`: la rutina `84:ECC0` (modo `$EDC7`) deja en la tabla de color x=1 los valores de fundido a negro (`$016B=$AD` resta, `$016D/6F/71=$FF`, `$0109=$FF`, `$014F=$1E`). En carrera el gancho de `80:806E` copia x=0→x=1 cada fotograma, pero el bucle de pausa llama a `84:ECC0` desde `80:80B5` y no pasa por ahí. Copiar x=0→x=1 también tras `80:80B5` quita el negro pero deja ver un Mode 7 corrupto (hierba ampliada), así que NO es la solución: esa mitad inferior no contiene la vista de carrera en ese estado (la tabla de matrices/IRQ de la pausa es otra). Sospecha: el estado aparece tras pulsar X o Select (conmutación mapa/retrovisor vanilla, ver `$0D50/$0D52`, `$0D6B=$80`), no tras Start. Revertido; el candidato no cambia.
- **STANDINGS:** el rótulo y las reglas están centrados (regla 16..239, centro 127,5; panel 8..247), pero las filas de texto ocupan x=41..245 (centro ≈143, rozan el borde derecho del panel): hay que desplazarlas ≈15 px a la izquierda. Pendiente de localizar qué dibuja las filas (BG o sprites) y si es así también en el juego vanilla.
- Perfilador: `tools/core_patch_prof.py` reproduce el core de perfil (`cores/bsnes_prof.so`); `OAMW=f` ahora vigila WRAM `$0100–$04FF` (último PC que escribió cada byte).

### 2026-10-01 (noche, 2) — Bloque negro RESUELTO: Select+Start = "GIVE UP?" y Select alterna mapa/retrovisor
- Observación del usuario: el bloque negro sale una vez sí y otra no con Select+Start. Confirmado: `80:9F1A..9F50` (rama 1P, `$0144==0`) alterna `$0174` entre 6 y 2 al pulsar Select o X (máscara `$2040`); con `$0174=2` el modo es `$10` (vista "mapa/retrovisor" del original → fundido a negro de la mitad inferior, que aquí es la carrera). Medido con `usa_bloque_payload.bin`: ROM anterior → 0,1,2,3 toques de Select = sin negro/negro/sin negro/negro; ROM nueva → nunca negro.
- Arreglo: 1 byte, `80:9F49` `02→06` (`LDA #$0006` siempre) en `tools/build_usa_camara.py`. 2P intacto (rama `$0144!=0` no se toca). Select y X quedan sin efecto en 1P hasta que exista el conmutador mapa/retrovisor. Candidato nuevo sha `75e11ee9fec84920…`.
- Panel RESULTS/STANDINGS (USA): navy en x 8..247 (margen 8/8) e y 15..214 (margen superior 15, inferior 9: 3 px más abajo que centrado 12/12).
- Nota de herramienta: `read_file` de un PNG con el mismo nombre devuelve la versión anterior; usar nombres nuevos.

### 2026-10-01 (noche, 3) — Tabla "LAP TIME" del final de carrera centrada en Y
- Aclaración del usuario: la tabla a centrar NO es STANDINGS (pantalla posterior) sino la tabla "LAP TIME" (L1..L5 + TOTAL) que flota sobre el circuito al acabar (`states/usa_tabla_payload.bin`). Está hecha de sprites OAM 28..102 (atributo `$29`, tiles `$80..$CA`), escritos por el motor de texto de sprites `81:DA16/DA65`; en vanilla ocupa Y 21..97 (mitad superior). El panel RESULTS/STANDINGS (15..214) no se toca.
- Parche: rutina `88:9400` (llamada con `JSR $9400` desde el barrido `88:9100`, solo en 1P por la puerta): si el slot 28 tiene tile `$80`, atr `$29` y Y==`$15` (tabla sin desplazar; evita sumar dos veces), suma `LAPDY=53` a la Y de los slots 28..102 con atr `$29` y Y<`$A0`. Bloque 21..97 → 74..150 (centro 112). Coste: ~60 ciclos CPU por vuelta cuando no hay tabla.
- Verificado con `usa_tabla`: aparición animada fotograma a fotograma (L1..L5, línea y TOTAL) con la posición desplazada; el primer fotograma tras cargar el estado sale sin desplazar porque ese OAM viene del propio estado. Los iconos de posición 1–4 de la izquierda (slots 0..7) no se mueven.
- Candidato nuevo sha `451c7607b91103d9…`. `tools/env_rapido.sh` reconstruye `/tmp/drive` (se borra entre turnos).

### 2026-10-01 (noche, 4) — Ajuste: tabla LAP TIME + caras de los 4 primeros puestos, +15 px
- Decision del usuario: dejar la tabla como en vanilla (el +53 de la prueba anterior se descarta) y bajar TODO 15 px (mas abajo chocaria con el numero de puesto grande): `LAPDY = 15` en `tools/build_usa_camara.py`.
- Las caras (sprites OAM 0..7, Y 39/56/73/90; ocultas en carrera con atr `$33` y X bit8, visibles al final con atr `$3D`) tienen la Y escrita una sola vez por el juego: la rutina `88:9400` (128 bytes) las pone a Y absoluta (+LAPDY) cuando slot1 tile `$40`+atr `$3D` y slot0 Y==`$27`; la tabla (slots 28..102) se desplaza como antes. Candidato nuevo (sha en la salida del builder).

### 2026-10-01 (noche, 5) — Aviso del usuario: borde de carretera que "empieza abruptamente" junto al horizonte (SIN diagnosticar)
- Ubicación en `usa_tabla_payload.bin` (pantalla 256x224, coordenadas de 1x): marca azul/verde de 2–3 px en x 137..140, y 32..34 (justo bajo la "TI" de "TIME" cuando la tabla está en su sitio vanilla); el borde de colores de la izquierda acaba en x≈59, y≈40 y entre ambos hay tierra lisa (~78 px).
- Datos: la escena está congelada (fin de carrera), la marca es idéntica en los fotogramas 0..240, no es sprite (OAM no tiene nada ahí) → es suelo Mode 7, en las primeras líneas del Mode 7 (el cielo/horizonte acaba en y≈31). En carrera (puente, `usa_bloque`) el borde lejano de la izquierda sí se ve como línea fina discontinua hacia el punto de fuga.
- Comparación con cámara vanilla (build con `m.S_MAX=0`) en el mismo estado: la imagen cambia mucho (geometría distinta), por tanto no concluyente. Pendiente: estado de carrera donde se vea el fallo, volcar la matriz por línea (DSP raster) de las primeras líneas y ver si saturan o si es aliasing normal del Mode 7 en la zona lejana.

### 2026-10-01 (noche, 6) — LAPDY 15 → 20
- Decision del usuario tras ver la secuencia: 5 px mas abajo (`LAPDY = 20`: tabla Y 41..117, caras 59/76/93/110). Sigue por encima del numero de puesto grande (lineas ~135+). La marca azul/verde del horizonte se atribuye a la forma irregular del circuito (usuario); no se toca.

### 2026-10-01 (noche, 7) — Select / retrovisor: lectura del código vanilla (sin cambios en la ROM)
- Confirmado por el usuario en la ROM vanilla: el retrovisor se ve sobre un bloque negro. Es lo que dibuja `84:EDC7` (modo `$10`) cuando `$0174==2`: pone la vista afectada (`$1E88`=arriba, `$1E8A`=abajo) en negro con mate de color (`$016A=$AD`, `$016C/6E/70=$FF`, `$0108`/`$014E`/`$017A` = ventanas) y tablas de ventana HDMA `$7F:E524` / `$7F:E550` (esta última es la que probablemente abre el hueco por el que se ve el Mode 7 del retrovisor). `84:ED40` (modo `$12`, vista normal) pasa a `$10` si `$0174==2`; `EDC7` vuelve a `$12` si `$0174==6`. Select/X (máscara `$2040`) alternan `$0174` en `80:9F1A..9F50`.
- En el candidato (carrera a pantalla completa) no existe esa vista inferior, por eso solo se veía el bloque negro; con Select anulado en 1P (`80:9F49`) ya no sale.
- Para hacer el conmutador hace falta ver el retrovisor vanilla real (forma del hueco, qué líneas ocupa, matriz Mode 7 que usa). Pendiente: estado de la ROM vanilla USA con el retrovisor activo.

### 2026-10-01 (noche, 8) — Digito de puesto 16 px mas arriba
- Peticion del usuario: el numero grande se montaba sobre `car x3` y `moneda xN`; con pantalla completa no hace falta. `DIGBLANK = 0x50` (antes `$60`) en `tools/build_usa_camara.py`: el tramo en blanco de la tabla HDMA del digito (`$7E:0AC0`) pierde 16 lineas. Medido con `usa_tabla` (diferencia entre fotogramas): digito Y 137..193 -> 121..177 (57 lineas, X 193..224). Contador de coches OAM Y=179 (visible 180..187), monedas Y=188. Tabla LAP TIME acaba en Y 117 (sin solape en X). Candidato nuevo sha `bcfad01aef1bcbfd…`.

### 2026-10-01 (noche, 9) — Correccion: solo el digito GRANDE sube; el pequeno vuelve a su sitio
- Aclaracion del usuario: hay dos tamanos. El pequeno (normal, a la derecha de `car x3`/`moneda`) debe quedar donde estaba; el GRANDE (animacion breve al cambiar de puesto, permanente al terminar) es el que sube 16 px.
- Estructura de la tabla HDMA del digito (`$7F:E500`, canal 7 indirecto con repeticion): pequeno = 36+44 lineas en blanco + 20 de digito (`94 b0 e7`); grande = 41 en blanco + 44 (`ac 00 e8`) + 20 (`94 b0 e8`). Prefijo de la tabla del hack (`$7E:0AC0`): `$60` (pequeno, sitio original, Y 176..195) y `$50` (grande, Y 121..177).
- Rutina nueva `88:9500` (+ tabla `88:9600`, 40 bytes): suma las lineas en blanco B de los tramos no repetidos (B=80 pequeno, 41 grande) y escribe el prefijo `$50 + round(16*(B-41)/39)`: interpola la subida durante la animacion. Verificado: `usa_tabla` -> prefijo `$50` (grande, Y 121..177); `usa_bloque` (digito pequeno) -> prefijo `$60` (sitio original). La interpolacion intermedia no se ha podido ver (no hay estado con el cambio de puesto en curso).
- El stub del digito (`88:87A0`) ya no escribe el contador del prefijo; hace `JSR $9500` tras copiar los tramos.

## Variante de prueba (no oficial): `roms/usa_camara_prueba_digito.sfc`
Se genera con `SMK_PRUEBA=1 python3 tools/build_usa_camara.py` (sin la variable sale el candidato oficial, idéntico byte a byte).
- Dígito pequeño en la posición del GRANDE (prefijo `$4E`→`$50` interpolado, fila inferior 177).
- Dígitos +4 px en X: rutina `88:9700` suma `$0404` a las ventanas HDMA del dígito en sitio; marca de "ya desplazado" = `W2L=$FF` en la primera línea de ventana 2 vacía (el juego la borra al regenerar los datos).
- 🚗×3 y 🪙×N +15 px en X: rutina `88:9800` (asignaciones absolutas por frame).
- Sin validar en animación real de cambio de puesto (no hay estado).

### Actualización: variante `usa_camara_prueba_hud_sup.sfc` (sustituye a `usa_camara_prueba_digito.sfc`, eliminada)
`SMK_PRUEBA=1 python3 tools/build_usa_camara.py` (sin variable = oficial, idéntico).
- 🚗×3 / 🪙×N arriba a la izquierda (`88:9900`): margen visible 15 px izq. / 6 px sup. (sprite coche X=11, Y=5; monedas X+8, Y+9).
- Dígito pequeño y GRANDE con la línea base original de las monedas (fila 195): prefijo `$60` (pequeño) → `$62` (GRANDE).
- Desplazamiento X de los dígitos (`88:9700`, byte a byte, solo ventanas no vacías, marca W2=(FF,FE)): GRANDE +4, pequeño −10 respecto al original (centrado con el GRANDE: ambos centro ≈221).

### Variante `usa_camara_prueba_hud_sup.sfc` — ronda 3 (contadores abajo, RANKED OUT, RETRY)
- 🚗×3/🪙×N abajo a la izquierda (`88:9900`): margen izq. 15 (visible) e inferior 8 (fila 215 es la última visible de las monedas; el marco del emulador tiene 3 filas negras arriba y 5 abajo). Posición absoluta por frame sin comprobar la Y previa (robusto frente a estados guardados con otra variante).
- Dígitos: borde inferior en 215 (prefijo `$74` pequeño → `$76` GRANDE). X: GRANDE +4, pequeño −10 (centrado). `88:9700` con vía rápida (compara la primera línea con la marca FF,FE) y vía lenta solo al regenerarse los datos; una vuelta de bucle ≈ 130 ciclos en reposo, ≈ 5k ciclos el fotograma del cambio de puesto (provoca 1 fotograma de ralentización solo en escenas extremas: p. ej. explosión de monedas).
- RANKED OUT: las letras caen por abajo y reaparecen por arriba (Y de 8 bits). En vanilla el mapa las tapa; aquí gancho `81:B0B0` → `88:9A00` aparca en Y=$F0 las letras (tiles $E6..$F7) con Y inferior 100..223 (solo 1P).
- Menú RETRY/END (`81:A883`, 4 constantes): +64 en Y (debajo de RANKED OUT, separación 12 px como arriba) y −25 en X.
- Pendiente: monedas perdidas (se ven ~2.5× más altas: es la perspectiva ampliada, los objetos siguen la proyección real).
- `SMK_SKIP=rk,dx,hud` y `SMK_DBG=1` solo para depurar.

## Variante de prueba "ronda 4" (HUD abajo, margen 7 px, X vanilla, retirada oscura, monedas)

Solo en `roms/usa_camara_prueba_hud_sup.sfc` (`SMK_PRUEBA=1`); el candidato oficial no cambia (`cmp` idéntico).

- **Margen inferior 7 px**: HUD (coche Y=196, monedas Y=205) y los dos dígitos terminan en la fila 211; la franja negra empieza en la 219.
- **Dígitos en su X vanilla**: `DXON = False` (el desplazamiento DX queda en el código pero no se emite). Además desaparece el tirón de la sacudida de monedas (`Monedas_perdidas`: 399/399 fotogramas).
- **Fondo oscuro al retirarse**: en el modo RETRY/END el juego oscurece con la tabla HDMA del canal 7 (`$7F:E500`, ventana `$E528`) y con los colores de la región superior (`x=0`), pero la región inferior (`x=1`, líneas > 107) recibe cada fotograma los valores "claros" de `84:EDB3`. Dos ganchos:
  - `84:EDB3` → stub `88:9BC0`: hace lo mismo y, en 1P, copia `x=0 → x=1` (`88:9000`).
  - `81:A883` (dibujo del menú) → stub `88:9B80`: devuelve el canal 7 a `$7F:E500` y copia colores, solo en 1P y si la tabla no es la del dígito (`$7F:E501 != $24`).
- **Moneda del objeto** (`85:E6F3`, dibujo de partículas con Y relativa a la posición vanilla del coche, Y≈70): en 1P el coche está 88 px más abajo → stub `88:9C00` suma `$5800` a la Y (solo 1P). Verificado: la moneda nace sobre el coche igual que en vanilla (Δ = 88 px exactos).
- **Las "chispas" eran monedas que saltan** (perdidas al chocar, recogidas y uso del objeto): las tres salen por `85:E6F3`, así que el mismo stub las corrige. Medido con `tools/oamseq.py`: en las tres, la moneda nace donde el coche (Y vanilla + 88 px exactos en toda la trayectoria; salto de 42 px idéntico al vanilla). Sin el stub nacían en Y≈66 con el coche en Y≈158.
- Herramienta nueva: `tools/oamseq.py` (lista por fotograma las entradas OAM que cumplen un filtro; `SCR=script`).

### Ronda 5 (variante de prueba)
- Menú RETRY/END (fondo oscuro) 8 px más arriba: inmediatos `81:A883/A88C/A894/A8CD` con Y−8 (`$68/$68/$78/$64`).
- Menú `GIVE UP? / YES / NO` (START en carrera) 40 px más abajo en 1P: `81:A28F` → stub `88:9C40` (texto, Y `$20→$48`) y `81:A2A3` → stub `88:9C80` (selector, `+$2800`, vuelve a `81:AA63`); ambos solo con `$7E:00AA == $1000`. 2P queda como vanilla.
- Alineado X de dígitos: el usuario eligió la opción **C** del mockup (pequeño −8 px, GRANDE sin mover): `DXON = True`, `DXS = -8`, `DXG = 0` (`88:9700`). Medido: el 8 pequeño queda en x=216..231 y el GRANDE en x=192..241 (antes 224..239: diferencia de centros 15 → 7 px). Coste: 1 fotograma perdido de 399 en el cambio de puesto (una sola vez).

### Coste en fotogramas de la variante de prueba (medido con `tools/lag.sh`, `Monedas_perdidas`, B pulsado)
- Fuentes de fotogramas perdidos, aisladas por parches: (1) desplazamiento X del dígito (`88:9700`) al regenerar el juego los datos de ventana; (2) stub de `84:EDB3` (copia x=0→x=1 redundante en carrera) coincidiendo con el fotograma de la explosión de monedas.
- Corregido: GRANDE ya no se recorre (`DXG=0` → solo se marca); el stub de `84:EDB3` copia solo si el manejador de carrera no corrió (marca `$7E:0A9E` fijada por `88:9B00`); el stub de `85:E6F3` lee el desplazamiento de `$7E:0A9C` (fijado una vez por fotograma).
- Resultado: sin desplazamiento X del dígito, 399/399. Con él, 1 fotograma perdido cada vez que el dígito pequeño reaparece tras un cambio de puesto (no por carrera: por cambio de puesto).

### Ronda 6 (variante de prueba) — arreglo de fondo del tirón del dígito y banner Ranked Out
- **Dígito pequeño**: los datos de ventana de los 8 dígitos pequeños (`$7F:E580..E7FF`, 8×20 líneas×4 bytes) los descomprime el juego una sola vez al inicializar (`84:EA17`, `JSL $84E09E` en `84:EA23`) y luego son estáticos. Se redirige esa llamada a `88:9D00`, que ejecuta la descompresión original y desplaza −8 px en X cada ventana no vacía (solo 1P). El desplazamiento en caliente (`88:9700`) queda desactivado (`DXON=False`): coste cero durante la carrera. Verificado tras un reinicio (RETRY): 198 ventanas desplazadas exactamente −8, 122 vacías intactas, datos GRANDE idénticos al candidato.
- **Banner Ranked Out**: el stub RK (`88:9A00`) resta 5 px a la Y de las letras (tiles `E6..F7`) en 1P. Las letras rebotan (filas 76..94 tras el cambio); las caras del menú empiezan en la fila 100, así que la separación mínima es de 5 px.
- **Banners de texto (1P, solo variante de prueba)**: GAME OVER (+48 px en los slots 28..59 = rótulo animado y copia final; letras que entrarían por debajo de la fila 192 se ocultan; las de Y>=$F0 / fragmentos arriba también se desplazan), ROUND N (+56 px, rutina de sprites `80:C096`, intercepción en `80:C0B3` → `88:9F80`) y Ranked Out (−5 px y se aparcan por separado los sprites que queden entre las filas 100 y 223; antes un sprite de la fila inferior parpadeaba un fotograma en el borde inferior). Código en el stub `88:9E00` (enganche `81:B0B0`).
- **Plátano (1P)**: la distancia detrás del kart pasa de 8 a 5,5 unidades (`LDY #$0800` → `$0580` en las llamadas a `80:FE52` de `80:F3F0` y `80:F475`, puente `88:9FC0` solo en 1P). A 4 unidades el propio kart lo toca; a 5,5 no.
- **Humo/chispas del aplastamiento (1P)**: el kart aplastado dibuja el humo con `80:DEB9` (Y = tabla + `$BA`, `$BA`=0 para P1) y salía 88 px más arriba que el kart. Se sustituye `TAY ; JSR $DEB9` (`80:D9BD`) por `JSL 88:A000`, copia de la rutina que suma `s = $0A86` (88) a la Y solo en 1P. Verificado con el state `humo aplastamiento`.

- **Topo (Monty Mole) pegado en pantalla (PRUEBA):** al chocar con un topo, vanilla lo coloca sobre el kart (rutina `80:FD6C`, objeto de estado `$60,x` negativo) hasta que el jugador lo sacude moviendo la cruceta izquierda/derecha varias veces (`80:A460`). Esa rutina calcula la Y con `$BB` (origen de jugador, 0 en 1P), así que con el kart 88 px más abajo el topo quedaba flotando delante. Parche: `80:FD88` (`ADC $BB / STA $1E`) → `JSL 88:A100`, que suma además `$7E:0A86` en 1P. Omitible con `SMK_SKIP=mo`. No es un fallo de velocidad: el topo no se quita si no se sacude, igual que en vanilla.

- **Monedas (corrección, PRUEBA):** el gancho `88:9C00` de `85:E700` sumaba `$0A9C` con direccionamiento absoluto (`ADC $0A9C`), que depende del DBR de la llamada; en algunos contextos leía ROM y desplazaba la moneda (+69 en X e Y en lugar de +88 en Y). Ahora usa `ADC $7E0A9C` (largo). Comprobado con `MonedaDesp` (moneda recogida sale sobre el kart, X sin cambio) y `Monedas_perdidas`.

- **Plátano que desaparece tras la nube (`PlatanoNube`):** no es un fallo del hack (idéntico en el candidato oficial). El juego solo tiene 2 objetos plátano (`$1A00`, `$1A80`, lista `80:F174`). Cuando un rival (kart `$1700`) suelta un plátano (`80:F17A`) y los dos están en uso, se recicla el más antiguo: ese objeto pasa de (846,117) a la posición del nuevo plátano. La nube del cartel de vuelta pasa por casualidad en el mismo momento.

### 2026-10-01 (ronda 6, cierre) — Variante promovida a candidato USA
- `tools/build_usa_camara.py` ahora construye por defecto la variante de la ronda 6 (HUD abajo-izquierda, dígitos, menús, banners, plátano, humo, topo, monedas): `roms/usa_camara_candidato.sfc` (sha `ad1443ce0333f679…`). `SMK_PRUEBA=0` genera el candidato anterior (`usa_camara_candidato_anterior.sfc`, HUD arriba). Lag 399/399 en Monedas, Humo, Topo, MonedaDesp, PlatanoNube. IPS pendiente del repaso de 2P por el usuario.
- Pendiente opcional (conmutador Select 1 nada / 2 mapa / 3 retrovisor): el usuario propone el retrovisor en la mitad superior sin el bloque negro. Limitación: Mode 7 es una sola capa (BG1), así que el panel solo puede ocupar líneas enteras de ancho completo (sin recuadro con el escenario a los lados). Hace falta generar una matriz Mode 7 trasera (cámara girada 180°) para esas líneas en la tabla HDMA y restaurar Select (`80:9F1A..9F50`, `$0174`). No iniciado.

### 2026-10-01 (ronda 7) — Conmutador Select (mapa / retrovisor): primer sondeo (línea aparte, sin cambios en el candidato)
- Vanilla 1P: arriba la vista de carrera (112 líneas), abajo mapa (Mode 7 cenital + sprites) o retrovisor (Mode 7 de cámara girada dentro de un bloque negro hecho con ventana + mate de color, `84:EDC7`). Select/X alternan `$0174` (`80:9F1A..9F50`). El hack fullscreen base (53 bytes de diferencia con la ROM vanilla: `80:8B42/8B67/8BC2/8BDA` anulan los ajustes de la región inferior, `80:C86F/C88B` y `80:C93A` cambian el desplazamiento y los límites de la proyección de objetos) usa la región inferior como continuación de la vista.
- Matrices Mode 7 por línea: se ven en el log del core (`a=211b..211e`, ~193 filas por fotograma, A,B,C,D con la escala decreciente hacia abajo). Copias en WRAM: A `7E:4540`, B `7E:D540`, C `7E:6A00`, D `7E:A540` (una entrada por fila y una segunda serie a partir de la entrada ~100).
- Experimento (`SMK_NEG=a,b` en `tools/build_usa_camara.py`, stub `88:A200` enganchado en el envoltorio de `80:806E`; harness `NEG=a,b`): negar esas entradas NO cambia la imagen, ni escribiendo desde el NMI ni desde el harness → esas tablas son un buffer intermedio; la fuente real del HDMA es otra. Pendiente: localizar el buffer HDMA real (canales 3–6) y, después, generar la matriz trasera (A..D negadas con compensación de la fila) para una franja superior, y la cenital para el mapa.

### 2026-10-01 (ronda 7, sondeo 2 del conmutador Select)
- **Correccion del sondeo 1**: las pruebas de negar tablas eran invalidas (negaban con signo alterno cada fotograma, y usaban la fila de angulo equivocada). Repetidas con `-abs(v)` y la fila correcta, y poniendo a cero **todo** `7E:4000..FFFF` en cada fotograma: la imagen no cambia. Esas tablas (generadas en `81:F964..F9DF` con el comando Raster del DSP-1, 128 filas x 96 entradas, stride `$C0`) son de precalculo; el HDMA vivo no las lee directamente.
- Barrido por bloques (poner a cero 2 KB de WRAM por fotograma y comparar el fotograma 30): solo importan `7E:0000..17FF`, `7E:3800` (kart/sombra), `7F:E000`, `7F:F800`. `7F:0000..0FFF` es el mapa de tiles Mode 7; `7E:4000..FFFF`, `7F:1000..DFFF` son irrelevantes en carrera.
- **Tabla HDMA viva en `7E:0640`** (4 bloques de 13 bytes: `18 00 00 | e0 ptr1 | e0 ptr2 | 00 ...`, punteros en banco 7E: `1B00/9B00`, `4B00/CB00`, `1440/9440`). Los datos apuntados son rampas suaves por linea (-137,-134,... / 66,65,... / 82,79,...): parecen **scroll/centro por linea**, no las matrices. Cambiar el byte `7E:0645` en cada NMI (builder `SMK_POKE=645:3c`, stub en `88:A300` enganchado al envoltorio `80:806E`) **si cambia la imagen** (desplaza/deforma la zona del suelo), asi que esta tabla se puede reapuntar a buffers propios.
- Las matrices A/B/C/D del log (`$211B..$211E`, 193 lineas, impares = media de vecinas) coinciden con filas de `7E:4000+fila*$C0` (A), `7E:D000+..` (B), pero su fuente HDMA real sigue sin localizar (no es ninguna de las tablas de angulo ni `7E:0640`).
- `harness/drive.c`: nuevas variables `NEGALL`/`LO`/`HI`/`ZERO` (barrido por bloques) y `POKE=addr:hex` (se pisa en el NMI del juego: usar el stub del builder). La ROM por defecto no cambia (sha `ad1443ce…`).

### 2026-10-01 (ronda 7, conmutador Select: prototipo funcional, LINEA APARTE)
- **Fuente real de las matrices**: 4 canales HDMA indirectos (ch1..ch4 -> `$211B..$211E`), tabla en `7E:0640` (bloques de 13 bytes: `18 ptr0 | e0 ptr1 | e0 ptr2`), segmento 1 = lineas 24..119, segmento 2 = 120..215. Los datos estan en **ROM**: bancos `C9` (A, C) y `CA` (B, D) (registros `$4317/$4327/$4337/$4347`), una fila de 96 palabras por angulo (stride `$C0`). La rutina de `81:FA9D` (vanilla) calcula `ptr = fila*$C0` con `fila=|h|` (A,D), `|h+$40|` (B) y `|h-$40|` complementado (C), con `h = $95` (byte alto del angulo `$94`); el hack anade el segmento 2 como `ptr+$8000`.
- **Retrovisor**: se recalculan los 4 punteros con `h+$80` (angulo + 180 grados) y la imagen sale correcta (pista detras, coches CPU al fondo).
- **Mapa**: se reapuntan los 4 canales al banco `$88` (`$4317..=$88`): A=D=`$0400` (88:A700), B=C=0 (88:A7C0). Sale el circuito cenital centrado en la posicion del kart (norte arriba).
- Builder: `SMK_SEL=1 python3 tools/build_usa_camara.py out.sfc` -> `roms/usa_camara_select_prueba.sfc` (stub NMI `88:A440`, `fold/mul` `88:A400`, Select `88:A600` enganchado en `80:9F41`, flag en `7E:08A0`, temporales `7E:08A2..08AA`). Ciclo: nada -> retrovisor -> mapa -> nada (el orden pedido, nada->mapa->retrovisor, es solo cambiar el orden del contador). Lag 398/398.
- Pendiente de pulir: sprites (CPU/objetos) se dibujan con la proyeccion delantera, el mapa deberia escalarse/centrarse mejor (pivote en la zona del kart), ocultar el HUD de objetos opcional. La ROM por defecto no cambia (sha `ad1443ce…`).

## Luigi convertido en basura gráfica (corregido)
- Causa: el stub de la firma del título estaba en `80:92F2` (supuesto relleno 0xFF), pero esa zona es parte de la tabla `$80:9292` de fotogramas de kart (entradas `0xFFFF` = "no subir gráficos") para los fotogramas `$1030` = `$60..$70`. Al leer código en vez de `0xFFFF`, la rutina `80:8EED` hacía DMA a VRAM desde datos erróneos (banco 84, `F9B0`, que es código) y el kart se dibujaba como ruido.
- Arreglo: el stub se mueve a `80:FFA0` (16 bytes a 0 antes de la cabecera; `tools/add_signature.py`, `S = 0xFFA0`, sin NOPs). Comprobado: no hay otra diferencia con el vanilla en zonas de relleno (barrido de todos los bytes cambiados); título y menú idénticos fotograma a fotograma; regresión de todos los states sin cambios salvo `states/varios/luigi_basura_payload.bin`.
- Release regenerada tras este arreglo: CRC32 `370A3F82`, SHA-1 `E1DB322815888CBB6BF97B2D4095717D005E17F1` (sustituida por la siguiente sección).
- Herramientas auxiliares nuevas: `tools/sheet2.py`, `tools/cmp.py`.

## Resto de color bajo el dígito GRANDE (Ranked Out) — corregido
- Síntoma: bajo el dígito GRANDE (p. ej. el 6) aparecía una franja de 3 líneas (filas 216..218) con restos de suelo medio oscuro. El dígito ocupa las filas 155..211; las filas 212..215 están vacías; la franja aparece en 216..218, fija en pantalla (no sigue al dígito: con la tabla subida 16 filas seguía en su sitio).
- Descartado con pruebas (POKE en el `7F:ED00`, `E524`, tabla de ventanas): no es dato de ventana (es aditiva a W1 y W2, abiertas, cerradas o invertidas), ni sprite (OAM sin nada en esas filas), ni la firma/Lakitu/Luigi (también está en `usa_camara_candidato.sfc`). También aparece en la pantalla RETRY de 2P. La causa exacta del desenmascarado (probablemente los registros de color/subpantalla por región tras la HDMA de matrices, que cubre solo hasta la fila 215) no se ha identificado.
- Arreglo (no toca cámara ni dígitos): `tools/ranked_borde.py`. El IRQ del modo 8 (`80:8B8F`, V=211) programa el siguiente IRQ en V=`$DB` (219, donde el juego apaga la pantalla). El gancho `80:8B93` (`LDA #$DB / STA $4209`) pasa a `JSL 88:9A40 / NOP`; el stub carga `$D8` (216) solo si es 1P (`$00:00AB == $10`), el modo de Lakitu es Ranked Out (`$7E:1C30 == 8`) y la pantalla es la oscura (`$00:016B == $AD`; la tabla LAP TIME gris usa `$3D`). En el resto de casos carga `$DB` como antes.
- Verificado: franja eliminada (filas 216..218 negras en `digito6_payload.bin`, 69 fotogramas distintos solo en esas 3 filas); regresión de todos los estados: sin diferencias fuera de las filas 216..218 de las pantallas oscuras de Ranked Out/Game Over (la tabla LAP TIME gris y las carreras no cambian). Único detalle: en `Time_trial_artefactos` la fila 107 cambia en 2/255 de brillo cada 4 fotogramas (imperceptible).
- (Release intermedia: CRC32 `CCBBF9C4`.) Cadena: `usa_camara_candidato.sfc` → `add_signature.py` → `lakitu_sombra.py` → `ranked_borde.py`.

## Parpadeo del marcador de monedas/vidas (1P) — corregido
- Estado del usuario: `states/varios/parpadeo_marcador_payload.bin` (inicio de carrera con Lakitu). En los fotogramas 77/78, 83/84, 139... las monedas aparecían 17 px más arriba, pegadas a los coches (OAM 20..23 con Y=188 en vez de 205). Medido en 700 fotogramas: 19 fotogramas malos.
- Causa: el bucle de espera del NMI (`80:805C`) está redirigido a `88:8000`; al salir de la espera llama a `88:8035`, que escribe Y=`$BC` (la Y vanilla, 188) en los 4 sprites de las monedas al empezar la lógica de cada fotograma. El barrido de final de fotograma (`88:9100` → `88:9900`) los sube a 205 después. Si la lógica dura más de un fotograma (lag: arranque con Lakitu), la DMA del OAM (IRQ de la línea 219) cae entre las dos cosas y ese fotograma se ve el marcador sin subir. Los fotogramas con lag se reconocen porque el cronómetro `$0100` no avanza (77, 83, 139...).
- Arreglo: `tools/hud_coin_y.py`. `88:8035` → `JMP 88:9AC0`; el stub solo escribe `$BC` si no es 1P (`$AA != $1000`). En 1P la Y final (205) la deja el barrido y nadie la vuelve a tocar. 2P igual que antes.
- Descartado: colocar el HUD dentro del IRQ de la 219 justo antes de la DMA (`tools/hud_irq.py`, no incluido): el IRQ es muy sensible al tiempo (añadir 2 NOP más al stub corrompía gráficos de todo el fotograma) y esa vía no es segura.
- Verificado: 700 fotogramas del estado del usuario con 0 fotogramas malos; regresión de todos los estados (150 fotogramas): las únicas diferencias son la caja del marcador (x19..51, y188..213) en fotogramas con lag de `parpadeo_marcador`, `Monedas_perdidas` y `luigi_basura` (parpadeos corregidos); 2P y todo lo demás idéntico.
- Release regenerada: CRC32 `1FA9C82B`, SHA-1 `A4D02EA162FAE99C165AACDB1E6DF0F2FFEBAC87`. Cadena: `usa_camara_candidato.sfc` → `add_signature.py` → `lakitu_sombra.py` → `ranked_borde.py` → `hud_coin_y.py`.


### Regresión final (release `1FA9C82B`)
- Comparada con la ROM anterior a los dos últimos arreglos (candidato + firma + Lakitu, CRC `370A3F82`) en todos los states de `states/` (incluidas las carpetas `copa`, `mario_oct`, `mario_sep30` y `varios`; excluidos los vanilla/EU), 200 fotogramas cada uno, manteniendo B (acelerar) pulsado (`/tmp/acc.txt` = `0 5000 0`).
- Diferencias solo en: filas 216..218 de las pantallas oscuras de Ranked Out/Game Over (arreglo del resto bajo el dígito), caja del marcador en fotogramas con lag (parpadeo corregido) y fila 107 de `Time_trial_artefactos` (2/255 de brillo). Además, en `copa/Parpadeo` la animación de los créditos va un fotograma desfasada desde el 171 (los 4 sprites cambian de fotograma, no hay fallo visual; lo provoca el stub de `ranked_borde.py` al variar el reparto de fotogramas con lag).
- Fotogramas con lag (cronómetro `$0100` sin avanzar) en 600 fotogramas: idénticos entre ambas ROM en los 8 states probados.

## Limpieza del workspace (2026-10-03)
- Eliminadas la carpeta `diagnostics/` (las capturas citadas en secciones antiguas de este documento ya no se conservan), ROMs de prueba/Europe no publicadas (`eu_camara_candidato`, `usa_camara_select_prueba`, `Europe Full Screen (ported)`; esta última se regenera con `patches/base_fullscreen_europe_portado.ips` sobre la ROM Europe), ~55 scripts experimentales (rama de orden OAM, bisecciones, constructor/portado Europe, `lookahead_zonas`, `hud_irq`…) y volcados sueltos.
- Nuevo `tools/reconstruir_release.sh`: reconstruye la ROM v1.0 desde la base y comprueba que es idéntica (verificado: CRC32 `1FA9C82B`).
- Reescritos `README_ES.md`, `TRANSFER_PROMPT_NUEVO_CHAT_ES.md` (el anterior está en `docs/ARCHIVO_prompt_transferencia_2026-09-29.md`), los README de `roms/`, `tools/`, `states/`, `cores/`, `patches/` y `MANIFEST.txt`.

## v1.1 (2026-10-04)
- Cadena de release: `build_usa_camara.py` → `add_signature.py` → `lakitu_sombra.py` → `ranked_borde.py` → `hud_coin_y.py` → **`fix_banda_hblank.py`** (todo en `tools/reconstruir_release.sh`, verificado: CRC32 `17EFB04F`, SHA-1 `342150EB6D1FE2F3888510472F46F74624E6D932`). IPS y BPS se generan contra la USA vanilla (`CD80DB86`); ambos verificados aplicándolos a mano.
- Cambios respecto a v1.0 (`1FA9C82B`): (1) píxeles blancos de la banda: el bloque de color-math de `88:88DE..88F6` se ejecuta ahora en H-blank (`88:A140`, 83 bytes) — confirmado en hardware real por un probador; (2) `LAPDY` 20 → 25 (tabla LAP TIME y caras, +5 px). Diferencia binaria con v1.0: 91 bytes.
- Regresión: 12 estados idénticos a v1.0 salvo la tabla; posición del kart tras 700 fotogramas idéntica (sin lag añadido); cronómetro idéntico a 10 y 300 fotogramas.
- Saltos/cajas de objeto (`Saltos.zip`): no es bug de física; la zona de recogida es una franja fina en el mundo (≈4 unidades de profundidad, ≈15 de ancho). Detalle en la conversación; pendiente comparación con vanilla.
- Comparación con vanilla (state del usuario, USA vanilla, 2026-10-04): mismo comportamiento. Ventana de aterrizaje que acaba recogiendo la caja: vanilla dy −8..+14 (≈23 unidades); fork v1.0 ≈ −31..−11 (≈21). Aterrizar demasiado pronto o tarde falla en ambos. En vanilla la recogida también depende de x (x=46 falla, x=45 recoge en y≈507). El parche solo suma `s` a la Y de pantalla; la colisión es en coordenadas de mundo y no se toca.

## 2026-10-04 — Candidato v1.2 (experimental): colisiones/muros/vacío (centro del suelo) y rescate de Lakitu

**Estado: candidato en `roms/candidato_v1.2.sfc` (CRC32 `D6EA0E4A`), parches en `prueba/`. NO es release.** Se reconstruye con `bash tools/reconstruir_v12.sh` (v1.1 + `make_camera_ramp.py` con `DF_MAX=12` + `lakitu_y.py`). `reconstruir_release.sh` ya no reproduce v1.1 (compara contra la release; usar `SMK_DF=0` si hiciera falta).

1. **Causa de muros/cajas/vacío (medida):** los sprites siguen la proyección DSP (pies del coche en fila ≈189–190), pero el suelo Mode 7 colocaba el punto de mundo del coche en la fila ≈152 → el punto de colisión quedaba ≈37 filas por encima de los pies (vanilla: 6). Todo lo que se decide por posición de mundo (muros, cajas, bordes de vacío) ocurre ≈1 baldosa antes de lo que se ve. Arreglo: desplazar el centro del suelo (`$0A8C/$0A8E`, tabla D en `88:8DC0`, rutina `88:8D80`): fila del coche 159→186 (pies 190 → 4 filas, vanilla 6).
2. **Rescate de Lakitu (dos fallos reproducidos y arreglados):** el guion de Lakitu (banco $85) guarda Y como palabra 8.8 y usa el bit 15 como signo. Con +88 px Lakitu pasa de Y=127 y el guion cree que ya salió por arriba: `85:DE68` terminaba el guion en cuanto empezaba a subir (Lakitu desaparecía, sin moneda); la moneda que sujeta (`85:E588`) tenía el mismo test; y los destinos de bajada (`85:DE59`, $6000/$4800) eran coordenadas vanilla (salto de Lakitu hasta el coche). `tools/lakitu_y.py` (bloques `88:8E10` y `88:9030`): Y sin signo en 1P, destinos +$5800, velocidades ×3 (bajada) y ×2 (subida) para conservar la duración vanilla (la moneda vive $60 fotogramas), moneda con +88 consistente.
3. **Rendimiento (medido, `HIST`):** margen libre en conducción normal: vanilla ≈28–30 % del fotograma, hack ≈14 %. En el rescate la lógica pide ≈380k ciclos maestros por fotograma de lógica (vanilla ≈281k) → 1 de cada 3 fotogramas cae en lag. Ganchos del banco 88 ≈35k/fotograma; el gate `JSR $8F00` se llama ≈48 veces/fotograma (≈3,2 %).

## Candidato v1.2 — optimizacion de rendimiento (cache del gate 1P)

**Problema medido.** El gate `88:8F00` (decide si el modo es 1P a pantalla completa; ~40 ciclos + JSR/RTS) se llamaba ~40-55 veces por fotograma desde los ganchos de la ventana de sprites. En el rescate de Lakitu la logica costaba 358k clk por fotograma (presupuesto 357k) y 18 de cada 100 fotogramas iban con lag (vanilla: 281k, sin lag).

**Cambio (`tools/gate_cache.py`, ultimo paso de `reconstruir_v12.sh`).**
- El resultado del gate (0 = pantalla completa, 1 = no) se guarda en `$7E:0A88` y se recalcula una vez por pasada del bucle principal, en los dos sitios que ya lo evaluaban en todos los modos: `88:88FE` (inicio de la espera de NMI, tras la logica) y `88:8917` (salida de la espera). `JSR $8F00; NOP x4` pasa a `JSR $8F00; STA $7E0A88` (STA no toca flags).
- Solo los 4 ganchos calientes (ventana de culling de sprites, `88:8A9B`, `8AB8`, `8AD6`, `8BEE`; ~35 llamadas/fotograma) leen la cache: `LDA $7E0A88; NOP x3` (mismo tamano, mismo Z). El resto (1-2 llamadas/fotograma, varios con escrituras a registros PPU o logica de transicion) conservan la llamada viva.
- Descartado: la cache en todos los ganchos. En una prueba de arranque desde reset hasta la carrera daba 1-2 fotogramas de discrepancia justo al entrar en carrera (cambio de modo a mitad de la logica, ganchos `88:8C6E` y `88:8842`). Con los 4 ganchos de aritmetica pura, 0 discrepancias.
- `lakitu_y.py` vuelve a usar la llamada viva (no depende de la cache).

**Resultados (`tools/perf.py`, 400 fotogramas desde el estado).**

| Escena | v1.2 antes | ahora |
|---|---|---|
| Conduccion normal (Rec_ours) | 15.5 % idle, 0 lag | 17.2 % idle, 0 lag |
| Rescate de Lakitu | 12.9 % idle, 35 lag | 8.6 % idle, 3 lag (con ventana 285-385: 0 lag, 5.4 % idle) |
| luigi_basura | 8 lag | 0 lag |
| Monedas_perdidas | 6 lag | 1 lag |

**Validacion.** (1) Build de depuracion: cada lectura de cache compara con el gate vivo y cuenta discrepancias en `$7E:3A00`: 0 en 20+ estados (1500 fotogramas) y en un arranque desde reset hasta la carrera pulsando A. (2) Imagenes identicas a v1.2 anterior en 8 estados sin lag (`tools/abframes.py`); en el resto solo cambia la alineacion por lag. (3) Excepciones: 1 fotograma de 166 en Rec_ours con 43 pixeles distintos en una linea lejana de pista (temporizacion de raster), y 1 linea negra mas en el separador del menu de seleccion de copa/pista (la IRQ llega antes).

**Limites.** Con cache en todos los ganchos, el rescate rinde ~4.5k clk mejor (0 lag), pero con riesgo de fotogramas erroneos al cambiar de modo. El resto del exceso respecto a vanilla es codigo de sprites (bank 80 `C300/BD00`), consecuencia de dibujar mas objetos/distancia con la vista ampliada.

Herramientas nuevas: `tools/abframes.py` (compara por indice de fotograma), `tools/abvideo.py` (alinea por cronometro, insensible al lag, ignora el cronometro del HUD), `tools/abtimer.py` (WRAM, ruidoso, no recomendado).
