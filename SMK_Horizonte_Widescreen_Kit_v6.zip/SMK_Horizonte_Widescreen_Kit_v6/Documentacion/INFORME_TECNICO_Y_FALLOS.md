# INFORME TÉCNICO: SUPER MARIO KART HORIZONTE (WIDESCREEN 16:9 EN BSNES-HD)

Este documento recopila el estado actual de la adaptación panorámica 16:9 de **Super Mario Kart: Horizonte (Hack P13)**, detallando exactamente qué modificaciones se han realizado en la ROM, qué errores críticos/cuelgues han ocurrido durante el desarrollo (y por qué fallaron) y cuáles son los problemas gráficos que todavía quedan pendientes de resolver.

---

## 1. Modificaciones Técnicas Implementadas hasta la Fecha (v6)

### A. Base Estable (Funcionalidades del Hack Horizonte Preservadas)
- **Rótulo `ROUND 1` Centrado (`0x89F94`)**:
  - En el hack Horizonte, el rótulo de inicio de carrera se diseñó para aparecer centrado verticalmente en la pantalla (mediante una llamada nativa a `$88:8F00` que aplica un offset `ADC #$38` / +56 píxeles).
  - Se mantiene la instrucción `20 00 8F EA EA EA EA` intacta en `0x89F94` para evitar que vuelva a la parte superior como en SNES vanilla.
- **Retratos de Clasificación al Cruzar la Meta (`0x89400`)**:
  - Corregida la subrutina `$88:9400` para que los retratos de los corredores no se corrompan ni se conviertan en baldosas de Toad en la parrilla.
- **Attract Mode Completo con los 8 Corredores (`0x8A34C`)**:
  - Restaurado el puntero de karts CPU para que la demo previa renderice los 8 vehículos completos y no solo a Mario.
- **Tasa de Cuadros Estable en Bowser Castle (`0x8A500`)**:
  - Ajustado el temporizador de ciclos V-Blank para garantizar 30 fps fluidos sin caídas.
- **Cursor de Menú por Defecto (`0x58227 = 0x00`)**:
  - El menú principal selecciona por defecto `1P Game`.

### B. Ampliación del Culling de Objetos Mode 7 (Bancos $00 y $01)
El motor de Super Mario Kart descarta el cálculo de sprites cuando su coordenada proyectada en Mode 7 excede el margen del cuadro 4:3 clásico. Se ensancharon las 6 compuertas principales de `$10..$20` a `$60..$C0` (192 píxeles de semiancho):
1. `0x0C892` (mínimo) y `0x0C895` (máximo): Rivales y proyección primaria.
2. `0x0C9A5` y `0x0C9A8`: Rivales alternativos e ítems arrojados.
3. `0x0C9CF` y `0x0C9D2`: Sprites secundarios (topos, tuberías).
4. `0x0CA1A` y `0x0CA1D`: Obstáculos fijos, plantas piraña y fantasmas de Ghost Valley.
5. `0x0ED8D` y `0x0ED90`: Pantalla dividida Jugador 1.
6. `0x0EDB7` y `0x0EDBA`: Pantalla dividida Jugador 2.

### C. Compuertas de Proyección de Escenografía (Banco $88)
En las direcciones `0x88BBC`, `0x88BC4`, `0x88BDB` y `0x88BE3`, los límites de descarte de la escenografía lejana se ampliaron de `$60` a `$C0` para sincronizarlos con la ventana 16:9.

### D. Subrutina `$8BC00` (Culling de Sprites 32..127)
- En `0x8BC00`, la ROM base Horizonte tenía una rutina que recorría los sprites 32 a 127 forzando su coordenada vertical `Y = $E0` (ocultándolos) si se detectaba que sobrepasaban el ancho clásico de 256 píxeles.
- En la versión v6, se reemplazó la cabecera de `0x8BC00` con:
  ```assembly
  0x8BC00: 08          ; PHP (guarda el registro de estado P en la pila)
  0x8BC01: 4C 03 91    ; JMP $9103 (salta al final de la rutina evitando el culling destructivo)
  ```

---

## 2. Lo que Ha Fallado Estrepitosamente (Cuelgues y Bloqueos)

### El desastre del cuelgue al entrar en carrera (Error de Pila PHP/PLP)
1. **El fallo cometido**:
   - En una versión experimental previa, se intentó desactivar la rutina `$8BC00` colocando `NOP`s (`EA EA EA`) en la llamada `0x89100` (`JMP $BC00`).
2. **Consecuencia observada**:
   - Al navegar por los menús todo parecía funcionar, pero en el momento exacto de iniciar la carrera (tras elegir circuito o salir de la parrilla de salida), la pantalla mostraba una franja negra horizontal, artefactos de video en los sprites de Luigi y el HUD, y **el juego se congelaba por completo**.
3. **Causa raíz descubierta en desensamblado**:
   - La rutina de salida de VBlank en `$88:919A` termina ejecutando una instrucción `PLP` (`28`), la cual **espera obligatoriamente** el `PHP` (`08`) que se ejecutaba al entrar en `$8BC00`.
   - Al reemplazar la llamada por `NOP`s, la instrucción `PHP` jamás se ejecutaba. Por tanto, en cada frame de VBlank se extraía 1 byte de más de la pila de la CPU mediante `PLP`.
   - Cuando el juego cambiaba de estado para iniciar el bucle de carrera, las direcciones de retorno (`RTS` / `RTL`) quedaron desalineadas por el desbordamiento de pila, saltando a memoria no ejecutable.
4. **Lección técnica aprendida**:
   - Nunca se debe omitir el `PHP` en esa cadena de VBlank. Cualquier bypass debe ejecutar primero `08` (`PHP`) antes de saltar.

---

## 3. Lo que Todavía NO Funciona (Problemas Gráficos Pendientes)

A pesar de las modificaciones de v6, persisten problemas visuales notorios al jugar en 16:9 (`bsnes_mode7_wsobj = unsafe`):

### 1. Marcador de Posiciones en Meta visible a la derecha en carrera
- **Síntoma**:
  - Durante toda la carrera, en el extremo derecho de la pantalla se ve una columna vertical fija con números y banderines: `1 2`, `2 3`, `3 4`, `4 5`.
- **Causa**:
  - En Super Mario Kart nativo de SNES (resolución 256×224), el juego "aparca" los sprites del marcador de meta en coordenadas horizontales X = 264..272 (fuera de la pantalla de 256 píxeles).
  - Al activar el modo panorámico de bsnes-hd con sprites inseguros (`wsobj = unsafe`, campo visual de 384 píxeles), el rango X = 256..384 se vuelve visible, revelando los números aparcados que deberían permanecer ocultos hasta que el jugador cruza la meta.
- **Reto pendiente**:
  - Mover o suprimir estos sprites (sprites OAM 0 a 7) mientras la carrera está en curso (por ejemplo, forzando su coordenada Y = $E0 en carrera o reubicándolos más allá de X = 384) sin romper la pantalla de resultados final.

### 2. Desaparición / Pop-in de Elementos de Fondo y Escenografía
- **Síntoma**:
  - En circuitos como **Donut Plains** (árboles lejanos, montículo de tierra a la izquierda), **Mario Circuit 1** (árboles sobre la colina al doblar a la izquierda) y **Vanilla Lake** (montañas nevadas del fondo), los elementos gráficos desaparecen de repente o aparecen bruscamente dentro del campo panorámico en lugar de entrar y salir de manera fluida por los bordes laterales.
- **Causa**:
  - El motor de Super Mario Kart proyecta los elementos lejanos mediante tablas angulares dependientes del rumbo del kart y una serie de filtros de ángulo y posición. Si el ángulo de visión excede la ventana tradicional de 4:3, la rutina matemática interna de proyección descarta el elemento antes de que alcance el borde de 16:9.
- **Reto pendiente**:
  - Localizar y ampliar los umbrales angulares en el motor de cálculo trigonométrico (bancos $00, $01 y $88) para que la escenografía se mantenga proyectada en un ángulo ampliado de 16:9.

### 3. Desaparición de Sprites Dinámicos en Bordes Extremos
- **Síntoma**:
  - Topos de Donut Plains, peces voladores de Koopa Beach, plantas piraña y karts rivales se desvanecen cuando aún están dentro del tercio lateral panorámico.
- **Causa**:
  - Además de las compuertas ya parcheadas en `$0C892..$0CA1D`, existen rutinas secundarias de recorte en las entidades de IA y física que dejan de procesar la posición del sprite si la distancia relativa al kart supera el semiancho clásico de 128 píxeles.
