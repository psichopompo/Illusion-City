#!/usr/bin/env python3
"""SMK Horizonte — Soporte Widescreen v6 Definitivo (bsnes-hd).

Novedades de la versión v6:
1. RESOLUCIÓN DEFINITIVA DE LA ESCENOGRAFÍA LATERAL (ÁRBOLES Y MONTÍCULOS):
   - En v5, la subrutina '$8BC00' ejecutaba un bucle de descarte sobre los sprites 32 a 127
     con atributo $0E y tiles $C0..$F7, forzando Y = $E0 en cuanto salían del margen 4:3.
     Esto provocaba que en Donut Plains desaparecieran repentinamente a la izquierda
     el montículo y los árboles, y en Mario Circuit 1 aparecieran con pop-in brusco.
   - En v6, se reemplaza la cabecera de '$8BC00' con '08 4C 03 91' (PHP : JMP $9103).
     La instrucción PHP preserva la paridad exacta de la pila de la CPU para el PLP
     de salida en '$8919A', eliminando cualquier desbalance de retorno.
   - Esto anula el culling destructivo manteniendo el juego 100% estable en carrera,
     permitiendo que la vegetación y los relieves entren y salgan del encuadre 16:9
     con total naturalidad y suavidad.

2. RÓTULO ROUND 1 CENTRADO (0x89F94):
   - Se mantiene intacta la subrutina nativa '$88:8F00' (20 00 8F EA EA EA EA)
     que aplica el desplazamiento vertical de +56 píxeles (ADC #$38), garantizando
     que el letrero de 'ROUND 1' se muestre en el centro de la pantalla como
     en el diseño original de Horizonte y no en el borde superior de SNES vanilla.

3. ESTABILIDAD Y COMPATIBILIDAD INTEGRAL:
   - Conserva los 4 pilares: corrección de retratos ($88:9400), attract mode
     con los 8 corredores ($88:A34C), tasa fluida de 30 fps en Bowser Castle ($88:A500)
     y selector de menú por defecto a 1P Game (0x58227 = 0x00).

4. CULLING HORIZONTAL PANORÁMICO ENSANCHADO ($60..$C0):
   - Ventanas de descarte ampliadas a $60..$C0 en las compuertas del motor
     (rivales, obstáculos fijos, tuberías, topos, monedas y fantasmas).
   - Umbrales de escenografía en banco $88 ampliados a $C0 (192 px de semiancho).

5. CONFIGURACIÓN BSNES-HD (.bso):
   - Archivo complementario con 'w:1 s:1 b:1 B:0 l:1':
     * 'w:1': Modo panorámico activo (cielo Mode 1 + suelo Mode 7).
     * 's:1': Renderizado panorámico extendido de sprites (Unsafe Widescreen Sprites).
     * 'b:1': Extensión horizontal panorámica en BG1.
     * 'B:0': Supresión de extensión repetitiva en BG2 (elimina franjas rojas/negras en Ghost Valley).
     * 'l:1': Eliminación del límite de sprites por línea (cero parpadeos).
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

SHA_WIDESCREEN_V6 = "7a9d07406bf5a357b0e1299b75491c7732332fc0507862c518d4626c93700338"

WIDESCREEN_GATES = [
    (0x0C892, 0x60, 0x0C895, 0xC0, "Compuerta 1: Rivales y proyección primaria"),
    (0x0C9A5, 0x60, 0x0C9A8, 0xC0, "Compuerta 2: Rivales alternativos e ítems"),
    (0x0C9CF, 0x60, 0x0C9D2, 0xC0, "Compuerta 3: Sprites secundarios (topos, tuberías)"),
    (0x0CA1A, 0x60, 0x0CA1D, 0xC0, "Compuerta 4: Obstáculos fijos y fantasmas"),
    (0x0ED8D, 0x60, 0x0ED90, 0xC0, "Compuerta 5: Pantalla dividida P1"),
    (0x0EDB7, 0x60, 0x0EDBA, 0xC0, "Compuerta 6: Pantalla dividida P2"),
]

CULLING_PATCHES_88 = [
    (0x88AD6, bytes.fromhex("48af880a7ed0086869f800c9f8006b68692001c9c0006beaeaeaeaeaeaeaea")),
    (0x88B15, bytes.fromhex("48af880a7ed0086869f800c9f8006b68692001c9c0006beaeaeaeaeaeaeaea")),
    (0x88B34, bytes.fromhex("48af880a7ed0086869a000c9a0006b6869a000c9c0006beaeaeaeaeaeaeaea")),
    (0x88B53, bytes.fromhex("48af880a7ed0086869a000c9a0006b6869a000c9c0006beaeaeaeaeaeaeaea")),
    (0x88B72, bytes.fromhex("48af880a7ed0086869f800c9f8006b68692001c9c0006beaeaeaeaeaeaeaea")),
    (0x88B91, bytes.fromhex("48af880a7ed0086869b000c9b0006b6869b000c9c0006beaeaeaeaeaeaeaea")),
    (0x88BB0, bytes.fromhex("48af880a7ed00868696800c9c0006b6869c000c9c0006beaeaeaeaeaeaeaea")),
    (0x88BCF, bytes.fromhex("48af880a7ed0086869f8ffc9c0006b68695000c9c0006beaeaeaeaeaeaeaea")),
]

def recalcular_checksum(rom: bytearray) -> tuple[int, int]:
    rom[0xFFDC:0xFFE0] = bytes.fromhex("ffff0000")
    csum = sum(rom) & 0xFFFF
    csum_comp = csum ^ 0xFFFF
    rom[0xFFDC:0xFFDE] = csum_comp.to_bytes(2, "little")
    rom[0xFFDE:0xFFE0] = csum.to_bytes(2, "little")
    return csum, csum_comp

def aplicar_widescreen_v6(rom_bytes: bytes) -> tuple[bytearray, list[str]]:
    # Importar motor base estable
    from arreglar_demo_smk_horizonte import rebuild as rebuild_estable
    
    # 1. Asegurar base estable sin widescreen con ROUND centrado
    rom = bytearray(rebuild_estable(rom_bytes))
    cambios = ["Base estable consolidada (ROUND 1 centrado, retratos, demo fluida, 30 fps)"]

    # 2. Compuertas de culling panorámico en banco $00 / $01
    for off_min, val_min, off_max, val_max, desc in WIDESCREEN_GATES:
        rom[off_min] = val_min
        rom[off_max] = val_max
        cambios.append(f"Culling Widescreen: {desc} -> [0x{val_min:02X}, 0x{val_max:02X}]")

    # 3. Compuertas de escenografía y culling en banco $88
    for off, patch in CULLING_PATCHES_88:
        rom[off:off+len(patch)] = patch
    cambios.append("Culling Widescreen: Proyección horizonte y escenografía ampliada a $C0")

    # 4. Asegurar llamada intacta a $BC00 en 0x89100 (4C 00 BC)
    rom[0x89100:0x89103] = bytes.fromhex("4c00bc")
    cambios.append("VBlank 1P: JMP $BC00 preservado en 0x89100")

    # 5. Parche de estabilidad de pila y bypass de culling destructivo en 0x8BC00
    # PHP : JMP $9103 (08 4C 03 91)
    rom[0x8BC00:0x8BC04] = bytes.fromhex("084c0391")
    cambios.append("Escenografía Widescreen: PHP + JMP $9103 en 0x8BC00 (equilibrio de pila + árboles continuos)")

    # 6. Verificación de ROUND 1 intacto
    assert rom[0x89F94:0x89F9B] == bytes.fromhex("20008feaeaeaea"), "Error: 0x89F94 alterado en widescreen"
    cambios.append("Banner ROUND 1 verificado centrado (0x89F94: 20 00 8F EA EA EA EA)")

    # 7. Checksum
    csum, csum_comp = recalcular_checksum(rom)
    cambios.append(f"Checksum SNES actualizado: 0x{csum:04X} (complemento 0x{csum_comp:04X})")

    return rom, cambios

def main():
    parser = argparse.ArgumentParser(description="Aplicar soporte Widescreen v6 definitivo a SMK Horizonte.")
    parser.add_argument("rom_entrada", nargs="?", default=None, help="Ruta de la ROM base .sfc")
    parser.add_argument("-o", "--output", default=None, help="Ruta de salida de la ROM .sfc")
    args = parser.parse_args()

    dir_parches = Path(__file__).resolve().parent
    entrada = Path(args.rom_entrada) if args.rom_entrada else dir_parches / "SMK_Horizontee_fix_demo_v3.sfc"
    if not entrada.exists():
        entrada = dir_parches.parent / "originales" / "SMK_Horizontee.sfc"
    salida = Path(args.output) if args.output else dir_parches / "SMK_Horizontee_widescreen_v6.sfc"
    bso_salida = salida.with_suffix(".bso")

    print(f"Leyendo ROM: {entrada}")
    rom_bytes = entrada.read_bytes()
    rom_out, cambios = aplicar_widescreen_v6(rom_bytes)

    for c in cambios:
        print(f"  [+] {c}")

    salida.write_bytes(rom_out)
    bso_salida.write_text("w:1 s:1 b:1 B:0 l:1\n", encoding="ascii")
    sha_res = hashlib.sha256(rom_out).hexdigest()
    print(f"\nROM Widescreen v6 guardada: {salida}")
    print(f"SHA-256: {sha_res}")
    print(f"Configuración bsnes-hd: {bso_salida} (w:1 s:1 b:1 B:0 l:1)")
    assert sha_res == SHA_WIDESCREEN_V6, f"Error: hash inesperado {sha_res}"

if __name__ == "__main__":
    main()
