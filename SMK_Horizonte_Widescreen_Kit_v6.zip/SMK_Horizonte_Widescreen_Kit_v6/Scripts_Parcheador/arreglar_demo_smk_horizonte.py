#!/usr/bin/env python3
"""SMK Horizonte — Corrección definitiva sin widescreen (Demo attract mode, rivales, retratos y ROUND 1 centrado).

Python 3, biblioteca estándar. ROM HiROM 1 MiB sin cabecera de copiador.
Acepta como base:
  - SMK_Horizontee.sfc (original Horizonte P13)
  - SMK_Horizontee_fix_retratos_v1.sfc (con fix de retratos)
  - SMK_Horizontee_fix_demo_v2.sfc (versión intermedia anterior)
  - SMK_Horizontee_fix_demo_v3.sfc (versión anterior con regresión de banner)

Produce la versión estable definitiva sin widescreen con:
  1. Fix de parpadeo de retratos en meta ($88:9400).
  2. Eliminación de sobrecarga en las 8 compuertas de culling críticas ($88:AD6..$88:BCF).
  3. Proyección vertical de sprites ($88:A34C) con acumulador recargado (#$FF00),
     restituyendo a todos los rivales en la pantalla 1 en attract mode.
  4. Optimización de búsqueda de escalas en $88:A500 (30 fps en Bowser Castle).
  5. Menú por defecto en 1P Game en Cold Boot (0x58227 = 0x00).
  6. RÓTULO ROUND 1 CENTRADO (0x89F94): preserva la llamada nativa a $8F00
     ('20 00 8F EA EA EA EA') para que el banner se ubique en el centro (Y = 56 px)
     tal como diseñó Psicopompo en Horizonte original, sin desplazarlo arriba.
  7. Recálculo del checksum SNES oficial ($FFDC..$FFDF).

Uso:
  python3 arreglar_demo_smk_horizonte.py "SMK_Horizontee.sfc" --comprobar
  python3 arreglar_demo_smk_horizonte.py "SMK_Horizontee.sfc"
  python3 arreglar_demo_smk_horizonte.py "SMK_Horizontee.sfc" --restaurar
"""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile

SHA_BASE_ORIGINAL = '105738925b047e7656f2f92a493f099836f5f8ed098c7d54e7f2f676c3c32ca3'
SHA_V1_RETRATOS   = '5a6cfabe3fc1ee522aa3595284402076c5ccbb3329c2207dd84fb0492abf5dac'
SHA_V2_INTERMEDIA = 'ddd1d603de00a160f6729f71d05ce937c3aa06295a2ac523d5e857c32b471abe'
SHA_V3_ANTERIOR   = '110db4d26a2a5f26997e05f5790fa1ecc03868d6ce36ab09717b0258b3445ca1'
SHA_FINAL_ESTABLE = 'ed688b9031218f0d1d92605f4cbe97bb81f4801b903a3f2f73938554a3e84097'

PORTRAIT_OFFSET = 0x89400
PORTRAIT_CODE = bytes.fromhex(
    'e220c210af06027ec940d03aaf07027e29f1c931d030af01027ec927d028a940'
    '8f01027e8f05027ea9518f09027e8f0d027ea9628f11027e8f15027ea9738f19'
    '027e8f1d027eaf72027ec980d033af73027ec929d02baf71027ec915d023a270'
    '00bf03027ec929d00fbf01027ec9a0b0071869199f01027ee8e8e8e8e09c01d0'
    'e060'
)

A500_OFFSET = 0x8A500
A500_CODE = bytes.fromhex(
    'af880a7ed025a504c935ddd01ea5b8d01aa5b4c5a8f014daa20000a518df00a688'
    'b004e8e880f69bfa386ba0feffa518c8c8d10490fa6beaea'
)

A34C_OFFSET = 0x8A34C
A34C_CODE = bytes.fromhex('a900ff65986d00605c73c880')

def make_fast_culling(van_adc, van_cmp, hack_adc, hack_cmp, total_len):
    hack_part = bytes.fromhex(hack_adc + hack_cmp + '6b')
    van_part = bytes.fromhex('68' + van_adc + van_cmp + '6b')
    bne_offset = len(hack_part) + 1
    prefix = bytes.fromhex('48af880a7ed0') + bytes([bne_offset]) + bytes.fromhex('68')
    res = prefix + hack_part + van_part
    return res + b'\xea' * (total_len - len(res))

CULLING_PATCHES = [
    (0x88AD6, make_fast_culling('692001', 'c9c000', '69f800', 'c9f800', 0x88AF5 - 0x88AD6)),
    (0x88B15, make_fast_culling('692001', 'c9c000', '69f800', 'c9f800', 0x88B34 - 0x88B15)),
    (0x88B34, make_fast_culling('69a000', 'c9c000', '69a000', 'c9a000', 0x88B53 - 0x88B34)),
    (0x88B53, make_fast_culling('69a000', 'c9c000', '69a000', 'c9a000', 0x88B72 - 0x88B53)),
    (0x88B72, make_fast_culling('692001', 'c9c000', '69f800', 'c9f800', 0x88B91 - 0x88B72)),
    (0x88B91, make_fast_culling('69b000', 'c9c000', '69b000', 'c9b000', 0x88BB0 - 0x88B91)),
    (0x88BB0, make_fast_culling('69c000', 'c96000', '696800', 'c96000', 0x88BCF - 0x88BB0)),
    (0x88BCF, make_fast_culling('695000', 'c96000', '69f8ff', 'c96000', 0x88BEE - 0x88BCF)),
]

class PatchError(Exception):
    pass

def sha(data):
    return hashlib.sha256(data).hexdigest()

def rebuild(rom_bytes):
    data = bytearray(rom_bytes)

    # Si proviene de una versión intermedia (v2 o v3 anterior) que reemplazó masivamente
    # 20 00 8f en el banco 88, restauramos los 39 puntos a su opcode original de Horizonte P13:
    orig_target = bytes.fromhex('20008feaeaeaea')
    broken_target = bytes.fromhex('af880a7eeaeaea')
    for i in range(0x88000, 0x90000 - 7):
        if data[i:i+7] == broken_target:
            data[i:i+7] = orig_target
    
    # 1. Aplicar arreglo de retratos en meta ($88:9400)
    data[PORTRAIT_OFFSET:PORTRAIT_OFFSET+len(PORTRAIT_CODE)] = PORTRAIT_CODE
            
    # 2. Optimizar búsqueda de escalas en $88:A500 (30 fps en Bowser Castle)
    data[A500_OFFSET:A500_OFFSET+len(A500_CODE)] = A500_CODE
    
    # 3. Optimizar $88:A34C con recarga exacta de A (#$FF00) para rivales en pantalla 1
    data[A34C_OFFSET:A34C_OFFSET+len(A34C_CODE)] = A34C_CODE
    
    # 4. Optimizar las 8 compuertas de culling críticas
    for off, patch in CULLING_PATCHES:
        data[off:off+len(patch)] = patch

    # 5. Selector de menú por defecto en 1P Game (0x58227 = 0x00)
    data[0x58227] = 0x00

    # 6. Verificación explícita de ROUND 1 (0x89F94): DEBE ser 20 00 8F EA EA EA EA
    assert data[0x89F94:0x89F9B] == orig_target, "Error: 0x89F94 no contiene la llamada nativa a $8F00"
        
    # 7. Recalcular checksum SNES
    data[0xFFDC:0xFFE0] = bytes.fromhex('ffff0000')
    checksum = sum(data) & 0xFFFF
    data[0xFFDC:0xFFDE] = (checksum ^ 0xFFFF).to_bytes(2, 'little')
    data[0xFFDE:0xFFE0] = checksum.to_bytes(2, 'little')
    
    out = bytes(data)
    if sha(out) != SHA_FINAL_ESTABLE:
        raise PatchError(f'Error interno en la reconstrucción: SHA256 ({sha(out)}) no coincide con la versión estable.')
    return out

def create_backup(path, bak, expected):
    created = False
    try:
        with bak.open('xb') as f:
            created = True
            f.write(expected)
            f.flush()
            os.fsync(f.fileno())
        if bak.read_bytes() != expected:
            raise PatchError('Verificación de backup fallida.')
        shutil.copystat(str(path), str(bak))
    except BaseException:
        if created:
            try:
                bak.unlink()
            except OSError:
                pass
        raise

def atomic_write(path, data):
    fd, name = tempfile.mkstemp(prefix=path.name+'.smk-', suffix='.tmp', dir=str(path.parent))
    tmp = Path(name)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if tmp.read_bytes() != data:
            raise PatchError('El temporal no coincide: la ROM no se sustituye.')
        shutil.copymode(str(path), str(tmp))
        os.replace(str(tmp), str(path))
    finally:
        if tmp.exists():
            tmp.unlink()

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('rom', help='SMK_Horizontee.sfc local')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--comprobar', action='store_true', help='comprobar sin escribir ni crear backup')
    group.add_argument('--restaurar', action='store_true', help='restaurar exactamente el .bak original')
    args = parser.parse_args(argv)
    
    path = Path(args.rom).expanduser().resolve()
    if not path.is_file():
        raise PatchError('No existe el archivo: ' + str(path))
        
    bak = Path(str(path)+'.bak')
    current = path.read_bytes()
    
    if args.restaurar:
        if not bak.is_file():
            raise PatchError('No existe el .bak original para restaurar.')
        origin = bak.read_bytes()
        if sha(origin) not in [SHA_BASE_ORIGINAL, SHA_V1_RETRATOS, SHA_V2_INTERMEDIA, SHA_V3_ANTERIOR]:
            raise PatchError('El .bak no corresponde a una ROM compatible.')
        if current == origin:
            print('El archivo ya coincide con el backup original.')
            return 0
        atomic_write(path, origin)
        print('RESTAURADA desde el backup: ' + bak.name)
        return 0
        
    origin = bak.read_bytes() if bak.is_file() else current
    current_hash = sha(current)
    origin_hash = sha(origin)
    
    if current_hash == SHA_FINAL_ESTABLE:
        print('Esta ROM ya tiene aplicadas las correcciones definitivas (ROUND centrado + demo + 30fps).')
        return 0
        
    if origin_hash not in [SHA_BASE_ORIGINAL, SHA_V1_RETRATOS, SHA_V2_INTERMEDIA, SHA_V3_ANTERIOR]:
        raise PatchError('La ROM (o su backup) no corresponde a SMK_Horizontee compatible.')
        
    result = rebuild(origin)
    print('ROM compatible verificada por SHA256. Tamaño: 1 MiB.')
    print('Plan: culling rápido banco 88 + proyección vertical 88:A34C + ROUND 1 centrado.')
    
    if args.comprobar:
        print('COMPROBACIÓN COMPLETADA: no se ha escrito nada.')
        return 0
        
    copies = 1 if bak.is_file() else 2
    if shutil.disk_usage(path.parent).free < len(origin)*copies + 1024*1024:
        raise PatchError('Espacio libre insuficiente para temporal/backup.')
        
    if not bak.is_file():
        create_backup(path, bak, origin)
        print('Backup original creado: ' + bak.name)
        
    atomic_write(path, result)
    print('ROM CORREGIDA con éxito (versión estable: ROUND centrado + retratos + demo fluida sin lag).')
    print('Backup conservado: ' + bak.name)
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (PatchError, OSError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print('Interrumpido. El archivo no se ha alterado.', file=sys.stderr)
        sys.exit(130)
