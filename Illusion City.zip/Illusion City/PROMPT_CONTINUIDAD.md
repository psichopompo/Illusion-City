# ILLUSION CITY (Mega CD) — Pack de continuidad para nuevo chat

**Fecha:** 26/09/2026
**ROM oficial actual:** TEST_BL.bin — MD5 d52709bc5d2616c55861ac8f86cb3790

## Qué es esto

Proyecto de traducción al castellano del Illusion City (Gen'ei Toshi) de Mega CD.
Trabajamos por tandas, tocando menús del sistema de uno en uno. Este pack tiene
TODO lo necesario para retomar el proyecto: ROM oficial, herramientas, documentación
completa del proyecto (diario de ~100 tandas), y las instrucciones para continuar.

## Contenido del pack

- `TEST_BL.bin` — la ROM oficial con todo lo que ha funcionado hasta ahora
- `DIARIO.md` — el diario completo del proyecto (CASI 100 tandas de conocimiento)
- `recursos/` — herramientas, documentos de referencia, fuente de David
- `pruebas/` — arnés de emulación (Genesis Plus GX instrumentado)
- `bios/` — las BIOS del Mega CD (necesarias para el arnés)
- `capturas_tanda/` — capturas de referencia

**Falta en el pack (por peso, se entrega por separado):**
- La ROM base japonesa `Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin`
  (18 MB, MD5 ab72a6c1b949f8cb3a1c8b1c81f0559e). David la tiene.
- La TEST_BH.bin (base anterior, MD5 9884eeffa93640b814108b3909a96730). David la tiene.

## MÉTODO DE TRABAJO (normas de David, innegociables)

- Siempre en castellano. Tutear a David. Estilo ingeniero, conciso, no condescendiente.
- Reconocer errores propios explícitamente. Distinguir [HECHO] de [HIPÓTESIS].
- Una sola pregunta por mensaje, al final, con ¿.
- Capturas individuales, nunca rejillas. Mirar la captura ENTERA antes de enviarla.
- Si David contradice el análisis, comprobarlo antes de descartarlo: casi siempre lleva razón.
- Cuando David menciona un problema antiguo, copiar el MÉTODO, no tocar aquel caso.
- NUNCA partir una palabra. No pedir a David que cambie su texto por falta de espacio
  sin agotar TODAS las vías técnicas.
- La maquetación la decide David. Sólo ROMs numeradas por versión.
- Una ROM, una prueba. No generar ROM hasta ver capturas de cómo quedan los cambios.
- Presupuesto de workspace: 128 MB / 10K ficheros. Limpiar periódicamente.
- El workspace se reinicia entre sesiones: /tmp NO persiste. Todo lo importante va
  en /home/user/. Los states y ficheros que David comparte hay que GUARDARLOS en
  el workspace inmediatamente (no en /tmp).

## ARCHITECTURA DE LA ISO

- ISO cruda: .bin de 18.444.384 B, 7842 sectores MODE1/2352
- Módulos en el disco (LBA, tamaño, se cargan en RAM):
  - START: LBA 59, 98184 B -> PRG-RAM $10000
  - SSTART: LBA 43, 32644 B -> PRG-RAM $00000
  - INIT: LBA 107, 149400 B -> RAM $28000
  - OPEN: LBA 285, 69258 B -> RAM $10000
  - CHR: LBA 180, 94310 B
  - SD: LBA 251, 69194 B
  - GFONT: LBA 679, 7920 B
- Mapeo bin<->region: `(LBA + off//2048)*2352 + 16 + off%2048`
- EDC/ECC correctos; validar con la referencia de Corlett (recursos/terceros/ecc_ref)
- Toda modificación de bytes exige recalcular EDC/ECC (`m.edcecc.repara_bytes(bytes(raw))`)

## CÓMO FUNCIONA EL MOTOR DE VENTANAS

- Las ventanas tienen un descriptor: $4=fila, $6=col, $8=ancho (celdas), $a=alto,
  $1a=color de marco, $1e=buffer de dibujo, $22=puntero a la plantilla de texto
- El descriptor SE MONTA AL ABRIR LA VENTANA en el array $a4200 (Word RAM)
- La plantilla de texto es una cadena con códigos:
  - Marcas de color: `26 xx` donde xx=30-37. El color REAL depende de la paleta
    de cada ventana: &0=verde, &1=rojo, &2=?, &3=amarillo, &4=?, &5=azul oscuro,
    &6=azul claro, &7=blanco. **CALIBRAR POR VENTANA con el COLOR_test**.
  - ∆ (icono de sección) = código 0x965F = celda 1349 de la fuente (diseñado por David)
  - `%` = código 0x8193
  - salto de línea = `2f 6e`
  - espacios = `81 40`
  - letras fullwidth A-Z = 82 60..79, a-z = 82 81..9a
  - dígitos 0-9 = 82 4f..58
- El pintor de cadenas es $20852 (copia hasta el 0)
- El pintor de números es $18722 (escribe la cifra desde el inicio del campo)
- El blanker de nombres es $23C94 (borra el campo con espacios antes de escribir)
- **El motor de render de la ventana hace WRAP al llegar al ancho de línea ($8)**
- La fuente tiene celdas 12x12 = 18 B, en INIT (0x14E0 y 0x4ED0) y OPEN (0x6D20
  y 0xA710). Dos tablas: A (menús) y B (cifras), con numeraciones diferentes.
- La fuente de David está en `recursos/documentos/Fuente Illusion City.png`
  (128x56 = 16x7 celdas de 8x8). Herramienta: `recursos/tools/fuente_8px.py`.

## LA PLANTILLA DE TÉCNICAS (el menú que estamos maquetando)

En TEST_BL, la plantilla de Técnicas está en START 0x15410 y mide 474 B.
Terminador (0000) en off 472-473. Después hay 0xFF hasta off 578 aprox.

### Estructura (offsets dentro de la plantilla, contados desde 0):
```
off 0-29:    título ∆TÉCNICAS∆ (30 B)
off 30-75:   rótulo 1 (46 B): [&5][7 esp][ARMA][_][RIFLE][_][OBÚS][_][CAÑÓN][|]
off 76-129:  fila v1 (54 B): [&4][8 esp][&7][000% × 4][|]
off 130-183: fila v2 (54 B): igual
off 184-237: fila v3 (54 B): igual
off 238-239: | | (línea vacía)
off 240-283: rótulo 2 (44 B): [&5][9 esp][GARRA][_]...[HILO][|]
off 284-337: fila v4 (54 B): igual
off 338-391: fila v5 (54 B): igual
off 392-445: fila v6 (54 B): igual
off 446-473: fila v6 continúa + terminador 0000
```

### Referencias del código a la plantilla (38 refs, TODAS actualizadas):
```
file 0x12FF0: move.l #$25410,$22(a0)  <- la plantilla (off 0)
file 0x12FFC: lea $2545E,a2          <- blanker del nombre fila 1 (off 78)
file 0x13006: lea $25494,a2          <- blanker fila 2 (off 132)
file 0x13010: lea $254CA,a2          <- blanker fila 3 (off 186)
file 0x1301A: lea $2552E,a2          <- blanker fila 4 (off 286)
file 0x13024: lea $25564,a2          <- blanker fila 5 (off 340)
file 0x1302E: lea $2559A,a2          <- blanker fila 6 (off 394)
file 0x13150-0x131C4: tabla dc.l con 29 refs (los campos de valores)
```
Ver `parche_tk_rotulos7.py` (o su lógica) para el mapa completo.

### Descriptor de la ventana de Técnicas (file 0x12F96-0x12FBC):
```
move.w #$2,$4(a0)      fila 2
move.w #$3,$6(a0)      col 3
move.w #$1d,$8(a0)     ANCHO 29 celdas (ensanchado de 22)
move.w #$16,$a(a0)     ALTO 22
move.w #$8020,$1a(a0)
move.l #$a6000,$1e(a0) BUFFER de dibujo
```

### CAMPOS DE VALORES en la plantilla (en BL):
Los campos "000%" están en las celdas 10, 14, 18, 22 de cada fila de valores.
El pintor ($18722) escribe cifra+% DESDE EL INICIO del campo.
Con "65%": 65%@10-12, el % de la plantilla en la celda 13 queda VISIBLE pero el
pintor lo sobreescribe con el siguiente valor... NO: el pintor escribe cifra+%
desde el inicio, con "65%" ocupa 3 celdas del campo de 4, y el % de la plantilla
(4a celda) NO se pinta (queda como espacio). Con "0%": ocupa 2 celdas del campo.

## EL PROBLEMA ACTUAL: mover los rótulos de armas a la derecha

David quiere que ARMA/RIFLE/OBÚS/CAÑÓN y GARRA/VARA/ESP./HILO estén a la derecha
(alineados con las columnas de valores). Los rótulos +7 celdas FUNCIONARON
(verificado en pantalla) PERO la ventana tenía que ensancharse a $8=29, y ese
ensanche ROMPE Perfiles (la ficha de Estado sale recortada) porque Perfiles y
Técnicas comparten el MISMO descriptor (se monta al abrir cada ventana).

### Lo que NO ha funcionado (lista negra de errores):
1. Insertar bytes sin actualizar refs => refs desfasadas => texto roto
2. Insertar bytes y actualizar refs por rango sin verificar opcode => BSRs
   del SSTART pisados => el juego no arranca
3. Reapuntar en el mismo bucle que decide => tabla dc.l rota
4. Offset calculado antes de la inserción => rótulo 2 se come un %
5. Mover el buffer de dibujo a $b0000 => pisa gráficos del fondo => glitches
   parpadeantes en la ficha y fondo corrupto
6. Mover el buffer a $aa000 => funciona para Técnicas pero PISA el buffer de
   Perfiles => Perfiles se cuelga
7. Ensanchar $8 sin mover el buffer => el render corta igual (el buffer no da)
8. Offset de región vs offset de fichero: la región 0x12FB4 = fichero 0x379C4
   (el mapeo de sector lo desplaza). NO usar offsets de región como offsets
   de fichero para editar directamente.

### La causa del problema:
El descriptor de la ventana ($8) es COMPARTIDO entre Perfiles y Técnicas
(ambas escriben en el mismo array $a4200 al abrirse). Si pones $8=29 para
Técnicas, la ficha de Estado sale recortada. Si pones $8=22, los rótulos
desplazados de Técnicas hacen wrap y se mezclan con los valores.

### POSIBLES SOLUCIONES (por explorar):
1. **Parchear el descriptor EN CALIENTE**: cuando el usuario selecciona
   TÉCNICAS del submenu, el código escribe el descriptor. Se podría interceptar
   ese momento y cambiar $8 a 29 solo para Técnicas (y a 22 cuando se abre
   Perfiles). El código que abre cada ventana está en el código del submenu
   (file 0x13036: bsr $23086 = Perfiles, bsr $23096 = ?, bsr $230A6 = ?).
2. **Usar un descriptor SEPARADO para Técnicas**: crear un segundo descriptor
   en memoria libre y hacer que el código de Técnicas lo use.
3. **Cambiar el buffer de Técnicas a una zona de Word RAM realmente libre**:
   hay que encontrar una zona que el juego NO use nunca (ni para gráficos
   descomprimidos ni para otros buffers). El área $a6000-$aa000 está toda
   asignada a ventanas. $aa000+ tiene datos. Habría que investigar qué usa
   el juego en cada zona de la Word RAM durante la pantalla de Técnicas.
4. **Rediseñar el layout de la plantilla**: colocar los rótulos y las filas
   de valores en líneas diferentes para que no haya conflicto (por ejemplo,
   los rótulos en la línea del título, aprovechando el espacio sobrante).

## LO QUE YA FUNCIONA EN TEST_BL (aprobado por David)

- Menú principal en castellano (Magia/Objetos/Equipo/Hablar/Estado/Sistema)
- Dinero con "Dinero:" y formato correcto
- Ficha de Estado completa (NIVEL, EXPERIENCIA, SIGUIENTE, PV, PM, ATAQUE,
  DEFENSA, VELOCIDAD, HABILIDAD, PRECISIÓN) con nombres completos
- Ventana de nombres de personajes (84 px, selector 70 px)
- Menú Objetos: título ∆OBJETOS∆, Usar/Cambiar/Tirar, columnas ajustadas
- Menú Sistema: Velocidad/Ajustes, Rápido/Lento, Mensajes/Movimiento/Batalla
- Menú TÉCNICAS: título, nombres completos "Tian Ren"/"Mei Hong", valores
  en blanco, un % detrás de cada cifra
- Submenu Perfiles/Técnicas/Combate en castellano
- Fuente: q y p g j , ; ¡ ¿ bajados 1 px
- OBÚS con acento, CAÑÓN con Ñ y Ó

## CÓMO USAR EL ARNÉS

### Emulador
El core está en `/home/user/emu/bin/genesis_plus_gx_libretro.so` (con los
ganchos arena_* y el tag de CPU en los eventos). Si no existe, reconstruir
con `emu/RECETA.md` (necesita el repo GPGX y las herramientas).

### Arnés (pruebas/mdcd.py)
```python
import sys; sys.path.insert(0,'.')
import mdcd
md = mdcd.MD('bl.cue')   # el .cue apunta a la ROM
md.load_rzip('states/TEST_BL_david.state')  # cargar state de David
md.run(30)
# ... navegar con pulsa() de arranque.py
```
- El core a veces se queda colgado (pantalla negra): reiniciar el proceso.
- `md.word_ram_2m()` devuelve 256 KB de Word RAM. Zonas: $a6000-$aa000 = area
  de ventanas (offset 0x26000 en el dump), $aa000+ = datos del juego,
  $b0000+ = gráficos descomprimidos (NO USAR como buffer).

### Navegación a TÉCNICAS
```
A (menú) -> 4 DOWN (Estado) -> C (submenu Perfiles/Tecnicas/Combate)
-> DOWN (Tecnicas) -> C
```
OJO: el cursor del submenu RECORDA la última opción usada.
El state de David (TEST_BL_david.state) está en la sala de guardado con el
menú abierto y el selector en "Save". Al cargarlo + reset + C + C se llega
al juego.

### Rutas de menús
- A (abrir menú) -> el cursor arranca donde se quedó la última vez
- Magia: C directamente -> panel de MAGIA -> C abre Efecto/Info/Grupo
- Estado: 4 DOWN -> C -> C (ficha) o C C (submenu) -> Perfiles/Tecnicas/Combate
- Sistema: 5 DOWN -> C -> ventana Velocidad/Ajustes -> C (Velocidad)

### Las capturas que David pasa
Cuando David pasa capturas (a menudo en un zip o enlazadas), mirarlas UNA POR
UNA con `read_file` antes de diagnosticar. Son la única verdad de su emulador.

## PENDIENTES (lo que David quiere)

### TÉCNICAS (el menú actual)
- ✅ Nombres completos "Tian Ren"/"Mei Hong"
- ✅ Valores en blanco (no amarillos)
- ✅ Un % detrás de cada cifra
- ✅ Rótulos desplazados 7 celdas (FUNCIONÓ con $8=29, pero rompía Perfiles)
- ❌ **MOVER RÓTULOS +2 celdas a la derecha** (el pendiente actual: NO CABE
  con $8=22 porque el rótulo llega a la celda 29 y la ventana corta en 22.
  Hay que resolver el conflicto del descriptor compartido)
- ❌ Alineación fina de los rótulos con las columnas de valores
- ❌ Color del título (ahora amarillo &4; decidir con David)

### Otros menús (pendientes de David)
- "Dinero:" en amarillo en la ventana del dinero
- Títulos de las secciones con la palabra en azul oscuro (calibrar paleta)
- Menú EQUIPO (David: "hecho un caos", siguiente tarea)
- Ajustes: textos pisados, sí/no pendientes
- Nombres de armas alineados con las columnas de valores
