#!/usr/bin/env python3
"""Escribe el gancho del cursor de Objetos byte a byte (verificado)."""
import capstone
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
PINTOR = 0x1048A    # `move.w $2e(a0),d2 + subq.w #3,d2` (6 B) en RAM $2048A
G = 0x17F20         # hueco libre (file) = RAM $27F20

# el gancho byte a byte:
gancho = bytes([
    0x48, 0xE7, 0x40, 0x00,             # movem.l d1,-(a7)
    0x22, 0x68, 0x00, 0x22,             # movea.l $22(a0),a1
    0x0C, 0x69, 0x3E, 0x16,             # cmpi.w #$3E16,(a1)
    0x66, 0x0E,                         # bne.s .comun (+$0E)
    0x0C, 0x69, 0x00, 0x02, 0x00, 0x02, # cmpi.w #$0002,$2(a1)
    0x66, 0x0A,                         # bne.s .comun (+$0A)
    0x32, 0x28, 0x00, 0x2C,             # move.w $2C(a0),d1
    0xD2, 0x41,                         # add.w d1,d1
    0xD2, 0x41,                         # add.w d1,d1
    0x43, 0xF9, 0x00, 0x27, 0xF1, 0x10, # lea $27F10,a1
    0xD3, 0xC1,                         # adda.w d1,a1
    0x34, 0x10,                         # move.w (a1),d2
    0x60, 0x04,                         # bra.s .fin (+$04)
    0x34, 0x28, 0x00, 0x2E,             # .comun: move.w $2E(a0),d2
    0x57, 0x42,                         # .comun: subq.w #3,d2
    0x4E, 0x71,                         # .fin: nop
    # .tabla:
    0x00, 0x00, 0x00, 0x00,             # [0] dummy
    0x00, 0x00, 0x00, 0x00,             # [1] Usar: d2=0
    0x00, 0x02, 0x00, 0x00,             # [2] Cambiar: d2=2
    0x00, 0x01, 0x00, 0x04,             # [3] Tirar: d2=1, d0+=4
])

# verificar los saltos:
# bne1 en offset 12, instr siguiente en 14, .comun en 42, rel = 42-14 = 28 = $1C
assert gancho[13] == 0x0E, 'bne1 rel'
# bne2 en offset 20, instr siguiente en 22, .comun en 42, rel = 42-22 = 20 = $14
assert gancho[21] == 0x0A, 'bne2 rel'
# bra en offset 40, instr siguiente en 42, .fin en 46, rel = 46-42 = 4
assert gancho[41] == 0x04, 'bra rel'

cs = capstone.Cs(capstone.CS_ARCH_M68K, capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
print('  --- gancho ---')
for i in cs.disasm(gancho, 0x27F20):
    print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                  i.mnemonic + ' ' + i.op_str))

# aplicar sobre TEST_BA.bin
raw = bytearray(open(sys.argv[1], 'rb').read())
st = bytearray(m.region(raw, LBA, SZ))
assert st[PINTOR:PINTOR+6] == bytes.fromhex('3428002e5742'), \
    'pintor no tiene los bytes: %s' % st[PINTOR:PINTOR+6].hex(' ')
assert st[G:G+2] == b'\xff\xff', 'hueco no libre'
st[G:G+len(gancho)] = gancho
off = (0x10000 + G) - (0x10000 + PINTOR + 2)
st[PINTOR:PINTOR+6] = bytes([0x61, 0x00]) + (off & 0xffff).to_bytes(2, 'big') + bytes.fromhex('4e71')
print('  pintor parcheado: bsr %+#x' % off)

for i in cs.disasm(bytes(st[PINTOR-4:PINTOR+14]), 0x10000 + PINTOR - 4):
    print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                  i.mnemonic + ' ' + i.op_str))

m.escribe_region(raw, LBA, bytes(st))
raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
open(sys.argv[2], 'wb').write(bytes(raw))
print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
