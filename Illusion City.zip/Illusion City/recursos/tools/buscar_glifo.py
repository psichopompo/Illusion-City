"""Busca el bitmap (12x12, 1bpp) de un glifo extraido de captura en los modulos.

Comparacion por bounding box recortado -> inmune a desfases verticales/horizontales.
Strides probados por fila: 16 B (2B fila, 12 bits MSB), 18 B (12 bits + 4 pad),
24 B (2B fila, 16 bits), y tambien 12 bits sin pad por byte (stride 12 B no
alineado -> via bits planos).
"""
import sys, glob
from glifos_desde_captura import binarizar, bandas_y_glifos, art

GH = GW = 12

def bbox(bm):
    rows = [y for y, r in enumerate(bm) if any(r)]
    if not rows:
        return None
    y0, y1 = rows[0], rows[-1]
    cols = [x for x in range(GW) if any(bm[y][x] for y in range(GH))]
    x0, x1 = cols[0], cols[-1]
    return y0, y1, x0, x1

def trim(bm):
    y0, y1, x0, x1 = bbox(bm)
    return [bm[y][x0:x1 + 1] for y in range(y0, y1 + 1)]

def eq(a, b):
    if len(a) != len(b) or len(a[0]) != len(b[0]):
        return False
    return all(a[y][x] == b[y][x] for y in range(len(a)) for x in range(len(a[0])))

def rows_at(data, off, stride):
    """12 filas de 12 bits empezando en off con el stride dado; None si fuera de rango."""
    if off + stride * (GH - 1) + 2 > len(data):
        return None
    rows = []
    for r in range(GH):
        b0, b1 = data[off + r * stride], data[off + r * stride + 1]
        rows.append(((b0 << 8) | b1) & 0xFFF)   # 12 bits MSB-first
    return rows

def rows_to_bm(rows):
    return [[1 if (v >> (11 - x)) & 1 else 0 for x in range(GW)] for v in rows]

def buscar(bm):
    """Devuelve [(path, off, stride)] cuyo bitmap recortado == objetivo recortado."""
    tgt = trim(bm)
    hits = []
    for path in sorted(glob.glob('extraidos/*.BIN')):
        data = open(path, 'rb').read()
        n = len(data)
        # indices de candidatos: todo offset (barato con filtro de primera fila)
        t0 = int(''.join('1' if v else '0' for v in tgt[0]), 2)
        for stride in (16, 18, 24):
            if n < stride * GH:
                continue
            for off in range(0, n - stride * (GH - 1) - 2):
                rows = rows_at(data, off, stride)
                if rows is None:
                    break
                if rows[0] != t0:
                    continue
                bm2 = rows_to_bm(rows)
                if any(not any(f) for f in bm2):
                    continue
                if eq(trim(bm2), tgt):
                    hits.append((path, off, stride))
        # bits planos contiguos (12 bits por fila, sin pad, alineado a bits)
        flat = ''.join(''.join('1' if v else '0' for v in fila) for fila in bm)
        pat_bits = ''.join(''.join('1' if v else '0' for v in fila) for fila in tgt)
        # busqueda por bytes de la primera fila recortada
    return hits

if __name__ == '__main__':
    png, bi, gi = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    bits, w, h = binarizar(png)
    y0, glyphs = bandas_y_glifos(bits, w, h)[bi]
    x0, bm = glyphs[gi]
    print(f'glifo banda {bi} idx {gi} (x={x0}, y={y0}):')
    print('\n'.join(art(bm)))
    tb = trim(bm)
    print(f'bbox recortado: {len(tb)} filas x {len(tb[0])} cols')
    hits = buscar(bm)
    if hits:
        print(f'{len(hits)} HITS:')
        for p, o, s in hits[:40]:
            print(f'  {p} off={hex(o)} stride={s}')
    else:
        print('NINGUN hit en extraidos/')
