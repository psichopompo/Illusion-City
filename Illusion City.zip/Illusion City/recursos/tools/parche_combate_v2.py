#!/usr/bin/env python3
"""parche_combate_v2.py - columnas del menu de COMBATE, como las pidio David.

OBJETIVO (medido sobre la pantalla actual)
  Las letras van a 8 px y los espacios tambien; las cifras a 8 px. La fila de cabeceras
  se corre 2 celdas (16 px) a la derecha para que ATAQUE empiece donde ahora esta su
  segunda A (x=73 -> 89). Con eso:
      ATAQUE  x=89   (A 89 T 97 A 105 Q 113 U 121 E 129)
      DEFENSA x=145  (D 145 E 153 F 161 E 169 N 177 S 185 A 193)
      VEL     x=209  (V 209 E 217 L 225)
  Y los valores se colocan debajo de las letras centrales:
      79/35 -> celdas 12,13 (debajo de la «AQ» de ATAQUE)
      24/24 -> celdas 20,21 (debajo de la «EN» de DEFENSA)
      4/5   -> celda 26      (debajo de la «E» de VEL)
  La fila del tercer personaje (los 0) lleva sus 0 en las celdas 13, 21 y 26, que son
  las columnas del 9 de 79, del 4 de 24 y de la E de VEL.

COMO ESTA HECHO
  El build que entra ya tiene la primera version del parche de combate (TEST_AX), asi que
  la plantilla actual tiene las filas 2,3,4 y 7,8,9 en sus offsets conocidos. El mapa de
  abajo traduce cada direccion vieja a su sitio nuevo y se reapuntan las 43 referencias.

Uso: python3 parche_combate_v2.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TPL = 0x14268
ICONO = 0x965F
M4, M5, M7 = bytes.fromhex('2634'), bytes.fromhex('2635'), bytes.fromhex('2637')
SALTO, ESP = bytes.fromhex('2f6e'), bytes.fromhex('8140')
D0, SL = bytes.fromhex('824f'), bytes.fromhex('815e')
# offsets (desde TPL) de la plantilla ACTUAL (v1)
V1 = {'fila0': 0, 'fila6': 206,
      'f2': (78, (96, 104, 112)), 'f3': (120, (138, 146, 154)),
      'f4': (162, (180, 188, 196)),
      'f7': (258, (280, 288, 296, 304)), 'f8': (312, (334, 342, 350, 358)),
      'f9': (366, (388, 396, 404, 412))}


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    assert st[TPL + V1['f2'][0] + 16:TPL + V1['f2'][0] + 18] == M7, \
        'no reconozco la plantilla de partida (esperaba la v1 del parche de combate)'

    nueva = bytearray()
    off = {}
    # fila 0: titulo (igual)
    off['fila0'] = len(nueva)
    nueva += M5 + ICONO.to_bytes(2, 'big') + fw('COMBATE') + ICONO.to_bytes(2, 'big') + SALTO
    # fila 1: cabeceras corridas 2 celdas
    nueva += M5 + ESP * 10 + fw('ATAQUE') + ESP + fw('DEFENSA') + ESP + fw('VEL') + SALTO
    # filas 2,3,4: datos de ATAQUE
    REFS = {2: (13, 21, 26), 3: (13, 21, 26), 4: (13, 21, 26)}
    for fila_i in (2, 3, 4):
        c = bytearray(ESP * 30)
        c[0:2] = M4
        c[22:24] = M7                    # celda 11
        off['f%d' % fila_i] = len(nueva)
        cifs = []
        for cel in REFS[fila_i]:
            c[cel * 2:cel * 2 + 2] = D0
            c[cel * 2 + 2:cel * 2 + 4] = D0
            cifs.append(len(nueva) + cel * 2)
        off['c%d' % fila_i] = tuple(cifs)
        nueva += bytes(c) + SALTO
    # fila 5: linea vacia
    nueva += SALTO
    # fila 6: cabeceras SALUD / MAGIA (igual)
    off['fila6'] = len(nueva)
    nueva += ESP * 11 + M5 + fw('SALUD') + ESP * 3 + fw('MAGIA') + SALTO
    # filas 7-9: PV/PM (igual estructura, cambia de sitio)
    for fila_i in (7, 8, 9):
        off['f%d' % fila_i] = len(nueva)
        nueva += (M4 + ESP * 9 + M7 + D0 * 3 + SL + D0 * 3 + ESP
                  + D0 * 3 + SL + D0 * 3 + (SALTO if fila_i < 9 else b'\x00'))
        # el $7 esta en la celda 10 de la fila -> la celda c esta en row_off + 2*c
        off['c%d' % fila_i] = tuple(off['f%d' % fila_i] + 2 * c for c in (11, 15, 19, 23))
    print('  plantilla nueva: %d B (antes %d). offsets: %s'
          % (len(nueva), 418, {k: v for k, v in off.items() if k.startswith('f')}))
    for fila_i in (2, 3, 4):
        print('   fila %d: cifras en las celdas %s' % (fila_i, REFS[fila_i]))

    # --- mapa v1 -> v2 (direcciones de RAM) ---
    def ram(x):
        return x + 0x10000
    mapa = {ram(TPL + V1['fila0']): ram(TPL + off['fila0']),
            ram(TPL + V1['fila6']): ram(TPL + off['fila6'])}
    for fila_i, clave in ((2, 'f2'), (3, 'f3'), (4, 'f4')):
        base, cifs = V1[clave]
        mapa[ram(TPL + base + 2)] = ram(TPL + off[clave] + 2)
        for i, c in enumerate(cifs):
            mapa[ram(TPL + c)] = ram(TPL + off['c%d' % fila_i][i])
    for fila_i, clave in ((7, 'f7'), (8, 'f8'), (9, 'f9')):
        base, cifs = V1[clave]
        mapa[ram(TPL + base + 2)] = ram(TPL + off[clave] + 2)
        for i, c in enumerate(cifs):
            mapa[ram(TPL + c)] = ram(TPL + off['c%d' % fila_i][i])

    st[TPL:TPL + len(nueva)] = nueva
    n = 0
    o = 0
    while o < len(st) - 4:
        v = int.from_bytes(st[o:o + 4], 'big')
        if v in mapa:
            st[o:o + 4] = mapa[v].to_bytes(4, 'big')
            n += 1
        o += 2
    print('  %d referencias reapuntadas (%d direcciones)' % (n, len(mapa)))

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
