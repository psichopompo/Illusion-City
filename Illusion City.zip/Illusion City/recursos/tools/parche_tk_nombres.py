#!/usr/bin/env python3
"""parche_tk_nombres.py - TECNICAS: nombres de 8 glifos + filas alineadas por %.

Base: TEST_BK. Plantilla en 0x15410 (410 B). Cada fila de valores es:
[&4][5 esp][&7][32 B de valores][terminador 2 B] = 48 B (la ultima acaba en 0000).
Cambios: el campo de nombre pasa a 8 espacios (+6 B por fila) y los valores se
desplazan +6 B con ella (todas las filas alineadas por los %). Las 37 referencias
de START se reapuntan (delta +6 para todo lo que este a partir del &7 de su fila).
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 410
ESP = b'\x81\x40'
FILAS = [76, 124, 172, 266, 314, 362]

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    tpl = bytearray(st[T0:T0+LEN])

    # 1) reconstruir: en cada fila, 5 espacios -> 8 (todo lo posterior +6 B)
    nueva = bytearray()
    mapa = {}                       # off_viejo -> off_nuevo (para refs fuera de filas)
    rangos = []                     # (F_viejo, F_nuevo) de cada fila
    i = 0; posn = 0; idx = 0
    while i < len(tpl):
        if idx < len(FILAS) and i == FILAS[idx]:
            F = i; Fn = posn
            rangos.append((F, Fn))
            term = tpl[F+46:F+48]   # 2f6e o 0000
            cuerpo = tpl[F+14:F+46] # los 32 B de valores tal cual
            nueva += bytes.fromhex('2634') + ESP*8 + bytes.fromhex('2637') + cuerpo + term
            # mapa del tramo completo de la fila:
            for k in range(48):
                if k <= 11:  mapa[F+k] = Fn + k              # marca + espacios viejos
                else:        mapa[F+k] = Fn + k + 6          # &7, valores y terminador
            i += 48; posn += 54; idx += 1
            continue
        mapa[i] = posn
        nueva.append(tpl[i]); i += 1; posn += 1
    assert idx == 6, idx
    print('  plantilla: %d -> %d B' % (LEN, len(nueva)))

    extra = len(nueva) - LEN
    assert all(st[T0+LEN+k] == 0xFF for k in range(extra)), 'sin 0xFF detras'

    # 2) reapuntar TODAS las refs de START a la plantilla
    base = T0 + 0x10000
    n = 0
    for k in range(4, len(st) - 4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        off = v - base
        if base <= v < base + LEN and k % 2 == 0 and off in mapa:
            st[k:k+4] = (base + mapa[off]).to_bytes(4, 'big')
            n += 1
    print('  refs reapuntadas: %d' % n)

    st[T0:T0+len(nueva)] = nueva
    st[T0+len(nueva):T0+LEN+extra] = b'\xff' * (LEN + extra - len(nueva))
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
