#!/usr/bin/env python3
"""Scan for 1bpp font data: long runs of bytes with popcount 1..6."""
import sys

def popcount(b): return bin(b).count('1')

def main():
    path = sys.argv[1]
    data = open(path, 'rb').read()
    n = len(data)
    run_start = None
    good = 0
    total = 0
    MIN_RUN = 1024
    results = []
    i = 0
    while i < n:
        b = data[i]
        pc = popcount(b)
        ok = 1 <= pc <= 6
        if ok:
            if run_start is None: run_start = i
            good += 1
        else:
            if run_start is not None:
                total = i - run_start
                # allow some bad bytes; close run if this one is far off
                if pc in (0, 7, 8):
                    if total >= MIN_RUN and good / total > 0.9:
                        results.append((run_start, i))
                    run_start = None
                    good = 0
        i += 1
    if run_start is not None and n - run_start >= MIN_RUN:
        results.append((run_start, n))
    # merge nearby runs
    merged = []
    for a, b in results:
        if merged and a - merged[-1][1] < 64:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    for a, b in merged:
        if b - a >= MIN_RUN:
            print(f"0x{a:08X}-0x{b:08X} ({b-a} B)")

main()
