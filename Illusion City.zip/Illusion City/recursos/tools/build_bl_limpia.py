#!/usr/bin/env python3
"""build_bl_limpia.py - regenera TEST_BL desde BH con todo lo que tenía.

Secuencia de parches sobre TEST_BH para llegar a TEST_BL:
  1. parche_tecnicas_bc.py (Técnicas mudada a 0x15410, 446 B)
  2. parche_tk_rotulos7.py (rótulos +7 celdas)
  (los demás cambios ya están en BH: nombres, columnas Objetos, etc.)
"""
import importlib, importlib.util, os, sys, hashlib

AQUI = os.path.dirname(os.path.abspath(__file__))
PROY = os.path.dirname(AQUI)

def load(name):
    spec = importlib.util.spec_from_file_location(name.replace('.py',''), os.path.join(AQUI, name))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

BH = os.path.join(PROY, "TEST_BH.bin")
OUT = os.path.join(PROY, "TEST_BL.bin")

def step(script_name, ent, sal):
    print('  [%s] %s -> %s' % (script_name, os.path.basename(ent), os.path.basename(sal)))
    spec = importlib.util.spec_from_file_location(script_name, os.path.join(AQUI, script_name))
    mod = importlib.util.module_from_spec(spec)
    # parche_tk_rotulos7.py usa sys.argv, no tiene funcion aplica con args posicionales
    # parche_tk_rotulos.py tiene aplica(ent, sal)
    mod.aplica(ent, sal)
    md5 = hashlib.md5(open(sal,'rb').read()).hexdigest()
    print('    MD5 %s' % md5)

def main():
    tmp1 = '/tmp/_bl_step1.bin'
    print('=== TEST_BL desde TEST_BH ===')
    step('parche_tk_rotulos.py', BH, tmp1)       # Técnicas a 0x15410 (446 B)
    # parche_tk_rotulos7.py espera una plantilla de 446 B con filas en off 76,130,184,284,338,392
    # y el test de assert es flexible. Lo ejecutamos con subprocess:
    import subprocess
    r = subprocess.run([sys.executable, os.path.join(AQUI, 'parche_tk_rotulos7.py'), tmp1, OUT],
                       capture_output=True, text=True, cwd=AQUI)
    print(r.stdout)
    if r.returncode != 0:
        print(r.stderr[-2000:])
        raise SystemExit('fallo')
    md5 = hashlib.md5(open(OUT,'rb').read()).hexdigest()
    print('=== TEST_BL final: MD5 %s ===' % md5)

main()
