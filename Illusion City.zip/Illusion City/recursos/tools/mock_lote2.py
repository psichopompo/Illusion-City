#!/usr/bin/env python3
"""mock_lote2.py - simulacion (NO captura real) de los textos del lote 2.

Usa los bitmaps REALES de la fuente del juego (INIT.BIN 0x4ED0, celdas 12x12).
El glifo de "$" se copia de la propia captura.
"""
import numpy as np
from PIL import Image

INIT = 'recursos/analisis/INIT.BIN'
BASE, CELL = 0x4ED0, 18
d = open(INIT, 'rb').read()


def celda(rel):
    raw = d[BASE + rel * CELL: BASE + rel * CELL + CELL]
    g = np.zeros((12, 12), int)
    for r in range(12):
        for c in range(12):
            bit = 12 * r + c
            if raw[bit // 8] & (1 << (7 - bit % 8)):
                g[r, c] = 1
    return g


def celda_de(ch):
    if '0' <= ch <= '9':
        return celda(-772 + ord(ch) - ord('0'))
    if 'A' <= ch <= 'Z':
        return celda(-762 + ord(ch) - ord('A'))
    if 'a' <= ch <= 'z':
        return celda(-736 + ord(ch) - ord('a'))
    return None


def pega(img, g, x, y):
    px = img.load()
    W, H = img.size
    for r in range(12):
        for c in range(12):
            if g is not None and g[r, c] and 0 <= x + c < W and 0 <= y + r < H:
                px[x + c, y + r] = (255, 255, 255)


def linea(img, texto, x0, y0, extra=None):
    for k, ch in enumerate(texto):
        pega(img, extra[ch] if extra and ch in extra else celda_de(ch), x0 + 12 * k, y0)


# "$" copiado de la captura del juego (celda 12x12 en x=200, y=136)
im = Image.open("/home/user/uploads/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST]-260919-235032.png").convert('RGB')
src = im.load()
dolar = np.zeros((12, 12), int)
for r in range(12):
    for c in range(12):
        p = src[200 + c, 136 + r]
        if p[0] > 190 and p[1] > 190 and p[2] > 190:
            dolar[r, c] = 1
extra = {'$': dolar}

# ------------------------------------------------- 1) recuadro del dinero
for y in range(133, 150):
    for x in range(52, 220):
        im.putpixel((x, y), (0, 0, 0))
# "Dinero" + 6 cifras (los ceros de delante van en blanco) + "$"  = 13 glifos
linea(im, 'Dinero' + '   140' + '$', 56, 136, extra)
im.save('preview_dinero.png')

# ------------------------------------------------- 2) fila "Ficha" -> "Estado"
im3 = Image.open("/home/user/uploads/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST]-260919-235032.png").convert('RGB')
for y in range(88, 101):
    for x in range(56, 145):
        im3.putpixel((x, y), (0, 0, 0))
linea(im3, 'Estado', 59, 89, extra)
im3.save('preview_estado.png')

# ------------------------------------------------- 3) pantalla de titulo
im2 = Image.open('/home/user/image-search/illusion-city-mega-cd-sega-title-screen--1.jpg').convert('RGB')
for y0, y1 in ((110, 122), (126, 134), (137, 147)):
    for y in range(y0, y1 + 1):
        for x in range(58, 198):
            im2.putpixel((x, y), (0, 0, 0))
for txt, y in (('Cargar', 111), ('Con intro', 124), ('Sin intro', 136)):
    for k, ch in enumerate(txt):
        if ch == ' ':
            continue
        pega(im2, celda_de(ch), 77 + 12 * k, y)
im2.save('preview_titulo.png')
print('previews: preview_dinero.png  preview_estado.png  preview_titulo.png')
