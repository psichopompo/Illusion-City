#!/usr/bin/env python3
"""mock_lote3.py - simulacion (NO captura real) del espaciado nuevo.

Regla nueva: las LETRAS avanzan 8 px, el resto (cifras, simbolos, espacio) 12 px.
Los glifos son los REALES del juego (INIT.BIN 0x4ED0, celdas 12x12).
El glifo de "$" se copia de la captura.
"""
import numpy as np
from PIL import Image

INIT = 'recursos/analisis/INIT.BIN'
BASE, CELL = 0x4ED0, 18
d = open(INIT, 'rb').read()
ACENTOS = {0x95FB: 'Á', 0x9660: 'á', 0x966B: 'É', 0x967B: 'Í', 0x9682: 'Ó',
           0x96AF: 'Ú', 0x96B3: 'Ñ', 0x96BD: 'Ü', 0x96C5: '¿', 0x96DA: '¡',
           0x9744: 'é', 0x9755: 'í', 0x975C: 'ú', 0x975F: 'ó', 0x976C: 'ü', 0x9770: 'ñ'}


def celda(rel):
    raw = d[BASE + rel * CELL: BASE + rel * CELL + CELL]
    g = np.zeros((12, 12), int)
    for r in range(12):
        for c in range(12):
            bit = 12 * r + c
            if raw[bit // 8] & (1 << (7 - bit % 8)):
                g[r, c] = 1
    return g


def glifo(ch):
    if '0' <= ch <= '9':
        return celda(-772 + ord(ch) - 48), 12
    if 'A' <= ch <= 'Z':
        return celda(-762 + ord(ch) - 65), 8
    if 'a' <= ch <= 'z':
        return celda(-736 + ord(ch) - 97), 8
    raise ValueError(ch)


DOLAR = None


def carga_dolar():
    global DOLAR
    im = Image.open("/home/user/uploads/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST]-260919-235032.png").convert('RGB')
    src = im.load()
    DOLAR = np.zeros((12, 12), int)
    for r in range(12):
        for c in range(12):
            p = src[200 + c, 136 + r]
            if p[0] > 190 and p[1] > 190 and p[2] > 190:
                DOLAR[r, c] = 1


def pega(im, g, x, y):
    px = im.load()
    W, H = im.size
    for r in range(12):
        for c in range(12):
            if g[r, c] and 0 <= x + c < W and 0 <= y + r < H:
                px[x + c, y + r] = (255, 255, 255)


def linea(im, texto, x, y, cursor_visible=False):
    """Pinta con la regla nueva. ' ' = hueco de 12 px, '$' = glifo especial."""
    for ch in texto:
        if ch == ' ':
            x += 12
            continue
        if ch == '$':
            pega(im, DOLAR, x, y)
            x += 12
            continue
        g, w = glifo(ch)
        pega(im, g, x, y)
        x += w
    return x


carga_dolar()
CAP = "/home/user/uploads/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST]-260919-235032.png"

# ---------------------------------------------- 1) recuadro del dinero
im = Image.open(CAP).convert('RGB')
for y in range(132, 151):
    for x in range(52, 218):
        im.putpixel((x, y), (0, 0, 0))
# 7 cifras = 7 glifos (los ceros de delante van en blanco, ocupan lo mismo)
fin = linea(im, 'Dinero' + ' ' + '    140' + 'H$', 54, 136)
im.save('preview_D_dinero.png')
print('preview_D_dinero.png   tinta x54..%d  (borde de la caja en x222)' % (fin - 2))

# ---------------------------------------------- 2) menu principal
# filas medidas en la captura: tinta a y=43,55,67,79,91,103 (paso 12 px), x=59
im = Image.open(CAP).convert('RGB')
for y in range(41, 112):
    for x in range(56, 142):
        im.putpixel((x, y), (0, 0, 0))
for k, txt in enumerate(['Objetos', 'Equipo', 'Hablar', 'Estado', 'Sistema']):
    linea(im, txt, 59, 55 + k * 12, )
im.save('preview_D_menu.png')
print('preview_D_menu.png  (la fila resaltada "Magia" no se toca)')

# ---------------------------------------------- 3) pantalla de titulo
im2 = Image.open('/home/user/image-search/illusion-city-mega-cd-sega-title-screen--1.jpg').convert('RGB')
for y0, y1 in ((110, 122), (126, 134), (137, 147)):
    for y in range(y0, y1 + 1):
        for x in range(58, 198):
            im2.putpixel((x, y), (0, 0, 0))
for txt, y in (('Cargar partida', 111), ('Con intro', 124), ('Sin intro', 136)):
    linea(im2, txt, 75, y)
im2.save('preview_D_titulo.png')
print('preview_D_titulo.png   "Cargar partida" acaba en x%d (borde derecho de la caja ~x197)'
      % linea(Image.new('RGB', (4, 4)), 'Cargar partida', 75, 0))
