#!/usr/bin/env python3
"""parche_lote3.py - ancho de letras + textos del lote 3 (TEST_E).

HALLAZGOS MEDIDOS (26/09)
-------------------------
1) El avance entre caracteres es fijo: 3 unidades de 4 px = 12 px.
   Solo existen DOS instrucciones asi en todo el disco:
     START  file 0x8B54   addq.w #$3,$14(a0)   (lo usan los DOS interpretes)
     SSTART file 0x242A   addq.w #$3,$14(a0)   (pintor del menu del titulo)
2) La rutina nueva sustituye ese avance: LAS LETRAS (Ａ-Ｚ ａ-ｚ y los 16
   codigos con acento) avanzan 2 unidades (8 px); el resto no cambia:
     - DIGITOS y simbolos a 12 px (los numeros del menu de Velocidad siguen
       alineados con sus flechas y el campo del dinero no baila).
     - ESPACIO a 12 px (las alineaciones hechas con espacios se mantienen).
3) NO se excluye ningun descriptor: en TEST_D se excluia $A423A y el titulo
   no encogio. Como ese descriptor no aparece NUNCA en SSTART, la exclusion
   no podia ser la causa; aun asi se elimina para no dejar dudas.

ERRORES PROPIOS CORREGIDOS EN ESTA VERSION
------------------------------------------
A) `st[a:a+8] = <14 bytes>` en un bytearray NO sobrescribe: INSERTA y desplaza
   el resto +6 bytes. Eso movio la rutina de START 12 bytes y dejo el salto
   cayendo en zona vacia (0xFF) -> instruccion ilegal -> pantalla negra.
   Arreglado con un helper que exige que el trozo tenga la MISMA longitud, mas
   una comprobacion de que el tamano del array no cambia.
B) Ademas el bytearray desplazado escribia 12 bytes de mas al final del fichero.
   Con (A) arreglado, no puede pasar; se comprueba igualmente que nada cambie
   fuera de los offsets previstos.
C) `revisa_rutina()` ya no depende de capstone (se instala fuera del workspace
   y no persiste).

Uso:
    python3 tools/parche_lote3.py estado
    python3 tools/parche_lote3.py aplica [salida.bin]
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
BASE = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")

SECTOR = 2352
LBA_START, SZ_START = 59, 98184
LBA_SSTART, SZ_SSTART = 43, 32644
MD5_ESPERADO = "ab72a6c1b949f8cb3a1c8b1c81f0559e"   # build con la caja de texto (B)

_spec = importlib.util.spec_from_file_location('edcecc', os.path.join(AQUI, 'edcecc.py'))
edcecc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(edcecc)


def region(raw, lba, size):
    out = bytearray()
    for k in range(0, size, 2048):
        b = (lba + k // 2048) * SECTOR + 16
        out.extend(raw[b:b + min(2048, size - k)])
    return bytes(out)


def escribe_region(raw, lba, datos):
    for k in range(0, len(datos), 2048):
        t = datos[k:k + 2048]
        b = (lba + k // 2048) * SECTOR + 16
        raw[b:b + len(t)] = t


def fw(s):
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif '0' <= ch <= '9':
            out += bytes([0x82, 0x4F + ord(ch) - 48])
        elif ch == ' ':
            out += bytes([0x81, 0x40])
        elif ch == '$':
            out += bytes([0x81, 0x90])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


# ---------------------------------------------------------------- rutina
ACENTOS = [0x95FB, 0x9660, 0x966B, 0x967B, 0x9682, 0x96AF, 0x96B3, 0x96BD,
           0x96C5, 0x96DA, 0x9744, 0x9755, 0x975C, 0x975F, 0x976C, 0x9770]
BCLR = bytes.fromhex('08b900060000a75d')     # bclr.b #$6,$a75d.l
ANCHO = bytes.fromhex('56680014')            # addq.w #$3,$14(a0)
ESTRECHO = bytes.fromhex('54680014')         # addq.w #$2,$14(a0)
ETQ = {'acentos': 0x22, 'estrecho': 0x44, 'bucle': 0x26, 'tabla': 0x52}


def rutina_ancho(ram):
    """Codigo que sustituye al avance fijo. Los saltos se cuentan desde la
    PALABRA SIGUIENTE al opcode, como hace el 68000."""
    b = bytearray()
    saltos = []
    b += bytes.fromhex('3004')                      # move.w d4,d0
    b += bytes.fromhex('0c408260')                  # cmpi.w #$8260,d0
    b += bytes.fromhex('6d00'); saltos.append((len(b), 'acentos')); b += b'\x00\x00'
    b += bytes.fromhex('0c408279')                  # cmpi.w #$8279,d0
    b += bytes.fromhex('6f00'); saltos.append((len(b), 'estrecho')); b += b'\x00\x00'
    b += bytes.fromhex('0c408281')                  # cmpi.w #$8281,d0
    b += bytes.fromhex('6d00'); saltos.append((len(b), 'acentos')); b += b'\x00\x00'
    b += bytes.fromhex('0c40829a')                  # cmpi.w #$829A,d0
    b += bytes.fromhex('6f00'); saltos.append((len(b), 'estrecho')); b += b'\x00\x00'
    assert len(b) == 0x22, hex(len(b))
    b += bytes.fromhex('47fa'); saltos.append((len(b), 'tabla')); b += b'\x00\x00'
    b += bytes.fromhex('321b')                      # move.w (a3)+,d1
    b += bytes.fromhex('b041')                      # cmp.w d1,d0
    b += bytes.fromhex('6700'); saltos.append((len(b), 'estrecho')); b += b'\x00\x00'
    b += bytes.fromhex('0c41ffff')                  # cmpi.w #$ffff,d1
    b += bytes.fromhex('6600'); saltos.append((len(b), 'bucle')); b += b'\x00\x00'
    assert len(b) == 0x36, hex(len(b))
    b += ANCHO + BCLR + bytes.fromhex('4e75')       # 12 px + bclr + rts
    assert len(b) == 0x44, hex(len(b))
    b += ESTRECHO + BCLR + bytes.fromhex('4e75')    # 8 px + bclr + rts
    assert len(b) == 0x52, hex(len(b))
    for c in ACENTOS:
        b += c.to_bytes(2, 'big')
    b += bytes.fromhex('ffff')
    for pos, destino in saltos:
        b[pos:pos + 2] = ((ETQ[destino] - pos) & 0xFFFF).to_bytes(2, 'big')
    return bytes(b)


def revisa_rutina():
    """Comprueba opcodes, saltos, la tabla y los destinos. Sin dependencias."""
    r = rutina_ancho(0x27C00)
    fallos = []

    def u16(i):
        return int.from_bytes(r[i:i + 2], 'big')

    def destino(i):
        d = u16(i + 2)
        if d >= 0x8000:
            d -= 0x10000
        return 0x27C00 + i + 2 + d

    esperado = [
        (0x00, '3004'), (0x02, '0c408260'), (0x06, '6d00'),
        (0x0A, '0c408279'), (0x0E, '6f00'),
        (0x12, '0c408281'), (0x16, '6d00'),
        (0x1A, '0c40829a'), (0x1E, '6f00'),
        (0x22, '47fa'), (0x26, '321b'), (0x28, 'b041'), (0x2A, '6700'),
        (0x2E, '0c41ffff'), (0x32, '6600'),
        (0x36, '56680014'), (0x3A, '08b900060000a75d'), (0x42, '4e75'),
        (0x44, '54680014'), (0x48, '08b900060000a75d'), (0x50, '4e75'),
    ]
    for off, hexs in esperado:
        got = r[off:off + len(bytes.fromhex(hexs))].hex()
        if got != hexs:
            fallos.append('opcode en 0x%X: %s (esperaba %s)' % (off, got, hexs))
    for i, esp in {0x06: 0x27C22, 0x0E: 0x27C44, 0x16: 0x27C22, 0x1E: 0x27C44,
                   0x2A: 0x27C44, 0x32: 0x27C26}.items():
        got = destino(i)
        if got != esp:
            fallos.append('salto en 0x%X -> $%X (esperaba $%X)' % (i, got, esp))
    if 0x27C00 + 0x24 + u16(0x24) != 0x27C52:
        fallos.append('lea de la tabla mal')
    if r[0x52:0x72] != b''.join(c.to_bytes(2, 'big') for c in ACENTOS):
        fallos.append('tabla de acentos mal')
    if r[0x72:0x74] != b'\xff\xff':
        fallos.append('la tabla no termina en FFFF')
    if len(r) != 0x74:
        fallos.append('longitud %d (esperaba 116)' % len(r))
    if fallos:
        raise SystemExit('RUTINA MAL:\n  ' + '\n  '.join(fallos))
    return r


# ---------------------------------------------------------------- direcciones
OFF_AVANCE_ST, RAM_RUTINA_ST = 0x8B54, 0x27C00
OFF_AVANCE_SS, RAM_RUTINA_SS = 0x242A, 0x12EC2
OFF_RUTINA_ST = RAM_RUTINA_ST - 0x10000
OFF_RUTINA_SS = RAM_RUTINA_SS - 0x10000
OFF_DINERO_ST, OFF_ESTADO_ST = 0x17AA0, 0x17AB0
MARC_FILA_FICHA, FILA_VIEJA = 0x13D22, bytes.fromhex('00023d4a')
LEA_DINERO = (0x10B04, 0x10B9E)
LEA_VIEJO = bytes.fromhex('43f90002187a')
OFF_TABLA_TIT = 0x1010
STRING_RAMS = (0x13000, 0x13020, 0x13040)
TITULO = ("Cargar partida", "Con intro", "Sin intro")

# --- plantilla del menu de VELOCIDAD (0x17914, 142 B) ---
# La plantilla la pinto yo en la 19ª tanda (142 B en 0x17914, puntero en 0x139B0).
# Aqui se reescribe con las palabras nuevas de David y el bloque "Rapido Lento"
# desplazado para que el hueco entre las dos palabras caiga bajo la flecha 4.
OFF_TPL_VEL = 0x17914
RAM_TPL_VEL = 0x27914
PTR_TPL_VEL = 0x139B0
TPL_VEL = (b'&5' + b'\x82\x75\x82\x85\x82\x8c\x82\x8f\x82\x83\x82\x89\x82\x84\x82\x81\x82\x84'   # Velocidad
           + b'/n/n&4' + b'\x81\x40' * 7       # 7 espacios (medido 47ª tanda: «Rápido» x=109;
                                            # con 6 quedaba en x=97 y David lo quiere ~106)
           + b'\x82\x71\x96\x60\x82\x90\x82\x89\x82\x84\x82\x8f'  # Rapido (con á)
           + b'\x81\x40'                                                   # hueco
           + b'\x82\x6b\x82\x85\x82\x8e\x82\x94\x82\x8f'            # Lento
           + b'&7/n' + b'\x81\x40' * 7 + b'\x82\x50\x82\x51\x82\x52\x82\x53\x82\x54\x82\x55\x82\x56\x82\x57'  # 1-8
           + b'/n\x82\x6c\x82\x85\x82\x8e\x82\x93\x82\x81\x82\x8a\x82\x85\x82\x93'       # Mensajes
           + b'/n\x82\x6c\x82\x8f\x82\x96\x82\x89\x82\x8d\x82\x89\x82\x85\x82\x8e\x82\x94\x82\x8f'  # Movimiento
           + b'/n\x82\x61\x82\x81\x82\x94\x82\x81\x82\x8c\x82\x8c\x82\x81'  # Batalla
           + b'\x00\x00')
LEN_JSR, LEN_RUT = 12, 116


def pon(buf, off, data, cual):
    """Escribe data en buf[off:off+len(data)] exigiendo que NO cambie el tamano.

    Este es el error que rompio TEST_D: una asignacion a un trozo MAS CORTO
    inserta bytes y desplaza todo lo que viene detras.
    """
    assert off + len(data) <= len(buf), '%s: se sale del fichero' % cual
    cola = len(buf)
    buf[off:off + len(data)] = data
    assert len(buf) == cola, '%s: el fichero cambio de tamano (%d -> %d) !!!' % (
        cual, cola, len(buf))


def estado():
    raw = open(BASE, 'rb').read()
    st = region(raw, LBA_START, SZ_START)
    ss = region(raw, LBA_SSTART, SZ_SSTART)
    print('.bin  MD5 %s' % hashlib.md5(raw).hexdigest())
    print('START  avance 0x%X = %s' % (OFF_AVANCE_ST, st[OFF_AVANCE_ST:OFF_AVANCE_ST + 4].hex(' ')))
    print('SSTART avance 0x%X = %s' % (OFF_AVANCE_SS, ss[OFF_AVANCE_SS:OFF_AVANCE_SS + 4].hex(' ')))
    print('SSTART tabla titulo %s' % ss[OFF_TABLA_TIT:OFF_TABLA_TIT + 12].hex(' '))
    print('START  fila 5 -> %s' % st[MARC_FILA_FICHA:MARC_FILA_FICHA + 4].hex(' '))


def aplica(salida):
    raw0 = open(BASE, 'rb').read()
    assert hashlib.md5(raw0).hexdigest() == MD5_ESPERADO, 'el .bin no es el esperado'
    rut = revisa_rutina()
    st = bytearray(region(raw0, LBA_START, SZ_START))
    ss = bytearray(region(raw0, LBA_SSTART, SZ_SSTART))
    notas = []

    # ---- comprobaciones previas ----
    assert len(st) == SZ_START and len(ss) == SZ_SSTART
    for buf, off, nom in ((st, OFF_AVANCE_ST, 'START'), (ss, OFF_AVANCE_SS, 'SSTART')):
        assert buf[off:off + 4] == ANCHO, 'avance inesperado en %s' % nom
        assert buf[off + 4:off + 12] == BCLR, 'el bclr no sigue al avance en %s' % nom
    assert st[MARC_FILA_FICHA:MARC_FILA_FICHA + 4] == FILA_VIEJA, 'fila 5 inesperada'
    for off in LEA_DINERO:
        assert st[off:off + 6] == LEA_VIEJO, 'lea del dinero inesperado en 0x%X' % off
    for k, ram in enumerate(STRING_RAMS):
        assert ss[OFF_TABLA_TIT + k * 4:OFF_TABLA_TIT + k * 4 + 4] == \
            (0x1101C + k * 0x16).to_bytes(4, 'big'), 'tabla del titulo inesperada'
    for off, nom in ((OFF_RUTINA_ST, 'START'), (OFF_RUTINA_SS, 'SSTART')):
        buf = st if nom == 'START' else ss
        assert buf[off:off + LEN_RUT] == b'\xff' * LEN_RUT, 'hueco ocupado en %s' % nom

    # ---- 1) avance de las letras: START ----
    pon(st, OFF_AVANCE_ST,
        bytes.fromhex('4eb9') + RAM_RUTINA_ST.to_bytes(4, 'big') + bytes.fromhex('4e71') * 3,
        'avance START')
    pon(st, OFF_RUTINA_ST, rut, 'rutina START')
    notas.append('1) START   avance 0x%X -> jsr $%X, rutina (%d B) en $%X'
                 % (OFF_AVANCE_ST, RAM_RUTINA_ST, len(rut), RAM_RUTINA_ST))

    # ---- 2) avance de las letras: SSTART + strings del titulo ----
    pon(ss, OFF_AVANCE_SS,
        bytes.fromhex('4eb9') + RAM_RUTINA_SS.to_bytes(4, 'big') + bytes.fromhex('4e71') * 3,
        'avance SSTART')
    pon(ss, OFF_RUTINA_SS, rut, 'rutina SSTART')
    for k, (ram, txt) in enumerate(zip(STRING_RAMS, TITULO)):
        data = fw(txt) + b'\x00\x00'
        assert len(data) <= 0x20, txt
        pon(ss, ram - 0x10000, data + b'\x00' * (0x20 - len(data)), 'string %d' % k)
        pon(ss, OFF_TABLA_TIT + k * 4, ram.to_bytes(4, 'big'), 'puntero %d' % k)
    notas.append('2) SSTART  avance 0x%X -> jsr $%X; titulo: %s'
                 % (OFF_AVANCE_SS, RAM_RUTINA_SS,
                    ' / '.join('%r (%d)' % (t, len(t)) for t in TITULO)))

    # ---- 3) "Estado" en la fila 5 del menu ----
    pon(st, OFF_ESTADO_ST, fw('Estado') + b'\x00\x00', 'Estado')
    pon(st, MARC_FILA_FICHA, (0x10000 + OFF_ESTADO_ST).to_bytes(4, 'big'), 'fila 5')
    notas.append('3) menu    fila 5 -> "Estado" ($%X)' % (0x10000 + OFF_ESTADO_ST))

    # ---- 4) dinero: etiqueta ----
    pon(st, OFF_DINERO_ST, fw('Dinero') + b'\x00\x00', 'Dinero')
    for off in LEA_DINERO:
        pon(st, off, bytes.fromhex('43f9') + (0x10000 + OFF_DINERO_ST).to_bytes(4, 'big'),
            'lea dinero 0x%X' % off)
    notas.append('4) dinero  etiqueta -> "Dinero"; 7 cifras y "H$" sin tocar')

    # ---- verificaciones antes de escribir ----
    assert len(st) == SZ_START and len(ss) == SZ_SSTART, 'tamano alterado'
    # el destino de cada jsr debe contener la rutina (el bug de TEST_D)
    for buf, off_j, off_r, nom in ((st, OFF_AVANCE_ST, OFF_RUTINA_ST, 'START'),
                                   (ss, OFF_AVANCE_SS, OFF_RUTINA_SS, 'SSTART')):
        dest = int.from_bytes(buf[off_j + 2:off_j + 6], 'big')
        assert dest == 0x10000 + off_r, '%s: el jsr no apunta a la rutina' % nom
        assert buf[off_r:off_r + len(rut)] == rut, '%s: la rutina no esta en su sitio' % nom

    raw = bytearray(raw0)
    escribe_region(raw, LBA_START, bytes(st))
    escribe_region(raw, LBA_SSTART, bytes(ss))
    raw = bytearray(edcecc.repara_bytes(bytes(raw)))
    print('\n'.join(notas))

    dif = [i // SECTOR for i in range(0, len(raw0), SECTOR)
           if raw0[i:i + SECTOR] != raw[i:i + SECTOR]]
    esperados = set()
    for lba, sz in ((LBA_START, SZ_START), (LBA_SSTART, SZ_SSTART)):
        esperados |= set(range(lba, lba + (sz + 2047) // 2048))
    fuera = [s for s in dif if s not in esperados]
    assert not fuera, 'cambio algo fuera de START/SSTART: %s' % fuera[:10]
    open(salida, 'wb').write(bytes(raw))

    cur = open(salida, 'rb').read()
    st2 = region(cur, LBA_START, SZ_START)
    ss2 = region(cur, LBA_SSTART, SZ_SSTART)
    print('\nsectores tocados: %d (todos dentro de START/SSTART)' % len(dif))
    print('escrito %s' % salida)
    print('  MD5 .bin %s' % hashlib.md5(cur).hexdigest())
    print('  START    %s' % hashlib.md5(st2).hexdigest())
    print('  SSTART   %s' % hashlib.md5(ss2).hexdigest())
    v = edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC  %s' % ('OK' if not any(v.values()) else 'MAL %s' % v))
    for buf, off_j, off_r, nom in ((st2, OFF_AVANCE_ST, OFF_RUTINA_ST, 'START'),
                                   (ss2, OFF_AVANCE_SS, OFF_RUTINA_SS, 'SSTART')):
        dest = int.from_bytes(buf[off_j + 2:off_j + 6], 'big')
        ok = buf[off_r:off_r + len(rut)] == rut
        print('  %-7s jsr -> $%05X  rutina presente: %s' % (nom, dest, ok))
    print('  titulo: %r / %r / %r'
          % tuple(ss2[r - 0x10000:r - 0x10000 + 0x1e].split(b'\x00\x00')[0]
                  .decode('shift_jis') for r in STRING_RAMS))


if __name__ == '__main__':
    if len(sys.argv) < 2 or sys.argv[1] == 'estado':
        estado()
    else:
        aplica(sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROY, "TEST_E.bin"))
