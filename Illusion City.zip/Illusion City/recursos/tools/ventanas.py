"""ventanas.py - mapa de VENTANAS del motor: quien usa cada buffer.

Busca los bloques de inicializacion de ventana del START:
    move.w #fila,$4(a0) / #col,$6(a0) / #ancho,$8(a0) / #alto,$a(a0)
    ... move.l #$aXXXX,$1e(a0)     <- el buffer de dibujo
y saca el tamano que necesita cada una ($1c = $8*$a*16 palabras = $8*$a*32 bytes).

Uso: python3 ventanas.py [fichero.bin]
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

BIN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(os.path.dirname(AQUI)), "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
st = m.region(open(BIN, 'rb').read(), 59, 98184)
print('  %-8s %-22s %-12s %-6s %-6s %-7s %s' % ('fichero', 'RAM', 'buffer', 'ancho', 'alto', 'bytes', 'rango'))
usos = []
for o in range(0, len(st) - 8, 2):
    if st[o:o + 2] == b'\x21\x7c' and st[o + 6:o + 8] == b'\x00\x1e':
        buf = int.from_bytes(st[o + 2:o + 6], 'big')
        if not (0xA5000 <= buf < 0xAC000):
            continue
        # busca hacia atras el bloque de la ventana
        anc = alt = None
        for k in range(o - 2, max(0, o - 60), -2):
            if st[k:k + 2] == b'\x31\x7c' and st[k + 4:k + 6] == b'\x00\x08':
                anc = int.from_bytes(st[k + 2:k + 4], 'big')
            if st[k:k + 2] == b'\x31\x7c' and st[k + 4:k + 6] == b'\x00\x0a':
                alt = int.from_bytes(st[k + 2:k + 4], 'big')
            if anc and alt:
                break
        if anc is None or alt is None:
            continue
        b = anc * alt * 32
        usos.append((buf, b, o, anc, alt))
for buf, b, o, anc, alt in sorted(usos):
    print('  0x%05X  \$%06X  \$%05X  %5d  %5d  %6d   \$%05X..\$%05X  (setup 0x%05X)'
          % (o, o + 0x10000, buf, anc, alt, b, buf, buf + b, o))
