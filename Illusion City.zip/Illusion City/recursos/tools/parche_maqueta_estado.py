#!/usr/bin/env python3
"""parche_maqueta_estado.py - la MAQUETA del menu de Estado con las palabras ENTERAS.

POR QUE AHORA SI CABEN (medido el 22/09)
  El texto de la ficha NO se dibuja a celdas de 12 px: el pintor avanza **8 px por
  letra** y **12 px por espacio** (medido: las letras de «EXPER» empiezan en
  x=17, 25, 33, 41, 49 -> paso de 8). Asi que una etiqueta de 11 letras ocupa
  88 px, no 132. La ventana da 179 px de texto (x=17..196):
      EXPERIENCIA(11) 88 + espacio 12 + 7 digitos 56 = 156  ENTRA
      HABILIDAD(9) + «65%» + nombre del arma = 72+12+32+12+40 = 168 ENTRA
  => Se ponen las palabras enteras: NIVEL, EXPERIENCIA, SIGUIENTE, PV, PM, ATAQUE,
     DEFENSA, VELOCIDAD, HABILIDAD, PRECISIÓN.

ESTRUCTURA DE CADA FILA (celdas de la plantilla)
  [marca $5][ETIQUETA (1 celda por letra)][1 espacio][$7][BLOQUE ORIGINAL]
  El BLOQUE se copia tal cual del original (los digitos, el ／, el ＋ y el % son
  literales de la plantilla): lo unico que cambia es su POSICION, y con ella las
  direcciones que el codigo usa para escribir las cifras.
  El bloque de HABILIDAD conserva sus 5 celdas finales: ahi va el NOMBRE DEL ARMA
  (dato vivo, lo copia el codigo: «Gun», «Rifle»...). Se devuelve a su sitio.

Uso: python3 parche_maqueta_estado.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TPL_ORIG = 0x13F8A
TPL = 0x17ADA
MARCA5, MARCA7 = bytes.fromhex('2635'), bytes.fromhex('2637')
SALTO, ESPACIO = bytes.fromhex('2f6e'), bytes.fromhex('8140')
ACENTOS = {'Ó': 0x9682, 'Í': 0x967B, 'É': 0x966B, 'Á': 0x95FB, 'Ú': 0x96AF,
           'Ñ': 0x96B3, 'Ü': 0x96BD}
# fila -> etiqueta nueva
ETIQ = {2: 'NIVEL', 3: 'EXPERIENCIA', 4: 'SIGUIENTE', 6: 'PV', 7: 'PM',
        9: 'ATAQUE', 10: 'DEFENSA', 11: 'VELOCIDAD', 12: 'HABILIDAD', 13: 'PRECISIÓN'}
# celdas EXTRA antes del $7, para cuadrar las columnas de cifras con las de EXPERIENCIA
# (pedido por David): el 2º grupo de PV/PM/DEFENSA va al 1er 0 de EXP, el de
# ATAQUE/VELOCIDAD al 2º 0, y el 1 de NIVEL al ultimo 0 de EXP.
# celdas EXTRA antes del $7, para que las cifras caigan donde pide David. Se midio la
# posicion actual de la 1ª cifra de cada fila y el objetivo (los 0 de EXPERIENCIA, que
# van de 114 a 162 px de 8 en 8):
#   fila        actual  objetivo  celdas
#   SIGUIENTE     98      114      +2
#   PV / PM       90      114      +3
#   ATAQUE        90      122      +4
#   DEFENSA       91      114      +3
#   VELOCIDAD    114      122      +1
#   HABILIDAD    106      114      +1
#   PRECISION    106      114      +1
#   NIVEL        115      162      +6
EXTRA = {2: 6, 4: 2, 6: 8, 7: 8, 9: 4, 10: 3, 11: 1, 12: 1, 13: 1}
# fila -> (referencia de la 1ª cifra, referencia de la 2ª cifra, celda de la 1ª cifra
#          desde el $7, celda de la 2ª cifra desde el $7)
# El NIVEL usa OTRA rutina ($186D6) que escribe DOS glifos (decena+unidad, o espacio+unidad)
# en las dos ULTIMAS celdas de su bloque: la direccion tiene que ser la de la 1ª de esas dos
# (5 celdas despues del $7). Con $18722 (3 glifos) saldria «1  00».
REFS = {2: ([(0x12E8E, 0)], 6),
        3: ([(0x12E9E, 0)], 1),
        4: ([(0x12EAE, 0)], 1),
        6: ([(0x12EC2, 0)], 1), 7: ([(0x12EE2, 0)], 1),
        9: ([(0x12F02, 0)], 1), 10: ([(0x12F22, 0)], 1), 11: ([(0x12F42, 0)], 1),
        12: ([(0x12E3C, 0), (0x12F7E, 0)], 1), 13: ([(0x12E42, 0), (0x12F8C, 0)], 1)}
# la 2ª cifra (el 2º numero o el maximo) de las filas de 7 celdas: a +5 celdas del $7
REFS2 = {6: [(0x12ED2, 5)], 7: [(0x12EF2, 5)], 9: [(0x12F12, 5)], 10: [(0x12F32, 5)],
         11: [(0x12F52, 5)]}
# el nombre del arma: primer celda despues del bloque con «%» (+6 celdas del $7)
ARMA_REF = [0x12E32, 0x12F72]
ARMA_CELDA = 6


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif ch in ACENTOS:
            out += ACENTOS[ch].to_bytes(2, 'big')
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def lee_filas(st, base):
    """parte la plantilla en filas: [(inicio, celdas, tiene_salto)]"""
    filas = []
    o = base
    while True:
        ini = o
        celdas = []
        while True:
            cel = st[o:o + 2]
            if cel == SALTO:
                o += 2; break
            if cel[0] == 0:
                o += 1; break
            celdas.append(cel); o += 2
        filas.append((ini, celdas, st[o - 2:o] == SALTO))
        if not filas[-1][2]:
            break
    return filas


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    orig = lee_filas(st, TPL_ORIG)
    print('  plantilla original: %d filas' % len(orig))

    nueva = bytearray()
    ini_fila = {}
    celdas_bloque = {}
    for k, (ino, celdas, con_salto) in enumerate(orig):
        ini_fila[k] = TPL + len(nueva)
        if k == 0:                                   # fila del nombre: 27 celdas + salto
            nueva += ESPACIO * 27 + SALTO
            continue
        if k not in ETIQ:                            # lineas vacias
            nueva += (SALTO if con_salto else b'\x00')
            continue
        i7 = celdas.index(MARCA7)
        lab = fw(ETIQ[k])
        fila = (MARCA5 + lab + ESPACIO * (1 + EXTRA.get(k, 0)) + MARCA7
                + b''.join(celdas[i7 + 1:]))
        # OFFSET EN BYTES del $7 dentro de la fila (¡incluye las celdas EXTRA!)
        celdas_bloque[k] = 2 + len(lab) + 2 * (1 + EXTRA.get(k, 0))
        nueva += fila + (SALTO if con_salto else b'\x00')
        ancho_px = 8 * (len(lab) // 2) + 12 + 8 * (len(fila) - 1 - len(lab) // 2 - 1)
        print('   fila %2d %-12s %2d celdas  ~%3d px de texto'
              % (k, ETIQ[k], len(fila), ancho_px))
    assert len(nueva) <= 1190, 'la plantilla nueva (%d B) no cabe' % len(nueva)
    st[TPL:TPL + len(nueva) + 2] = nueva + b'\x00\x00'
    print('  plantilla nueva: %d B' % len(nueva))

    # --- referencias ---
    n = 0
    for k, (lista, desde) in REFS.items():
        b7 = celdas_bloque[k]
        for sitio, _ in lista:
            nuevo = ini_fila[k] + b7 + 2 * desde + 0x10000
            st[sitio:sitio + 4] = nuevo.to_bytes(4, 'big'); n += 1
    for k, lista in REFS2.items():
        b7 = celdas_bloque[k]
        for sitio, desde in lista:
            nuevo = ini_fila[k] + b7 + 2 * desde + 0x10000
            st[sitio:sitio + 4] = nuevo.to_bytes(4, 'big'); n += 1
    for sitio in ARMA_REF:
        nuevo = ini_fila[12] + celdas_bloque[12] + 2 * ARMA_CELDA + 0x10000
        st[sitio:sitio + 4] = nuevo.to_bytes(4, 'big'); n += 1
    print('  %d referencias reapuntadas (incluidas las 2 del nombre del arma)' % n)

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
