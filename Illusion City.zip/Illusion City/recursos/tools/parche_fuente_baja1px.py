#!/usr/bin/env python3
"""parche_fuente_baja1px.py - baja 1 px los glifos que David dibujo "en alto".

DAVID (96ª tanda): bajar 1 px  q p g j , ; ¡ ¿ y el ICONO de las secciones (el que
llamamos ∆ para entendernos: fila 7, col 5 de su fuente). Motivo: los disenos se
subieron para que no se salieran de la celda 8x8 del PNG; en pantalla deben colgar.

METODO: cada glifo son 18 B = rejilla 12x12 (MSB first, fila a fila). Bajar 1 px =
desplazar las filas una abajo (la fila 11 se pierde; David los dibujo SIN colgar, se
comprueba que la ultima fila esta vacia). Se buscan TODAS las copias de cada glifo
por bytes en INIT y OPEN (el ';' vive en 4 tablas) y se reescriben.

Uso: python3 parche_fuente_baja1px.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('g', os.path.join(AQUI, 'glifo_offset.py'))
g = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(g)

REGS = (('INIT', 107, 149400), ('OPEN', 285, 69258))
OBJETIVOS = [('q', 0x8291), ('y', 0x8299), ('p', 0x8290), ('g', 0x8287), ('j', 0x828A),
             (',', 0x8143), (';', 0x8146), ('¡', 0x96DA), ('¿', 0x96C5)]


def baja_1px(data18, ch):
    bits = ''.join('{:08b}'.format(b) for b in data18)
    filas = [bits[r * 12:(r + 1) * 12] for r in range(12)]
    assert filas[11].strip('0') == '', '%s: la ultima fila NO esta vacia (%s); se perderian pixels' % (ch, filas[11])
    nuevas = ['0' * 12] + filas[:11]
    todos = ''.join(nuevas)
    return bytes(int(todos[k * 8:(k + 1) * 8], 2) for k in range(18))


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    regiones = {n: bytearray(m.region(raw, lba, sz)) for n, lba, sz in REGS}
    for ch, cod in OBJETIVOS:
        foff, _, _ = g.glifo(cod)
        base = regiones['INIT'][foff:foff + 18]
        nuevo = baja_1px(base, ch)
        n = 0
        for nombre, reg in regiones.items():
            i = 0
            while True:
                i = reg.find(base, i)
                if i < 0:
                    break
                reg[i:i + 18] = nuevo
                n += 1
                i += 1
        print('  %s (0x%04X): %d copias bajadas 1 px' % (ch, cod, n))
        assert n >= 2, '%s: solo %d copias, raro' % (ch, n)
        base = nuevo                  # por si hubiera copias encadenadas (no las hay)
    for nombre, (lba, sz) in ((n, (l, s)) for n, l, s in REGS):
        m.escribe_region(raw, lba, bytes(regiones[nombre]))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
