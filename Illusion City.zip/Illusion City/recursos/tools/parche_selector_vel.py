#!/usr/bin/env python3
"""parche_selector_vel.py - el recuadro azul del menu de VELOCIDAD, a medida.

MEDIDO (49ª tanda, con el estado de David que tiene el menu abierto)
  El recuadro azul NO lo dibuja el texto: lo emite la rutina **$20430** del START,
  que construye entradas de SPRITE en la lista ($a220) y la llama en bucle el menu
  ($20244) — de ahi que parpadee. Sus numeros salen del descriptor $A4200:
```
      X de la caja  = 8*$04 + 4*$32          (la X de la ventana + el margen)
      ancho         = 12 * $2e               (trozo de 12 px por unidad)
      Y             = fila seleccionada ($2c) — con los desplazamientos $a77a/$a77c
```
  El setup del menu de Velocidad está en START 0x139BE y trae $04=3, $32=3, $2e=5:
```
      0x13A04  317c 0003 0032    move.w #$3,$32(a0)   -> X de la caja = 24 + 12 = 36
      0x13A0A  317c 0005 002e    move.w #$5,$2e(a0)   -> ancho = 60  -> caja 36..95
```
  «Movimiento» va de x=25 a x=153, asi que la caja no lo cubria (se quedaba en 95).

ARREGLO (medido en el emulador antes de tocarlo)
```
      $32 = 0   -> X de la caja = 24 (el texto NO se mueve: medido)
      $2e = 7   -> ancho = 84  -> caja 24..107
  OJO (corregido el 27/09): «Movimiento» acaba en x=102, NO en 153 (aquel 153 era la
  FLECHA, que se colaba en la medida). David pidio que terminara en X=103. Con $2e=7
  queda en 107: 4 px de mas, y es lo minimo posible porque el ancho va de 12 EN 12
  (con $2e=6 serian 12 px de menos, que dejaria fuera la «o» final).
```
  OJO: $32 NO mueve el texto (comprobado moviéndolo de 0 a 3 en vivo): el texto de esa
  ventana usa otros campos, asi que el recuadro se puede ajustar sin tocar la maqueta.

Uso: python3 parche_selector_vel.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

OFF_32, OFF_2E = 0x13A04, 0x13A0A          # move.w #N,$32(a0) / move.w #N,$2e(a0)
VIEJO_32, NUEVO_32 = 0x0003, 0x0000
VIEJO_2E, NUEVO_2E = 0x0005, 0x0007


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual
    n = len(buf); buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    for off, viejo, nuevo, nom in ((OFF_32, VIEJO_32, NUEVO_32, '$32 (margen)'),
                                   (OFF_2E, VIEJO_2E, NUEVO_2E, '$2e (trozos)')):
        ins = st[off:off + 6]
        assert ins[0:2] == bytes.fromhex('317c') and ins[4:6] == (0x0032 if nom.startswith('$32') else 0x002e).to_bytes(2, 'big'), \
            '%s: instruccion inesperada en 0x%X (%s)' % (nom, off, ins.hex(' '))
        assert int.from_bytes(ins[2:4], 'big') == viejo, \
            '%s: esperaba %d y hay %d' % (nom, viejo, int.from_bytes(ins[2:4], 'big'))
        pon(st, off + 2, nuevo.to_bytes(2, 'big'), nom)
    m.escribe_region(raw, m.LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  selector del menu de Velocidad: $32 %d -> %d y $2e %d -> %d'
          % (VIEJO_32, NUEVO_32, VIEJO_2E, NUEVO_2E))
    print('  (caja resultante x=24..155; «Movimiento» va de 25 a 153)')
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
