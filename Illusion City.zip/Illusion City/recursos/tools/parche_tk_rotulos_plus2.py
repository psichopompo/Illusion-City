#!/usr/bin/env python3
"""parche_tk_rotulos_plus2.py - TECNICAS: rótulos de armas +2 celdas a la derecha.

Base: TEST_BL. Solo cambia el inicio de los dos rótulos de armas: se añaden 2
espacios fullwidth delante de ARMA y de GARRA (de 7 a 9 celdas de separación
desde la marca &5). La plantilla crece 4 B por rótulo (+8 B total). Las filas
de valores que siguen a cada rótulo se desplazan 4 B y sus refs se actualizan.

Uso: python3 parche_tk_rotulos_plus2.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    base = T0 + 0x10000

    # localizar las marcas &5 de los dos rótulos
    ARMA = bytes.fromhex('82608271826c8260')
    GARRA = bytes.fromhex('82668260827182718260')
    a1 = st.find(ARMA, T0, T0+500)
    a2 = st.find(GARRA, T0, T0+500)
    assert a1 > 0 and a2 > 0, 'no encuentro los rótulos'
    m1 = a1 - 14  # 7 espacios × 2 B antes de ARMA
    m2 = a2 - 14
    assert st[m1-2:m1] == b'\x26\x35' and st[m2-2:m2] == b'\x26\x35', 'marcas mal'
    print('  rotulo 1: marca &5 en off %d, ARMA en off %d' % (m1-T0, a1-T0))
    print('  rotulo 2: marca &5 en off %d, GARRA en off %d' % (m2-T0, a2-T0))

    # insertar 2 espacios (4 B) justo después de cada marca &5
    # (de mayor a menor offset para no desplazar el segundo)
    ins = sorted([m1, m2], reverse=True)
    for p in ins:
        st[p+2:p+2] = ESP * 2
        print('  +2 espacios insertados en off %d' % (p+2))

    # actualizar refs que apunten a la plantilla por encima de los puntos de inserción
    extra = 8  # 4 B por rótulo, 2 rótulos
    def nueva_dir(v):
        off = v - base
        if off < 0 or off >= LEN + extra:
            return None
        nd = off
        if off >= ins[0] + 2: nd += 4   # después de la inserción del rótulo 2
        if off >= ins[1] + 2: nd += 4   # después de la inserción del rótulo 1
        return base + nd
    n = 0
    for k in range(4, len(st)-4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        off = v - base
        if 0 <= off < LEN and k % 2 == 0:
            # ¿es una ref a un campo de valor? (los campos se desplazan con la fila)
            # si la ref apunta a algo que YA fue actualizado por la inserción, no tocar
            # => solo actualizar refs que NO apunten a posiciones ya correctas
            # (después de la inserción, el offset viejo y el nuevo difieren)
            nd = nueva_dir(v)
            if nd is not None and nd != v:
                st[k:k+4] = nd.to_bytes(4, 'big')
                n += 1
    print('  refs actualizadas: %d' % n)

    # limpiar los 8 B extra al final de la plantilla
    fin = T0 + LEN + extra
    st[fin:fin+16] = b'\xff' * 16

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
