#!/usr/bin/env python3
"""parche_lote2.py - 3 cambios de texto del menu, medidos y verificados.

  1) Ficha -> Estado      (fila 5 del menu principal)
  2) 所持金 -> Dinero     (recuadro del dinero: menu principal Y tienda)
       + 7 cifras -> 6 cifras (rutina reubicada)
       + "H$" -> "$"       (el campo solo da para 13 glifos)
  3) pantalla de titulo   (SSTART.BIN, 3 opciones del menu de inicio)

Todo son datos + 3 punteros; no se mueve nada de sitio.
Los textos nuevos van al hueco libre 0x17A00+ de START.BIN (0xFF en el
original -> libre) y la rutina de 6 cifras tambien.

Uso:
    python3 tools/parche_lote2.py estado          # ver como esta el .bin
    python3 tools/parche_lote2.py aplica [salida.bin]
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
BASE = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")

SECTOR = 2352
LBA_START, SZ_START = 59, 98184
LBA_SSTART, SZ_SSTART = 43, 32644

MD5_ESPERADO = "ab72a6c1b949f8cb3a1c8b1c81f0559e"   # build con la caja de texto (B)

_spec = importlib.util.spec_from_file_location('edcecc', os.path.join(AQUI, 'edcecc.py'))
edcecc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(edcecc)

# ---------------------------------------------------------------- helpers
def region(raw, lba, size):
    out = bytearray()
    for k in range(0, size, 2048):
        b = (lba + k // 2048) * SECTOR + 16
        out.extend(raw[b:b + min(2048, size - k)])
    return bytes(out)


def escribe_region(raw, lba, datos):
    for k in range(0, len(datos), 2048):
        t = datos[k:k + 2048]
        b = (lba + k // 2048) * SECTOR + 16
        raw[b:b + len(t)] = t


def fw(s):
    """texto ASCII -> bytes Shift-JIS de ancho completo (ＡＢＣ...０-９)."""
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - ord('A')])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - ord('a')])
        elif '0' <= ch <= '9':
            out += bytes([0x82, 0x4F + ord(ch) - ord('0')])
        elif ch == ' ':
            out += bytes([0x81, 0x40])
        elif ch == '$':
            out += bytes([0x81, 0x90])
        else:
            raise SystemExit('caracter sin glifo: %r' % ch)
    return bytes(out)


def rutina_cifras(cifras):
    """Genera la rutina que escribe las cifras del dinero (como $18624 pero
    con N cifras en vez de 7) en el buffer (a2)+.

    Estructura identica a la del juego:
        move.l $a660.l,d0 ; movem.l d0-d6,-(a7)
        por cifra:  move.w #$824f,dN / subi.l #div,d0 / bmi / addq / bra / addi.l
        + addi.w #$824f,d0 (unidades) + stores + movem + rts
    """
    divs = [10 ** k for k in range(cifras - 1, 0, -1)]     # 100000..10
    assert len(divs) == cifras - 1
    b = bytearray()
    b += bytes.fromhex('20390000a660')      # move.l $a660.l,d0
    b += bytes.fromhex('48e7fe00')          # movem.l d0-d6,-(a7)
    for i, div in enumerate(divs):
        reg = i + 1                          # d1, d2, ...
        w = 0x303C | (reg << 9)                                # move.w #$824f,dN
        b += bytes([w >> 8, w & 0xFF, 0x82, 0x4F])
        b += bytes.fromhex('0480') + div.to_bytes(4, 'big')    # subi.l #div,d0
        b += bytes.fromhex('6b000006')                         # bmi.w +6
        b += bytes([0x52, 0x40 | reg])                         # addq.w #1,dN
        b += bytes.fromhex('60f2')                             # bra.b -14
        b += bytes.fromhex('0680') + div.to_bytes(4, 'big')    # addi.l #div,d0
    b += bytes.fromhex('0640824f')           # addi.w #$824f,d0  (unidades)
    for i in range(len(divs)):
        b += bytes([0x34, 0xC0 | (i + 1)])   # move.w dN,(a2)+
    b += bytes.fromhex('34c0')               # move.w d0,(a2)+
    b += bytes.fromhex('4cdf007f')           # movem.l (a7)+,d0-d6
    b += bytes.fromhex('4e75')               # rts
    return bytes(b)


# ---------------------------------------------------------------- hueco libre
OFF_RUTINA = 0x17A00        # -> RAM $27A00
OFF_DINERO = 0x17AA0        # -> RAM $27AA0
OFF_ESTADO = 0x17AB0        # -> RAM $27AB0

# rutina original de 7 cifras (file 0x8624) y sus 2 llamadas
OFF_JSR_1, OFF_JSR_2 = 0x10B12, 0x10BA8
JSR_VIEJO = bytes.fromhex('4eb900018624')

# etiqueta del dinero: 2 usos
OFF_LEA_DINERO_1, OFF_LEA_DINERO_2 = 0x10B04, 0x10B9E
LEA_VIEJO = bytes.fromhex('43f90002187a')

# blanco extra: no cabe -> se quita en los DOS sitios (menu principal y tienda)
OFF_BLANCO_MAIN = 0x10B0E
OFF_BLANCO_SHOP = 0x10B9A
BLANCO = bytes.fromhex('34fc8140')
NOP = bytes.fromhex('4e71')

# moneda: cuesta del string "Ｈ＄"
OFF_MONEDA = 0x11882
MONEDA_VIEJA = bytes.fromhex('82678190')
MONEDA_NUEVA = bytes.fromhex('8190')          # "＄"

# fila 5 del menu: puntero a la cadena "Ficha"
OFF_FILA_FICHA = 0x13D22
FILA_VIEJA = bytes.fromhex('00023d4a')

# --- titulo (SSTART.BIN) ---
TITULO = [
    (0x101C, 22, "Cargar"),        # セーブした時点から
    (0x1032, 22, "Con intro"),     # オープニングから
    (0x1048, 22, "Sin intro"),     # スタート地点から
]


def estado():
    raw = open(BASE, 'rb').read()
    print('.bin  MD5 %s' % hashlib.md5(raw).hexdigest())
    st = region(raw, LBA_START, SZ_START)
    ss = region(raw, LBA_SSTART, SZ_SSTART)
    print('START   fila5 -> %s   %s' % (st[OFF_FILA_FICHA:OFF_FILA_FICHA + 4].hex(' '),
          'Ficha' if st[OFF_FILA_FICHA:OFF_FILA_FICHA + 4] == FILA_VIEJA else 'ya cambiado'))
    print('        lea dinero %s  jsr cifras %s  moneda %s' % (
        st[OFF_LEA_DINERO_1:OFF_LEA_DINERO_1 + 6].hex(' '),
        st[OFF_JSR_1:OFF_JSR_1 + 6].hex(' '),
        st[OFF_MONEDA:OFF_MONEDA + 6].hex(' ')))
    print('SSTART  linea1 %r' % ss[0x101C:0x1032].decode('shift_jis', 'replace'))
    print('        linea2 %r' % ss[0x1032:0x1048].decode('shift_jis', 'replace'))
    print('        linea3 %r' % ss[0x1048:0x105E].decode('shift_jis', 'replace'))


def aplica(salida):
    raw0 = open(BASE, 'rb').read()
    md5 = hashlib.md5(raw0).hexdigest()
    if md5 != MD5_ESPERADO:
        raise SystemExit('El .bin de trabajo NO es el esperado.\n  esperado %s\n  actual   %s'
                         % (MD5_ESPERADO, md5))
    raw = bytearray(raw0)
    st = bytearray(region(raw0, LBA_START, SZ_START))
    ss = bytearray(region(raw0, LBA_SSTART, SZ_SSTART))
    notas = []

    # ---- comprobaciones previas (abortan si algo no cuadra) ----
    assert st[OFF_FILA_FICHA:OFF_FILA_FICHA + 4] == FILA_VIEJA, 'fila 5 inesperada'
    for off in (OFF_LEA_DINERO_1, OFF_LEA_DINERO_2):
        assert st[off:off + 6] == LEA_VIEJO, 'lea del dinero inesperado en 0x%X' % off
    for off in (OFF_JSR_1, OFF_JSR_2):
        assert st[off:off + 6] == JSR_VIEJO, 'jsr de cifras inesperado en 0x%X' % off
    for off in (OFF_BLANCO_MAIN, OFF_BLANCO_SHOP):
        assert st[off:off + 4] == BLANCO, 'blanco inesperado en 0x%X' % off
    assert st[OFF_MONEDA:OFF_MONEDA + 4] == MONEDA_VIEJA, 'moneda inesperada'
    assert rutina_cifras(7) == st[0x8624:0x8624 + len(rutina_cifras(7))], \
        'la rutina generada no coincide con la del juego (7 cifras)'
    for off, campo, txt in TITULO:
        assert ss[off + campo - 2:off + campo] == b'\x00\x00', 'sin terminador en titulo %d' % off

    # ---- 1) Ficha -> Estado ----
    est = fw("Estado") + b'\x00\x00'
    st[OFF_FILA_FICHA:OFF_FILA_FICHA + 4] = (0x10000 + OFF_ESTADO).to_bytes(4, 'big')
    st[OFF_ESTADO:OFF_ESTADO + len(est)] = est
    notas.append('1) Ficha -> Estado   (cadena nueva en file 0x%X, fila 5 -> $%X)'
                 % (OFF_ESTADO, 0x10000 + OFF_ESTADO))

    # ---- 2) dinero: etiqueta, cifras y moneda ----
    din = fw("Dinero") + b'\x00\x00'
    st[OFF_DINERO:OFF_DINERO + len(din)] = din
    for off in (OFF_LEA_DINERO_1, OFF_LEA_DINERO_2):
        st[off:off + 6] = bytes.fromhex('43f9') + (0x10000 + OFF_DINERO).to_bytes(4, 'big')
    rut = rutina_cifras(6)
    st[OFF_RUTINA:OFF_RUTINA + len(rut)] = rut
    for off in (OFF_JSR_1, OFF_JSR_2):
        st[off:off + 6] = bytes.fromhex('4eb9') + (0x10000 + OFF_RUTINA).to_bytes(4, 'big')
    for off in (OFF_BLANCO_MAIN, OFF_BLANCO_SHOP):
        st[off:off + 4] = NOP * 2
    st[OFF_MONEDA:OFF_MONEDA + 2] = MONEDA_NUEVA
    st[OFF_MONEDA + 2:OFF_MONEDA + 4] = b'\x00\x00'
    notas.append('2) dinero: "Dinero" (%d B) + 6 cifras (rutina %d B en file 0x%X) + "$"'
                 % (len(din), len(rut), OFF_RUTINA))
    notas.append('   campo: 6+6+1 = 13 glifos = 156 px < 160 px del campo ($08=20)')

    # ---- 3) titulo ----
    for off, campo, txt in TITULO:
        nuevo = fw(txt) + b'\x00\x00'
        assert len(nuevo) <= campo, 'no cabe %r' % txt
        ss[off:off + campo] = nuevo + b'\x00' * (campo - len(nuevo))
        notas.append('3) titulo 0x%X: %-10r (%d glifos = %d px)' % (off, txt, len(txt), len(txt) * 12))

    # ---- escribir ----
    escribe_region(raw, LBA_START, bytes(st))
    escribe_region(raw, LBA_SSTART, bytes(ss))
    raw = bytearray(edcecc.repara_bytes(bytes(raw)))

    # ---- verificaciones ----
    print('\n'.join(notas))
    # 1) solo deben cambiar sectores de START y SSTART
    dif = [i // SECTOR for i in range(0, len(raw0), SECTOR) if raw0[i:i + SECTOR] != raw[i:i + SECTOR]]
    esperados = set()
    for lba, sz in ((LBA_START, SZ_START), (LBA_SSTART, SZ_SSTART)):
        esperados |= set(range(lba, lba + (sz + 2047) // 2048))
    print('\nsectores tocados: %d (de los %d posibles de START+SSTART)'
          % (len(dif), len(esperados)))
    fuera = [s for s in dif if s not in esperados]
    assert not fuera, 'ha cambiado algo fuera de START/SSTART: %s' % fuera[:10]
    open(salida, 'wb').write(bytes(raw))
    cur = open(salida, 'rb').read()
    st2 = region(cur, LBA_START, SZ_START)
    ss2 = region(cur, LBA_SSTART, SZ_SSTART)
    print('escrito %s' % salida)
    print('  MD5 .bin %s' % hashlib.md5(cur).hexdigest())
    print('  START    %s' % hashlib.md5(st2).hexdigest())
    print('  SSTART   %s' % hashlib.md5(ss2).hexdigest())
    v = edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC  %s' % ('OK' if not any(v.values()) else 'MAL %s' % v))
    # releer lo escrito
    print('  fila5 -> %s  (Estado = %s)' % (st2[OFF_FILA_FICHA:OFF_FILA_FICHA + 4].hex(' '),
                                            (0x10000 + OFF_ESTADO).to_bytes(4, 'big').hex(' ')))
    print('  titulo: %r / %r / %r' % (ss2[0x101C:0x102A].decode('shift_jis', 'replace'),
                                      ss2[0x1032:0x1040].decode('shift_jis', 'replace'),
                                      ss2[0x1048:0x1056].decode('shift_jis', 'replace')))


if __name__ == '__main__':
    if len(sys.argv) < 2 or sys.argv[1] == 'estado':
        estado()
    else:
        aplica(sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROY, "TEST_C.bin"))
