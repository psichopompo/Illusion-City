#!/usr/bin/env python3
"""Lote de normalización de nombres propios (canon de la wiki japonesa).

Origen: lista aportada por el usuario (wiki japonesa de Gen'ei Toshi).
Cambio principal: 美紅 = MEIFAN (no Meihong) y ホウメイ = HOUMEI.

Estrategia:
1. Reescrituras exactas por id para las frases que necesitan re-tintar
   (Meihong->Meifan, Homei->Houmei, Airen->Airén, títulos de los 八部衆,
   Nantian Li->Lee del Cielo Sur, Xiaomei->Xiao Mei...).
2. Sustituciones regex generales para el resto de cadenas ya traducidas
   (por si el nombre aparece en frases no listadas).
3. Sincronización de tools/lote1.py y tools/lote2.py (se reescriben las
   entradas afectadas para que los lotes queden como fuente de verdad).

Ejecutar desde la raíz:  python3 tools/lote_nombres.py
"""
import csv
import re

# ----------------------------------------------------------------------
# 1) Reescrituras exactas (id -> texto castellano completo). Solo toca
#    cadenas YA traducidas; las claves no traducidas se ignoran.
# ----------------------------------------------------------------------
EXACT = {
    # --- diálogo del prólogo (INIT.BIN) ---
    '2131': 'ﾇMeifan「Oye, Tianren. ¿De verdad sirve esta niña para algo?」',
    '2132': 'ﾇMeifan「Imposible que la tengas tú, Isaac.」',
    '2133': 'ﾇMeifan「Perdón. Tonta de mí por preguntar.」',
    '2134': 'ﾇMeifan「Al entrar en el Área Interior, primero regístrate. Algo así te sobra, ¿no?」',
    '2135': 'ﾇMeifan「De momento, en la sede de SIVA sabrán algo.」',
    '2136': 'ﾇMeifan「Tú también lo crees, ¿verdad, Isaac?」',
    '2138': 'ﾇMaestro Shu「Primero hay que rescatar a Meifan.」',
    '2139': 'ﾇMeifan「El edificio del fondo de Jurá era una antigua instalación biológica.」',
    '2140': 'ﾇCash「No habrá arácnidos, ¿eh? El blindaje no me queda de mi talla.」',
    '2141': 'ﾇMeifan「¿Qué es eso?」',
    '2142': 'ﾇCash「Heinlein... Qué generación tan distinta.」',
    '2143': 'ﾇMeifan「...Hay que dar con Houmei cuanto antes.」',
    '2144': 'ﾇCash「La pantera quedó muy tocada. Si vamos a acabar con ella, es ahora.」',
    '2145': 'ﾇMeifan「Pero si aparece Vaara, el Emperador de Jurá... Nada de confiarse.」',
    '2146': 'ﾇCash「Vaya, la novata ya habla como veterana.」',
    '2147': 'ﾇMeifan「Que siga siendo policía, aunque sea de nombre.」',
    '2148': 'ﾇCash「En el salón de la Secta Maten está la pista que buscamos.」',
    '2149': 'ﾇMeifan「Invitación de Airén... Ojalá no sea lío de los gordos...」',
    '2150': 'ﾇCash「Perdimos la pista tras Vaara. Esto nos viene de perlas.」',
    '2151': 'ﾇMeifan「No me hace ninguna gracia.」',
    '2152': 'ﾇMeifan¿Tiene Saikun algún escondite? 」',
    '2153': 'ﾇCash「Quién sabe. Yendo se sabrá.」',
    '2154': 'ﾇMeifan「¡El alcantarillado es lo peor de lo peor!」',
    '2155': 'ﾇCash「No hay opción: el escondite de Tiuchan está tras las cloacas.」',
    '2156': 'ﾇMeifan「Por eso digo que no me hace gracia. Los encargos de Airén son siempre igual.」',
    '2157': 'ﾇMeifan「Si Holland cayó como preso de clase A, su celda será la famosa celda especial.」',
    '2158': 'ﾇMeifan「Debe de estar muy en el fondo del edificio Haitao.」',
    '2159': 'ﾇMeifan「No queda otra que irromper. Ojalá los Spinner no estén cerca.」',
    '2160': 'ﾇMeifan「De Holland debió escapar el paradero del escondite de Tiuchan.」',
    '2161': 'ﾇCash「Arrancar confesiones es pan de cada día. La Resistencia lo sabía bien.」',
    '2162': 'ﾇMeifan「Una invitación al laberinto subterráneo... Menudo chiste.」',
    '2163': 'ﾇMeifan¿Estará Houmei en la taberna Taoyuan? 」',
    '2164': 'ﾇMaestro Shu「No veo otro remedio.」',
    '2165': 'ﾇMeifan「Fusou Lane, en Saikun... allí el sindicato es muy fuerte, ¿no?」',
    '2166': 'ﾇMaestro Shu「Esos cacharros no me gustan nada.」',
    '2167': 'ﾇMeifan「La Consorte del Acero y el Emperador Ark: dos de los cinco que quedan están en la zona industrial.」',
    '2168': 'ﾇHoumei「No: tres, Meifan. Lee del Cielo Sur también está aquí. Lo presiento.」',
    '2169': 'ﾇMeifan「Aunque capture a la Consorte del Acero, ¿confesará dónde está Lee?」',
    '2170': 'ﾇHoumei「Meifan, ¿de verdad vamos a ver a Meshmer?」',
    '2171': 'ﾇMaestro Shu「Airén a lo mejor no sabe nada aún, pero vamos a mirar.」',
    '2172': 'ﾇHoumei「Oye, Tianren... ¿De verdad saltamos desde el puente Tairon?」',
    '2173': 'ﾇMaestro Shu「Bah, ya has mejorado mucho. No hay nada que temer.」',
    '2174': 'ﾇHoumei「¡A mí no me lo preguntas!」',
    '2175': 'ﾇHoumei「Dices que es la Zona Nueva, pero aún no gobierna nada, ¿no?」',
    '2176': 'ﾇMaestro Shu「Me dijeron que instalan ahí el nuevo sistema central de SIVA.」',
    '2177': 'ﾇHoumei「Al final, Meshmer no raptó a Meifan, parece.」',
    '2178': 'ﾇMaestro Shu「Hum. Yama movía los hilos. Qué tramaría esa zorra...」',
    '2179': 'ﾇHoumei「En fin, vamos a preguntar a Airén por Yama.」',
    '2180': 'ﾇHoumei「Al final fue Yama quien fingió que Meshmer raptaba a Meifan, ¿verdad?」',
    '2181': 'ﾇMaestro Shu「Hum. Meshmer fue traicionada. Las mujeres dan miedo.」',
    '2182': 'ﾇHoumei「¡¿Por qué me miras así?! En fin, vamos al laboratorio genético.」',
    '2183': 'ﾇHoumei「Meifan, ¿estará bien?」',
    '2184': 'ﾇMaestro Shu「Mientras viva, no pasa nada. Vamos a buscar a Yama en el laboratorio.」',
    '2185': 'ﾇHoumei「Lee está dentro de la torre SIVA. Lo siento aquí.」',
    '2186': 'ﾇHoumei「Y a Lee del Cielo Sur solo lo vi cuando raptaron a Xiao Mei... y aún así... así...」',
    '2187': 'ﾇHoumei「Meifan me dijo que al verle sabría si este sentimiento es verdad...」',
    '2188': 'ﾇLee「Rey Maten: te derrotaré, ya verás.」',
    '2190': 'ﾇInfo de fallo: ¡¿condición omitida?!',
    # --- nombres de enemigos (INIT.BIN) ---
    '2196': 'Misteriosos',
    '2197': 'Robot guardia',
    '2198': 'Soldado Haitao',
    '2199': 'Zu Va',
    '2200': 'Ki Tua',
    '2201': 'Hamerln',
    '2202': 'Ninyutua',
    '2203': 'Vamu',
    '2204': 'Liu-Kei',
    '2205': 'Solid',
    '2206': 'Colonia',
    '2207': 'Cazador',
    '2208': 'Martillo',
    '2209': 'Látigo',
    '2210': 'Vaara',
    '2211': 'Pantera',
    '2212': 'Durand',
    '2213': 'Mensajero Kiria',
    '2214': 'Esclavo Kiria',
    '2215': 'Soldado Kiria',
    '2216': 'Vecino Kiria',
    '2217': 'Fruto Kiria',
    '2218': 'Meshmer',
    '2219': 'I Lima',
    '2220': 'Ryao Bertz',
    '2221': 'Sherba',
    '2222': 'Araña',
    '2223': 'Raiden',
    '2224': 'Sumeragi',
    '2225': 'Kurogane',
    '2226': 'Proto 1513',
    '2227': 'Fili Yag',
    '2228': 'Srap Yag',
    '2229': 'Kerape Yag',
    '2230': 'Kro Yag',
    '2231': 'Yag maestro',
    '2232': 'Va Gi',
    '2233': 'Sreuba',
    '2234': 'Yag Kiria',
    '2235': 'Varte',
    '2236': 'Yu Lima',
    '2237': 'Verdugo Kiria',
    # --- acciones y ataques enemigos ---
    '2238': '$1 se ríe',
    '2239': 'Suena la flauta de $1',
    # --- tiendas / localizaciones ---
    '2448': 'Tienda de Doc',
    '2450': 'Saikun',
    '2476': 'Doc',
    # --- OPEN.BIN ---
    '2829': 'Tienda de Doc',
}

# ----------------------------------------------------------------------
# 2) Sustituciones regex para el resto de cadenas traducidas.
# ----------------------------------------------------------------------
SUBS = [
    (r'\bMeihong\b', 'Meifan'),
    (r'\bHomei\b', 'Houmei'),
    (r'\bAiren\b', 'Airén'),
    (r'\bKash\b', 'Cash'),
    (r'\bVara\b', 'Vaara'),
    (r'\bJura\b', 'Jurá'),
    (r'\bRayden\b', 'Raiden'),
    (r'\bRyukei\b', 'Liu-Kei'),
    (r'\bDuran\b', 'Durand'),
    (r'\bDok\b', 'Doc'),
    (r'\bXiaomei\b', 'Xiao Mei'),
    (r'\bNantian Li\b', 'Lee del Cielo Sur'),
    (r'(?<!del )(?<!del Cielo )\bLi\b', 'Lee'),
    (r'\bSeñor de Maten\b', 'Rey Maten'),
    (r'\bSeñor del Rayo\b', 'Emperador Ark'),
    (r'\bDama del Acero\b', 'Consorte del Acero'),
]

# ----------------------------------------------------------------------
# 3) Sincronización de los lotes fuente
# ----------------------------------------------------------------------
LOTES = {
    'tools/lote1.py': [('2194: "Kash"', '2194: "Cash"'), ('2476: "Dok"', '2476: "Doc"')],
}


def sync_lote2(path, exact):
    """Reescribe en lote2.py las entradas 'id': '...' cuyo texto cambia."""
    src = open(path, encoding='utf-8').read()
    n = 0
    for k, v in exact.items():
        pat = re.compile(r"((?:^|\n)\s*'" + k + r"':\s*')(.*?)(',?\n)")
        m = pat.search(src)
        if not m:
            continue
        old = m.group(2)
        if old != v:
            src = src[:m.start(2)] + v.replace('\\', '\\\\') + src[m.end(2):]
            n += 1
    open(path, 'w', encoding='utf-8').write(src)
    return n


def main():
    # --- CSV ---
    rows = list(csv.DictReader(open('textos_dumper.csv', encoding='utf-8-sig')))
    fields = list(rows[0].keys())
    n_exact = n_sub = 0
    for r in rows:
        k = r['id']
        t = r['traduccion_castellano'].strip()
        if not t:
            continue
        if k in EXACT:
            if t != EXACT[k]:
                r['traduccion_castellano'] = EXACT[k]
                n_exact += 1
        else:
            new = t
            for pat, rep in SUBS:
                new = re.sub(pat, rep, new)
            if new != t:
                r['traduccion_castellano'] = new
                n_sub += 1
    with open('textos_dumper.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f'CSV: {n_exact} reescritas EXACT, {n_sub} por sustitucion regex')

    # --- lote1.py ---
    n1 = 0
    src1 = open('tools/lote1.py', encoding='utf-8').read()
    for old, new in LOTES['tools/lote1.py']:
        if old in src1:
            src1 = src1.replace(old, new)
            n1 += 1
    open('tools/lote1.py', 'w', encoding='utf-8').write(src1)
    print(f'lote1.py: {n1} entradas sincronizadas')

    # --- lote2.py (todas las EXACT que vengan de INIT/OPEN) ---
    n2 = sync_lote2('tools/lote2.py', {k: v for k, v in EXACT.items()
                                       if k in [r['id'] for r in rows]})
    print(f'lote2.py: {n2} entradas reescritas')


if __name__ == '__main__':
    main()
