#!/usr/bin/env python3
"""caja_menu.py - experimentos sobre la CAJA DE TEXTO del menu principal.

DIAGNOSTICO (medido sobre la captura 223746 y el codigo)
--------------------------------------------------------
El texto del menu se pinta en un BITMAP de 4bpp (buffer -> VRAM) cuyas filas
miden **80 px = 10 celdas de 8 px**. El 7º glifo de "Objetos"/"Sistema" empieza
en la celda 10,5 (12 px de paso por glifo), asi que **no cabe**: la parte que
sobra se escribe al principio de la fila SIGUIENTE del bitmap (por eso asoma por
la izquierda, la muesca de la O) y la tinta que llega al borde se corta en
**x136**.

De donde salen los 80 px:
    descriptor de $A4200 (el que pinta las 6 filas del menu):
        file 0x119D2  move.w #$7,$04(a0)    ; X de la caja (unidades de 8 px) -> x56
        file 0x119DE  move.w #$0A,$08(a0)   ; ANCHURA de fila (unidades de 8 px) -> 80 px
        x56 + 80 = x136  <- el corte medido
    y con el 7º glifo necesitando 84 px (12 x 7), sobran 4 px.

AVISO IMPORTANTE PARA PROBAR
----------------------------
El texto se pinta en VRAM **cuando el juego dibuja el menu**. Un savestate
hecho dentro del menu trae la VRAM ya pintada, asi que un cambio en el ancho NO
se ve hasta que el juego vuelve a pintar (entrar al menu desde el juego, o mover
el cursor). Casi todos los intentos anteriores ("sin efecto") pueden ser esto.

EXPERIMENTOS
------------
  A) marcador: $04 7 -> 6  (la caja y el texto se mueven 8 px a la izquierda)
     - si se mueve: ese descriptor es el vivo y el campo responde -> seguir
     - si no se mueve: ese descriptor NO es el que pinta el menu
  B) candidato: $08 10 -> 11  (fila de 88 px; cabe el 7º glifo, y 88 < 92 px
     de interior de la caja)
     - si las palabras salen completas: arreglado
     - si el texto sale "cruzado"/desplazado: es que el plano espera 10 celdas
       por fila y hay que ajustar tambien el tilemap (siguiente paso)

Uso:
    python3 tools/caja_menu.py A [salida.bin]
    python3 tools/caja_menu.py B [salida.bin]
    python3 tools/caja_menu.py estado              # valores actuales
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
BASE = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
SECTOR = 2352
LBA_START = 59
SZ_START = 98184

OFF_X = 0x119D4        # immediato de $04 (X de la caja)
OFF_ANCHO = 0x119E0    # immediato de $08 (anchura de fila)
VAL_X = 7
VAL_ANCHO = 10

_spec = importlib.util.spec_from_file_location('edcecc', os.path.join(AQUI, 'edcecc.py'))
edcecc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(edcecc)


def region(raw, lba, size):
    out = bytearray()
    for k in range(0, size, 2048):
        base = (lba + k // 2048) * SECTOR + 16
        out.extend(raw[base:base + min(2048, size - k)])
    return bytes(out)


def escribe(raw, lba, datos):
    for k in range(0, len(datos), 2048):
        t = datos[k:k + 2048]
        base = (lba + k // 2048) * SECTOR + 16
        raw[base:base + len(t)] = t


def estado():
    raw = open(BASE, 'rb').read()
    st = region(raw, LBA_START, SZ_START)
    print('START.BIN  MD5 %s' % hashlib.md5(st).hexdigest())
    print('  $04 (X de la caja)   file 0x%X = %d' % (OFF_X, (st[OFF_X] << 8) | st[OFF_X + 1]))
    print('  $08 (anchura de fila) file 0x%X = %d' % (OFF_ANCHO, (st[OFF_ANCHO] << 8) | st[OFF_ANCHO + 1]))


def aplica(exp, salida):
    raw = bytearray(open(BASE, 'rb').read())
    st = bytearray(region(raw, LBA_START, SZ_START))
    x = (st[OFF_X] << 8) | st[OFF_X + 1]
    w = (st[OFF_ANCHO] << 8) | st[OFF_ANCHO + 1]
    if exp == 'A':
        assert x == VAL_X, 'esperaba $04=%d y hay %d' % (VAL_X, x)
        st[OFF_X + 1] = 6
        print('A) $04  %d -> 6   (la caja/texto deben moverse 8 px a la izquierda)' % x)
    elif exp == 'B':
        assert w == VAL_ANCHO, 'esperaba $08=%d y hay %d' % (VAL_ANCHO, w)
        st[OFF_ANCHO + 1] = 11
        print('B) $08  %d -> 11  (fila de %d -> %d px)' % (w, w * 8, 11 * 8))
    else:
        raise SystemExit('experimento desconocido: %s' % exp)
    escribe(raw, LBA_START, bytes(st))
    raw = bytearray(edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    # verificacion
    cur = open(salida, 'rb').read()
    st2 = region(cur, LBA_START, SZ_START)
    print('   escrito %s' % salida)
    print('   MD5 .bin %s' % hashlib.md5(cur).hexdigest())
    print('   START    %s' % hashlib.md5(st2).hexdigest())
    print('   EDC/ECC  %s' % ('OK' if not any(edcecc.verifica_imagen(salida, verbose=False).values()) else 'MAL'))


if __name__ == '__main__':
    if len(sys.argv) < 2 or sys.argv[1] == 'estado':
        estado()
    else:
        exp = sys.argv[1]
        salida = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
            PROY, "TEST_%s.bin" % exp)
        aplica(exp, salida)
