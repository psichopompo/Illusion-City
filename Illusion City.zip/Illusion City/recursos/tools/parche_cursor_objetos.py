#!/usr/bin/env python3
"""parche_cursor_objetos.py - cursor del menu de OBJETOS: caja a medida por opcion.

El gancho sustituye `movea.l #$a220,a1` (6 B, file 0x10478) por `bsr gancho` (4 B)
+ `nop` (2 B). El gancho calcula d2 (ancho) y opcionalmente ajusta d0 (posicion),
ejecuta el movea sustituido y vuelve.

Solo actua si la ventana es la de Objetos ($22(a0) = $00023E16). Los demas menus
siguen por el camino de siempre ($2e - 3).

Tabla de 3 entradas de 4 B al final del gancho:
    Usar:    ancho d2=0 (34 px), desplaz d0+=0
    Cambiar: ancho d2=2 (58 px), desplaz d0+=0
    Tirar:   ancho d2=1 (46 px), desplaz d0+=4 (centrar los 38 px en 46)

MOVEM: predecremento (48E7): bit 15=D0, bit 14=D1, bit 6=A1 -> $C040
       postincremento (4CDF): bit 0=D0, bit 1=D1, bit 9=A1 -> $0203
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
PINTOR = 0x10478                    # `movea.l #$a220, a1` (6 B) en RAM $20478
G = 0x17ED2                         # hueco libre (file) = RAM $27ED2

# d2 (ancho) y d0 (desplaz) por opcion
ANCHOS = (0, 2, 1)
DESLPLAZ = (0, 0, 4)


def gancho_bytes():
    g = bytearray()
    # guardar d0, d1 y a1 (predecremento: bit 15=D0, bit 14=D1, bit 6=A1)
    g += bytes.fromhex('48e7c040')                     # +$00: movem.l d0-d1/a1,-(a7)
    # comparar $22(a0) = $00023E16 (plantilla de Objetos)
    g += bytes.fromhex('0c683e160022')                 # +$04: cmpi.w #$0002,$22(a0)
    g += bytes.fromhex('6620')                         # +$0A: bne.s .comun (+$20)
    g += bytes.fromhex('0c6800020024')                 # +$0C: cmpi.w #$3e16,$24(a0)
    g += bytes.fromhex('6618')                         # +$12: bne.s .comun (+$18)
    # --- caso Objetos ---
    tabla_ram = 0x10000 + G + 62                       # RAM $27ED2 + 66 = $27F114
    g += bytes.fromhex('43f9') + tabla_ram.to_bytes(4, 'big')   # +$14: lea tabla,a1
    g += bytes.fromhex('3228002c')                     # +$1C: move.w $2c(a0),d1
    g += bytes.fromhex('d241')                         # +$20: add.w d1,d1
    g += bytes.fromhex('d241')                         # +$22: add.w d1,d1   (opcion * 4)
    g += bytes.fromhex('d2c1')                         # +$24: adda.w d1,a1
    g += bytes.fromhex('3419')                         # +$26: move.w (a1)+,d2 (ancho)
    g += bytes.fromhex('d059')                         # +$28: add.w (a1),d0  (desplaz)
    g += bytes.fromhex('6006')                         # +$2A: bra.s .fin (+$06)
    # --- .comun: camino original para todos los demas menus ---
    g += bytes.fromhex('3428002e')                     # +$2C: move.w $2e(a0),d2
    g += bytes.fromhex('5742')                         # +$32: subq.w #3,d2
    # --- .fin: la instruccion sustituida + restaurar + rts ---
    g += bytes.fromhex('22790000a220')                 # +$34: movea.l #$a220,a1
    g += bytes.fromhex('4cdf0203')                     # +$3A: movem.l (a7)+,d0-d1/a1
    g += bytes.fromhex('4e75')                         # +$3E: rts
    # --- .tabla: (ancho, desplaz) x opcion ---
    # $2c(a0) empieza en 1 (el setup hace move.w #$1,$2c(a0)), asi que la tabla
    # tiene una entrada dummy en el indice 0 y las reales en 1..3
    g += (0).to_bytes(2, 'big') + (0).to_bytes(2, 'big')       # [0] dummy ($2c empieza en 1)
    for k in range(3):
        g += ANCHOS[k].to_bytes(2, 'big') + DESLPLAZ[k].to_bytes(2, 'big')
    return bytes(g)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    assert st[PINTOR:PINTOR + 6] == bytes.fromhex('22790000a220'), \
        'el pintor no tiene los bytes esperados: %s' % st[PINTOR:PINTOR + 6].hex(' ')
    assert st[G:G + 2] == b'\xff\xff', 'el hueco no esta libre'

    g = gancho_bytes()
    st[G:G + len(g)] = g
    off = (0x10000 + G) - (0x10000 + PINTOR + 2)
    st[PINTOR:PINTOR + 6] = bytes([0x61, 0x00]) + (off & 0xffff).to_bytes(2, 'big') \
        + bytes.fromhex('4e71')
    print('  gancho en 0x%05X (%d B) -> RAM $%06X ; bsr %+d' % (G, len(g), 0x10000 + G, off))

    import capstone
    cs = capstone.Cs(capstone.CS_ARCH_M68K, capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
    print('  --- gancho ---')
    for i in cs.disasm(bytes(st[G:G + len(g)]), 0x10000 + G):
        print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                      i.mnemonic + ' ' + i.op_str))
    print('  --- pintor parcheado ---')
    for i in cs.disasm(bytes(st[PINTOR - 4:PINTOR + 14]), 0x10000 + PINTOR - 4):
        print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                      i.mnemonic + ' ' + i.op_str))

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
