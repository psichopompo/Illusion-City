#!/usr/bin/env python3
"""parche_cajas.py - ajusta el ANCHO de las cajas de menu y dinero.

MEDIDO (26/09, con el texto ya a 8 px)
  El ancho de la caja es el campo $08 del descriptor, y va de 12 en 12 px:
      $08 = 11 -> borde derecho x=150    $08 = 10 -> x=142    $08 = 9 -> x=134
      $08 =  7 -> x=118                  $08 =  8 -> x=126
  Menu principal (descriptor $A4200, lo pone la instruccion de 0x119DE):
      texto mas largo («Objetos» y «Sistema») acaba en x=110 y el borde izquierdo
      esta en x=49 -> margen izquierdo 8 px. Con $08=11 el borde derecho queda en 150
      (margen derecho 40 px). Con $08=7 queda en 118 -> margen derecho 8 px. <- iguales
  Dinero (descriptor $A42AE, instruccion de 0x10B36):
      texto acaba en x=209 y el borde derecho con $08=20 esta en 222 (margen 13 px).
      Con $08=19 el borde queda en 217 y el «$» SE CORTA (medido: el ultimo glifo
      ocupa hasta 209 y el interior util acaba antes). Por eso el dinero se queda
      en 20 salvo que David acepte quitar el hueco de 8 px que el juego mete
      detras de «Dinero:».

Uso: python3 parche_cajas.py <entrada.bin> <salida.bin> [ancho_menu] [ancho_dinero]
     por defecto: menu 7, dinero 20 (sin tocar)
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

OFF_ANCHO_MENU = 0x119DE      # move.w #$b,$8(a0) del menu principal
OFF_ANCHO_DINERO = 0x10B36    # move.w #$14,$8(a0) del dinero
ANCHO_MENU = 7
ANCHO_DINERO = 20    # 19 no da: el texto con espacio no cabe (medido)


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual
    n = len(buf); buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida, ancho_menu=ANCHO_MENU, ancho_dinero=ANCHO_DINERO):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    for off, viejo, nuevo, nom in ((OFF_ANCHO_MENU, 0x0B, ancho_menu, 'caja del menu'),
                                   (OFF_ANCHO_DINERO, 0x14, ancho_dinero, 'caja del dinero')):
        actual = st[off:off + 6]
        assert actual[0:2] == bytes.fromhex('317c') and actual[4:6] == bytes.fromhex('0008'), \
            '%s: instruccion inesperada en 0x%X (%s)' % (nom, off, actual.hex(' '))
        assert int.from_bytes(actual[2:4], 'big') == viejo, \
            '%s: esperaba ancho %d y hay %d' % (nom, viejo, int.from_bytes(actual[2:4], 'big'))
        pon(st, off + 2, nuevo.to_bytes(2, 'big'), nom)
    m.escribe_region(raw, m.LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  ancho de la caja del MENU   : %d celdas (borde derecho x=118 con 7)' % ancho_menu)
    print('  ancho de la caja del DINERO : %d celdas' % ancho_dinero)
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2],
           int(sys.argv[3]) if len(sys.argv) > 3 else ANCHO_MENU,
           int(sys.argv[4]) if len(sys.argv) > 4 else ANCHO_DINERO)
