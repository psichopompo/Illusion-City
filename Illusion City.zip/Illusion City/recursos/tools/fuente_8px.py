#!/usr/bin/env python3
"""fuente_8px.py - pasa la fuente de celdas de 12x12 (glifo centrado) a
celdas de 8x8 (glifo pegado a la izquierda), para que el texto use paso de 8 px.

MEDIDO sobre la fuente de David (Fuente Lord Monarch.png, celdas 8x8):
  ningun glifo ocupa 8 px: van de 1 a 7 (casi todos 5-7) y empiezan en la
  columna 1 o 2 de su celda.  => colocados a la IZQUIERDA de la celda, la
  separacion entre caracteres sale de 1 a 3 px.
"""
import numpy as np
from PIL import Image

import os
FONT_PNG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        'documentos', 'Fuente Illusion City.png')
CELL = 18                      # 12x12 bits = 144 bits
CELLS_FW = 62                  # bloque fullwidth ０..ｚ  (rel -772 .. -711)
# OJO: el ultimo tramo estaba MAL (errata de la 1ª tanda, corregida el 22/09 con
# celdas_fuente.py): 'ó' va en el rel 599 y 'ú' en el 596, no al reves. Tal como
# estaba, el 'ú' se escribia en la celda del 'ó' y el 'ó' en una celda que NO es suya
# -> los dos salian cambiados (o con el kanji original) en los dialogos.
ACENTOS_REL = [510, 526, 529, 531, 534, 550, 554, 557, 561, 568,
               584, 592, 596, 599, 606, 607]
# celda del simbolo '$' del juego (medida marcando celdas: rel -2235).
# La linea del dinero es lo unico que lo usa.
REL_DOLAR = -2235
TABLAS = {'INIT': (107, 149400, 0x4ED0), 'OPEN': (285, 69258, 0xA710)}


def glifos_david():
    """{caracter: matriz 8x8} leida del PNG de David (128x56 = 16x7 celdas).

    Disposicion del PNG (filas de 16):
      0: . , : ; ! ¿ ¡ ? ( ) [ ] « » " %
      1: 0-9 A-F      2: G-U      3: V-k      4: l-z
      5: Á É Í Ó Ú Ü á é í ó ú ü ~ — + -
      6: $ ? ? # ?    (los 4 simbolos nuevos, de referencia)
    """
    a = np.array(Image.open(FONT_PNG).convert('RGB'))
    def celda(r, c):
        g = np.zeros((8, 8), int)
        for y in range(8):
            for x in range(8):
                g[y, x] = 1 if int(a[r*8+y, c*8+x, 0]) < 50 else 0
        return g
    G = {}
    filas = ['. , : ; ! ¿ ¡ ? ( ) [ ] « » " %'.split(),
             '0 1 2 3 4 5 6 7 8 9 A B C D E F'.split(),
             'G H I J K L M N Ñ O P Q R S T U'.split(),
             'V W X Y Z a b c d e f g h i j k'.split(),
             'l m n ñ o p q r s t u v w x y z'.split(),
             'Á É Í Ó Ú Ü á é í ó ú ü ~ — + -'.split(),
             '$ ◊ ÷ # ∆'.split()]
    for r, chars in enumerate(filas):
        for c, ch in enumerate(chars):
            G[ch] = celda(r, c)
    return G


def a_celda12(g8, off_x, off_y=2):
    """8x8 -> 18 B (12x12, MSB row-major)."""
    g = np.zeros((12, 12), int)
    oy = max(0, min(4, off_y)); ox = max(0, min(4, off_x))
    g[oy:oy+8, ox:ox+8] = g8
    out = bytearray(CELL)
    for r in range(12):
        for c in range(12):
            if g[r, c]:
                bit = 12*r + c
                out[bit//8] |= 1 << (7 - bit % 8)
    return bytes(out)


def destinos():
    """[(rel, caracter)] de las celdas que llevan glifos latinos."""
    d = {}
    fw = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    for i, ch in enumerate(fw):
        d[-772 + i] = ch
    ac = 'ÁáÉÍÓÚÑÜ¿¡éíúóüñ'
    for rel, ch in zip(ACENTOS_REL, ac):
        d[rel] = ch
    d[REL_DOLAR] = '$'          # el simbolo del dinero, con el glifo de David
    return d


def region(raw, lba, size):
    S = 2352
    out = bytearray()
    for k in range(0, size, 2048):
        b = (lba + k//2048)*S + 16
        out.extend(raw[b:b+min(2048, size-k)])
    return bytes(out)


def escribe_region(raw, lba, datos):
    S = 2352
    for k in range(0, len(datos), 2048):
        t = datos[k:k+2048]
        b = (lba + k//2048)*S + 16
        raw[b:b+len(t)] = t
