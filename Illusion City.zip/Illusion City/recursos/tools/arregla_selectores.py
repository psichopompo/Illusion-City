#!/usr/bin/env python3
"""arregla_selectores.py - arregla el cursor de los RECUADROS FLOTANTES.

SINTOMA (David, TEST_O)
  En la ventana flotante del menu Magia (titulo «Efecto», opciones «Ind» y «Grupo»)
  el recuadro azul del cursor sale 48 px mas abajo, fuera de la ventana, en sus dos
  posiciones.

CAUSA (medida, 26/09)
  - El cursor de los recuadros con el bit 4 del campo $0 se dibuja sumando los
    globales $a77a y $a77c a su posicion (codigo en $203D8 y $2046C).
  - El menu de VELOCIDAD pone $a77c = $30 (48) al abrirse ($23A1A) y lo devuelve a 0
    al cerrarse ($23A56)… pero SOLO si sale por B o A: saliendo con START, X, Y o Z
    ese epilogo no se ejecuta y $a77c se queda en 48 (medido en el emulador).
  - El popup solo inicializa $a77a (12), no $a77c, asi que hereda el 48 -> su cursor
    sale 48 px (4 filas) por debajo de su fila. En la captura de David el desfase
    medido es exactamente 48 px: fila «Ind» en y=92 y cursor en y=140.
  Es un fallo del juego original, no del paso mixto.

ARREGLO
  Envolver la rutina del popup ($2201C) para que ponga $a77c = 0 al entrar:
    - el llamador (bsr.w en el fichero 0x11FCA) pasa a apuntar a un trozo nuevo
    - el trozo nuevo hace  move.w #$0,$a77c.l  y luego  jmp $2201C
  (mismo truco que el paso mixto: se cambia el destino de un bsr.w de 4 bytes y el
  trozo nuevo termina en jmp, asi que la pila cuadra sola.)

Uso: python3 arregla_selectores.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

POPUP = 0x2201C              # rutina del popup (Efecto/Ind/Grupo)
LLAMADA_POPUP = 0x11FCA      # bsr.w $2201C dentro del manejador de Magia
STUB_OFF = 0x15400           # hueco libre de START.BIN
STUB_RAM = 0x10000 + STUB_OFF
VUELVE_POPUP = 0x21FCE       # la instruccion que sigue a la llamada

TROZO = (bytes.fromhex('33fc') + (0).to_bytes(2, 'big') + (0x0000a77c).to_bytes(4, 'big')
         + bytes.fromhex('4ef9') + POPUP.to_bytes(4, 'big'))


def aplica_en(st):
    """Parchea el trozo de START (bytearray de la region) en memoria."""
    assert st[STUB_OFF:STUB_OFF + len(TROZO)] == b'\xff' * len(TROZO), 'hueco ocupado'
    assert st[LLAMADA_POPUP:LLAMADA_POPUP + 2] == bytes.fromhex('6100'), 'no hay bsr'
    destino = 0x10000 + LLAMADA_POPUP + 2 + int.from_bytes(st[LLAMADA_POPUP + 2:LLAMADA_POPUP + 4],
                                                           'big', signed=True)
    assert destino == POPUP, 'el bsr no llama al popup (llama a $%X)' % destino
    st[STUB_OFF:STUB_OFF + len(TROZO)] = TROZO
    desp = (STUB_RAM - (0x10000 + LLAMADA_POPUP + 2)) & 0xFFFF
    st[LLAMADA_POPUP + 2:LLAMADA_POPUP + 4] = desp.to_bytes(2, 'big')
    return destino


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    destino = aplica_en(st)
    n = len(st)
    m.escribe_region(raw, m.LBA_START, bytes(st))
    assert len(st) == n
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  bsr.w en 0x%05X -> $%05X (popup en $%05X); trozo nuevo en $%05X (%d B)'
          % (LLAMADA_POPUP, STUB_RAM, destino, STUB_RAM, len(TROZO)))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
