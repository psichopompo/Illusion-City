#!/usr/bin/env python3
"""Desensamblador 68000 rapido (capstone) sobre un fichero del proyecto.

Uso:
    python3 tools/dis68k.py START_act.bin 0x72A6 60 [base]
    base = direccion logica (por defecto 0x10000, la base de carga de START/SSTART)
"""
import sys
import capstone as cs

def main():
    path = sys.argv[1]
    off = int(sys.argv[2], 0)
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    base = int(sys.argv[4], 0) if len(sys.argv) > 4 else 0x10000
    data = open(path, 'rb').read()
    md = cs.Cs(cs.CS_ARCH_M68K, cs.CS_MODE_M68K_000)
    md.detail = True
    code = data[off:off + n * 12]
    addr = base + off
    for insn in md.disasm(code, addr):
        print("  %06X  %-22s %s %s" % (insn.address, insn.bytes.hex(), insn.mnemonic, insn.op_str))

if __name__ == '__main__':
    main()
