#!/usr/bin/env python3
"""verifica_fuente.py - auditoria COMPLETA: tu PNG contra la fuente que hay en el ISO.

Para cada caracter de `Fuente Illusion City.png`:
  1. se busca el codigo del motor que el juego usa para ese caracter,
  2. se calcula su celda (rutina del juego, celdas_fuente.py),
  3. se lee el glifo que hay HOY en esa celda del ISO y se compara, pixel a pixel,
     con el de tu PNG colocado como lo coloca el parche (a_celda12: filas 2..9,
     columnas 0..7 de la celda de 12x12).

Sale un OK/MAL por caracter. Los caracteres que no tienen codigo en el juego se
listan aparte (esos necesitan una celda secuestrada).

Uso: python3 verifica_fuente.py [fichero.bin]
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('cf', os.path.join(AQUI, 'celdas_fuente.py'))
cf = importlib.util.module_from_spec(spec); spec.loader.exec_module(cf)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
spec3 = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec3); spec3.loader.exec_module(m)

TABLAS = (('INIT', 107, 149400, 0x14E0), ('OPEN', 285, 69258, 0x6D20))
ICONO_GLIFO = '∆'      # el que lleva puesto el build (parche_rotulos.GLIFO_ICONO)
ICONO_CELDA = 1349

# caracter -> (codigo del motor, celda, de donde sale el codigo)
CARACTERES = [
    (',',   0x8141, 1,  'codificador (、)'),
    ('.',   0x8142, 2,  'codificador (。)'),
    (':',   0x8146, 6,  'codificador (：)'),
    (';',   0x8147, 7,  'codificador (；)'),
    ('?',   0x8148, 8,  'codificador (？)'),
    ('!',   0x8149, 9,  'codificador (！)'),
    ('—',   0x815C, 13, 'codificador (―)'),
    ('~',   0x815E, 14, 'plantilla de PV/PM (12 ~ 12)'),
    ('(',   0x8169, 22, 'codificador (（)'),
    (')',   0x816A, 23, 'codificador (）)'),
    ('[',   0x816D, 26, 'plantillas [Tecnica]/[Item]'),
    (']',   0x816E, 27, 'plantillas [Tecnica]/[Item]'),
    ('"',   0x8171, 30, 'codificador (」)'),
    ('+',   0x817B, 40, 'plantilla de ATA (4+ 75)'),
    ('-',   0x817C, 41, 'codificador (－)'),
    ('%',   0x8193, 50, 'plantilla de PRE (91%)'),
    ('0',   0x824F, 52, 'digitos'),
    ('1',   0x8250, 53, 'digitos'),
    ('2',   0x8251, 54, 'digitos'),
    ('3',   0x8252, 55, 'digitos'),
    ('4',   0x8253, 56, 'digitos'),
    ('5',   0x8254, 57, 'digitos'),
    ('6',   0x8255, 58, 'digitos'),
    ('7',   0x8256, 59, 'digitos'),
    ('8',   0x8257, 60, 'digitos'),
    ('9',   0x8258, 61, 'digitos'),
    ('A',   0x8260, 62, 'letras'),
    ('Z',   0x8279, 87, 'letras'),
    ('a',   0x8281, 88, 'letras'),
    ('m',   0x828D, 100, 'letras'),
    ('z',   0x829A, 113, 'letras'),
    ('$',   0x8190, 49, 'la linea del dinero'),
    ('Á', 0x95FB, 1334, 'acentos (slots secuestrados)'),
    ('É', 0x966B, 1353, 'acentos'),
    ('Í', 0x967B, 1355, 'acentos'),
    ('Ó', 0x9682, 1358, 'acentos'),
    ('Ú', 0x96AF, 1374, 'acentos'),
    ('Ñ', 0x96B3, 1378, 'acentos'),
    ('Ü', 0x96BD, 1381, 'acentos'),
    ('¿', 0x96C5, 1385, 'acentos'),
    ('¡', 0x96DA, 1392, 'acentos'),
    ('á', 0x9660, 1350, 'acentos'),
    ('é', 0x9744, 1408, 'acentos'),
    ('í', 0x9755, 1416, 'acentos'),
    ('ó', 0x975F, 1423, 'acentos'),
    ('ú', 0x975C, 1420, 'acentos'),
    ('ü', 0x976C, 1430, 'acentos'),
    ('ñ', 0x9770, 1431, 'acentos'),
    (ICONO_GLIFO, 0x965F, 1349, 'ICONO de los rotulos (fila 7)'),
]
SIN_CODIGO = ['«', '»', '÷', '#', '∆']          # caracteres de tu PNG sin codigo
DUDAS = [('「', 'comilla de apertura: el codificador usa 」 para las dos')]


def glifo_iso(D, base, celda):
    o = base + celda * 18
    d = D[o:o + 18]
    g = [[0] * 12 for _ in range(12)]
    for r in range(12):
        for c in range(12):
            bit = 12 * r + c
            g[r][c] = (d[bit // 8] >> (7 - bit % 8)) & 1
    return g


def glifo_david(ch):
    G = f.glifos_david()
    g8 = G[ch]
    g = [[0] * 12 for _ in range(12)]
    for r in range(8):
        for c in range(8):
            g[2 + r][c] = int(g8[r, c])
    return g


def main():
    fichero = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROY, 'TEST_AC.bin')
    raw = open(fichero, 'rb').read()
    datos = {n: bytearray(m.region(raw, lba, sz)) for n, lba, sz, _ in TABLAS}
    bases = {n: b for n, _, _, b in TABLAS}
    print('  fichero: %s' % os.path.basename(fichero))
    print('  %-4s %-7s %-6s %-6s %s' % ('chr', 'codigo', 'celda', 'estado', 'procedencia'))
    malos = []
    for ch, cod, celda, donde in CARACTERES:
        ccalc = cf.celda(cod)
        aviso = '' if ccalc == celda else '  <<< la celda calculada es %s' % ccalc
        est = []
        for n, _, _, _ in TABLAS:
            g = glifo_iso(datos[n], bases[n], celda)
            est.append('%s:%s' % (n, 'OK' if g == glifo_david(ch) else 'MAL'))
        if 'MAL' in ''.join(est):
            malos.append(ch)
        print('  %-4s U+%04X  %-6d %-6s %s%s'
              % (ch, cod, celda, ' '.join(est), donde, aviso))
    print()
    if malos:
        print('  PENDIENTES DE METER: %s' % ' '.join(malos))
    else:
        print('  Todo lo que tiene codigo esta con tu glifo (INIT y OPEN).')
    print('  SIN CODIGO en el juego (hay que darles una celda secuestrada): %s'
          % ' '.join(SIN_CODIGO))
    for ch, nota in DUDAS:
        print('  DUDA: %s -> %s' % (ch, nota))


if __name__ == '__main__':
    main()
