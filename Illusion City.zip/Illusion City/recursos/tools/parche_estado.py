#!/usr/bin/env python3
"""parche_estado.py - la fila del NOMBRE+CLASE del menu de Estado.

EL PROBLEMA (medido el 22/09)
  La fila del nombre no esta en ninguna tabla: la rutina de la ficha (START $22E0A)
  BORRA las primeras 14 celdas de la plantilla y escribe encima
      icono + NOMBRE + icono + hueco(1) + CLASE
  Con nombres de 3 glifos y clases de 6 (el original) son 11 celdas y sobran 3.
  Con «Tian Ren» (8) y «POLICÍA» (7) son 18: se come los 2 saltos de linea que hay
  detras (la linea vacia) y el marcador $5 de la fila siguiente -> el «NV» salia
  pegado a la clase y en BLANCO (perdio su $5, que es el cambio de color).
  Poner el espacio que David quiere entre el icono y la clase anade una celda mas.

EL ARREGLO
  La fila pasa a 20 celdas (el peor caso: icono + 8 letras + icono + espacio + 10 de
  clase = 20) y la plantilla se COPIA a sitio libre (START 0x179A2) porque crecer en
  su sitio desplazaria las plantillas que van detras. Como se mueve, hay que reapuntar
  las 17 direcciones que la referencian (medidas: 16 `lea` + el puntero del descriptor).
  No hay referencias PC-relativas (comprobado).

Uso: python3 parche_estado.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TPL_VIEJA = 0x13F8A            # plantilla de la ficha de ESTADO (fichero)
TPL_NUEVA = 0x17ADA            # a donde se muda (sitio libre medido en el build: 1190 B)
FILA = 14                      # celdas de la fila del nombre en el original
FILA_NUEVA = 20                # celdas que necesita el peor caso
N_ESPACIOS = 0x12E1E           # move.w #$E,d0  (los espacios que borra la rutina)
ESPACIO_CLASE = 0x12E76        # adda.w #$2,a2  (el hueco icono->clase)
# (direccion vieja, sitio de la referencia en el fichero)
REFS = [
    (0x23F8A, 0x12E18), (0x23F8A, 0x12E24), (0x23F8A, 0x12E54),
    (0x23FC4, 0x12E8E), (0x23FDA, 0x12E9E), (0x23FFA, 0x12EAE),
    (0x2401A, 0x12EC2), (0x24022, 0x12ED2), (0x24038, 0x12EE2),
    (0x24040, 0x12EF2), (0x24058, 0x12F02), (0x24060, 0x12F12),
    (0x24076, 0x12F22), (0x2407E, 0x12F32), (0x24094, 0x12F42),
    (0x2409C, 0x12F52), (0x240B2, 0x12E3C), (0x240B2, 0x12F7E),
    (0x240BC, 0x12E32), (0x240BC, 0x12F72), (0x240D4, 0x12E42),
    (0x240D4, 0x12F8C),
]
LARGO_VIEJO = 0x140DE - 0x13F8A      # 342 B hasta el 00 final


def pon(buf, off, data, cual):
    n = len(buf)
    buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))

    # --- 1) copiar la plantilla con la fila del nombre mas larga ---
    tpl = bytearray(st[TPL_VIEJA:TPL_VIEJA + LARGO_VIEJO])
    assert tpl[:28] == b'\x81\x40' * FILA, 'la plantilla no empieza por espacios'
    nuevos = FILA_NUEVA - FILA
    tpl[28:28] = b'\x81\x40' * nuevos
    print('  plantilla: %d B -> %d B (%d celdas mas en la fila del nombre)'
          % (LARGO_VIEJO, len(tpl), nuevos))
    assert st[TPL_NUEVA:TPL_NUEVA + len(tpl)] == b'\xff' * len(tpl), 'el sitio nuevo no esta libre'
    st[TPL_NUEVA:TPL_NUEVA + len(tpl)] = tpl

    # --- 2) la rutina: 14 espacios -> 20, y el hueco antes de la clase ---
    assert st[N_ESPACIOS:N_ESPACIOS + 4] == bytes.fromhex('303c000e'), \
        'en 0x%05X esperaba move.w #$E,d0' % N_ESPACIOS
    pon(st, N_ESPACIOS, bytes.fromhex('303c') + FILA_NUEVA.to_bytes(2, 'big'), 'espacios')
    pon(st, ESPACIO_CLASE, bytes.fromhex('d4fc0002'), 'hueco de la clase (1 celda)')
    print('  rutina: %d espacios (antes %d) y el hueco de 1 celda restaurado'
          % (FILA_NUEVA, FILA))

    # --- 3) reapuntar las 17 direcciones ---
    for viejo, sitio in REFS:
        assert st[sitio:sitio + 4] == viejo.to_bytes(4, 'big'), \
            'en 0x%05X esperaba $%06X y hay %s' % (sitio, viejo, st[sitio:sitio + 4].hex(' '))
        despues = viejo - TPL_VIEJA
        nuevo = TPL_NUEVA + despues + (nuevos * 2 if despues >= 28 else 0)
        pon(st, sitio, nuevo.to_bytes(4, 'big'), 'referencia 0x%05X' % sitio)
    print('  %d referencias reapuntadas (plantilla nueva en RAM $%05X)'
          % (len(REFS), TPL_NUEVA + 0x10000))

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
