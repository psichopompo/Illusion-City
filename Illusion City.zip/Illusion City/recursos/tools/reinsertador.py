#!/usr/bin/env python3
"""Reinsertador de textos castellanos para Gen'ei Toshi (Mega CD).

Estrategia v1: sustitución IN-SITU.
- Cadena nueva codificada + terminador 00 + relleno de 00 hasta el tamaño
  original. Es seguro en los archivos de guion porque el flujo de comandos
  ya contiene runs naturales de 00 entre registros (p. ej. `...8176 00 00 00 c7`),
  luego el motor tolera/salta bytes nulos entre comandos.
- Para cadenas en tablas secuenciales (START.BIN y el bloque de batalla de
  INIT.BIN a partir de 0x22900) se exige longitud EXACTA; si no cabe, se omite.

Entrada:  textos_dumper.csv (columna traduccion_castellano rellenada)
Salida:   track01_castellano.iso + .bin [CAST] (fuente + textos)
          informe_reinsercion.txt

Uso:
    python3 tools/reinsertador.py --dry   # solo informe
    python3 tools/reinsertador.py         # aplica y reconstruye imágenes
"""
import csv
import os
import sys
import importlib.util

sys.path.insert(0, os.path.dirname(__file__))
from codificador_castellano import encode_spanish, decode_engine, EncodeError

CSV_IN = 'textos_dumper.csv'
ISO_ORIG = 'track01.iso'
BIN_ORIG = "Gen'ei Toshi - Illusion City (Japan) (Track 01).bin"
ISO_OUT = 'track01_castellano.iso'
BIN_OUT = "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"
GFONT_PATCH = 'analisis/GFONT_CAST.BIN'
GFONT_LBA = 679
INFORME = 'informes/informe_reinsercion.txt'

# NOTA: el relleno de ceros preserva la longitud total del archivo, luego
# también sirve en tablas secuenciales de cadenas (cada una sigue terminada
# en 00 y la siguiente conserva su offset).


def iso_to_raw(iso_off):
    """offset en ISO 2048B/sector -> offset en .bin crudo 2352B/sector."""
    n, r = divmod(iso_off, 2048)
    return 0x9300 + (n - 16) * 2352 + 16 + r


def main():
    dry = '--dry' in sys.argv
    iso = bytearray(open(ISO_ORIG, 'rb').read())
    informe = []
    stats = {'ok': 0, 'skip_largo': 0, 'skip_error': 0, 'exact': 0}

    rows = list(csv.DictReader(open(CSV_IN, encoding='utf-8-sig')))
    for row in rows:
        trad = row['traduccion_castellano'].strip()
        if not trad:
            continue
        rid = row['id']
        fname = row['archivo']
        iso_off = int(row['offset_iso'], 16)

        # longitud original (hasta el terminador 00 incluido)
        end = iso.index(b'\x00', iso_off)
        orig_len = end - iso_off + 1

        # opcode halfwidth inicial (ﾇ, ﾈ...) y comillas: se conservan del original
        try:
            new = encode_spanish(trad)
        except EncodeError as e:
            stats['skip_error'] += 1
            informe.append(f'[{rid}] ERROR codificacion: {e}  | {trad}')
            continue

        if len(new) + 1 > orig_len:
            stats['skip_largo'] += 1
            informe.append(
                f'[{rid}] NO CABE en {fname}@{row["offset_archivo"]} '
                f'(necesita {len(new)+1}, hay {orig_len}) | {trad}')
            continue

        # escribir: nuevo + 00 + relleno de ceros hasta completar el hueco
        data = new + b'\x00'
        data += b'\x00' * (orig_len - len(data))
        iso[iso_off:iso_off + orig_len] = data

        # verificación: releer y decodificar
        back = decode_engine(bytes(iso[iso_off:end]))
        stats['ok'] += 1
        tag = 'EXACTO' if len(new) + 1 == orig_len else f'RELLENO({orig_len-len(new)-1})'
        informe.append(
            f'[{rid}] {tag} {fname}@{row["offset_archivo"]} | {trad}  ->  {back}')

    informe.insert(0, f"aplicadas={stats['ok']}  no_caben={stats['skip_largo']}  "
                      f"errores={stats['skip_error']}")
    txt = '\n'.join(informe)
    print(txt)
    open(INFORME, 'w').write(txt + '\n')

    if dry:
        print('\n(dry run: nada escrito)')
        return

    # parchear la fuente en la ISO
    font = open(GFONT_PATCH, 'rb').read()
    foff = GFONT_LBA * 2048
    assert iso[foff:foff + 18] == bytes(18), 'glifo 0 deberia estar vacio'
    iso[foff:foff + len(font)] = font

    open(ISO_OUT, 'wb').write(bytes(iso))
    print(f'\n{ISO_OUT} escrito')

    # reconstruir el .bin crudo desde el ORIGINAL (no acumulativo)
    raw = bytearray(open(BIN_ORIG, 'rb').read())
    orig = open(ISO_ORIG, 'rb').read()
    nsec = len(iso) // 2048
    for n in range(nsec):
        blk = iso[n * 2048:(n + 1) * 2048]
        if blk != orig[n * 2048:(n + 1) * 2048]:
            ro = iso_to_raw(n * 2048)
            raw[ro:ro + 2048] = blk
    open(BIN_OUT, 'wb').write(bytes(raw))
    print(f'{BIN_OUT} escrito')


if __name__ == '__main__':
    main()
