#!/usr/bin/env python3
"""Scan a raw binary for 4bpp tile data (Sega Genesis/Mega CD font candidates)."""
import sys
from collections import Counter

def score_4bpp(buf: bytes) -> float:
    """Ratio of nibbles in low planes (0-3) vs high (4-F). Fonts are mostly 0/1/2."""
    lo = 0
    total = 0
    for b in buf:
        for nib in (b >> 4, b & 0xF):
            total += 1
            if nib <= 3:
                lo += 1
    return lo / total

def main():
    path = sys.argv[1]
    block = int(sys.argv[2]) if len(sys.argv) > 2 else 512
    data = open(path, 'rb').read()
    # candidate font regions: consecutive blocks with heavy low-nibble usage and many exact 0x00/0x11/0x22 bytes
    results = []
    for off in range(0, len(data) - block, block):
        buf = data[off:off+block]
        if buf.count(b'\x00') < block // 3:
            continue
        c = Counter(buf)
        # fonts have repeated identical bytes (row pairs) and lots of zeros
        zeros = c[0]
        if zeros < block * 0.25:
            continue
        top = c.most_common(1)[0][1]
        if top < block * 0.25:
            continue
        results.append((off, zeros, top))
    # merge consecutive
    merged = []
    for off, zeros, top in results:
        if merged and off == merged[-1][1]:
            merged[-1] = (merged[-1][0], off + block)
        else:
            merged.append((off, off + block))
    for a, b in merged:
        if b - a >= 512:
            print(f"0x{a:08X}-0x{b:08X} ({b-a} B)")

if __name__ == '__main__':
    main()
