#!/usr/bin/env python3
"""Scan a raw binary for runs of Shift-JIS text (2-byte kanji + kana + ASCII)."""
import sys, re

def looks_like_shiftjis(buf: bytes) -> bool:
    i = 0
    n = len(buf)
    score = 0
    while i < n:
        b = buf[i]
        if b < 0x80:
            if b in (0x0A, 0x0D, 0x09):
                i += 1
                continue
            if 0x20 <= b < 0x7F:
                score += 1
                i += 1
                continue
            return False
        # 2-byte Shift-JIS ranges
        if 0x81 <= b <= 0x9F or 0xE0 <= b <= 0xEF:
            if i + 1 >= n:
                return False
            b2 = buf[i + 1]
            if 0x40 <= b2 <= 0x7E or 0x80 <= b2 <= 0xFC:
                score += 2
                i += 2
                continue
            return False
        # half-width katakana (0xA1-0xDF)
        if 0xA1 <= b <= 0xDF:
            score += 1
            i += 1
            continue
        return False
    return score >= 6

def main():
    path = sys.argv[1]
    min_len = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    data = open(path, 'rb').read()
    # Candidate lead bytes for SJIS double-byte
    pattern = re.compile(rb'[\x81-\x9f\xe0-\xef][\x40-\x7e\x80-\xfc]')
    results = []
    pos = 0
    n = len(data)
    while pos < n:
        m = pattern.search(data, pos)
        if not m:
            break
        start = m.start()
        # extend backwards over preceding ASCII/kana to catch mixed strings
        s = start
        while s > 0 and (0x20 <= data[s-1] < 0x7F or 0xA1 <= data[s-1] <= 0xDF):
            s -= 1
        # extend forward validating SJIS
        i = start
        end = start
        ok = True
        while i < n:
            b = data[i]
            if b < 0x80:
                if b in (0x0A, 0x0D):
                    # allow line breaks inside block
                    i += 1
                    end = i
                    continue
                if 0x20 <= b < 0x7F or 0xA1 <= b <= 0xDF:
                    i += 1
                    end = i
                    continue
                break
            if (0x81 <= b <= 0x9F or 0xE0 <= b <= 0xEF) and i + 1 < n:
                b2 = data[i+1]
                if 0x40 <= b2 <= 0x7E or 0x80 <= b2 <= 0xFC:
                    i += 2
                    end = i
                    continue
            break
        buf = data[s:end]
        if end - s >= min_len and looks_like_shiftjis(buf):
            try:
                text = buf.decode('shift_jis', errors='replace')
            except Exception:
                text = repr(buf)
            results.append((s, end, text))
            pos = end
        else:
            pos = start + 1
    for s, e, text in results:
        print(f"0x{s:08X}-0x{e:08X} ({e-s} B): {text[:200]!r}")
    print(f"\nTotal: {len(results)} blocks", file=sys.stderr)

if __name__ == '__main__':
    main()
