#!/usr/bin/env python3
"""dis_zona.py - desensambla un TROZO de un fichero de la ISO (no una linea).

Uso:
    python3 dis_zona.py START 0x11D60 0x11EC0        # desde 0x11D60 hasta 0x11EC0
    python3 dis_zona.py START 0x11D60 0x11EC0 2      # forzando el desfase (0 o 2)

Las direcciones que imprime son de RAM (offset + base del fichero).
"""
import capstone
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

REG = {'START': (59, 98184), 'SSTART': (43, 32644), 'INIT': (107, 149400),
       'OPEN': (285, 69258), 'CHR': (180, 94310), 'SD': (251, 69194),
       'GFONT': (679, 7920)}


def region(nombre):
    raw = open(m.BASE, 'rb').read()
    lba, sz = REG[nombre]
    return m.region(raw, lba, sz)


def des(name, ini, fin, off=None, base=None):
    d = region(name)
    base = 0x10000 if base is None else base
    cs = capstone.Cs(capstone.CS_ARCH_M68K,
                     capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
    if off is None:                       # busca el desfase que da codigo valido
        mejor, n = 0, -1
        for o in (0, 2):
            k = sum(1 for _ in cs.disasm(d[ini + o:fin], base + ini + o))
            if k > n:
                mejor, n = o, k
        off = mejor
    for i in cs.disasm(d[ini + off:fin], base + ini + off):
        print('  %06X  %-16s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                    i.mnemonic + ' ' + i.op_str))


if __name__ == '__main__':
    des(sys.argv[1], int(sys.argv[2], 0), int(sys.argv[3], 0),
        int(sys.argv[4], 0) if len(sys.argv) > 4 else None)
