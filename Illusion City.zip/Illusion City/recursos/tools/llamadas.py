#!/usr/bin/env python3
"""llamadas.py - quien llama a una direccion (jsr absoluto o bsr relativo).

Uso: python3 llamadas.py START 0x203C0
"""
import capstone
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

REG = {'START': (59, 98184), 'SSTART': (43, 32644), 'INIT': (107, 149400),
       'OPEN': (285, 69258), 'CHR': (180, 94310), 'SD': (251, 69194)}
nombre = sys.argv[1]
objetivo = int(sys.argv[2], 0)
lba, sz = REG[nombre]
d = m.region(open(m.BASE, 'rb').read(), lba, sz)
base = 0x10000
cs = capstone.Cs(capstone.CS_ARCH_M68K, capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
cs.skipdata = True
print('  llamadas a $%06X en %s:' % (objetivo, nombre))
for i in cs.disasm(d, 0x10000):
    mn = i.mnemonic
    if mn in ('jsr', 'bsr', 'bra', 'jmp'):
        op = i.op_str.strip()
        try:
            if op.endswith('.l'):
                op = op[:-2]
            if op.startswith('$'):
                tgt = int(op[1:], 16)
            else:
                tgt = int(op, 16)
        except ValueError:
            continue
        if tgt == objetivo:
            print('    $%06X  %-16s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                           mn + ' ' + i.op_str))
