#!/usr/bin/env python3
"""parche_sistema.py - ARREGLA el menu de Sistema (la ventana de Velocidad/Ajustes).

EL BUG (medido)
  En el START original, justo DETRAS de la plantilla de Combate (0x14268) hay un
  bloque de datos del menu flotante de Sistema:
      0x143D2:  00 02 43 da      -> puntero a la cadena 1
      0x143D6:  00 02 43 e4      -> puntero a la cadena 2
      0x143DA:  スピード 00 00
      0x143E4:  スイッチ 00 00
  La rutina que monta esa ventana tiene escrito el long $243D2 en 0x11D20
  (`move.l #$243d2,$22(a0)`), y esa es la unica referencia que hay.
  Nuestra plantilla de COMBATE traducida es 114 B mas larga que la japonesa y
  **se come ese bloque entero** (0x143D2-0x1444A): los punteros pasan a apuntar
  a basura -> la ventana sale VACIA y el juego se cuelga al pintarla.

EL ARREGLO
  Se rehace el bloque en el hueco libre que hay detras de la plantilla de Magia
  (0x17CC2 + su longitud) y se reapunta la unica referencia (0x11D20).
  De paso se traducen las dos cadenas: スピード -> Velocidad, スイッチ -> Ajustes.

Uso: python3 parche_sistema.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
REF = 0x11D1E                  # el long $243D2 dentro de `move.l #$243d2,$22(a0)`
                               # (la instruccion empieza en 0x11D1C y el dato en 0x11D1E)
VIEJO = 0x243D2                # valor que hay que sustituir
LIBRE = 0x17CC2                # hueco libre; la plantilla de Magia empieza aqui
C1, C2 = 'Velocidad', 'Ajustes'


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += b'\x81\x40'
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


# MEDIDO: $2e de esta ventana = BYTES de texto que se pintan (2 B por caracter).
#   Con $2e = 4 salian 8 caracteres ("Velocida"); con 5 salen 10 ("Velocidad").
#   (En las ventanas de nombres $2e es el largo del selector en px/6: son ventanas
#    distintas, aunque compartan nombre de campo.)
# $8 = ancho de la ventana en columnas de 8 px; ademas LIMITA el texto que se pinta:
#   se pintan $8 x 2 BYTES (con $8=8 salian 16 B = 8 caracteres -> "Velocida").
#   Con $8=10 la ventana mide 92 px (16 mas que la japonesa, que media 76) y caben
#   20 B = 10 caracteres: "Velocidad" (18 B) entra.
LARGO_TEXTO = 5
ANCHO_VENTANA = 9


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    print('  0x%05X = $%06X (la referencia del menu de Sistema)' % (REF, VIEJO))
    assert st[REF:REF + 4] == VIEJO.to_bytes(4, 'big'), \
        'no veo la referencia esperada: %s' % st[REF:REF + 4].hex(' ')
    # sitio libre: detras de la plantilla de Magia
    fin = LIBRE
    while fin < len(st) and st[fin] != 0xFF:
        fin += 1
    if fin % 2:
        fin += 1
    print('  la plantilla de Magia llega hasta 0x%05X; el bloque nuevo va en 0x%05X'
          % (fin - 1, fin))
    A1 = fin + 8                       # tabla: 2 punteros de 4 B
    A2 = A1 + len(fw(C1)) + 2
    # OJO: lo que va en la tabla son direcciones de RAM ($xxxxxx), NO offsets de
    # fichero. El error de la primera version fue escribir 0x17D8A en vez de $27D8A:
    # el pintor leia $00017D8A (basura) y la ventana salia con dos simbolos.
    R1, R2 = A1 + 0x10000, A2 + 0x10000
    bloque = (R1.to_bytes(4, 'big') + R2.to_bytes(4, 'big') +
              fw(C1) + b'\x00\x00' + fw(C2) + b'\x00\x00')
    assert st[fin:fin + len(bloque)] == b'\xff' * len(bloque), 'el hueco no esta libre'
    st[fin:fin + len(bloque)] = bloque
    print('  bloque nuevo: 0x%05X  (cadenas en $%06X y $%06X)' % (fin, R1, R2))
    st[REF:REF + 4] = (fin + 0x10000).to_bytes(4, 'big')
    print('  reapuntado: 0x%05X -> $%06X' % (REF, fin + 0x10000))
    # largo del texto y ancho de la ventana
    assert st[0x11D50:0x11D56] == bytes.fromhex('317c0004002e'), st[0x11D50:0x11D56].hex(' ')
    st[0x11D52:0x11D54] = LARGO_TEXTO.to_bytes(2, 'big')
    print('  $2e (caracteres que se pintan): 4 -> %d' % LARGO_TEXTO)
    assert st[0x11D62:0x11D68] == bytes.fromhex('317c00080008'), st[0x11D62:0x11D68].hex(' ')
    st[0x11D64:0x11D66] = ANCHO_VENTANA.to_bytes(2, 'big')
    print('  $8 (ancho de la ventana): 8 -> %d' % ANCHO_VENTANA)
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
