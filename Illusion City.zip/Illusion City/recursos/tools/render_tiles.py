#!/usr/bin/env python3
"""Render a region of the ISO as 8x8 4bpp Sega tiles (bitplanes interleaved per row-pair) to PNG."""
import sys
from PIL import Image

def main():
    path = sys.argv[1]
    off = int(sys.argv[2], 0)
    ntiles = int(sys.argv[3])
    out = sys.argv[4]
    scale = int(sys.argv[5]) if len(sys.argv) > 5 else 4
    data = open(path, 'rb').read()
    cols = 16
    rows = (ntiles + cols - 1) // cols
    img = Image.new('P', (cols*8*scale, rows*8*scale), 0)
    pal = [ (17,17,17), (255,255,255), (120,200,255), (255,120,120),
            (60,60,60), (200,200,200), (80,120,255), (255,80,80) ] + [(0,0,0)]*248
    img.putpalette([c for rgb in pal for c in rgb])
    px = img.load()
    for t in range(ntiles):
        tile = data[off + t*32 : off + t*32 + 32]
        if len(tile) < 32: break
        tx, ty = (t % cols)*8*scale, (t // cols)*8*scale
        for y in range(8):
            b0 = tile[y*4]; b1 = tile[y*4+1]; b2 = tile[y*4+2]; b3 = tile[y*4+3]
            for x in range(8):
                bit = 7 - x
                v = ((b0 >> bit) & 1) | (((b1 >> bit) & 1) << 1) | (((b2 >> bit) & 1) << 2) | (((b3 >> bit) & 1) << 3)
                v &= 3  # fonts usually use only 2bpp of the 4bpp planes
                for sy in range(scale):
                    for sx in range(scale):
                        px[tx + x*scale + sx, ty + y*scale + sy] = v
    img.save(out)

if __name__ == '__main__':
    main()
