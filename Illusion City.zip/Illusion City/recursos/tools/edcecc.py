#!/usr/bin/env python3
"""edcecc.py - EDC y ECC (paridad P/Q) de los sectores Mode 1 de un .bin de CD.

POR QUE HACE FALTA
------------------
De los 2352 B de un sector Mode 1, solo 2048 son datos. Los otros 304 son
metadatos: sync (12), cabecera MSF+modo (4), EDC (4), un campo de ceros (8) y
las paridades Reed-Solomon P (172) y Q (104).

El pipeline del proyecto escribia los 2048 B de datos y dejaba el resto a CERO
("el emulador lo ignora"). Eso es cierto para Genesis Plus GX y compañía, pero
**NO para hardware real**: el controlador del Mega CD usa EDC/ECC para validar y
corregir sectores, y con esos campos a cero puede dar lecturas con error.

Que se calcula (estándar de CD-ROM Mode 1, el de cdrdao / Neill Corlett):
  - EDC: CRC-32 con polinomio 0xD8018001, semilla 0, SIN xor final, sobre los
    2064 B que van del sync al final de los datos (offset 0..2063). Se guarda
    como u32 LITTLE-endian en +2064.
  - ECC: dos codigos Reed-Solomon sobre GF(2^8) con polinomio primitivo 0x11D:
        P: (86, 24, 2)  -> 172 B  en +2076
        Q: (52, 43, 86) -> 104 B  en +2248
    **Se calculan con la CABECERA A CERO** (se pone 00 00 00 00 en +12..+15
    mientras se calcula y luego se restaura). Ese detalle es del estándar y si
    se omite la paridad sale mal.

VALIDACION INDEPENDIENTE
------------------------
`autotest()` comprueba el encoder con una formulacion DISTINTA del mismo
problema: calcula los SINDROMES del codigo Reed-Solomon (evaluando el polinomio
recibido en las raices del generador). Si el codigo es correcto, todos los
sindromes valen cero. Es decir, no se compara contra "lo que yo espero" sino
contra una propiedad matematica independiente.

    python3 tools/edcecc.py autotest FICHERO.bin     # valida un .bin entero
    python3 tools/edcecc.py repara FICHERO.bin       # recalcula EDC/ECC
    python3 tools/edcecc.py partes FICHERO.bin       # solo estructura
"""
import hashlib
import os
import sys

SECTOR = 2352
OFF_EDC = 2064
OFF_P = 2076
OFF_Q = 2248

# ---------------------------------------------------------------- EDC
def _tabla_edc():
    t = []
    for i in range(256):
        e = i
        for _ in range(8):
            e = (e >> 1) ^ (0xD8018001 if e & 1 else 0)
        t.append(e & 0xFFFFFFFF)
    return t


_T_EDC = _tabla_edc()


def edc(datos):
    """CRC-32/EDC con tabla (implementacion rapida)."""
    e = 0
    for b in datos:
        e = (e >> 8) ^ _T_EDC[(e ^ b) & 0xFF]
    return e & 0xFFFFFFFF


def edc_bitwise(datos):
    """La MISMA cuenta, bit a bit y sin tabla: implementacion independiente
    para poder contrastar la de arriba."""
    e = 0
    for b in datos:
        e ^= b
        for _ in range(8):
            e = (e >> 1) ^ (0xD8018001 if e & 1 else 0)
    return e & 0xFFFFFFFF


# ---------------------------------------------------------------- ECC
def _luts():
    f = [0] * 256
    b = [0] * 256
    for i in range(256):
        j = (i << 1) ^ (0x11D if i & 0x80 else 0)
        f[i] = j & 0xFF
        b[(i ^ j) & 0xFF] = i
    return f, b


F_LUT, B_LUT = _luts()


def _ecc_bloque(src, major_count, minor_count, major_mult, minor_inc, base=12):
    """Encoder Reed-Solomon tal cual lo hace el estandar (LUTs)."""
    size = major_count * minor_count
    out = bytearray(major_count * 2)
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        a = bb = 0
        for _ in range(minor_count):
            t = src[base + index]
            index += minor_inc
            if index >= size:
                index -= size
            a ^= t
            bb ^= t
            a = F_LUT[a]
        a = B_LUT[F_LUT[a] ^ bb]
        out[major] = a
        out[major + major_count] = a ^ bb
    return bytes(out)


def ecc_p(sector):
    return _ecc_bloque(sector, 86, 24, 2, 86)


def ecc_q(sector):
    return _ecc_bloque(sector, 52, 43, 86, 88)


def calcula_sector(sector):
    """Devuelve (edc, P, Q) para un sector completo de 2352 B (Mode 1).

    ORDEN IMPORTANTE (aqui estuvo un error propio): el EDC se calcula primero y
    **se escribe en la copia** antes de calcular la paridad, porque la paridad P
    y Q cubre TAMBIEN los 4 bytes de EDC y los 8 reservados. Si se calcula la
    paridad sobre el EDC viejo, al escribir el EDC nuevo la paridad queda
    invalida (el sector parece bien para un verificador que use el mismo orden
    equivocado, pero la referencia lo caza).

    Referencia (ecm.cpp, reconstruct_sector): primero
    `put32lsb(sector+0x810, edc_compute(...))`, los 8 reservados a cero, y
    despues `ecc_writesector(sector+0xC, sector+0x10, sector+0x81C)`.
    """
    assert len(sector) == SECTOR
    s = bytearray(sector)
    e = edc(s[:OFF_EDC])
    s[OFF_EDC:OFF_EDC + 4] = e.to_bytes(4, 'little')
    s[OFF_EDC + 4:OFF_P] = bytes(8)          # 8 bytes reservados = 0
    P = ecc_p(s)
    s[OFF_P:OFF_P + 172] = P
    Q = ecc_q(s)
    return e, P, Q


def repara_sector(sector):
    """Devuelve el sector con EDC/P/Q correctos. No toca los datos.

    El orden (EDC -> paridad) no es cosmetico: la paridad cubre el EDC.
    """
    e, P, Q = calcula_sector(sector)
    s = bytearray(sector)
    s[OFF_EDC:OFF_EDC + 4] = e.to_bytes(4, 'little')
    s[OFF_EDC + 4:OFF_P] = bytes(8)
    s[OFF_P:OFF_P + 172] = P
    s[OFF_Q:OFF_Q + 104] = Q
    return bytes(s)


# ------------------------------------------------- validacion independiente
_GF_EXP = [0] * 512
_GF_LOG = [0] * 256
_x = 1
for _i in range(255):
    _GF_EXP[_i] = _x
    _GF_LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _GF_EXP[_i] = _GF_EXP[_i - 255]


def _mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _GF_EXP[_GF_LOG[a] + _GF_LOG[b]]


def sintomas(codeword, n_paridad, raiz_base=0):
    """Sindromes de un codeword RS sistematico.

    Para un codigo correcto TODOS deben salir 0. Es una comprobacion
    independiente del encoder: aqui no se usan ni las LUTs ni su formula.
    """
    out = []
    for j in range(n_paridad):
        alpha = _GF_EXP[(j + raiz_base) % 255]
        acc = 0
        for byte in codeword:
            acc = _mul(acc, alpha) ^ byte
        out.append(acc)
    return out


def valida_sector_pq(sector):
    """Comprueba P y Q recalculandolos. Devuelve (ok_p, ok_q)."""
    s = bytearray(sector)
    # P: el codeword son los 1032 B de datos P mas los 172 de paridad
    datos_p = bytes(s[12:12 + 1032])
    cw_p = datos_p + bytes(s[OFF_P:OFF_P + 172])
    ok_p = all(v == 0 for v in sintomas_range(cw_p, 86, 24))
    # Q: la paridad Q se calcula sobre el sector con P ya incluido
    datos_q = bytes(s[12:12 + 2236 - 12])
    cw_q = datos_q + bytes(s[OFF_Q:OFF_Q + 104])
    ok_q = all(v == 0 for v in sintomas_range(cw_q, 52, 43))
    return ok_p, ok_q


def sintomas_range(cw, major_count, minor_count):
    """Sindromes por bloque (misma estructura de interleave que la paridad).

    El interleave del estandar reparte los bytes en `major_count` bloques; cada
    bloque es un codigo RS independiente con `minor_count` bytes de paridad. Se
    calcula el sindrome de cada bloque y se devuelven todos.
    """
    size = major_count * minor_count
    n_par = minor_count
    # reconstruir los bloques: el byte en la posicion k del bloque i es
    # index = k*major_count + i  (eso es el interleave del estandar)
    res = []
    for i in range(major_count):
        blk = bytearray()
        for k in range(minor_count):
            idx = k * major_count + i
            if idx < len(cw):
                blk.append(cw[idx])
        # los ultimos `n_par` bytes del bloque son la paridad
        res += sintomas(bytes(blk), n_par)
    return res


# ------------------------------------------------------------------ fichero
def verifica_imagen(ruta, verbose=True):
    raw = open(ruta, 'rb').read()
    n = len(raw) // SECTOR
    malos = {'edc': [], 'p': [], 'q': [], 'bitwise': []}
    for k in range(n):
        s = raw[k * SECTOR:(k + 1) * SECTOR]
        e, P, Q = calcula_sector(s)
        if int.from_bytes(s[OFF_EDC:OFF_EDC + 4], 'little') != e:
            malos['edc'].append(k)
        if bytes(s[OFF_P:OFF_P + 172]) != P:
            malos['p'].append(k)
        if bytes(s[OFF_Q:OFF_Q + 104]) != Q:
            malos['q'].append(k)
        # contraste de las dos implementaciones de EDC sobre el sector 0..n
        if edc(s[:OFF_EDC]) != edc_bitwise(s[:OFF_EDC]):
            malos['bitwise'].append(k)
    if verbose:
        print('sectores: %d' % n)
        print('  EDC distinto del calculado : %d' % len(malos['edc']))
        print('  P distinta                 : %d' % len(malos['p']))
        print('  Q distinta                 : %d' % len(malos['q']))
        print('  EDC tabla != EDC bit a bit : %d  (si es >0, hay un bug en edc())'
              % len(malos['bitwise']))
    return malos


def repara_imagen(ruta, salida=None):
    raw = bytearray(open(ruta, 'rb').read())
    n = len(raw) // SECTOR
    for k in range(n):
        raw[k * SECTOR:(k + 1) * SECTOR] = repara_sector(raw[k * SECTOR:(k + 1) * SECTOR])
    dst = salida or ruta
    open(dst, 'wb').write(bytes(raw))
    return hashlib.md5(bytes(raw)).hexdigest()


def repara_bytes(raw):
    """Igual que repara_imagen pero sobre bytes ya en memoria (para el pipeline)."""
    raw = bytearray(raw)
    n = len(raw) // SECTOR
    for k in range(n):
        raw[k * SECTOR:(k + 1) * SECTOR] = repara_sector(raw[k * SECTOR:(k + 1) * SECTOR])
    return bytes(raw)


def autotest(ruta):
    """Validacion del encoder contra una propiedad independiente."""
    raw = open(ruta, 'rb').read()
    n = len(raw) // SECTOR
    print('=== AUTOTEST del encoder ECC sobre %d sectores ===' % n)
    print('(los sindromes de un codigo Reed-Solomon correcto son todos CERO)')
    mal_p = mal_q = 0
    for k in range(n):
        s = raw[k * SECTOR:(k + 1) * SECTOR]
        okp, okq = valida_sector_pq(s)
        mal_p += (not okp)
        mal_q += (not okq)
    print('  sectores con sindromes P != 0 : %d de %d' % (mal_p, n))
    print('  sectores con sindromes Q != 0 : %d de %d' % (mal_q, n))
    print('  => %s' % ('PASS: el encoder es coherente' if mal_p == 0 and mal_q == 0
                       else 'FALLO: el encoder NO es coherente'))
    # y el contraste de las dos implementaciones de EDC
    s0 = raw[:SECTOR]
    a, b = edc(s0[:OFF_EDC]), edc_bitwise(s0[:OFF_EDC])
    print('  EDC (tabla) vs EDC (bit a bit) en el sector 0: 0x%08X vs 0x%08X  %s'
          % (a, b, 'OK' if a == b else 'DISTINTOS'))


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(0)
    cmd, ruta = sys.argv[1], sys.argv[2]
    if cmd == 'autotest':
        autotest(ruta)
    elif cmd == 'repara':
        antes = hashlib.md5(open(ruta, 'rb').read()).hexdigest()
        nuevo = repara_imagen(ruta)
        print('%s reparado' % ruta)
        print('  MD5 antes: %s' % antes)
        print('  MD5 ahora: %s' % nuevo)
    elif cmd == 'partes':
        raw = open(ruta, 'rb').read()
        print('sectores: %d' % (len(raw) // SECTOR))
        s = raw[:SECTOR]
        print('  sync     : %s' % s[:12].hex(' '))
        print('  cabecera : %s  (MSF+modo)' % s[12:16].hex(' '))
        print('  EDC      : %s' % s[OFF_EDC:OFF_EDC + 4].hex(' '))
        print('  ceros    : %s' % s[OFF_EDC + 4:OFF_P].hex(' '))
        print('  P (172B) : %s...' % s[OFF_P:OFF_P + 8].hex(' '))
        print('  Q (104B) : %s...' % s[OFF_Q:OFF_Q + 8].hex(' '))
    else:
        print(__doc__)
