#!/usr/bin/env python3
"""parche_ventana.py - el ANCHO de la ventana flotante de personajes (los TRES sitios).

MEDIDO (22/09)
  La ventana de personajes la montan TRES rutinas distintas (misma firma: $26=1,
  $28=3, $18=0 y $2e = ancho):
      0x0C86A   ($4=7,  $6=0xE, $8=0x14)
      0x13590   ($4=0xA, $6=8,  $8=8)
      0x13672   ($4=0xA, $6=8,  $8=8)   <- la que usa el menu de MAGIA
  Parchear solo una deja las otras con el ancho viejo: por eso la ventana seguia
  estrecha al abrirla desde otros menus.
  ancho del marco = 12*$2e - 2 px.  Con $2e=5 son 58 px y el borde derecho (3 px)
  cae encima de la ultima letra de «Mei Hong» -> la muesca.
  Se pone $2e = 7 -> 82 px en los tres.

Uso: python3 parche_ventana.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
# $2e = largo del SELECTOR azul; $8 = ancho de la VENTANA (y del selector, van acoplados)
#   MEDIDO con la ventana abierta desde el menu Magia (setup $13640):
#     $8 = 8  -> ventana 76 px   (el original)
#     $8 = 9  -> 84 px
#     $8 = 10 -> 92 px   <- +1 celda de 12 px, lo que pide David
#   OJO: $2e NO hace nada en ese camino (solo en el del menu Estado).
SITIOS = ((0x13684, 'ancho'), (0x135A2, 'ancho'))   # solo las DOS de la ventana de personajes
SITIOS_2E = ((0x0C86A, ), (0x13590, ), (0x13672, ))
ANCHO_VENTANA = 10                         # 8*10+12 = 92 px (una celda menos que 100)
ANCHO = 6


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    for off, cual in SITIOS:
        w = st[off:off + 6]
        assert w[:2] == bytes.fromhex('317c') and w[4:6] == bytes.fromhex('0008'), \
            'en 0x%05X esperaba move.w #$n,$8(a0): %s' % (off, w.hex(' '))
        print('  0x%05X  $8 = %d -> %d  (ventana %d px)'
              % (off, int.from_bytes(w[2:4], 'big'), ANCHO_VENTANA, 8 * ANCHO_VENTANA + 12))
        st[off + 2:off + 4] = ANCHO_VENTANA.to_bytes(2, 'big')
    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
