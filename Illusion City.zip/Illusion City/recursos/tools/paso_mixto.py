#!/usr/bin/env python3
"""paso_mixto.py - PASO MIXTO (v2, 26/09): letras 8 px / digitos+espacios 12 px en el
menu de Velocidad. Sustituye a la version que discriminaba por el campo $2e.

REGLA
  1) Si el caracter se esta pintando desde el buffer de linea del menu de
     VELOCIDAD (a2 entre $15750 y $157C0; medido: a2 = $1577E):
        - ESPACIO ($8140) y DIGITOS ($824F-$8258) -> 12 px (no se encogen)
        - lo demas -> regla normal
  2) Regla normal: letras, signos y los 16 codigos de acento -> 8 px;
     kana/kanji -> 12 px.

POR QUE ASI (medido con el espia, no deducido)
  - El menu de Velocidad NO pinta sus lineas desde la plantilla de la PRG-RAM,
    sino desde un buffer de linea del motor ($1577E), y el descriptor que llega
    al pintor es $A4200, el MISMO que usan las filas del menu principal. Por eso
    discriminar por descriptor (o por $2e) era fragil: al final el criterio bueno
    es el puntero de cadena a2.
  - Los numeros 1-8 del menu tienen que ir en celdas de 12 px porque la flecha
    del valor la dibuja el motor en su rejilla de 12 px (medido: la flecha cae
    en la celda del 4).
  - Los espacios tienen que ir a 12 px EN ESTE MENU para que la fila de numeros
    caiga en la rejilla del motor (7 espacios x 12 = 84 px).
  - La caja del DINERO se pinta desde otro buffer ($BB24) -> regla normal: todo
    a 8 px (que es lo que David aprobo).
"""
import hashlib, importlib.util, os, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI); PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('p', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

CAP1_RAM = 0x2513C
CAP2_RAM = 0x25200
GLIFO    = 0x18B18
VUELTA1  = 0x18392
VUELTA2  = 0x18A88
LLAMADA1 = 0x840E
LLAMADA2 = 0x8A80
# Codigos que se pintan a 8 px aunque su numero sea >= $829F: los 16 acentos
# (slots de kanji secuestrados) y el ICONO de los rotulos (0x965F, celda 1349).
ACENTOS = [0x95FB, 0x9660, 0x966B, 0x967B, 0x9682, 0x96AF, 0x96B3, 0x96BD,
           0x96C5, 0x96DA, 0x9744, 0x9755, 0x975C, 0x975F, 0x976C, 0x9770,
           0x965F]
# El menu de Velocidad se pinta desde DOS sitios distintos (medido 26/09):
#   - la primera vez, desde el buffer de linea del motor: a2 = $1577E
#   - al volver a entrar (p.ej. despues de pasar por el menu スイッチ), desde una
#     COPIA DE TRABAJO de la plantilla: a2 = $244B2  (si no se contempla, los
#     espacios y los digitos se encogen y el menu se descuadra).
BUF_VEL_LO = 0x00015750
BUF_VEL_HI = 0x000157C0
COPIA_VEL_LO = 0x00024490
COPIA_VEL_HI = 0x00024570

SALVA    = bytes.fromhex('2f01') + bytes.fromhex('2f0b')     # move.l d1,-(a7) ; move.l a3,-(a7)
RESTAURA = bytes.fromhex('265f') + bytes.fromhex('221f')     # move.l (a7)+,a3 ; move.l (a7)+,d1
ESTRECHO = bytes.fromhex('53680014')                         # subq.w #1,$14(a0)


def captura(ram, vuelta, con_wrap):
    b = bytearray(); saltos = []
    b += SALVA
    b += bytes.fromhex('4eb9') + GLIFO.to_bytes(4, 'big')        # jsr pintor
    # --- 1) ¿ estamos en el menu de VELOCIDAD ?
    #     MEDIDO (48ª tanda): el juego COPIA la linea del menu a un buffer de trabajo
    #     cuya direccion CAMBIA segun la partida: $1577E (1ª vez), $244B2 (al volver a
    #     entrar) y $5DEBA (desde una partida normal, state de David). Mirar direcciones
    #     no sirve. El criterio estable es el ANCHO del descriptor: el menu de Velocidad
    #     usa $08=26 (208 px) y el resto ($08=8 menu, 20 dinero, 31 dialogo) no.
    #     Asi que: si $08(a0) == 26 -> espacios y digitos a 12 px.
    b += bytes.fromhex('0c68001a0008')                            # cmpi.w #$1a,$8(a0)
    b += bytes.fromhex('6700'); saltos.append((len(b), 'vel')); b += b'\x00\x00'
    # --- y ademas, por si acaso, las dos direcciones conocidas ---
    b += bytes.fromhex('220a')                                    # move.l a2,d1
    b += bytes.fromhex('0c81') + BUF_VEL_LO.to_bytes(4, 'big')    # cmpi.l #$15750,d1
    b += bytes.fromhex('6500'); saltos.append((len(b), 'dos')); b += b'\x00\x00'
    b += bytes.fromhex('0c81') + BUF_VEL_HI.to_bytes(4, 'big')    # cmpi.l #$157C0,d1
    b += bytes.fromhex('6d00'); saltos.append((len(b), 'vel')); b += b'\x00\x00'
    # (si no esta en el primer rango, se sigue de largo a mirar el segundo)
    # --- segunda via: la copia de trabajo de la plantilla ---
    etq_dos = len(b)
    b += bytes.fromhex('0c81') + COPIA_VEL_LO.to_bytes(4, 'big')  # cmpi.l #$24490,d1
    b += bytes.fromhex('6500'); saltos.append((len(b), 'regla')); b += b'\x00\x00'
    b += bytes.fromhex('0c81') + COPIA_VEL_HI.to_bytes(4, 'big')  # cmpi.l #$24570,d1
    b += bytes.fromhex('6400'); saltos.append((len(b), 'regla')); b += b'\x00\x00'
    # --- es el menu de Velocidad: espacio y digitos se quedan a 12 px ---
    b += bytes.fromhex('0c408140')                                # cmpi.w #$8140,d0
    b += bytes.fromhex('6700'); saltos.append((len(b), 'ancho')); b += b'\x00\x00'
    b += bytes.fromhex('0c40824f')                                # cmpi.w #$824f,d0
    b += bytes.fromhex('6500'); saltos.append((len(b), 'regla')); b += b'\x00\x00'
    b += bytes.fromhex('0c408258')                                # cmpi.w #$8258,d0
    b += bytes.fromhex('6f00'); saltos.append((len(b), 'ancho')); b += b'\x00\x00'
    # --- 2) regla normal: ¿codigo < $829F? -> 8 px ---
    b += bytes.fromhex('0c40829f')
    b += bytes.fromhex('6d00'); saltos.append((len(b), 'estrecho')); b += b'\x00\x00'
    b += bytes.fromhex('47fa'); saltos.append((len(b), 'tabla')); b += b'\x00\x00'
    etq_bucle = len(b)
    b += bytes.fromhex('321b')                                    # move.w (a3)+,d1
    b += bytes.fromhex('b041')                                    # cmp.w d1,d0
    b += bytes.fromhex('6700'); saltos.append((len(b), 'estrecho')); b += b'\x00\x00'
    b += bytes.fromhex('0c41ffff')
    b += bytes.fromhex('6600'); saltos.append((len(b), 'bucle')); b += b'\x00\x00'
    etq_ancho = len(b)
    b += RESTAURA
    if con_wrap:
        b += bytes.fromhex('30280008')
    b += bytes.fromhex('4ef9') + vuelta.to_bytes(4, 'big')
    etq_estrecho = len(b)
    b += ESTRECHO
    b += RESTAURA
    if con_wrap:
        b += bytes.fromhex('30280008')
    b += bytes.fromhex('4ef9') + vuelta.to_bytes(4, 'big')
    etq_tabla = len(b)
    for c in ACENTOS:
        b += c.to_bytes(2, 'big')
    b += bytes.fromhex('ffff')
    etq = {'tabla': etq_tabla, 'bucle': etq_bucle, 'estrecho': etq_estrecho,
           'ancho': etq_ancho, 'dos': etq_dos}
    # 'vel' = empieza la comprobacion de espacio/digitos del menu de Velocidad
    # 'regla' = la comprobacion normal de $829F
    etq['vel'] = b.find(bytes.fromhex('0c408140'))
    etq['regla'] = b.find(bytes.fromhex('0c40829f'))
    assert etq['vel'] > 0 and etq['regla'] > etq['vel'], (etq['vel'], etq['regla'])
    for pos, nombre in saltos:
        destino = etq[nombre]
        assert destino is not None, nombre
        b[pos:pos + 2] = ((destino - pos) & 0xFFFF).to_bytes(2, 'big')
    return bytes(b), etq


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual
    n = len(buf); buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    C1, e1 = captura(CAP1_RAM, VUELTA1, False)
    C2, e2 = captura(CAP2_RAM, VUELTA2, True)
    for ram, data, nom in ((CAP1_RAM, C1, 'cap1'), (CAP2_RAM, C2, 'cap2')):
        off = ram - 0x10000
        assert st[off:off + len(data)] == b'\xff' * len(data), '%s: zona no libre' % nom
        pon(st, off, data, nom)
    for sitio, cap, nom in ((LLAMADA1, CAP1_RAM, 'llamada 1'), (LLAMADA2, CAP2_RAM, 'llamada 2')):
        pon(st, sitio, bytes.fromhex('4ef9') + cap.to_bytes(4, 'big'), nom)
    m.escribe_region(raw, m.LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('cap1 %d B en $%X | cap2 %d B en $%X' % (len(C1), CAP1_RAM, len(C2), CAP2_RAM))
    print('MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
