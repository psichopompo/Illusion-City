#!/usr/bin/env python3
"""Identify GFONT.BIN glyphs by matching against TTF-rendered reference bitmaps."""
from PIL import Image, ImageFont, ImageDraw
import os, json
from collections import Counter

GLYPH = 18

def parse_glyph(d, idx):
    tile = d[idx*GLYPH:(idx+1)*GLYPH]
    bits = ''.join(f'{b:08b}' for b in tile)
    return [[1 if bits[y*12+x] == '1' else 0 for x in range(12)] for y in range(12)]

def render_ref(ch, font):
    img = Image.new('L', (24, 24), 0)
    dr = ImageDraw.Draw(img)
    dr.text((2, -3), ch, fill=255, font=font)
    # downsample to 12x12 by threshold
    small = img.resize((12, 12), Image.LANCZOS)
    px = small.load()
    return [[1 if px[x, y] > 100 else 0 for x in range(12)] for y in range(12)]

def score(a, b):
    # weighted: penalize mismatched on-pixels heavily
    s = 0
    for y in range(12):
        for x in range(12):
            if a[y][x] and b[y][x]: s += 2
            elif a[y][x] != b[y][x]: s -= 1
    return s

def main():
    d = open('extraidos/GFONT.BIN', 'rb').read()
    n = len(d)//GLYPH
    # Candidate chars: all unique chars from game text (2-byte SJIS) + ASCII + space
    chars = Counter()
    for f in sorted(os.listdir('extraidos')):
        if not f.upper().endswith(('.BIN','.DAT')): continue
        t = open(f'extraidos/{f}','rb').read()
        i = 0
        while i < len(t)-1:
            b = t[i]
            if (0x81 <= b <= 0x9F or 0xE0 <= b <= 0xEF) and (0x40 <= t[i+1] <= 0xFC):
                try: chars[bytes(t[i:i+2]).decode('shift_jis')] += 1
                except: pass
                i += 2
            else: i += 1
    cand = [' '] + [chr(c) for c in range(0x20, 0x7F)] + sorted(chars)
    print("candidates:", len(cand))
    font = ImageFont.truetype('/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc', 14)
    refs = {}
    for ch in cand:
        try:
            refs[ch] = render_ref(ch, font)
        except Exception:
            pass
    mapping = {}
    for g in range(n):
        bm = parse_glyph(d, g)
        if not any(any(r) for r in bm):
            mapping[g] = ' '
            continue
        best, bs = None, -10**9
        for ch, rb in refs.items():
            s = score(bm, rb)
            if s > bs:
                bs, best = s, ch
        mapping[g] = best
    json.dump(mapping, open('font_map.json','w', encoding='utf-8'), ensure_ascii=False, indent=0)
    # summary
    inv = {v: k for k, v in mapping.items()}
    print("identified:", len(set(mapping.values())), "of", n)
    print(''.join(mapping.get(g, '?') for g in range(n)))

main()
