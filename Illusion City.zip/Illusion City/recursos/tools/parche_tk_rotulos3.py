#!/usr/bin/env python3
"""parche_tk_rotulos3.py - TECNICAS: maqueta de David + ventana ensanchada.

Base: TEST_BL. La ventana de Técnicas mide 22 celdas ($8=0x16) y la maqueta de
David necesita 34: se ensancha a $8=34 y el buffer de dibujo se mueve de $a6000
(area de ventanas, 16 KB) a $b0000 (Word RAM alta, 88 KB hasta $c0000).
Cambios:
  1. Descriptor de la ventana: $8: 0x16 -> 0x22 (34 celdas), $1e: $a6000 -> $b0000.
  2. Rótulos reescritos con las palabras en las celdas de la maqueta
     (ARMA/RIFLE/OBÚS/CAÑÓN y GARRA/VARA/ESP./HILO en 11, 18, 25, 32).
  3. Las filas de valores (BL off 76 y 284) se mud a un hueco libre con sus refs
     actualizadas.
Uso: python3 parche_tk_rotulos3.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'
HUECO = 0x155CE

AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD}

def fw(ch):
    if ch in AC:
        return AC[ch].to_bytes(2, 'big')
    if 'A' <= ch <= 'Z':
        return bytes([0x82, 0x60 + ord(ch) - 65])
    if ch == '.':
        return b'\x81\x42'
    raise SystemExit(ch)

def fwa(t):
    out = bytearray()
    for ch in t:
        out += ESP if ch == ' ' else fw(ch)
    return bytes(out)

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    base = T0 + 0x10000

    # ---- 1. descriptor de la ventana ($8 y $1e) ----
    # $8: move.w #$16,$8(a0) en 0x12FA2 => cambiar 16 -> 22 (0x22)
    assert st[0x12FA2:0x12FA8] == bytes.fromhex('317c00160008'), st[0x12FA2:0x12FA8].hex(' ')
    st[0x12FA5] = 0x22
    # $1e: move.l #$a6000,$1e(a0) en 0x12FB4 => cambiar a $b0000
    assert st[0x12FB4:0x12FBC] == bytes.fromhex('217c000a6000001e'), st[0x12FB4:0x12FBC].hex(' ')
    st[0x12FB8:0x12FBC] = (0x0B0000).to_bytes(4, 'big')
    print('  ventana: $8 = 34 celdas, buffer -> $b0000')

    # ---- 2. mudar las filas de valores al hueco y actualizar refs ----
    val1 = bytes(st[T0+76:T0+76+54])
    val2 = bytes(st[T0+284:T0+284+54])
    assert val1[:2] == b'\x26\x34' and val2[:2] == b'\x26\x34'
    assert st[HUECO:HUECO+110] == b'\xff' * 110, 'hueco no libre'
    st[HUECO:HUECO+54] = val1
    st[HUECO+54:HUECO+108] = val2
    NV1, NV2 = HUECO, HUECO + 54

    def remap(v):
        off = v - base
        if 76 <= off < 130:  return NV1 + (off - 76)
        if 284 <= off < 338: return NV2 + (off - 284)
        return None

    n = 0
    for k in range(4, len(st)-4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        nv = remap(v)
        if nv is not None and k % 2 == 0:
            st[k:k+4] = nv.to_bytes(4, 'big')
            n += 1
    print('  refs de valores actualizadas: %d' % n)

    # ---- 3. rótulos nuevos in-situ (ya hay hueco: las filas se fueron) ----
    fila1 = bytearray(bytes.fromhex('2635') + ESP*36)
    fila1[2+11*2:2+15*2] = fwa('ARMA')
    fila1[2+18*2:2+23*2] = fwa('RIFLE')
    fila1[2+25*2:2+29*2] = fwa('OBÚS')
    fila1[2+32*2:2+37*2] = fwa('CAÑÓN')
    fila1 += b'\x2f\x6e'
    fila2 = bytearray(bytes.fromhex('2635') + ESP*36)
    fila2[2+11*2:2+15*2] = fwa('GARRA')
    fila2[2+18*2:2+21*2] = fwa('VARA')
    fila2[2+25*2:2+28*2] = fwa('ESP.')
    fila2[2+32*2:2+36*2] = fwa('HILO')
    fila2 += b'\x2f\x6e'
    # rótulo1: cabía 30..75 (46 B); ahora 76 B: usa 30..105 y libera 106..129
    st[T0+30:T0+30+len(fila1)] = fila1
    st[T0+30+len(fila1):T0+130] = b'\xff' * (130 - 30 - len(fila1))
    # rótulo2: 240..283 (44 B) => 240..313, libera 314..337
    st[T0+240:T0+240+len(fila2)] = fila2
    st[T0+240+len(fila2):T0+284] = b'\xff' * (284 - 240 - len(fila2))
    print('  rótulos escritos con palabras en celdas 11/18/25/32 (11/18/25/32)')

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
