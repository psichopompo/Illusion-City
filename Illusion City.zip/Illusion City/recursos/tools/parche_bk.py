#!/usr/bin/env python3
"""parche_bk.py - SOLO lo pedido (base BH):
   1. Menu Objetos (interior): "Objetos" -> "OBJETOS" (in-place, misma longitud)
   2. Columnas de Cambiar y Tirar: un espacio a la izquierda (18->17, 33->32)
Uso: python3 parche_bk.py <entrada.bin> <salida.bin>
"""
import hashlib, importlib.util, os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
ESP = b'\x81\x40'

def fw(s):
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z': out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z': out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ': out += ESP
        else: raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    # 1) ObjetoS -> OBJETOS: la cadena del menu, tras el rombo y la marca amarilla
    firma = bytes.fromhex('965f2634') + fw('Objetos')
    i = st.find(firma)
    assert i > 0, 'no encuentro la cadena de Objetos'
    st[i+4:i+18] = fw('OBJETOS')
    print('  OBJETOS: "Objetos" -> "OBJETOS" en 0x%05X (in-place)' % (i+4))
    # 2) columnas: Cambiar 18->17, Tirar 33->32
    assert st[0x12358:0x1235E] == bytes.fromhex('317c00120034')
    assert st[0x1235E:0x12364] == bytes.fromhex('317c00210036')
    st[0x1235B] = 0x11
    st[0x12361] = 0x20
    print('  OBJETOS: Cambiar 18->17, Tirar 33->32')
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
