#!/usr/bin/env python3
"""verifica_bin.py - comprobacion COMPLETA de un [CAST].bin (2352 B/sector).

No depende de ningun otro fichero del proyecto: se lo traga todo del propio .bin.

Que comprueba
-------------
 1. Estructura: tamaño multiplo de 2352, sync (00 FF*10 00), modo 1 y
    direccion MSF (BCD, LBA+150 = 00:02:00) en los 7842 sectores.
 2. EDC de cada sector: CRC-32 con polinomio 0xD8018001 sobre los 2064 B
    (sync+cabecera+datos) contra el valor guardado (u32 LE en +2064).
 3. ECC P y Q de cada sector (172 B en +2076 y 104 B en +2248), calculadas
    con la cabecera a cero sobre los bytes a partir del offset 12.
    OJO: la paridad se calcula con la cabecera a cero (medido en el proyecto
    del Wonder Boy, el algoritmo no reproduce el original de otra forma).
 4. Marcadores del build: MD5 del START.BIN (LBA 59) y los bytes del arreglo.

Uso
---
    python3 tools/verifica_bin.py "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"
    python3 tools/verifica_bin.py FICHERO.bin --repara    # reescribe EDC/ECC
                                                         # (no toca los datos)
"""
import hashlib
import importlib.util
import os
import sys

# una sola implementacion de EDC/ECC en el proyecto: edcecc.py
_spec = importlib.util.spec_from_file_location(
    'edcecc', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'edcecc.py'))
edcecc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(edcecc)

SECTOR = 2352
N_SECTORES_ESPERADOS = 7842
LBA_START = 59
SZ_START = 98184
OFF_FIX_ANCHURA = 0x11B55          # $08 del descriptor del menu ($A423A)
OFF_FIX_CODIGO = 0x721C            # tabla: 3 entradas restauradas al build bueno
TABLA_BUENA = bytes.fromhex('0bea00002a7200010bea0001')

# ------------------------------------------------------------------ tablas
def _luts():
    f = [0] * 256
    b = [0] * 256
    for i in range(256):
        j = (i << 1) ^ (0x11D if i & 0x80 else 0)
        f[i] = j & 0xFF
        b[(i ^ j) & 0xFF] = i
    return f, b


F_LUT, B_LUT = _luts()

EDC_TABLA = []
for i in range(256):
    e = i
    for _ in range(8):
        e = (e >> 1) ^ (0xD8018001 if e & 1 else 0)
    EDC_TABLA.append(e & 0xFFFFFFFF)


def edc(datos):
    e = 0
    for byte in datos:
        e = (e >> 8) ^ EDC_TABLA[(e ^ byte) & 0xFF]
    return e & 0xFFFFFFFF


def _ecc(src, major_count, minor_count, major_mult, minor_inc, dest_off, base=12):
    size = major_count * minor_count
    out = bytearray(major_count * 2)
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        a = bb = 0
        for _ in range(minor_count):
            t = src[base + index]
            index += minor_inc
            if index >= size:
                index -= size
            a ^= t
            bb ^= t
            a = F_LUT[a]
        a = B_LUT[F_LUT[a] ^ bb]
        out[major] = a
        out[major + major_count] = a ^ bb
    return bytes(out)


def extrae_region(raw, lba, size):
    out = bytearray()
    for k in range((size + 2047) // 2048):
        out += raw[(lba + k) * SECTOR + 16:(lba + k) * SECTOR + 16 + 2048]
    return bytes(out[:size])


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    ruta = sys.argv[1]
    repara = '--repara' in sys.argv
    raw = bytearray(open(ruta, 'rb').read())
    print('fichero: %s' % ruta)
    print('tamaño : %d B = %d sectores de %d  (esperado %d)'
          % (len(raw), len(raw) // SECTOR, SECTOR, N_SECTORES_ESPERADOS))
    if len(raw) % SECTOR:
        print('  !! el tamaño no es multiplo de 2352')
        return
    n = len(raw) // SECTOR

    # ---- 1. estructura -------------------------------------------------
    mal_sync = []
    mal_msf = []
    mal_modo = []
    for k in range(n):
        s = raw[k * SECTOR:(k + 1) * SECTOR]
        if s[:12] != bytes([0] + [0xFF] * 10 + [0]):
            mal_sync.append(k)
        if s[15] != 1:
            mal_modo.append(k)
        msf = k + 150
        m, resto = divmod(msf, 60 * 75)
        seg, fr = divmod(resto, 75)
        esperado = bytes([((m // 10) << 4) | (m % 10), ((seg // 10) << 4) | (seg % 10),
                          ((fr // 10) << 4) | (fr % 10)])
        if s[12:15] != esperado:
            mal_msf.append(k)
    print()
    print('1) ESTRUCTURA')
    print('   sync mal:  %d sectores %s' % (len(mal_sync), mal_sync[:5]))
    print('   modo != 1: %d sectores %s' % (len(mal_modo), mal_modo[:5]))
    print('   MSF mal:   %d sectores %s' % (len(mal_msf), mal_msf[:5]))

    # ---- 2 y 3. EDC y ECC (con edcecc.py: implementacion unica del proyecto) ----
    mal_edc = []
    mal_p = []
    mal_q = []
    for k in range(n):
        s = raw[k * SECTOR:(k + 1) * SECTOR]
        e, P, Q = edcecc.calcula_sector(s)
        if int.from_bytes(s[edcecc.OFF_EDC:edcecc.OFF_EDC + 4], 'little') != e:
            mal_edc.append(k)
        if bytes(s[edcecc.OFF_P:edcecc.OFF_P + 172]) != P:
            mal_p.append(k)
        if bytes(s[edcecc.OFF_Q:edcecc.OFF_Q + 104]) != Q:
            mal_q.append(k)
    print()
    print('2) EDC (CRC-32 de los 2064 B de cada sector)')
    ceros_edc = sum(1 for k in range(n)
                    if all(b == 0 for b in raw[k * SECTOR + 2064:k * SECTOR + 2068]))
    print('   sectores con el campo EDC a CERO: %d de %d' % (ceros_edc, n))
    print('   sectores con EDC incorrecto     : %d de %d  %s' % (len(mal_edc), n, mal_edc[:8]))
    print()
    print('3) ECC (paridad Reed-Solomon P y Q, Mode 1 con la cabecera incluida)')
    print('   sectores con P incorrecta: %d de %d  %s' % (len(mal_p), n, mal_p[:8]))
    print('   sectores con Q incorrecta: %d de %d  %s' % (len(mal_q), n, mal_q[:8]))
    if not (mal_edc or mal_p or mal_q):
        print('   -> correctos. Para validacion independiente, ver')
        print('      recursos/terceros/ecc_ref/ (implementacion de referencia de')
        print('      Neill Corlett) y vectores_referencia.json.')

    # ---- 4. marcadores del build ---------------------------------------
    st = extrae_region(raw, LBA_START, SZ_START)
    print()
    print('4) MARCADORES DEL BUILD')
    print('   START.BIN (LBA %d) MD5 %s' % (LBA_START, hashlib.md5(st).hexdigest()))
    print('   $08 del descriptor $A423A  file 0x%X = $%02X  %s'
          % (OFF_FIX_ANCHURA, st[OFF_FIX_ANCHURA],
             'OK (0x1C, cambio consolidado del build bueno; el original japones tiene 0x1A)'
             if st[OFF_FIX_ANCHURA] == 0x1C else 'OJO'))
    tabla = st[OFF_FIX_CODIGO:OFF_FIX_CODIGO + len(TABLA_BUENA)]
    print('   tabla 0x%X = %s' % (OFF_FIX_CODIGO, tabla.hex(' ')))
    print('     esperado   %s  %s' % (TABLA_BUENA.hex(' '),
          'OK (fix del build bueno presente)' if tabla == TABLA_BUENA else 'OJO'))
    import struct
    print('   tabla del menu (0x13D12):')
    for k in range(6):
        ptr = struct.unpack('>I', st[0x13D12 + k * 4:0x13D16 + k * 4])[0]
        off = ptr - 0x10000
        fin = st.find(b'\x00', off)
        print('     fila %d -> $%X  %r' % (k + 1, ptr, st[off:fin].decode('shift_jis', 'replace')))

    # ---- reparacion (opcional) -----------------------------------------
    if repara and (mal_edc or mal_p or mal_q):
        print()
        print('REPARANDO (solo EDC/ECC; los datos no se tocan)')
        for k in range(n):
            s = bytearray(raw[k * SECTOR:(k + 1) * SECTOR])
            s[2064:2068] = edc(s[:2064]).to_bytes(4, 'little')
            cab = bytes(s[12:16])
            s[12:16] = bytes(4)
            s[2076:2248] = _ecc(s, 86, 24, 2, 86, 2076)
            s[2248:2352] = _ecc(s, 52, 43, 86, 88, 2248)
            s[12:16] = cab
            raw[k * SECTOR:(k + 1) * SECTOR] = s
        open(ruta, 'wb').write(bytes(raw))
        print('   escrito %s' % ruta)
        print('   MD5 nuevo: %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    main()
