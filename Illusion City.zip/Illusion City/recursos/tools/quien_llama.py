#!/usr/bin/env python3
"""quien_llama.py - busca QUIEN llama/usa una direccion de RAM en START.BIN.

Uso:  python3 quien_llama.py 0x239A2 [rango=0x40] [fichero]

Busca:
  - saltos relativos de 16 bits (bra/bsr/bcc/jsr-d16pc) cuyo destino caiga en el rango
  - valores absolutos de 4 bytes ($0000xxxx/$0002xxxx) dentro del rango
Imprime el offset de fichero (y la direccion de RAM = offset + 0x10000).
"""
import importlib.util, os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

BASE = 0x10000


def analiza(d, obj, rango):
    out = []
    for i in range(len(d) - 6):
        op = int.from_bytes(d[i:i + 2], 'big')
        if 0x6000 <= op < 0x7000 and (op & 0xff) == 0x00:            # bra/bsr/bcc .w
            dest = BASE + i + 2 + int.from_bytes(d[i + 2:i + 4], 'big', signed=True)
            if abs(dest - obj) <= rango:
                out.append((i, 'salto .w  -> $%05X' % dest))
        if op in (0x4ef9, 0x4eb9) or (op & 0xffc0) == 0x4ec0:        # jmp/jsr abs.l
            dest = int.from_bytes(d[i + 2:i + 6], 'big')
            if abs(dest - obj) <= rango:
                out.append((i, 'jmp/jsr .l -> $%05X' % dest))
        val = int.from_bytes(d[i:i + 4], 'big')
        if abs(val - obj) <= rango and val > 0x10000:
            out.append((i, 'long $%06X' % val))
    return out


if __name__ == '__main__':
    obj = int(sys.argv[1], 0)
    rango = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x40
    print('buscando referencias a $%05X (+-%d)' % (obj, rango))
    for nombre, lba, size in (('START', 59, 98184), ('SSTART', 43, 32644)):
        raw = open(m.BASE, 'rb').read()
        d = m.region(raw, lba, size)
        for off, txt in sorted(analiza(d, obj, rango)):
            print('  %-6s 0x%05X (RAM $%05X)  %s' % (nombre, off, BASE + off, txt))
