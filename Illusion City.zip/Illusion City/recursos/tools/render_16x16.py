#!/usr/bin/env python3
"""Render region as 16x16 1bpp glyphs (2 bytes/row, 32 bytes/glyph)."""
import sys
from PIL import Image

path, off, nglyphs, out = sys.argv[1], int(sys.argv[2],0), int(sys.argv[3]), sys.argv[4]
data = open(path,'rb').read()
cols = 8
rows = (nglyphs + cols - 1) // cols
scale = 2
img = Image.new('L', (cols*16*scale, rows*16*scale), 0)
px = img.load()
for g in range(nglyphs):
    tile = data[off + g*32 : off + g*32 + 32]
    if len(tile) < 32: break
    gx, gy = (g % cols)*16*scale, (g // cols)*16*scale
    for y in range(16):
        b0, b1 = tile[y*2], tile[y*2+1]
        for x in range(16):
            bit = 15 - x
            v = ((b0 << 8) | b1) >> bit & 1
            if v:
                for sy in range(scale):
                    for sx in range(scale):
                        px[gx + x*scale + sx, gy + y*scale + sy] = 255
img.save(out)
print("saved", out)
