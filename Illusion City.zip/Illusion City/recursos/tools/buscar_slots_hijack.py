#!/usr/bin/env python3
"""Localiza los slots REALES de los kanji secuestrados en GFONT.BIN.

Evidencia: el motor muestra 冒 para el codigo 0x9660 (nuestra 'a' aguda),
luego el slot del glifo 冒 en GFONT.BIN es el slot que el motor usa para
ese codigo. Buscamos por matching de pixeles los 16 kanji objetivo
(方北本魔民無命滅目冒優誘予誉様用) y validamos que queden en orden SJIS
ascendente.
"""
from PIL import Image, ImageFont, ImageDraw
import json

GLYPH = 18

TARGETS = ['方', '北', '本', '魔', '民', '無', '命', '滅', '目',
           '冒', '優', '誘', '予', '誉', '様', '用']


def parse_glyph(d, idx):
    tile = d[idx*GLYPH:(idx+1)*GLYPH]
    bits = ''.join(f'{b:08b}' for b in tile)
    return [[1 if bits[y*12+x] == '1' else 0 for x in range(12)] for y in range(12)]


def render_ref(ch, font):
    img = Image.new('L', (24, 24), 0)
    dr = ImageDraw.Draw(img)
    dr.text((2, -3), ch, fill=255, font=font)
    small = img.resize((12, 12), Image.LANCZOS)
    px = small.load()
    return [[1 if px[x, y] > 100 else 0 for x in range(12)] for y in range(12)]


def score(a, b):
    s = 0
    for y in range(12):
        for x in range(12):
            if a[y][x] and b[y][x]:
                s += 2
            elif a[y][x] != b[y][x]:
                s -= 1
    return s


def main():
    d = open('extraidos/GFONT.BIN', 'rb').read()
    n = len(d) // GLYPH
    font = ImageFont.truetype('/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc', 14)
    refs = {ch: render_ref(ch, font) for ch in TARGETS}

    # match solo contra los 16 objetivo
    found = {}
    for g in range(n):
        bm = parse_glyph(d, g)
        if sum(sum(r) for r in bm) < 10:
            continue
        best, bs = None, -10**9
        second = -10**9
        for ch, rb in refs.items():
            s = score(bm, rb)
            if s > bs:
                second = bs
                bs, best = s, ch
            elif s > second:
                second = s
        # margen: el mejor debe superar claramente al segundo
        if best and bs >= 60 and bs - second >= 8:
            if best not in found or bs > found[best][1]:
                found[best] = (g, bs)

    print('matches (kanji -> slot, score):')
    for ch in TARGETS:
        if ch in found:
            g, s = found[ch]
            print(f'  {ch}: slot {g} (score {s})')
        else:
            print(f'  {ch}: NO ENCONTRADO')

    # validar orden SJIS ascendente
    order = []
    ok = True
    prev = -1
    for ch in TARGETS:
        if ch in found:
            g = found[ch][0]
            order.append((ch, g))
            if g < prev:
                ok = False
            prev = g
    print('orden SJIS ascendente:', 'OK' if ok else 'VIOLADO')
    print('secuencia slots:', [g for _, g in order])

    json.dump({ch: found[ch][0] for ch in found},
              open('analisis/hijack_slots.json', 'w'), ensure_ascii=False)
    print('guardado analisis/hijack_slots.json')


if __name__ == '__main__':
    main()
