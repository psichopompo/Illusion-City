#!/usr/bin/env python3
"""parche_tk_rotulos2.py - TECNICAS: rótulos en las columnas de los valores.

Base: TEST_BL (o BN). Los rótulos ARMA/RIFLE/OBÚS/CAÑÓN y GARRA/VARA/ESP./HILO
se reescriben DENTRO de la plantilla (tienen que vivir en ella: el render copia
la plantilla entera al abrir la ventana) con las palabras en las columnas de los
campos de valor (v1@10, v2@14, v3@18, v4@22). Como los rótulos crecen (+26 B
cada uno), las filas de valores que iban detrás se MUDAN al hueco libre
(0x155CE) y sus referencias (blanker + campos) se actualizan.

Filas afectadas (BL): rótulo1 30..75 (46 B), valores1 76..129 (54 B),
rótulo2 240..283 (44 B), valores2 284..337 (54 B).

Uso: python3 parche_tk_rotulos2.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'
HUECO = 0x155CE

AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD}

def fw(ch):
    if ch in AC:
        return AC[ch].to_bytes(2, 'big')
    if 'A' <= ch <= 'Z':
        return bytes([0x82, 0x60 + ord(ch) - 65])
    if ch == '.':
        return b'\x81\x42'
    raise SystemExit(ch)

def fwa(t):
    out = bytearray()
    for ch in t:
        out += ESP if ch == ' ' else fw(ch)
    return bytes(out)

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    base = T0 + 0x10000

    # 1) mudar las dos filas de valores al hueco (mismo contenido, terminador incl.)
    val1 = bytes(st[T0+76:T0+76+54])
    val2 = bytes(st[T0+284:T0+284+54])
    assert val1[:2] == b'\x26\x34' and val2[:2] == b'\x26\x34'
    assert st[HUECO:HUECO+110] == b'\xff' * 110, 'hueco no libre'
    st[HUECO:HUECO+54] = val1
    st[HUECO+54:HUECO+108] = val2
    NV1 = HUECO            # file offset nuevo de valores1
    NV2 = HUECO + 54
    print('  filas de valores mudadas a 0x%05X y 0x%05X' % (NV1, NV2))

    # 2) actualizar las refs de esas filas (blanker off 78/132... y campos)
    def remap(v):
        off = v - base
        if 76 <= off < 76+54:  return NV1 + (off - 76)
        if 284 <= off < 284+54: return NV2 + (off - 284)
        return None
    n = 0
    for k in range(4, len(st)-4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        nv = remap(v)
        if nv is not None and k % 2 == 0:
            st[k:k+4] = nv.to_bytes(4, 'big')
            n += 1
    print('  refs de valores actualizadas: %d' % n)

    # 3) escribir los rótulos nuevos IN-SITU (la zona queda libre tras mudar)
    # rotulo1: off 30..75 (46 B). Nuevo: 2635 + texto hasta celda 33 + 2f6e:
    #   celdas: 1-9 libre, ARMA@10-13, esp 14-15, RIFLE@16-20, esp 21-22,
    #   OBÚS@23-26, esp 27-28, CAÑÓN@29-33, 2f6e en 34-35
    #   => necesita 36 celdas = 72 B + 2635 = 74 B > 46 B DISPONIBLE (30..75 = 46)
    # PERO detrás (76..129) ya está libre (la fila de valores se mudó): puedo
    # crecer hasta off 75 + lo que quiera: la zona 76..129 está vacía ahora.
    # rótulo1 nuevo: 30..75+30 = usaré 30..105 (76 B), resto a 0xFF:
    fila1 = bytearray(bytes.fromhex('2635') + ESP*36)
    fila1[2+10*2:2+14*2] = fwa('ARMA')
    fila1[2+16*2:2+21*2] = fwa('RIFLE')
    fila1[2+23*2:2+27*2] = fwa('OBÚS')
    fila1[2+29*2:2+34*2] = fwa('CAÑÓN')
    fila1 += b'\x2f\x6e'
    # rotulo2: off 240..283 (44 B) + detrás 284..337 libre (54 B mudada) => 98 B:
    fila2 = bytearray(bytes.fromhex('2635') + ESP*36)
    fila2[2+10*2:2+14*2] = fwa('GARRA')
    fila2[2+16*2:2+20*2] = fwa('VARA')
    fila2[2+23*2:2+26*2] = fwa('ESP.')
    fila2[2+29*2:2+33*2] = fwa('HILO')
    fila2 += b'\x2f\x6e'
    st[T0+30:T0+30+len(fila1)] = fila1
    st[T0+30+len(fila1):T0+30+len(fila1)+30] = b'\xff' * 30
    st[T0+240:T0+240+len(fila2)] = fila2
    st[T0+240+len(fila2):T0+240+len(fila2)+30] = b'\xff' * 30
    print('  rótulos escritos in-situ (%d y %d B), colas a 0xFF'
          % (len(fila1), len(fila2)))

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
