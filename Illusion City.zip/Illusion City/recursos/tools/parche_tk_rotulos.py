#!/usr/bin/env python3
"""parche_tk_rotulos.py - TECNICAS: rótulos de armas alineados con las columnas.

Base: TEST_BL. David: "ARMA y GARRA en la misma columna del 65%". En BL los
campos de valor empiezan en la celda 10 de cada fila (celda 0 = la marca).
Los rótulos actuales empiezan en la celda 1. Se reescriben con:
  ARMA@10, RIFLE@14, OBÚS@18, CAÑÓN@22  (2 espacios entre palabras)
  GARRA@10, VARA@14, ESP.@18, HILO@22
  (cada palabra de 4-5 celdas queda sobre su columna de valor; el hueco final
   de CAÑÓN/HILO no molesta: es texto de la fila del rótulo)
Los rótulos se MUDAN al hueco libre detrás de la plantilla (0x155CE, 7986 B de
0xFF) porque crecen: la fila vieja acababa en la celda 22 y la nueva llega a la
34. El terminador (2f6e) se coloca al final de cada rótulo nuevo.
NO hay referencias a los rótulos (texto estático dentro de la plantilla).

Uso: python3 parche_tk_rotulos.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'
HUECO = 0x155CE

AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD}

def fw(ch):
    if ch in AC:
        return AC[ch].to_bytes(2, 'big')
    if 'A' <= ch <= 'Z':
        return bytes([0x82, 0x60 + ord(ch) - 65])
    if ch == '.':
        return b'\x81\x42'
    raise SystemExit('sin glifo: %r' % ch)

def fwa(t):
    out = bytearray()
    for ch in t:
        out += ESP if ch == ' ' else fw(ch)
    return bytes(out)

def linea_rotulo(palabras, celdas_ini):
    """[&5] + palabras en sus celdas + [2f6e]; celdas 0..34 rellenas de espacios"""
    fila = bytearray(bytes.fromhex('2635') + ESP * 34)
    pos = celdas_ini
    for p in palabras:
        w = fwa(p)
        fila[2 + pos*2 : 2 + pos*2 + len(w)] = w
        pos += len(p) + 2
    fila += b'\x2f\x6e'
    return bytes(fila)

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))

    r1 = linea_rotulo(['ARMA', 'RIFLE', 'OBÚS', 'CAÑÓN'], 10)
    r2 = linea_rotulo(['GARRA', 'VARA', 'ESP.', 'HILO'], 10)
    assert len(r1) == 72 and len(r2) == 72, (len(r1), len(r2))

    # hueco libre para los dos rótulos nuevos
    assert st[HUECO:HUECO + 148] == b'\xff' * 148, 'hueco no libre'
    st[HUECO:HUECO + 74] = r1
    st[HUECO + 74:HUECO + 148] = r2
    print('  rótulos nuevos en 0x%05X y 0x%05X' % (HUECO, HUECO + 74))

    # las filas viejas de los rótulos se vacian IN-SITU (cabecera + espacios +
    # terminador exactamente como estaban, pero sin palabras):
    # rotulo1: off 30..75 = 46 B = 2635 + 21 espacios + 2f6e
    st[T0+30:T0+76] = bytes.fromhex('2635') + ESP*21 + b'\x2f\x6e'
    # rotulo2: off 240..283 = 44 B = 2635 + 20 espacios + 2f6e
    assert st[T0+282:T0+284] == b'\x2f\x6e', st[T0+282:T0+284].hex(' ')
    st[T0+240:T0+284] = bytes.fromhex('2635') + ESP*20 + b'\x2f\x6e'
    print('  filas de rótulos viejas vaciadas in-situ (46 y 44 B)')

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
