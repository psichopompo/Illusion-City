#!/usr/bin/env python3
"""dis_m68k.py - desensamblador rapido (capstone m68k) de los ficheros del disco.

Uso:
    python3 dis_m68k.py <fichero> <offset_hex> [n_bytes]
    python3 dis_m68k.py START 0x95a8 200          # saca el fichero del .bin y desensambla
Las direcciones que imprime son RAM: para START/INIT/etc se suma BASES[fichero].
Si capstone no esta instalado:  pip install capstone
"""
import sys, os, importlib.util
AQUI = os.path.dirname(os.path.abspath(__file__))
PROY = os.path.dirname(os.path.dirname(AQUI))
BASE_BIN = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
SECTOR = 2352
REGIONES = {   # nombre: (lba, tam, base_ram)
    'START':  (59,   98184,  0x10000),
    'SSTART': (43,   32644,  0x10000),
    'INIT':   (107, 149400,  0x10000),
    'OPEN':   (285,  69258,  0x10000),
    'CHR':    (180,  94310,  0x10000),
    'GFONT':  (679,   7920,  0x10000),
}


def extrae(nombre):
    lba, sz, _ = REGIONES[nombre]
    raw = open(BASE_BIN, 'rb').read()
    out = bytearray()
    for k in range(0, sz, 2048):
        b = (lba + k // 2048) * SECTOR + 16
        out.extend(raw[b:b + min(2048, sz - k)])
    return bytes(out)


def main():
    fichero, off = sys.argv[1], int(sys.argv[2], 0)
    n = int(sys.argv[3], 0) if len(sys.argv) > 3 else 160
    if fichero in REGIONES:
        d = extrae(fichero); base = REGIONES[fichero][2]
        nombre = fichero
    else:
        d = open(fichero, 'rb').read(); base = 0; nombre = fichero
    import capstone
    md = capstone.Cs(capstone.CS_ARCH_M68K,
                     capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
    trozo = d[off:off + n]
    for i in md.disasm(trozo, base + off):
        hexb = ' '.join('%02X' % b for b in i.bytes)
        print('  %06X  %-20s %-8s %s' % (i.address, hexb, i.mnemonic, i.op_str))


if __name__ == '__main__':
    main()
