#!/usr/bin/env python3
"""parche_magia.py - pantalla de MAGIA: titulo con el nombre completo y columnas.

MEDIDO (22/09)
  La pantalla se pinta desde la plantilla de START 0x1758A:
```
    [+  0]  <icono>MAGIA<icono> + 9 huecos del nombre + SALTO
    [+ 22]  (linea vacia)
    [+ 24]  7 espacios + [$4] + "PM" + 2 espacios + "Coste" + SALTO
    [+ 46]  [$5]"Ahora" ' ' [$7] + 3 huecos + 3 espacios + [$5]"Individual" ' ' [$7] + 2 huecos + SALTO
    [+100]  [$5]"Máximo" [$7] + 3 huecos + 3 espacios + [$5]"Grupo" + 5 espacios + [$7] + 2 huecos + 00
```
  El texto se dibuja a **8 px por caracter** y las marcas $5/$7 **no ocupan sitio visible**
  (son cambios de color). El codigo escribe:
      0x11DEA  puntero del descriptor  -> la fila del titulo
      0x11E02  destino del nombre      -> el primer hueco del nombre
      0x11E06  move.w #$7,d2           -> cuantos glifos del nombre copia (ahora 9)
      0x11E16 / 0x11E58                -> los dos valores de la fila «Ahora»
      0x11E68 / 0x11E9A                -> los dos valores de la fila «Máximo»
      0x13DEA                          -> el titulo del popup «Efecto» (va detras)

COLUMNAS QUE PIDE DAVID (medidas en caracteres, x = 17 + 8*caracter)
      PM      x=73   (car. 7)      Coste    x=105 (car. 11)  -> «o» de Coste x=113
      valor 1 x= 75  (car. 7 del campo)  -> +1 espacio respecto al original
      Individual / Grupo  x=113 (car. 12)
      valor de Individual y de Grupo  x=201 (car. 23) -> el 8 justo bajo el 2

Uso: python3 parche_magia.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TPL = 0x1758A
TPL_NUEVA = 0x17CC1        # hueco libre (703 B): la plantilla crece y no cabe en su sitio
POPUP = 0x1761C            # la plantilla del popup «Efecto» (justo detras de la de Magia)
ICONO = 0x965F
M4, M5, M7 = bytes.fromhex('2634'), bytes.fromhex('2635'), bytes.fromhex('2637')
SALTO, ESP = bytes.fromhex('2f6e'), bytes.fromhex('8140')
ACENTOS = {'á': 0x9660, 'é': 0x9744, 'í': 0x9755, 'ó': 0x975F, 'ú': 0x975C,
           'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF}
NOMBRE_MAX = 9


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch in ACENTOS:
            out += ACENTOS[ch].to_bytes(2, 'big')
        elif ch == ' ':
            out += ESP
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


class Fila:
    """constructor: cada item ocupa su sitio y se puede consultar su offset"""

    def __init__(self):
        self.d = bytearray()
        self.pos = {}

    def pon(self, texto=None, marca=None, nombre=None):
        ini = len(self.d)
        if marca is None and texto is None:      # solo para registrar una posicion
            pass
        elif marca is None:
            self.d += fw(texto)
        elif isinstance(marca, int):
            self.d += marca.to_bytes(2, 'big')
        else:
            self.d += marca
        if nombre:
            self.pos[nombre] = ini
        return self

    def huecos(self, n):
        self.d += ESP * n
        return self

    def char(self, n):
        """donde cae (en caracteres visibles) el inicio de un item ya puesto"""
        return n


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    assert st[TPL:TPL + 16] == (ICONO.to_bytes(2, 'big') + fw('MAGIA')
                                + ICONO.to_bytes(2, 'big') + ESP), 'no reconozco el titulo de MAGIA'
    assert st[0x175CC:0x175D8] == M5 + fw('Ahora'), 'no reconozco la fila de Ahora'

    f0 = Fila()
    f0.pon(marca=ICONO).pon('MAGIA').pon(marca=ICONO).pon(' ')
    f0.pon(nombre='nombre')                    # el codigo escribe NOMBRE_MAX glifos aqui
    f0.huecos(NOMBRE_MAX - 1).pon(marca=SALTO)

    f1 = Fila()
    f1.pon(marca=SALTO)

    f2 = Fila()
    f2.huecos(7).pon(marca=M4).pon('PM').huecos(2).pon('Coste').pon(marca=SALTO)

    f3 = Fila()
    f3.pon(marca=M5).pon('Ahora').pon(' ').pon(marca=M7, nombre='val_ahora')
    f3.huecos(3)                               # campo del valor (3 caracteres)
    f3.huecos(3)                               # 3 espacios hasta Individual
    f3.pon(marca=M5).pon('Individual').pon(' ')
    f3.pon(marca=M7, nombre='val_ind').huecos(2).pon(marca=SALTO)

    f4 = Fila()
    f4.pon(marca=M5).pon('Maximo')
    f4.huecos(max(0, (2 + 10) - len('Maximo')))   # relleno para que su valor cuadre
    f4.pon(marca=M7, nombre='val_max')
    f4.huecos(3).huecos(3)
    f4.pon(marca=M5).pon('Grupo').huecos(5)
    f4.pon(marca=M7, nombre='val_grp').huecos(2).pon(' ').pon(marca=b'\x00')

    nueva = bytes(f0.d + f1.d + f2.d + f3.d + f4.d)
    # offsets finales
    base = 0
    off = {}
    for k, f in enumerate((f0, f1, f2, f3, f4)):
        for nom, o in f.pos.items():
            off[nom] = base + o
        base += len(f.d)
    # el popup «Efecto» se copia al final (detras de un 00) y se reapunta su referencia
    popup_viejo = st[POPUP:st.find(b'\x00', POPUP)]
    popup_nuevo = TPL_NUEVA + len(nueva) + 1
    cola = b'\x00' + popup_viejo + b'\x00'
    print('  plantilla nueva: %d B (antes %d) en 0x%05X (+%d B de popup)'
          % (len(nueva), 0x17618 - TPL, TPL_NUEVA, len(cola)))
    for k, v in off.items():
        print('   %-10s +%3d  (nuevo 0x%05X)' % (k, v, TPL_NUEVA + v))

    REFS = {0x2758A: TPL_NUEVA + 0x10000,                   # la fila del titulo
            0x2759A: TPL_NUEVA + off['nombre'] + 0x10000,
            0x275DA: TPL_NUEVA + off['val_ahora'] + 0x10000,
            0x275EC: TPL_NUEVA + off['val_ind'] + 0x10000,
            0x27600: TPL_NUEVA + off['val_max'] + 0x10000,
            0x27612: TPL_NUEVA + off['val_grp'] + 0x10000,
            0x2761C: popup_nuevo + 0x10000}

    total = len(nueva) + len(cola)
    assert st[TPL_NUEVA:TPL_NUEVA + total] == b'\xff' * total, \
        'el hueco 0x%05X no esta libre' % TPL_NUEVA
    # OJO: la plantilla vieja sigue pintandose (hay mas codigo que la lee), asi que la
    # nueva se copia ENCIMA de la vieja (misma direccion) y la referencia del popup se
    # reapunta al hueco libre, que es donde va la copia larga del popup.
    st[TPL:TPL + total] = nueva + cola
    n = 0
    o = 0
    while o < len(st) - 4:
        v = int.from_bytes(st[o:o + 4], 'big')
        if v in REFS:
            st[o:o + 4] = REFS[v].to_bytes(4, 'big')
            n += 1
        o += 2
    assert st[0x11E06:0x11E0A] == bytes.fromhex('343c0007'), 'no veo el limite del nombre'
    st[0x11E08:0x11E0A] = NOMBRE_MAX.to_bytes(2, 'big')
    print('  %d referencias reapuntadas; limite del nombre 7 -> %d' % (n, NOMBRE_MAX))

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
