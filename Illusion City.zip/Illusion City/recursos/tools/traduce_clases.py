#!/usr/bin/env python3
"""traduce_clases.py - CLASES, HABILIDADES y ZONAS de combate al castellano (v2).

MEDIDO (22/09)
  Las tres columnas de texto del menu de Estado, de la ventana de HABILIDADES y de las
  tiendas son tres tablas de PUNTEROS de 16 bits (offset desde BASE = INIT 0x21246):
      clases       INIT 0x22292  (16 entradas de 2 B)
      habilidades  INIT 0x222A2  ( 8 entradas, comparten los textos 8..15)
      zonas        INIT 0x222B4  ( 6 entradas)
  Los textos estan PEGADOS, cada uno con su byte 00, en INIT 0x2425C..0x2434E (243 B,
  clases + habilidades + zonas). Como son offsets, da igual donde caigan: se mudan
  todos y se reescriben los punteros.

SITIO PARA LOS TEXTOS NUEVOS (316 B)
  a) El bloque viejo 0x2425C..0x2434E (243 B) queda libre entero al mudarlos: ahi van
     los mas largos.
  b) Los huecos de 13-29 B que hay tras la tabla de zonas: 0x223A0 (17), 0x223C6 (29),
     0x2240C (13), 0x22434 (23) = 82 B, para los cortos.
  (Descartados con prueba: los 24 B de 0x21918, 0x21AB8, 0x21E70 y 0x21FE3 los
   REEESCRIBE el juego al cargar la partida; y la tabla de fuente de los menus cae por
   DEBAJO de la base, asi que sus celdas no valen como offsets.)

Uso: python3 traduce_clases.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

# Hay DOS copias de estas tablas y textos: una en INIT.BIN (la que usa la pantalla de
# ESTADO) y otra en OPEN.BIN (la que usa la ventana de HABILIDADES). Cada fichero tiene
# su propia base: los offsets se cuentan desde la base de los textos de cada uno.
INIT = dict(nombre='INIT', lba=107, tam=149400, base=0x21246,
            tablas=(0x22292, 0x222A2, 0x222B4), bloque=(0x2425C, 0x2434E),
            huecos=[(0x223A0, 0x223B0), (0x223C6, 0x223E2), (0x2240C, 0x22418),
                    (0x22434, 0x2244A), (0x21A1F, 0x21A30), (0x21A74, 0x21A84)])
OPEN = dict(nombre='OPEN', lba=285, tam=69258, base=0x0D938,
            tablas=(0x0E984, 0x0E994, 0x0E9A6), bloque=(0x1094E, 0x10A40),
            huecos=[(0x0EA92, 0x0EA9E), (0x0EAB8, 0x0EAD5), (0x0EAFE, 0x0EB0B),
                    (0x0EB26, 0x0EB3D), (0x0E9FA, 0x0EA05), (0x0EA30, 0x0EA39),
                    (0x0EA5E, 0x0EA6D)])

ACENTOS = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
           'Ñ': 0x96B3, 'Ü': 0x96BD, '¿': 0x96C5, '¡': 0x96DA, 'á': 0x9660,
           'é': 0x9744, 'í': 0x9755, 'ó': 0x975F, 'ú': 0x975C, 'ü': 0x976C,
           'ñ': 0x9770}

CLASES = ['DIVER', 'POLICÍA', 'CIVIL', 'SABIO', 'ROBOT', 'RESIST.', 'DEMONIO',
          'EX-GENERAL', 'HILO', 'ESPADA', 'VARA', 'GARRA', 'CAÑÓN G.', 'OBÚS',
          'RIFLE', 'ARMA']
ZONAS = ['TIENDA', 'ZONA CRISIS', 'INTERIOR', 'ZONA PELIGRO', 'ZONA METAL',
         'TUBO AGUA']


def cod(ch):
    o = ord(ch)
    if 'A' <= ch <= 'Z':
        return bytes([0x82, 0x60 + o - 0x41])
    if 'a' <= ch <= 'z':
        return bytes([0x82, 0x81 + o - 0x61])
    if '0' <= ch <= '9':
        return bytes([0x82, 0x4F + o - 0x30])
    if ch == ' ':
        return b'\x81\x40'
    if ch == '.':
        return b'\x81\x42'
    if ch == '-':
        return b'\x81\x7C'
    if ch in ACENTOS:
        return ACENTOS[ch].to_bytes(2, 'big')
    raise SystemExit('sin glifo: %r' % ch)


def fw(s):
    out = bytearray()
    for ch in s:
        out += cod(ch)
    return bytes(out)


def traduce(init, cual):
    """mueve los textos y reescribe los punteros de una de las dos copias"""
    base = init['base']
    tablas = init['tablas']
    datos_fichero = init['datos']
    print('  --- %s (base de offsets 0x%05X) ---' % (init['nombre'], base))

    # 1) comprobar que las tablas son las que creo
    for k, t in enumerate(tablas):
        vals = [int.from_bytes(datos_fichero[t + 2 * i:t + 2 * i + 2], 'big') for i in range(4)]
        print('    tabla 0x%05X  %s' % (t, ' '.join('0x%04X' % v for v in vals)))

    # 2) destinos: los huecos a cero, y el bloque viejo
    sitios = {}
    pendientes = sorted(CLASES + ZONAS, key=lambda t: len(fw(t)))
    libres = [(x, y - x + 1) for x, y in init['huecos']]
    for txt in list(pendientes):
        d = fw(txt) + b'\x00'
        cand = None
        for i, (x, n) in enumerate(libres):
            if n >= len(d) and (cand is None or n < libres[cand][1]):
                cand = i
        if cand is None:
            continue
        x, n = libres[cand]
        datos_fichero[x:x + len(d)] = d
        sitios[txt] = x
        pendientes.remove(txt)
        if n == len(d):
            libres.pop(cand)
        else:
            libres[cand] = (x + len(d), n - len(d))
    pos = init['bloque'][0]
    for txt in sorted(pendientes, key=lambda t: -len(fw(t))):
        d = fw(txt) + b'\x00'
        assert pos + len(d) - 1 <= init['bloque'][1], 'no cabe «%s» en %s' % (txt, init['nombre'])
        datos_fichero[pos:pos + len(d)] = d
        sitios[txt] = pos
        pos += len(d)
    usados = sum(len(fw(t)) + 1 for t in CLASES + ZONAS)
    print('    %d textos, %d B (huecos %d B + bloque %d B)'
          % (len(CLASES) + len(ZONAS), usados,
             sum(y - x + 1 for x, y in init['huecos']), init['bloque'][1] - init['bloque'][0] + 1))

    # 3) punteros (16 en la tabla de clases, 8 en la de habilidades, 6 en la de zonas)
    tc, th, tz = tablas
    for k, txt in enumerate(CLASES):
        datos_fichero[tc + 2 * k:tc + 2 * k + 2] = (sitios[txt] - base).to_bytes(2, 'big')
    for k in range(8):
        datos_fichero[th + 2 * k:th + 2 * k + 2] = (sitios[CLASES[8 + k]] - base).to_bytes(2, 'big')
    for k, txt in enumerate(ZONAS):
        datos_fichero[tz + 2 * k:tz + 2 * k + 2] = (sitios[txt] - base).to_bytes(2, 'big')
    print('    punteros reescritos: %d + 8 + %d' % (len(CLASES), len(ZONAS)))


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    for init in (INIT, OPEN):
        d = bytearray(m.region(raw, init['lba'], init['tam']))
        for x, y in init['huecos']:
            assert d[x:y] == b'\x00' * (y - x), \
                '%s: el hueco 0x%05X no esta a cero' % (init['nombre'], x)
        init['datos'] = d
        traduce(init, init['nombre'])
        m.escribe_region(raw, init['lba'], bytes(d))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
