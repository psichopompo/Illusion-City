#!/usr/bin/env python3
"""mockup_iconos.py - los cuatro iconos de la fila 7, tal como quedarian.

Dibuja las dos lineas de rotulo con la fuente del PNG de David y el paso de 5 px
que usa el juego (4 de tinta + 1 de hueco), ampliado x6 para poder juzgarlo.
No toca ningun .bin.

Uso: python3 mockup_iconos.py [salida.png]
"""
import importlib.util
import os
import sys

from PIL import Image, ImageDraw

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec); spec.loader.exec_module(f)

PASO = 5            # paso de las letras
ESCALA = 6
ANCHO, ALTO = 100, 34      # px de "juego" por panel
MARGEN = 4


def main():
    G = f.glifos_david()
    variantes = [('AHORA: fila 7, columna 2', '◊'),
                 ('fila 7, columna 3', '÷'),
                 ('fila 7, columna 4', '#'),
                 ('fila 7, columna 5', '∆')]

    def tinta(im, x, y, ch):
        if ch == ' ':
            return PASO
        g = G[ch]
        for yy in range(8):
            for xx in range(8):
                if g[yy, xx]:
                    im.putpixel((x + xx, y + yy), 0)
        return 9 if ch in '◊÷#∆' else PASO

    im = Image.new('RGB', (ANCHO * len(variantes) * ESCALA, (ALTO * 2 + 26) * ESCALA),
                   (10, 10, 40))
    d = ImageDraw.Draw(im)
    for k, (etq, ico) in enumerate(variantes):
        x0 = k * ANCHO * ESCALA
        # panel
        d.rectangle([x0 + 3, 3, x0 + ANCHO * ESCALA - 4, (ALTO * 2 + 20) * ESCALA - 4],
                    fill=(24, 24, 80), outline=(120, 120, 200))
        capa = Image.new('1', (ANCHO, ALTO * 2 + 20), 1)
        # linea 1: <ico>MAGIA<ico> Tianren
        x, y = MARGEN, MARGEN
        for ch in [ico] + list('MAGIA') + [ico] + [' '] + list('Tianren'):
            x += tinta(capa, x, y, ch)
        # linea 2: <ico>Tianren<ico> DIVER
        x, y = MARGEN, MARGEN + 13
        for ch in [ico] + list('Tianren') + [ico] + [' '] + list('DIVER'):
            x += tinta(capa, x, y, ch)
        px = capa.load()
        for yy in range(capa.height):
            for xx in range(capa.width):
                if px[xx, yy] == 0:
                    for dy in range(ESCALA):
                        for dx in range(ESCALA):
                            im.putpixel((x0 + 6 + xx * ESCALA + dx,
                                         6 + yy * ESCALA + dy), (255, 255, 255))
        d.text((x0 + 8, (ALTO * 2 + 22) * ESCALA - 26), etq, fill=(255, 255, 120))
    salida = sys.argv[1] if len(sys.argv) > 1 else \
        '/home/user/Illusion City/capturas_tanda/mockup_iconos.png'
    im.save(salida)
    print('  %s  (%dx%d)' % (salida, im.width, im.height))


if __name__ == '__main__':
    main()
