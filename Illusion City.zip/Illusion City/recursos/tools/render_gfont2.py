#!/usr/bin/env python3
"""Render GFONT.BIN attempt 2: 18 B/glyph continuous 144-bit stream, 12x12."""
from PIL import Image
import sys

d = open('extraidos/GFONT.BIN','rb').read()
GLYPH = 18
count = len(d)//GLYPH
cols = 16
rows = (count + cols - 1) // cols
scale = 4
img = Image.new('P', (cols*13*scale, rows*12*scale), 0)
img.putpalette([17,17,17, 255,255,255] + [0]*254)
px = img.load()
for g in range(count):
    tile = d[g*GLYPH:(g+1)*GLYPH]
    bits = ''.join(f'{b:08b}' for b in tile)
    gx, gy = (g % cols)*13*scale, (g // cols)*12*scale
    for y in range(12):
        row = bits[y*12:(y+1)*12]
        for x in range(12):
            if row[x] == '1':
                for sy in range(scale):
                    for sx in range(scale):
                        px[gx+x*scale+sx, gy+y*scale+sy] = 1
img.save('gfont2.png')
print("saved gfont2.png,", count, "glyphs")
