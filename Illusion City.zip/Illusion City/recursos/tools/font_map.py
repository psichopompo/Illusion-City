#!/usr/bin/env python3
"""Reconstruct SJIS->glyph mapping of GFONT.BIN via optical matching."""
import glob, sys
from PIL import Image, ImageDraw, ImageFont

GFONT = 'extraidos/GFONT.BIN'
NG = 440
GSZ = 18  # bytes per glyph (12x12 1bpp bitstream)

def read_glyphs(path=GFONT, n=NG):
    d = open(path,'rb').read()
    glyphs = []
    for g in range(min(n, len(d)//GSZ)):
        chunk = d[g*GSZ:(g+1)*GSZ]
        px = []
        bits = ''.join(f'{b:08b}' for b in chunk)
        for y in range(12):
            px.append([1 if bits[y*12+x] == '1' else 0 for x in range(12)])
        glyphs.append(px)
    return glyphs

# candidates: symbol rows + fullwidth alnum + kana
CANDS = []
CANDS += list(range(0x8140, 0x824F))          # symbols
CANDS += list(range(0x824F, 0x829B))          # 0-9 A-Z a-z punct
CANDS += list(range(0x829F, 0x82F2))          # hiragana
CANDS += list(range(0x8340, 0x8397))          # katakana

# kanji candidates: codes extracted from event files (dense runs)
def valid_sjis_run(d, min_run=6):
    chars = []; run = []
    def flush():
        if len(run) >= min_run: chars.extend(run)
        run.clear()
    i = 0; n = len(d)
    while i < n-1:
        b = d[i]
        ok = (0x81 <= b <= 0x9F or 0xE0 <= b <= 0xEF) and 0x40 <= d[i+1] <= 0xFC and d[i+1] != 0x7F
        if ok: run.append((b<<8)|d[i+1]); i += 2
        else: flush(); i += 1
    flush()
    return chars

kanji = set()
for f in glob.glob('extraidos/*.BIN'):
    for c in valid_sjis_run(open(f,'rb').read()):
        if c >= 0x889F: kanji.add(c)
CANDS += sorted(kanji)

# render candidates at 12px with a Japanese-capable font
FONT_PATHS = [
    '/System/Library/Fonts/Hiragino Sans GB.ttc',
    '/System/Library/Fonts/Supplemental/Arial Unicode.ttf',
    '/System/Library/Fonts/Osaka.ttf',
]
fp = None
for p in FONT_PATHS:
    try:
        f = ImageFont.truetype(p, 12)
        fp = p; break
    except Exception:
        pass
if fp is None:
    sys.exit("no CJK font found")
print("font:", fp)

def render(code):
    ch = bytes([(code>>8)&0xFF, code&0xFF]).decode('shift_jis', 'replace')
    img = Image.new('L', (12,12), 0)
    dr = ImageDraw.Draw(img)
    dr.text((0,-1), ch, fill=255, font=ImageFont.truetype(fp,12))
    return [1 if img.getpixel((x,y)) > 100 else 0 for y in range(12) for x in range(12)]

# precompute rendered candidates
cand_px = {}
for c in CANDS:
    cand_px[c] = render(c)

def dist(a_px, b_px):
    return sum(x != y for x, y in zip(a_px, b_px))

glyphs = read_glyphs()
flat = [[v for row in g for v in row] for g in glyphs]

result = {}   # glyph index -> (code, dist)
for gi, gp in enumerate(flat):
    best = (999, None)
    for c, cp in cand_px.items():
        dd = dist(gp, cp)
        if dd < best[0]:
            best = (dd, c)
    result[gi] = best

# report + verify anchors
anchors = {38:0x8151, 50:0x824F, 60:0x8260, 113:0x829F, 181:0x8340, 270:0x889F, 273:0x9342}
nok = 0
for gi, code in sorted(anchors.items()):
    d, c = result[gi]
    m = 'OK' if c == code else f'got {hex(c) if c else None} d={d}'
    if c == code: nok += 1
    print(f"anchor glyph {gi}: want {hex(code)} -> {m}")
print(f"anchors: {nok}/{len(anchors)}")

# confidence stats
good = sum(1 for gi,(d,c) in result.items() if d <= 6)
print(f"confident matches (dist<=6): {good}/{NG}")
# save mapping
with open('font_map.txt','w') as out:
    for gi in range(NG):
        d, c = result[gi]
        ch = bytes([(c>>8)&0xFF, c&0xFF]).decode('shift_jis','replace') if c else '?'
        out.write(f"{gi}\t{c if c else '????'}\t{d}\t{ch}\n")
print("written font_map.txt")
