#!/usr/bin/env python3
"""dinero_formato.py - la fila del dinero: etiqueta con dos puntos y moneda «ＨＫ＄».

FORMATO PEDIDO POR DAVID
    Dinero: 0000140 ＨＫ＄      (espacio despues de los dos puntos y antes de la moneda)

MEDIDO (47ª tanda)
  - El hueco de la etiqueta ($17AA0, 16 B) NO da para «Dinero: » + terminador (17 B),
    asi que la etiqueta se mueve al hueco libre de $179C0 y se redirigen sus dos `lea`
    (0x10B04 y 0x10B9E).
  - El pintor del dinero ($20AF0) mete un espacio fijo detras de la etiqueta
    (0x10B0E: move.w #$8140,(a2)+). Aqui se ANULA (2 NOP) para que el hueco de 8 px lo
    ponga el texto y no el codigo.
  - Con la caja en 19 celdas (213 px) el texto no cabe (el «＄» se va a la linea
    siguiente); con 20 celdas (222 px) entra y termina en x=209. Por eso el ancho de la
    caja del dinero se queda en 20 (parche_cajas.py).
  - La moneda va en codigos FULLWIDTH (como la japonesa «Ｈ＄»): con ASCII el pintor cae
    en celdas sin glifo. Y el codigo de la K esta desplazado uno: $826A dibuja la K.
"""
import hashlib, importlib.util, os, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI); PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('p', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

OFF_ETIQUETA = 0x179C0      # hueco libre -> RAM $279C0 (17 B: «Dinero: » + 00)
OFF_MONEDA   = 0x17AD0      # hueco libre -> RAM $27AD0
LEAS_ETIQUETA = (0x10B04, 0x10B9E)
LEAS_MONEDA = (0x10B18, 0x10BAE, 0x10CE8, 0x10DBA)
MONEDA_VIEJA_RAM = 0x21882
ETIQUETA_VIEJA_RAM = 0x2187A
NOP_HUECO = 0x10B0E         # move.w #$8140,(a2)+  (el espacio fijo del pintor)


def fw(s):
    """texto -> bytes SJIS de ancho completo (anade ':' y el espacio a los signos)."""
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':   out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z': out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif '0' <= ch <= '9': out += bytes([0x82, 0x4F + ord(ch) - 48])
        elif ch == ' ':        out += bytes([0x81, 0x40])
        elif ch == ':':        out += bytes([0x81, 0x46])
        elif ch == '$':        out += bytes([0x81, 0x90])
        else: raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual
    n = len(buf); buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    etiqueta = fw('Dinero: ') + b'\x00'          # 17 B
    # la moneda: espacio + Ｈ + Ｋ ($826A, desplazado) + ＄
    moneda = bytes.fromhex('8140') + bytes.fromhex('8267') + bytes.fromhex('826A') \
        + bytes.fromhex('8190') + b'\x00\x00'
    assert st[OFF_ETIQUETA:OFF_ETIQUETA + len(etiqueta)] == b'\xff' * len(etiqueta), 'hueco de la etiqueta ocupado'
    assert st[OFF_MONEDA:OFF_MONEDA + len(moneda)] == b'\xff' * len(moneda), 'hueco de la moneda ocupado'
    pon(st, OFF_ETIQUETA, etiqueta, 'etiqueta')
    pon(st, OFF_MONEDA, moneda, 'moneda')
    # la etiqueta puede apuntar al original ($2187A) o al que deja build_test_i ($27AA0):
    # los dos son validos, aqui se reescriben igual
    for off in LEAS_ETIQUETA:
        v = int.from_bytes(st[off + 2:off + 6], 'big')
        assert st[off:off + 2] == bytes.fromhex('43f9') and v in (ETIQUETA_VIEJA_RAM, 0x27AA0), \
            'lea de la etiqueta inesperado en 0x%X ($%X)' % (off, v)
    for off in LEAS_MONEDA:
        assert st[off:off + 6] == bytes.fromhex('43f9') + MONEDA_VIEJA_RAM.to_bytes(4, 'big'), \
            'lea de la moneda inesperado en 0x%X' % off
    for o in LEAS_ETIQUETA:
        pon(st, o, bytes.fromhex('43f9') + (0x10000 + OFF_ETIQUETA).to_bytes(4, 'big'), 'lea 0x%X' % o)
    for o in LEAS_MONEDA:
        pon(st, o, bytes.fromhex('43f9') + (0x10000 + OFF_MONEDA).to_bytes(4, 'big'), 'lea 0x%X' % o)
    assert st[NOP_HUECO:NOP_HUECO + 4] == bytes.fromhex('34fc8140'), 'el hueco del pintor no esta'
    pon(st, NOP_HUECO, bytes.fromhex('4e714e71'), 'hueco del pintor')
    m.escribe_region(raw, m.LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  etiqueta "Dinero: " (%d B) en $%X; %d leas'
          % (len(etiqueta), 0x10000 + OFF_ETIQUETA, len(LEAS_ETIQUETA)))
    print('  moneda   " ＨＫ＄" (%d B) en $%X; %d leas; hueco del pintor anulado'
          % (len(moneda), 0x10000 + OFF_MONEDA, len(LEAS_MONEDA)))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
