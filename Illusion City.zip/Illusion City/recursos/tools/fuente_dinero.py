#!/usr/bin/env python3
"""fuente_dinero.py - glifos de David en la SEGUNDA tabla de fuente (la del dinero).

DESCUBRIMIENTO (medido marcando celdas con bloques solidos y viendo que zona de
pantalla cambia):
  El juego tiene **dos tablas de fuente**:
    - 0x4ED0 en INIT / 0xA710 en OPEN  -> la que usan los MENUS (letras fullwidth)
    - 0x14E0 en INIT / 0x6D20 en OPEN  -> la que usa la LINEA DEL DINERO
  Mapeo medido en la segunda (celda -> caracter):
    celda 49 = '$'     (x=204..215 en pantalla)
    celdas 52-61 = '0'-'9'   (celda = valor + 52)
    celda 69 = 'H'     (x=196..203)
  (la 'K' no aparece en el barrido 20-99: se dibuja mas alla; pendiente)

Este script escribe los glifos de David en esa tabla: el '$' (con su simbolo),
los digitos 0-9 y la 'H'.
"""
import hashlib, importlib.util, os, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI); PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('p', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)

CELL = 18
TABLAS = (('INIT', 107, 149400, 0x14E0), ('OPEN', 285, 69258, 0x6D20))
CELDA_DOLAR = 49
CELDA_DIGITOS = 52          # '0' ; celda = 52 + valor
CELDA_H = 69


def aplica(entrada, salida):
    G = f.glifos_david()
    raw = bytearray(open(entrada, 'rb').read())
    cambios = []
    for nombre, lba, sz, base in TABLAS:
        d = bytearray(m.region(raw, lba, sz))
        # el simbolo del dinero
        off = base + CELDA_DOLAR * CELL
        d[off:off + CELL] = f.a_celda12(G['$'], 0)
        cambios.append('%s celda %d = $' % (nombre, CELDA_DOLAR))
        # los digitos
        for v in range(10):
            off = base + (CELDA_DIGITOS + v) * CELL
            d[off:off + CELL] = f.a_celda12(G[str(v)], 0)
        cambios.append('%s celdas %d-%d = 0-9' % (nombre, CELDA_DIGITOS, CELDA_DIGITOS + 9))
        # la H (que quedo rota al escribir el $ en su celda)
        off = base + CELDA_H * CELL
        d[off:off + CELL] = f.a_celda12(G['H'], 0)
        cambios.append('%s celda %d = H' % (nombre, CELDA_H))
        m.escribe_region(raw, lba, bytes(d))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('\n'.join('  ' + c for c in cambios))
    print('MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
