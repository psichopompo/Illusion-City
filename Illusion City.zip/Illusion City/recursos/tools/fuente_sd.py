#!/usr/bin/env python3
"""fuente_sd.py - la TERCERA tabla de fuente: SD.BIN (base 0x8CF0).

MEDIDO (22/09)
  El juego tiene TRES tablas de fuente 12x12 identicas (misma disposicion de celdas):
      INIT  0x4ED0      OPEN  0xA710      SD.BIN  0x8CF0
  Los TEXTOS de los menus y paneles se pintan desde la de **SD.BIN** (esta comprobado
  que pintar INIT/OPEN no cambia el menu: la 'a' con tilde salia como el kanji 冒 y en
  INIT/OPEN esa celda ya tenia el glifo de David).
  Aqui se escriben en SD.BIN los mismos glifos que `fuente_8px.py` y
  `fuente_simbolos.py` escriben en INIT/OPEN: letras, digitos, acentos, el '$',
  la puntuacion y el ICONO.

Uso: python3 fuente_sd.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
spec3 = importlib.util.spec_from_file_location('s', os.path.join(AQUI, 'fuente_simbolos.py'))
sym = importlib.util.module_from_spec(spec3); spec3.loader.exec_module(sym)

LBA_SD, SZ_SD = 251, 69194
BASE_SD = 0x8CF0
CELL = 18
ICONO_CELDA = 1349          # el icono de David (fila 7) que usa parche_rotulos.py


def aplica(entrada, salida):
    G = f.glifos_david()
    raw = bytearray(open(entrada, 'rb').read())
    d = bytearray(m.region(raw, LBA_SD, SZ_SD))
    cambios = 0
    for rel, ch in f.destinos().items():        # letras, digitos, acentos y $
        celda = rel + sym.REL8 if False else rel - sym.REL8 + 0
        # en fuente_8px los destinos son (rel, ch) y la celda = rel + 824
        celda = rel + 824
        off = BASE_SD + celda * CELL
        if off < 0 or off + CELL > len(d):
            continue
        d[off:off + CELL] = f.a_celda12(G[ch], 0)
        cambios += 1
    for ch, celda in sym.SIMBOLOS.items():      # puntuacion y simbolos
        off = BASE_SD + celda * CELL
        d[off:off + CELL] = f.a_celda12(G[ch], 0)
        cambios += 1
    off = BASE_SD + ICONO_CELDA * CELL           # el icono
    d[off:off + CELL] = f.a_celda12(G[sym.__dict__.get('GLIFO_ICONO', '∆')], 0)
    cambios += 1
    m.escribe_region(raw, LBA_SD, bytes(d))
    raw2 = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw2))
    print('  SD.BIN: %d celdas escritas (base 0x%05X)' % (cambios, BASE_SD))
    print('  MD5 %s' % hashlib.md5(bytes(raw2)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
