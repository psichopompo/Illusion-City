#!/usr/bin/env python3
"""parche_plantillas.py - los rotulos de las pantallas de COMBATE y HABILIDADES.

MEDIDO (22/09)
  Las dos pantallas se pintan desde sendas PLANTILLAS de texto en START (con marcas
  $1..$8 para los valores). Se editan EN SU SITIO y **sin cambiar ni un byte de
  longitud**, porque el codigo escribe espacios en direcciones fijas dentro de ellas
  (hay ~60 `lea` apuntando al interior de la plantilla; mover 1 byte las descuadra).

      COMBATE      攻撃力 / 防御力 / 素早さ  ->  ATQ / DEF / VEL   (6 B cada uno, igual)
      HABILIDADES  «Tecnicas» + «Unid» (26 B) -> «HABILIDADES %»  (26 B, igual)
      y el ESPACIO que separa cada valor del siguiente -> «%»
      (asi cada cifra lleva su % detras, como pidio David; la 4ª columna no lleva
       porque la plantilla no tiene hueco y es la que esta pegada al borde)

Uso: python3 parche_plantillas.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
ESPACIO = bytes.fromhex('8140')
PORC = bytes.fromhex('8193')          # el '%' del motor


def fw(s):
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += bytes([0x81, 0x40])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def pon(buf, off, data, cual):
    n = len(buf)
    buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))

    # --- 1) rotulos de COMBATE ---
    for off, viejo, nuevo in ((0x1428A, bytes.fromhex('8d558c8297cd'), fw('ATQ')),
                              (0x14292, bytes.fromhex('96688ce497cd'), fw('DEF')),
                              (0x1429A, bytes.fromhex('9166918182b3'), fw('VEL'))):
        assert st[off:off + 6] == viejo, 'en 0x%05X esperaba el kanji y hay %s' % (off, st[off:off + 6].hex(' '))
        pon(st, off, nuevo, 'rotulo combate')
        print('  0x%05X  %s -> «%s»' % (off, viejo.hex(' '), nuevo.decode('latin1')))
    print('  (el campo del original mide 3 glifos: las palabras enteras no caben sin'
          ' recolocar las columnas de numeros)')

    # --- 2) titulo de HABILIDADES ---
    off, viejo = 0x140E0, m.fw('Tecnicas') + m.fw('Unid')
    nuevo = fw('HABILIDADES') + PORC   # el original mide 24 B: 'Tecnicas'(16) + 'Unid'(8)
    assert st[off:off + len(viejo)] == viejo, 'el titulo no cuadra: %s' % st[off:off + 26].hex(' ')
    assert len(nuevo) == len(viejo), 'cambia de longitud'
    pon(st, off, nuevo, 'titulo HABILIDADES')
    print('  0x%05X  «TecnicasUnid» -> «HABILIDADES %%»  (%d B, igual)' % (off, len(nuevo)))

    # --- 2b) los ROTULOS de las columnas de HABILIDADES ---------------------
    # MEDIDO: las dos filas de rotulos ocupan EXACTAMENTE 21 celdas cada una
    # (cols 0..20) y NO pueden cambiar de longitud: el codigo salta a direcciones
    # que caen DENTRO de la plantilla. Los nombres de David suman 22 con «GARRA»
    # (5) y «ESPADA» (6): entra «SABLE» (5) en vez de ESPADA.
    AC = {'Ó': 0x9682, 'Ú': 0x96AF, 'Ñ': 0x96B3, 'Á': 0x95FB, 'É': 0x966B,
          'Í': 0x967B, 'Ü': 0x96BD, 'á': 0x9660, 'é': 0x9744, 'í': 0x9755,
          'ó': 0x975F, 'ú': 0x975C, 'ü': 0x976C, 'ñ': 0x9770}

    def fwa(t):
        out = bytearray()
        for ch in t:
            if ch in AC:
                out += AC[ch].to_bytes(2, 'big')
            elif ch == ' ':
                out += ESPACIO
            elif ch == '.':
                out += bytes.fromhex('8142')
            else:
                out += fw(ch)
        return bytes(out)

    # Cada fila de rotulos son 20 celdas (40 B) DESPUES de la marca $5. Con los
    # nombres completos no caben (21 y 22 celdas), asi que van dos abreviaturas,
    # como David dijo para estos casos («si no cupieran, usariamos las abreviaturas»).
    for off, nuevo, etq in ((0x140FC, 'ARMA RIFLE OBÚS CAÑ.', 'fila 1: Gun/Rifle/Cañón/Pesado'),
                            (0x141B4, 'GARRA VARA ESP. HILO', 'fila 2: Garra/Vara/Espada/Hilo')):
        assert st[off - 2:off] == bytes.fromhex('2635'), 'en 0x%05X no esta la marca $5' % (off - 2)
        assert st[off + 40:off + 42] == bytes.fromhex('2f6e'), 'en 0x%05X no acaba la fila' % off
        d = fwa(nuevo)
        assert len(d) == 40, '%s: %d B (hacen falta 40 = 20 celdas)' % (nuevo, len(d))
        pon(st, off, d, 'rotulo ' + etq)
        print('  0x%05X  %-30s -> «%s»  (20 celdas)' % (off, etq, nuevo))

    # --- 3) el % detras de cada valor (el espacio que separa los campos) ---
    grupo = bytes.fromhex('824f') * 3      # los '０' del motor (fullwidth 0x824F)
    patron = grupo + ESPACIO + grupo + ESPACIO + grupo + ESPACIO + grupo
    n = 0
    o = 0
    while True:
        i = st.find(patron, o)
        if i < 0:
            break
        for k in (1, 2, 3):                      # los tres separadores internos
            p = i + k * (len(grupo) + len(ESPACIO)) - len(ESPACIO)
            assert st[p:p + 2] == ESPACIO
            pon(st, p, PORC, 'separador %d' % k)
        n += 1
        o = i + len(patron)
    print('  %d filas de valores: los 3 separadores de cada una son ahora «%%»' % n)

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
