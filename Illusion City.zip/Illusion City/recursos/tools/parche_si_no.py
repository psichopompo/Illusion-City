#!/usr/bin/env python3
"""parche_si_no.py - los tres ＯＦＦ del menu de Ajustes -> ＮＯ (6 B, mismo tamano).

Medido en la 89ª (ver DIARIO): los tres valores de Ajustes son ＯＦＦ (0x82 0x6E,
0x82 0x65, 0x82 0x65) en file 0x1767F, 0x1769E y 0x176BF. Se cambian por ＮＯ
(0x82 0x6E, 0x82 0x78) + un espacio fullwidth para mantener los 6 B.
David: los valores se traducen como SÍ y NO; el ＯＮ no aparece de fabrica.

Uso: python3 parche_si_no.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
SITIOS = (0x1767F, 0x1769E, 0x176BF)
OFF = bytes.fromhex('826e82658265')
NO = bytes.fromhex('826e82788140')          # ＮＯ + espacio fullwidth (6 B)

def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    for off in SITIOS:
        assert st[off:off+6] == OFF, 'en 0x%05X hay %s' % (off, st[off:off+6].hex(' '))
        st[off:off+6] = NO
        print('  0x%05X  ＯＦＦ -> ＮＯ' % off)
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
