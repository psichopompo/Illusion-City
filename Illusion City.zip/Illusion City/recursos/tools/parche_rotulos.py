#!/usr/bin/env python3
"""parche_rotulos.py - el ICONO de David en los rotulos de los menus.

QUE HACE
  1) Mete el glifo del icono (celda que David dibujo en la FILA 7, COLUMNA 2 de
     "Fuente Illusion City.png") en la fuente del juego, en la celda del codigo
     0x965F, en INIT y en OPEN.
  2) Plantilla del rotulo de EQUIPO: «Equipo de» -> «<icono>EQUIPO<icono> »
     (misma longitud: 9 glifos = 18 B, asi que el nombre sigue entrando en $23E82).
  3) Plantilla del rotulo de MAGIA: «Magia de» -> «<icono>MAGIA<icono> »
     (misma longitud: 8 glifos = 16 B).
  4) El limite de la copia del nombre en EQUIPO: era 5 glifos ($22856) -> 7, que es
     lo que mide «Tianren» (el de MAGIA ya era 7).
  5) Los CORCHETES del menu de ESTADO: «［nombre］» -> «<icono>nombre<icono>»
     (dos inmediatos en $22E58 y $22E72).

POR QUE EL CODIGO 0x965F
  La rutina del juego convierte el codigo SJIS en una CELDA de la fuente
  (START $1922C + $191BE, tabla en INIT $0000, glifos en $294E0). Imitando esa rutina
  (recursos/tools/celdas_fuente.py, comprobada contra las celdas ya medidas del
  dinero y de los 16 acentos) el 0x965F cae en la celda 1349, que es el unico hueco
  del rango direccionable con UN SOLO codigo y que no aparece en ningun texto del
  disco (barridos los 167 ficheros del ISO buscando cadenas japonesas).
  Esta al lado de los kanji ya sacrificados para los acentos (方=1334 ... 洋=1431).

Uso: python3 parche_rotulos.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)

ICONO = 0x965F              # codigo SJIS que dibuja el icono
GLIFO_ICONO = '∆'           # icono elegido por David: fila 7, columna 5
CELDA = 1349                # celda de la fuente (medida con celdas_fuente.py)
BASES_FUENTE = (('INIT', 107, 149400, 0x14E0), ('OPEN', 285, 69258, 0x6D20))

TPL_MAGIA = 0x1758A         # "Ｍａｇｉａ　ｄｅ"   (16 B) en START
CORCHETE_A = 0x12E58        # move.w #$816d,(a2)+
CORCHETE_B = 0x12E72        # move.w #$816e,(a2)+
ESPACIO_CLASE = 0x12E76     # adda.w #$2,a2  (salta una celda antes de la clase)


def fw(s):
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += bytes([0x81, 0x40])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


TPL_EQUIPO = 0x13E70        # "Equipo de" en START (plantilla del menu de EQUIPO)
NOMBRE_EQUIPO = 0x12856     # move.w #$N,d2  (limite de la copia del nombre)


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual + ': se sale'
    n = len(buf)
    buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    G = f.glifos_david()
    glifo = f.a_celda12(G[GLIFO_ICONO], 0)
    raw = bytearray(open(entrada, 'rb').read())

    # --- 1) el glifo del icono en las dos copias de la fuente ---
    for nombre, lba, sz, base in BASES_FUENTE:
        d = bytearray(m.region(raw, lba, sz))
        off = base + CELDA * 18
        viejo = bytes(d[off:off + 18])
        d[off:off + 18] = glifo
        m.escribe_region(raw, lba, bytes(d))
        print('  %-5s celda %d (0x%05X): %s -> icono' % (nombre, CELDA, off, viejo.hex(' ')[:20] + '...'))

    # --- 2) plantilla del rotulo de MAGIA ---
    st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
    for off, texto, viejo_hex in (
            (TPL_MAGIA,  'MAGIA',  '826c 8281 8287 8289 8281 8140 8284 8285'),):
        viejo = bytes.fromhex(viejo_hex.replace(' ', ''))
        nuevo = ICONO.to_bytes(2, 'big') + fw(texto) + ICONO.to_bytes(2, 'big') + b'\x81\x40'
        assert len(nuevo) == len(viejo), 'el rotulo cambia de tamano: %d != %d' % (len(nuevo), len(viejo))
        assert st[off:off + len(viejo)] == viejo, \
            'la plantilla de %s no cuadra en 0x%05X: %s' % (texto, off, st[off:off + len(viejo)].hex(' '))
        pon(st, off, nuevo, 'rotulo ' + texto)
        print('  rotulo %-6s 0x%05X  %s -> %s  (%d B, igual)'
              % (texto, off, viejo.hex(' '), nuevo.hex(' '), len(nuevo)))
        print('     (el icono es el de la fila 7: %s)' % GLIFO_ICONO)

    # --- 2b) rotulo de EQUIPO: largo 2 + 10 = 12 celdas (6 + iconos + nombre de 8) ---
    # La plantilla declara el largo de la COPIA delante de la cadena («02 78 00» = 0x27800)
    # y ese 2 es el 00 que corta. Con las 8 letras del nombre hace falta 0x0A.
    # OJO: NO tocar el valor de la tabla ($00023E70): cambiarlo deja la pantalla de
    # EQUIPO SIN TITULO (probado). El nombre de 8 letras ya no se corta con el limite
    # de la rutina en 10: el rotulo son 2 celdas (marca) + 8, y el espacio que ve
    # David lo pone el juego. Comprobado en pantalla: «◊EQUIPO◊ Tian Ren» entero.
    print('  rotulo EQUIPO: largo de la copia 0x02 (3 celdas) -> 0x0A (11 celdas)')
    rotulo_eq = ICONO.to_bytes(2, 'big') + fw('EQUIPO') + ICONO.to_bytes(2, 'big') + b'\x81\x40'
    viejo_eq = bytes.fromhex('8264 8291 8295 8289 8290 828f 8140 8284 8285')
    assert len(rotulo_eq) == len(viejo_eq), 'el rotulo de EQUIPO cambia de tamano'
    assert st[TPL_EQUIPO:TPL_EQUIPO + len(viejo_eq)] == viejo_eq, \
        'la plantilla de EQUIPO no cuadra: %s' % st[TPL_EQUIPO:TPL_EQUIPO + 18].hex(' ')
    pon(st, TPL_EQUIPO, rotulo_eq, 'rotulo EQUIPO')
    print('  rotulo EQUIPO 0x%05X  %s -> %s' % (TPL_EQUIPO, viejo_eq.hex(' ')[:20], rotulo_eq.hex(' ')))

    # --- 4) limite de la copia del nombre en EQUIPO ---
    assert st[NOMBRE_EQUIPO:NOMBRE_EQUIPO + 4] in (bytes.fromhex('343c0005'),
                                                   bytes.fromhex('343c0007'),
                                                   bytes.fromhex('343c0009')), \
        'en 0x%05X esperaba move.w #$n,d2 y hay %s' % (NOMBRE_EQUIPO, st[NOMBRE_EQUIPO:NOMBRE_EQUIPO + 4].hex(' '))
    pon(st, NOMBRE_EQUIPO, bytes.fromhex('343c000a'), 'limite Equipo')
    print('  limite del nombre en EQUIPO: -> 10 glifos (0x%05X)' % NOMBRE_EQUIPO)

    # --- 5) corchetes del menu de ESTADO ---
    for off, cual in ((CORCHETE_A, 'abre'), (CORCHETE_B, 'cierra')):
        esp = bytes.fromhex('34fc') + (0x816D if cual == 'abre' else 0x816E).to_bytes(2, 'big')
        assert st[off:off + 4] == esp, 'en 0x%05X esperaba %s y hay %s' % (off, esp.hex(' '), st[off:off + 4].hex(' '))
        pon(st, off, bytes.fromhex('34fc') + ICONO.to_bytes(2, 'big'), 'corchete ' + cual)
        print('  corchete %-6s 0x%05X  $%04X -> $%04X' % (cual, off, 0x816D if cual == 'abre' else 0x816E, ICONO))

    # --- 6) el hueco entre el icono y la CLASE ---
    # La fila del nombre+clase son 16 celdas + los 2 saltos de linea de la plantilla.
    # Con «Tian Ren»/«Mei Hong» (8 glifos) + 2 iconos + 1 espacio + clase de 7 (POLICÍA)
    # son 19: se comia los dos saltos y el «NV» se pegaba a la clase (visto en pantalla).
    # Solucion: el hueco pasa de 1 celda a 0 -> 17 celdas, y los saltos se conservan.
    assert st[ESPACIO_CLASE:ESPACIO_CLASE + 4] == bytes.fromhex('d4fc0002'), \
        'en 0x%05X esperaba adda.w #$2,a2 y hay %s' % (ESPACIO_CLASE, st[ESPACIO_CLASE:ESPACIO_CLASE + 4].hex(' '))
    pon(st, ESPACIO_CLASE, bytes.fromhex('d4fc0000'), 'hueco de la clase')
    print('  hueco entre el icono y la clase: 1 celda -> 0 (0x%05X)' % ESPACIO_CLASE)

    m.escribe_region(raw, m.LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
