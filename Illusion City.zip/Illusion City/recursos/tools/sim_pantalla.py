#!/usr/bin/env python3
"""Simula el render en pantalla de las cadenas traducidas usando los
bitmaps reales de GFONT_CAST.BIN (lo que el Mega CD blitea).

Produce: texto_en_pantalla_sim.png + pantalla_simulada.html (para el Preview).
"""
import base64
import csv
import importlib.util
import re
import sys

sys.path.insert(0, 'tools')
spec = importlib.util.spec_from_file_location('g', 'tools/glifos_castellanos.py')
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)
from codificador_castellano import encode_spanish

from PIL import Image, ImageDraw

FONT = open('analisis/GFONT_CAST.BIN', 'rb').read()
SCALE = 3

# tabla castellano: char -> codigo SJIS (2 bytes) del slot secuestrado
CAST = {}
for line in open('tabla_castellano.txt'):
    ch, hx = line.split()
    CAST[ch] = bytes.fromhex(hx)
# inverso: codigo -> filas del glifo
CODE2ROWS = {}
for i, ch in enumerate(G.GLYPHS.keys()):
    CODE2ROWS[CAST[ch]] = G.GLYPHS[ch]

FW_MAP = {}
for o in range(ord('A'), ord('Z') + 1):
    FW_MAP[bytes([0x82, 0x60 + o - ord('A')])] = chr(o)
for o in range(ord('a'), ord('z') + 1):
    FW_MAP[bytes([0x82, 0x81 + o - ord('a')])] = chr(o)
for o in range(ord('0'), ord('9') + 1):
    FW_MAP[bytes([0x82, 0x4F + o - ord('0')])] = chr(o)


def glyph_index_for(code):
    """Indice de glifo para rangos fullwidth CON huecos."""
    c = (code[0] << 8) | code[1]
    if 0x824F <= c <= 0x8258:
        return c - 0x824F + 50
    if 0x8260 <= c <= 0x8279:
        return c - 0x8260 + 60
    if 0x8281 <= c <= 0x829A:
        return c - 0x8281 + 86
    return None


def glyph_rows(code):
    rows = CODE2ROWS.get(code)
    if rows:
        return rows
    gi = glyph_index_for(code)
    if gi is None:
        return None
    o = gi * 18
    bits = ''.join(f'{b:08b}' for b in FONT[o:o + 18])
    return [''.join('#' if bits[y * 12 + x] == '1' else '.'
                    for x in range(12)) for y in range(12)]


def decode_visual(enc):
    """(texto_legible, lista de filas de glifo o None)."""
    out, items = [], []
    i = 0
    while i < len(enc):
        b = enc[i]
        if b == 0x24 or b == 0x23:  # $1 / #1 marcadores: 2 ascii
            items.append((enc[i:i + 2].decode(), None))
            out.append(enc[i:i + 2].decode())
            i += 2
            continue
        if b < 0x80:
            items.append((chr(b), None))
            out.append(chr(b))
            i += 1
            continue
        code = enc[i:i + 2]
        rows = glyph_rows(code)
        if code in FW_MAP:
            out.append(FW_MAP[code])
        elif rows:
            ch = next((c for c, v in CAST.items() if v == code), '?')
            out.append(ch)
        else:
            out.append('?')
        items.append((None, rows))
        i += 2
    return ''.join(out), items


def render_strings(strings, path_png, path_html):
    COLS = 1
    W = 640
    LH = 13 * SCALE + 10
    H = 40 + len(strings) * LH
    img = Image.new('P', (W, H), 0)
    img.putpalette([0, 0, 0, 255, 255, 255] + [0] * 762)
    dr = ImageDraw.Draw(img)
    y = 20
    for trad in strings:
        enc = encode_spanish(trad)
        txt, items = decode_visual(enc)
        x = 12
        for label, rows in items:
            if rows is None:
                # marcador $1/#1 o espacio: hueco
                if label:
                    dr.rectangle([x, y + 4, x + 3 * SCALE - 1, y + 3 * SCALE + 3], outline=120)
                    dr.text((x + 4, y + 2), label, fill=120)
                x += 4 * SCALE
                continue
            for ry, row in enumerate(rows):
                for rx, c in enumerate(row):
                    if c == '#':
                        dr.rectangle([x + rx * SCALE, y + ry * SCALE,
                                      x + rx * SCALE + SCALE - 1,
                                      y + ry * SCALE + SCALE - 1], fill=1)
            x += 12 * SCALE + SCALE
        y += LH
    img.save(path_png)
    b64 = base64.b64encode(open(path_png, 'rb').read()).decode()
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Simulación de pantalla - Gen'ei Toshi [CAST]</title>
<style>body{{background:#111;color:#ccc;font-family:monospace;padding:16px}}
h2{{color:#8f8}}img{{image-rendering:pixelated;border:1px solid #444;width:960px}}</style>
</head><body>
<h2>Simulación de render — lote 1 con la fuente parcheada del juego</h2>
<p>Cada glifo son los bits REALES de GFONT_CAST.BIN (slots 420-435 secuestrados
+ fullwidth original). Los recuadros grises <tt>$1</tt> <tt>#1</tt> los sustituye
el motor en runtime por nombres y números.</p>
<img src="data:image/png;base64,{b64}">
</body></html>"""
    open(path_html, 'w').write(html)
    print(f'{path_png} y {path_html} escritos')


def main():
    rows = list(csv.DictReader(open('textos_dumper.csv', encoding='utf-8-sig')))
    trs, seen = [], set()
    for r in rows:
        t = r['traduccion_castellano'].strip()
        if t and t not in seen:
            seen.add(t)
            trs.append(t)
    render_strings(trs, 'texto_en_pantalla_sim.png', 'pantalla_simulada.html')


if __name__ == '__main__':
    main()
