#!/usr/bin/env python3
"""lee_plantilla.py - decodifica una plantilla de texto del motor (START/SSTART).

Uso:  python3 lee_plantilla.py <fichero.bin|START> <offset> [long]
      START = el START.BIN de la ISO de trabajo (por defecto)
"""
import importlib.util, os, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI); PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def dec(b):
    out, i = [], 0
    while i < len(b):
        c = b[i]
        if c == 0:
            out.append('<00>')
            if i + 1 < len(b) and b[i + 1] == 0:
                out.append('<00>'); break
            i += 1; continue
        if c == 0x2f and b[i + 1:i + 2] == b'n':
            out.append('|'); i += 2; continue
        if c == 0x26:
            out.append('&%s' % chr(b[i + 1])); i += 2; continue
        if c == 0x23:
            out.append('#%s' % chr(b[i + 1])); i += 2; continue
        n = 1 if c < 0x80 else 2
        par = b[i:i + n]
        try:
            out.append(par.decode('shift_jis'))
        except Exception:
            out.append('{%s}' % par.hex())
        i += n
    return ''.join(out)


def main():
    cual = sys.argv[1] if len(sys.argv) > 1 else 'START'
    off = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x17500
    long = int(sys.argv[3], 0) if len(sys.argv) > 3 else 160
    if cual == 'START':
        raw = open(m.BASE, 'rb').read()
        d = m.region(raw, 59, 98184)
    elif cual == 'SSTART':
        raw = open(m.BASE, 'rb').read()
        d = m.region(raw, 43, 32644)
    else:
        d = open(cual, 'rb').read()
    print('  0x%X: %s' % (off, d[off:off + long].hex(' ')))
    print('  texto: %r' % dec(d[off:off + long]))


if __name__ == '__main__':
    main()
