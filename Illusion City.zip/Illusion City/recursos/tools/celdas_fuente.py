#!/usr/bin/env python3
"""celdas_fuente.py - imita la rutina del juego que convierte un codigo SJIS en la
CELDA de la fuente (START $1922C + $191BE) y dice en que offset del fichero cae.

LA RUTINA (desensamblada del START, $191BE y $1922C)
    ; --- $1922C: SJIS -> JIS
    d1 = (cod>>8) ; d0 = cod & $FF
    d1 = (d1 - $71)*2 + 1
    if d1 >= $DF: d1 -= $80
    d0 = d0 - $1F
    if d0 >= $80: d0 -= $5F ; d1 += 1
    elif d0 > $60: d0 -= 1
    jis = (d1<<8) | d0
    ; --- $191BE: JIS -> celda
    idx = ((jis & $F00)>>4)*3/2 + ((jis & $F0))*3/2 + (((jis>>2) - 8) & $3C)
    lo  = word[INIT + idx]        ; idx siempre multiple de 4
    hi  = word[INIT + idx + 2]
    for k in range(jis & $F):     ; los bits bajos
        carry, lo = lo>>1
        if carry: hi += 2
    celda_bytes = word[INIT + hi]
    direccion = $294E0 + celda_bytes      ; (INIT file 0x14E0)

En el fichero:  offset = 0x14E0 + celda_bytes   (INIT).
Los glifos son de 18 B colocados en 12x12.

Comprobaciones conocidas (medidas antes marcando celdas):
    '＄' 0x8190 -> celda 49      '$' del dinero
    '０'-'９' 0x824F-0x8258 -> celdas 52-61
    'Ｈ' 0x8267 -> celda 69
    'á' 0x9660 -> rel 526 -> celda 1350
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
BASE_BIN = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
SECTOR, INIT_LBA, INIT_SZ = 2352, 107, 149400
BASES = {'INIT': 0x14E0, 'OPEN': 0x6D20}
REL8 = 824          # rel de la fuente de 8 px  =  celda - 824


def region(lba, size):
    raw = open(BASE_BIN, 'rb').read()
    out = bytearray()
    for k in range(0, size, 2048):
        b = (lba + k // 2048) * SECTOR + 16
        out.extend(raw[b:b + min(2048, size - k)])
    return bytes(out)


INIT = region(INIT_LBA, INIT_SZ)


def sjis_a_jis(cod):
    d1 = (cod >> 8) & 0xFF
    d0 = cod & 0xFF
    d1 = (d1 - 0x71) * 2 + 1
    if d1 >= 0xDF:
        d1 -= 0x80
    d0 -= 0x1F
    if d0 >= 0x80:
        d0 -= 0x5F
        d1 += 1
    elif d0 > 0x60:
        d0 -= 1
    return (d1 << 8) | d0


def celda(cod, tabla=INIT):
    """devuelve el indice de celda (0..) que el juego usa para ese codigo SJIS.

    OJO con el primer termino: la rutina hace  (t - $200) & $F00  y luego lo
    multiplica por 1'5.  Con el desplazamiento a secas (((t & $F00)>>4)*3/2) sale
    un indice 12 palabras MAS ARRIBA y todo da 5094: era el error que tenia esta
    herramienta.  Comprobado contra las celdas ya medidas una a una (49 = '$',
    52-61 = '0'-'9', 69 = 'H', 1334 = 'Á', 1350 = 'á', 1431 = 'ñ').
    """
    jis = sjis_a_jis(cod)
    t = jis >> 4
    i1 = (t - 0x200) & 0xF00
    i1 += i1 // 2
    i2 = t & 0xF0
    i2 += i2 // 2
    i1 += i2 + (((jis >> 2) - 8) & 0x3C)
    lo = int.from_bytes(tabla[i1:i1 + 2], 'big')
    hi = int.from_bytes(tabla[i1 + 2:i1 + 4], 'big')
    for _ in range(jis & 0xF):
        lo, c = lo >> 1, lo & 1
        if c:
            hi += 2
    v = int.from_bytes(tabla[hi:hi + 2], 'big')
    return v // 18 if v % 18 == 0 else v


def offset(cod, base=BASES['INIT'], tabla=INIT):
    return base + celda(cod, tabla) * 18


if __name__ == '__main__':
    print('  COMPROBACION contra lo ya medido (marcando celdas):')
    casos = [('＄', 0x8190, 49), ('０', 0x824F, 52), ('９', 0x8258, 61),
             ('Ｈ', 0x8267, 69), ('Ａ', 0x8260, None), ('ｚ', 0x829A, None)]
    for ch, cod, esperado in casos:
        c = celda(cod)
        ok = '' if esperado is None else ('  OK' if c == esperado else '  <<< NO CUADRA (esperado %d)' % esperado)
        print('    %s U+%04X  celda %5d   offset INIT 0x%05X%s' % (ch, cod, c, 0x14E0 + c * 18, ok))
    print()
    print('  ACENTOS (el rel de la fuente de 8 px es celda-824):')
    AC = [('Á', 0x95FB, 510), ('É', 0x966B, 529), ('Í', 0x967B, 531), ('Ó', 0x9682, 534),
          ('Ú', 0x96AF, 550), ('Ñ', 0x96B3, 554), ('Ü', 0x96BD, 557), ('¿', 0x96C5, 561),
          ('¡', 0x96DA, 568), ('á', 0x9660, 526), ('é', 0x9744, 584), ('í', 0x9755, 592),
          ('ó', 0x975F, 599), ('ú', 0x975C, 600), ('ü', 0x976C, 606), ('ñ', 0x9770, 607)]
    for ch, cod, rel in AC:
        c = celda(cod)
        print('    %s U+%04X  celda %5d  rel %5d  %s' % (ch, cod, c, c - REL8,
              'OK' if c - REL8 == rel else '<<< NO CUADRA (esperado rel %d)' % rel))
