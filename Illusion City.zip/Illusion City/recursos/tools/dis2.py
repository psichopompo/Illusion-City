#!/usr/bin/env python3
"""dis2.py - desensamblador con skipdata: no se atasca en un byte raro.

Uso:  python3 dis2.py <fichero> <offset> [n_instrucciones] [base]
      fichero = START | SSTART | ruta
"""
import importlib.util, os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
import capstone as cs


def carga(cual):
    if cual == 'START':
        return m.region(open(m.BASE, 'rb').read(), 59, 98184), 0x10000
    if cual == 'SSTART':
        return m.region(open(m.BASE, 'rb').read(), 43, 32644), 0x10000
    return open(cual, 'rb').read(), 0x10000


def main():
    cual = sys.argv[1] if len(sys.argv) > 1 else 'START'
    off = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 40
    base = int(sys.argv[4], 0) if len(sys.argv) > 4 else None
    d, b = carga(cual)
    if base is not None:
        b = base
    md = cs.Cs(cs.CS_ARCH_M68K, cs.CS_MODE_M68K_000)
    md.skipdata = True
    code = d[off:off + n * 16]
    for i in md.disasm(code, b + off):
        print('  %06X  %-24s %s %s' % (i.address, i.bytes.hex(), i.mnemonic, i.op_str))


if __name__ == '__main__':
    main()
