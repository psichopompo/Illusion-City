#!/usr/bin/env python3
"""traduce_nombres.py - nombres completos de la party en la tabla del juego (v3).

EL MEOLLO DEL ASUNTO (medido el 21/09)
--------------------------------------
La tabla de personajes esta en **INIT.BIN 0x21270** (RAM $49270): 72 entradas de
6 bytes [id:2][off1:2][off2:2] cerradas con id=$00FF. La rutina START $195A8 NO
calcula donde esta cada nombre: lee esos **offsets de 16 bits** (sumados a la base
$49246 = INIT file 0x21246) y los deja en $bd00:

    lea $49246,a2 ; move.w (a0)+,d1 ; adda.l d1,a1 ; move.l a1,(a3)+

=> Los nombres son REUBICABLES: basta cambiar su offset. Escribirlos "en su hueco"
   (lo que hacia la v2) desplazaba la tabla y por eso el segundo nombre salia con
   kanjis: la rutina leia en la posicion vieja.

DONDE VAN LOS NOMBRES LARGOS
----------------------------
  a) El bloque de la party: INIT 0x2291A..0x22959 (64 B). Se vacia y se reparte
     a medida (antes: 8 huecos de 5..11 B, que solo daban para 2 glifos).
  b) El relleno que queda entre la TABLA DE OBJETOS y la de mensajes:
     INIT 0x21918..0x2192F (24 B, todo a cero, medido en memoria: sigue a cero en
     el juego y no lo toca nadie). Es el hueco mejor colocado de todo el rango
     direccionable: 24 B seguidos.

Resultado (necesitan 82 B; hay 88):
     bloque 0x2291A: Tianren(15) Meifan(13) Houmei(13) Lee(7) Shu(7) Kai(7) = 62
     hueco  0x21918: Isaac(11) Cash(9)                                   = 20

Uso: python3 traduce_nombres.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_INIT, SZ_INIT = 107, 149400
BASE = 0x21246                  # RAM $49246
TABLA = 0x21270                 # tabla de personajes: 72 x 6 B + $00FF
FIN_TABLA = 0x21426
BLOQUE = (0x2291A, 0x22959)     # bloque de la party (64 B)
HUECO_ITEMS = (0x21918, 0x2192F)  # relleno tras la tabla de objetos (24 B)

# id -> nombre, en orden de escritura. El sitio lo decide el reparto de abajo.
# NOMBRES del canon en INGLES (version MSX, decision de David 22/09):
#   Tianren -> «Tian Ren»   Meifan -> «Mei Hong»   (8 glifos los dos)
NOMBRES = [(0, 'Tian Ren'), (1, 'Mei Hong'), (2, 'Houmei'), (11, 'Houmei'),
           (7, 'Lee'), (3, 'Shu'), (6, 'Kai'), (4, 'Isaac'), (5, 'Cash')]
# 0 = bloque de la party, 1 = hueco de la tabla de objetos
REPARTO = {0: 0, 1: 0, 2: 0, 11: 0, 7: 0, 3: 0, 6: 0, 4: 1, 5: 1}


def fw(s):
    """texto castellano -> codigos del motor (fullwidth, 2 B por glifo)"""
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif '0' <= ch <= '9':
            out += bytes([0x82, 0x4F + ord(ch) - 48])
        elif ch == ' ':
            out += bytes([0x81, 0x40])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    init = bytearray(m.region(raw, LBA_INIT, SZ_INIT))

    # --- 1) leer la tabla ---
    entradas = []
    o = TABLA
    while o < FIN_TABLA:
        pid = int.from_bytes(init[o:o + 2], 'big')
        if pid == 0x00FF:
            break
        entradas.append((o, pid, int.from_bytes(init[o + 2:o + 4], 'big'),
                         int.from_bytes(init[o + 4:o + 6], 'big')))
        o += 6
    print('  tabla de personajes: %d entradas (0x%05X..0x%05X)' % (len(entradas), TABLA, o))
    assert {pid for _, pid, _, _ in entradas} >= {0, 1, 2, 3, 4, 5, 6, 7, 11}, 'faltan ids'

    # --- 2) el hueco de la tabla de objetos tiene que estar a cero ---
    a, b = HUECO_ITEMS
    assert init[a:b + 1] == b'\x00' * (b - a + 1), 'el hueco de objetos no esta a cero'
    print('  hueco de la tabla de objetos 0x%05X..0x%05X: %d B a cero'
          % (a, b, b - a + 1))

    # --- 3) reparto ---
    destinos = {}
    # reparto: de mayor a menor, el primer hueco donde entre (los dos huecos son 64 y 24 B
    # y los 88 B de los 8 nombres entran EXACTOS: 17+13+11+9+7+7 = 64 y 17+7 = 24)
    # reparto exacto: se prueban todas las combinaciones (8 nombres, 2 huecos) y se
    # elige la primera que encaje en los DOS (88 B de nombres en 64+24 B)
    import itertools
    zonas = [(BLOQUE[0], BLOQUE[1]), (HUECO_ITEMS[0], HUECO_ITEMS[1])]
    lista = [(pid, texto) for pid, texto in NOMBRES if pid != 11]
    tallas = [(pid, len(fw(t)) + 1) for pid, t in lista]
    elegido = None
    for k in range(len(lista) + 1):
        for grupo in itertools.combinations(range(len(lista)), k):
            a = sum(tallas[i][1] for i in grupo)
            b = sum(tallas[i][1] for i in range(len(lista)) if i not in grupo)
            if a <= BLOQUE[1] - BLOQUE[0] + 1 and b <= HUECO_ITEMS[1] - HUECO_ITEMS[0] + 1:
                elegido = set(grupo); break
        if elegido is not None:
            break
    assert elegido is not None, 'los 8 nombres no caben en los dos huecos'
    for z, grupo in ((0, elegido), (1, [i for i in range(len(lista)) if i not in elegido])):
        ini, fin = zonas[z]
        libre = ini
        for i in grupo:
            pid, texto = lista[i]
            b = fw(texto) + b'\x00'
            destinos[pid] = libre
            libre += len(b)
        print('  hueco %d (0x%05X..0x%05X): %d B usados de %d'
              % (z, ini, fin, libre - ini, fin - ini + 1))
    for z, (a, c) in zip(zonas, (BLOQUE, HUECO_ITEMS)):
        print('  zona 0x%05X..0x%05X: %d B de %d usados' % (a, c, z[0] - a, c - a + 1))
    # los ids que comparten cadena
    destinos[11] = destinos[2]

    # --- 4) el bloque de la party se vacia antes de escribir ---
    for a, b in (BLOQUE, HUECO_ITEMS):
        if a == BLOQUE[0]:
            init[a:b + 1] = b'\x00' * (b - a + 1)
    escritos = set()
    for pid, texto in NOMBRES:
        datos = fw(texto) + b'\x00'
        pos = destinos[pid]
        if pos in escritos:                 # ids 2 y 11 comparten cadena
            print('  id %-3d %-8s -> 0x%05X (misma cadena que otro id)' % (pid, texto, pos))
            continue
        assert init[pos:pos + len(datos)] == b'\x00' * len(datos), \
            'zona ocupada en 0x%05X' % pos
        init[pos:pos + len(datos)] = datos
        escritos.add(pos)
        print('  id %-3d %-8s -> 0x%05X..0x%05X  (%d B, offset 0x%04X)'
              % (pid, texto, pos, pos + len(datos) - 1, len(datos), pos - BASE))

    # --- 5) offsets nuevos en la tabla ---
    for o, pid, off1, off2 in entradas:
        if pid in destinos:
            init[o + 2:o + 4] = (destinos[pid] - BASE).to_bytes(2, 'big')

    # --- 6) comprobar el resultado como lo lee el juego ---
    print('  --- lo que leera el juego ---')
    o = TABLA
    while o < FIN_TABLA:
        pid = int.from_bytes(init[o:o + 2], 'big')
        if pid == 0x00FF:
            break
        off1 = int.from_bytes(init[o + 2:o + 4], 'big')
        s = init[BASE + off1:]
        fin = s.find(b'\x00')
        try:
            txt = s[:fin].decode('shift_jis')
        except Exception:
            txt = '{%s}' % s[:fin].hex()
        if pid in destinos:
            print('    id %-3d  off1 0x%04X en 0x%05X  «%s»' % (pid, off1, BASE + off1, txt))
        o += 6

    m.escribe_region(raw, LBA_INIT, bytes(init))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
