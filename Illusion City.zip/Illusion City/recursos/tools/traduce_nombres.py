#!/usr/bin/env python3
"""traduce_nombres.py - traduce la TABLA DE NOMBRES (INIT.BIN 0x22919).

HALLAZGOS (medidos)
  - La tabla es una LISTA SECUENCIAL de cadenas terminadas en 00, de 29 entradas,
    288 B en total (INIT 0x22919..0x22A39) y solo 7 B de holgura.
  - El recuadro del HUD (panel derecho) mide 48 px y el texto empieza en x=209:
    caben 4 glifos. Mas largos se salen del recuadro.
  - Los nombres de la partida en curso viven en el SAVE: la tabla se usa al crear
    los personajes (partida nueva / al unirse).
  - El codigo castellano es FULLWIDTH (cada glifo 2 B).

QUE HACE
  Reordena el bloque entero con los nombres cortos (los que caben en el HUD) y
  deja el resto de entradas como estan. Al ser una lista secuencial, se puede
  recolocar todo dentro del MISMO bloque (no hace falta mover nada ni cambiar
  punteros), siempre que la suma quepa en los 288 B.

USO
  python3 traduce_nombres.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI); PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_INIT, SZ_INIT = 107, 149400
INI, FIN = 0x22919, 0x22A39          # bloque de la tabla (288 B)

# nombres nuevos (cortos: el HUD solo admite 4 glifos) por nombre japones original
NUEVOS = {
    '天人': 'Tian',        # canon: Tianren (7 glifos) — no cabe en el HUD
    '美紅': 'Mei',         # canon: Meifan
    'ホウメイ': 'Hou',       # canon: Houmei
    'リー': 'Lee',
    'Ｓｈｕ': 'Shu',
    'Ｉｓａａｃ': 'Isaac',
    'Ｃａｓｈ': 'Cash',
    'Ｋａｉ': 'Kai',
}


def fw(s):
    """texto -> codigos FULLWIDTH del juego (SJIS, 2 B por glifo)."""
    out = bytearray()
    for ch in s:
        if 'A' <= ch <= 'Z':   out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z': out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif '0' <= ch <= '9': out += bytes([0x82, 0x4F + ord(ch) - 48])
        elif ch == ' ':        out += bytes([0x81, 0x40])
        else: raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    init = bytearray(m.region(raw, LBA_INIT, SZ_INIT))
    bloque = bytes(init[INI:FIN])
    # parsear las entradas (secuencia: [80] texto 00 ...)
    # OJO: el prefijo 0x80 NO lo llevan todas las entradas (solo el primer bloque
    # de la tabla). Se conserva el de cada una.
    entradas = []
    o = 0
    while o < len(bloque):
        pref = 1 if bloque[o] == 0x80 else 0
        ini = o + pref
        fin = bloque.find(b'\x00', ini)
        if fin < 0:
            break
        s = bloque[ini:fin]
        if not s:
            o = fin + 1
            continue
        entradas.append((pref, s))
        o = fin + 1
    print('  %d entradas en el bloque' % len(entradas))
    # reconstruir
    nuevo = bytearray()
    cambios = []
    for pref, s in entradas:
        try:
            jp = s.decode('shift_jis')
        except Exception:
            jp = None
        if jp in NUEVOS:
            b = fw(NUEVOS[jp])
            cambios.append('%s -> %s (%d B, antes %d B)' % (jp, NUEVOS[jp], len(b) + 1, len(s) + 1))
        else:
            b = s
        nuevo += (b'\x80' if pref else b'') + b + b'\x00'
    if len(nuevo) > len(bloque):
        raise SystemExit('NO CABE: %d B en un bloque de %d' % (len(nuevo), len(bloque)))
    nuevo += b'\x00' * (len(bloque) - len(nuevo))
    init[INI:FIN] = bytes(nuevo)
    m.escribe_region(raw, LBA_INIT, bytes(init))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    for c in cambios:
        print('    %s' % c)
    print('  bloque: %d B usados de %d (holgura %d)' % (len(nuevo.rstrip(b'\x00')), len(bloque),
                                                       len(bloque) - (len(nuevo.rstrip(b'\x00')))))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
