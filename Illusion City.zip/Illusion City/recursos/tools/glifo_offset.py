#!/usr/bin/env python3
"""glifo_offset.py - direccion REAL (en el fichero INIT y en RAM) del glifo de un codigo.

OJO con la trampa que me comi: el valor que devuelve la tabla NO es siempre multiplo
de 18, asi que la direccion no es  base + celda*18.  La direccion es  base + v, con
v = word[INIT + hi] tal cual.

    fichero INIT:  0x14E0 + v
    RAM:           $294E0 + v      (INIT se carga en $28000)
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('cf', os.path.join(AQUI, 'celdas_fuente.py'))
cf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cf)


def v(cod, tabla=None):
    """el valor crudo de la tabla de indices (byte offset dentro del bloque de glifos)."""
    t = cf.INIT if tabla is None else tabla
    jis = cf.sjis_a_jis(cod)
    tt = jis >> 4
    i1 = (tt - 0x200) & 0xF00
    i1 += i1 // 2
    i2 = tt & 0xF0
    i2 += i2 // 2
    i1 += i2 + (((jis >> 2) - 8) & 0x3C)
    lo = int.from_bytes(t[i1:i1 + 2], 'big')
    hi = int.from_bytes(t[i1 + 2:i1 + 4], 'big')
    for _ in range(jis & 0xF):
        lo, c = lo >> 1, lo & 1
        if c:
            hi += 2
    return int.from_bytes(t[hi:hi + 2], 'big')


def glifo(cod, tabla=None):
    x = v(cod, tabla)
    return 0x14E0 + x, 0x294E0 + x, x


if __name__ == '__main__':
    print('  cod     char   v        fichero INIT   RAM')
    for ch, cod in (('∆', 0x965F), ('á', 0x9660), ('Á', 0x95FB), ('Ａ', 0x8260),
                    ('０', 0x824F), ('＄', 0x8190), ('Ｍ', 0x826C), ('ａ', 0x8281)):
        f, r, x = glifo(cod)
        print('  0x%04X  %s    0x%05X  0x%05X       0x%05X' % (cod, ch, x, f, r))
