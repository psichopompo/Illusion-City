#!/usr/bin/env python3
"""Primer lote de traducciones: batalla, menús, tiendas, nombres y objetos.

Castellano ultra-conciso: cada caracter ocupa 2 bytes (fullwidth), igual que
el japonés, así que las traducciones deben caber en el hueco original.
La puntuación se escribe en ASCII: el codificador la convierte (, → 、etc).
"""
import csv

LOTE = {
    # --- START.BIN: mensajes de batalla ---
    2851: "$1 hallado: sin sitio.",
    # NOTA: 2854-2859 (体力０００/術気０００) y 2861 se dejan en japonés:
    # son plantillas de las que el runtime sobreescribe los dígitos.
    2852: "EXP:#1",
    2853: "Premio #1",
    2862: "$1: veneno",
    2863: "$1 sueña",
    2866: "$1: hechizo OK",
    2873: "At.$1",
    2875: "$1: $3",
    2876: "$2: -#1 PV",
    2877: "Todos: -#1 PV",
    2878: "$2: sin daño",
    2885: "Huyeron.",
    2886: "¡Falló!",
    2892: "$1: parál.",
    2893: "$1 sueña",
    2896: "$1: piedra",
    2897: "$1: K.O.",
    2899: "$2 revive",
    2908: "$1: OK",
    2912: "At.$1",
    2915: "$1: llamó",
    2862: "$1: veneno",
    2863: "$1 sueña",
    2866: "$1: hechizo OK",
    2873: "At.$1",
    2875: "$1: $3",
    2876: "$2: -#1 PV",
    2877: "Todos: -#1 PV",
    2878: "$2: sin daño",
    2885: "Huyeron.",
    2886: "¡Falló!",
    2892: "$1: parál.",
    2893: "$1 sueña",
    2896: "$1: piedra",
    2897: "$1: K.O.",
    2899: "$2 revive",
    2908: "$1: OK",
    2912: "At.$1",
    2915: "$1: llamó",
    2917: "Item",
    2921: "Cual",
    2922: "Set",
    2924: "Item",
    2925: "Ficha",
    2926: "Sist",
    2927: "Ind.",
    2928: "Grup",
    2932: "［Cura］",
    2933: "［Mag.］",
    # --- INIT.BIN: nombres de grupo ---
    2192: "Shu",
    2193: "Isaac",
    2194: "Cash",
    2195: "Kai",
    # --- INIT.BIN: acciones de enemigos que caben ---
    2242: "$1: aliento",
    2243: "$1: cura",
    # --- objetos ---
    2299: "Mina",
    2300: "Balas",
    2302: "Carga",
    2306: "Gema",
    2310: "Tranca",
    2311: "Daga",
    2312: "Daga T",
    2314: "Urna",
    2315: "Pase",
    2316: "VIP",
    2318: "Gafas",
    2442: "Resist",
    # --- tiendas ---
    2461: "Falta oro.", 2469: "Falta oro.", 2477: "Falta oro.",
    2462: "Gracias.", 2470: "Gracias.", 2478: "Gracias",
    2463: "Lleno.", 2471: "Lleno.", 2479: "Lleno.",
    2466: "Rebajado.",
    2467: "No lo compro.",
    2468: "Botica",
    2476: "Doc",
    2484: "［Venta］",
    2485: "［Armad］",
    2486: "［Armas］",
    2487: "［Balas］",
    2488: "［Droga］",
    2489: "［Talis］",
    2490: "［Curas］",
    2491: "［Ropa］",
    2492: "［Otro］",
    # --- localizaciones ---
    2449: "Kowlo",
    2450: "Saikun",
    2451: "Planta",
    2452: "Shenlon",
    2453: "Bahía",
    2454: "Aqua",
    2455: "Fosa",
    2456: "Toro",
    2457: "Biolab",
    2458: "Shatin",
    2459: "Torre",
    2460: "Armero",
}


def main():
    rows = list(csv.DictReader(open('textos_dumper.csv', encoding='utf-8-sig')))
    n = 0
    for r in rows:
        rid = int(r['id'])
        if rid in LOTE and not r['traduccion_castellano'].strip():
            r['traduccion_castellano'] = LOTE[rid]
            n += 1
    with open('textos_dumper.csv', 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"lote aplicado: {n} traducciones")


if __name__ == '__main__':
    main()
