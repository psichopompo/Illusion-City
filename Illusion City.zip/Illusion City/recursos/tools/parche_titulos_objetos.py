#!/usr/bin/env python3
"""parche_titulos_objetos.py - tanda 96: titulos en azul oscuro + columnas de Objetos.

DAVID (96ª): las palabras entre los dos iconos de las secciones van al AZUL OSCURO
(el (32,101,172) de NIVEL/ATAQUE/DEFENSA = marca &5 = 26 35), en MAYUSCULAS; los
iconos siguen en BLANCO (&7). Titulos: MAGIA, EQUIPO, OBJETOS, TECNICAS, COMBATE,
VELOCIDAD. Ademas: Cambiar y Tirar de Objetos, un espacio a la izquierda.

ORDEN DEL SCRIPT (importante): las dos INSERCIONES (COMBATE y EQUIPO) desplazan
todo lo posterior, asi que se hace primero COMBATE (con las refs escaneadas ANTES),
despues los in-place localizados por FIRMA (inmunes al desplazamiento) y EQUIPO al
final (su offset esta antes que el de COMBATE y no se mueve).

Uso: python3 parche_titulos_objetos.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
AZUL = bytes.fromhex('2635')
BLANCO = bytes.fromhex('2637')
AMARILLO = bytes.fromhex('2634')
ROMBO = bytes.fromhex('965f')
ESP = b'\x81\x40'
AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD}


def fw(s):
    out = bytearray()
    for ch in s:
        if ch in AC:
            out += AC[ch].to_bytes(2, 'big')
        elif 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += ESP
        elif ch == '.':
            out += b'\x81\x42'
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))

    # ================= 1. COMBATE (el titulo crece a la IZQUIERDA) ============
    # CERO inserciones: insertar desplazaria todo el modulo (imagen RAM) y con
    # el todos los punteros posteriores (el tropiezo de las dos primeras versiones).
    # El titulo [26 37][rombo]COMBATE[rombo][|] se reescribe en la zona 0xFF que
    # queda ANTES de la plantilla (la dejo libre la mudanza de Tecnicas), 4 B antes:
    # [26 37][rombo][26 35]COMBATE[26 37][rombo][|]  (22 -> 26 B, acaba justo donde
    # empezaban las filas: nada posterior se mueve).
    p = fw('COMBATE')
    i = st.find(p)
    assert i == 0x1426C and st[i-2:i] == ROMBO and st[i-4:i-2] == BLANCO, (hex(i), st[i-6:i+18].hex(' '))
    S = i - 4                               # inicio del titulo (file) = RAM $24268
    r2 = st.find(ROMBO, i + len(p))
    nl = st.find(b'\x2f\x6e', r2)
    R = nl + 2                              # fin del titulo (file, exclusivo)
    L = R - S
    titulo_viejo = bytes(st[S:R])
    assert titulo_viejo[:2] == BLANCO and titulo_viejo[2:4] == ROMBO
    titulo_nuevo = (titulo_viejo[:4] + AZUL + titulo_viejo[4:r2 - S] + BLANCO +
                    titulo_viejo[r2 - S:])
    assert len(titulo_nuevo) == L + 4
    assert all(st[S - 4 + k] == 0xFF for k in range(4)), 'la zona FF previa no esta libre'
    st[S - 4:S - 4 + len(titulo_nuevo)] = titulo_nuevo
    st[S:R] = b'\xff' * L                   # el titulo viejo, fuera
    NS = S - 4                              # nuevo inicio (RAM $24264)

    # refs al titulo: el setup ($24268) y cualquier otra dentro de [S,R)
    OPC = set()
    for hi in (0x20, 0x22, 0x24, 0x26, 0x28, 0x2A, 0x2C, 0x2E):
        OPC.add(bytes([hi, 0x79]))
    for hi in (0x21, 0x23, 0x25, 0x27, 0x29, 0x2B, 0x2D):
        OPC.add(bytes([hi, 0xFC]))
        OPC.add(bytes([hi, 0x7C]))
    for hi in (0x41, 0x43, 0x45, 0x47, 0x49, 0x4B, 0x4D, 0x4F):
        OPC.add(bytes([hi, 0xF9]))

    def es_ref(k):
        v = int.from_bytes(st[k:k+4], 'big')
        if not (S + 0x10000 <= v < R + 0x10000) or k % 2:
            return False
        return bytes(st[k-2:k]) in OPC

    movidos = 0
    for k in range(4, len(st) - 4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        if S + 0x10000 <= v < R + 0x10000 and k % 2 == 0:
            o = v - (S + 0x10000)
            nv = (NS + 0x10000) + (o if o < 2 else o + 4)
            st[k:k+4] = nv.to_bytes(4, 'big')
            movidos += 1
    print('  COMBATE : titulo azul crecido a la izquierda (0x%05X, %d B); %d refs movidas'
          % (NS, len(titulo_nuevo), movidos))

    # ================= 2. TECNICAS (marca por firma) ==========================
    p = fw('TÉCNICAS')
    i = st.find(p)
    assert st[i-2:i] == AMARILLO and st[i-4:i-2] == ROMBO
    st[i-2:i] = AZUL
    print('  TECNICAS: marca -> &5 (file 0x%05X)' % (i-2))

    # ================= 3. OBJETOS (marca por firma, tras 0x17DA0+DESP1) =======
    p = fw('Objetos')
    i = st.find(p, 0x17D98)
    assert st[i-2:i] == AMARILLO and st[i-4:i-2] == ROMBO
    st[i-2:i] = AZUL
    print('  OBJETOS : marca -> &5 (file 0x%05X)' % (i-2))

    # ================= 4. MAGIA (reescribe la cabeza, por firma) ==============
    # la firma matchea EN EL ROMBO; la plantilla VIVA es la que tiene la marca
    # blanca pegada al rombo (la vieja de parche_rotulos tiene 00 00: esta muerta)
    firma_cab = ROMBO + fw('MAGIA') + ROMBO
    cab = None
    i = 0
    while True:
        i = st.find(firma_cab, i)
        if i < 0:
            break
        if st[i-2:i] == BLANCO:
            cab = i - 2
            break
        i += 1
    assert cab > 0, 'firma MAGIA (plantilla viva) no encontrada'
    nueva = BLANCO + ROMBO + AZUL + fw('MAGIA') + BLANCO + ROMBO + ESP * 7
    n = len(st)
    st[cab:cab + len(nueva)] = nueva
    assert len(st) == n
    print('  MAGIA   : cabeza azul reescrita en 0x%05X (sin cambiar longitud)' % cab)

    # ================= 5. VELOCIDAD (cadena nueva + reapunte p1) ==============
    p1 = st.find(bytes.fromhex('00027d8a'))
    assert p1 > 0
    vieja = int.from_bytes(st[p1:p1+4], 'big') - 0x10000
    # hueco: buscar 44 B de 0xFF a partir del final de la plantilla de tecnicas
    HUECO = 0x155AA
    while not all(st[HUECO + k] == 0xFF for k in range(44)):
        HUECO += 2
    cad = BLANCO + ROMBO + AZUL + fw('VELOCIDAD') + BLANCO + ROMBO + b'\x00\x00'
    assert all(st[HUECO + k] == 0xFF for k in range(len(cad)))
    st[HUECO:HUECO + len(cad)] = cad
    st[p1:p1+4] = (HUECO + 0x10000).to_bytes(4, 'big')
    st[vieja:vieja + 20] = b'\xff' * 20
    print('  VELOCIDAD: cadena nueva en 0x%05X, p1 (0x%05X) reapuntado, vieja liberada'
          % (HUECO, p1))

    # ================= 6. EQUIPO (cadena nueva en sus ceros de cola) ==========
    p = fw('EQUIPO')
    i = st.find(p)
    assert i == 0x13E72 and st[i-2:i] == ROMBO, (hex(i), st[i-6:i+18].hex(' '))
    EQ = i - 2                              # la cadena empieza en el rombo
    nueva_eq = (BLANCO + ROMBO + AZUL + p + BLANCO + ROMBO + ESP + b'\x00\x00')
    DST = EQ + 0x14                         # 0x13E84: dentro de sus propios 00s
    assert all(st[DST + k] == 0x00 for k in range(len(nueva_eq) + 2)), 'la cola no esta libre'
    st[DST:DST + len(nueva_eq)] = nueva_eq
    st[EQ:EQ + 0x14] = b'\x00' * 0x14       # la cadena vieja, fuera
    assert int.from_bytes(st[0x13E54:0x13E58], 'big') == EQ + 0x10000
    st[0x13E54:0x13E58] = (DST + 0x10000).to_bytes(4, 'big')
    print('  EQUIPO  : cadena azul en 0x%05X, entrada de tabla -> $%05X' % (DST, DST + 0x10000))

    # ================= 7. OBJETOS: columnas a la izquierda ====================
    # tabla REAL en BH: move.w #$12,$34(a0) en 0x12358 y #$21,$36(a0) en 0x1235E
    # (la 15/30 de la 84ª se perdio con la reconstruccion; esto parte de lo que ve David)
    assert st[0x12358:0x1235E] == bytes.fromhex('317c00120034'), st[0x12358:0x1235E].hex(' ')
    assert st[0x1235E:0x12364] == bytes.fromhex('317c00210036'), st[0x1235E:0x12364].hex(' ')
    st[0x1235B] = 0x11          # col de Cambiar: 18 -> 17
    st[0x12361] = 0x20          # col de Tirar:   33 -> 32
    print('  OBJETOS : columnas 18->17 y 33->32 (Cambiar y Tirar, -8 px)')

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
