#!/usr/bin/env python3
"""parche_combate.py - el menu de COMBATE a castellano (v2, mapa de celdas medido).

MAPA MEDIDO (referencia -> fila y celda dentro de la fila)
```
   fila 0 (titulo)   celda 0     -> el puntero del descriptor
   filas 2,3,4       celda 1     -> nombre      (8 letras = celdas 1..8)
                     celdas 9,13,17 -> las tres cifras (3 digitos cada una)
   fila 6 (PV/PM)    celda 0     -> 6 referencias (principio de la fila)
   filas 7,8,9       celda 1     -> nombre
                     celdas 7,11,15,19 -> las cuatro cifras (3 digitos + ／)
```
  El nombre de 8 letras cabe en las filas de ATAQUE (celdas 1..8) pero NO en las de PV/PM
  (solo 5 celdas hasta el [$7]): por eso salia «Tian R». Aqui las filas de PV/PM se
  ensanchan 4 celdas (el nombre queda en la 1 y las cifras pasan a 11,15,19,23), lo que
  deja la fila en 26 celdas = 208 px (la pantalla tiene 256 y el panel del HUD empieza
  en x=243).

Uso: python3 parche_combate.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TPL = 0x14268
ICONO = 0x965F
M4, M5, M7 = bytes.fromhex('2634'), bytes.fromhex('2635'), bytes.fromhex('2637')
SALTO, ESP = bytes.fromhex('2f6e'), bytes.fromhex('8140')
D0, SL = bytes.fromhex('824f'), bytes.fromhex('815e')
# (celda del nombre, celdas de las cifras) por fila
FILAS = {2: (1, (9, 13, 17)), 3: (1, (9, 13, 17)), 4: (1, (9, 13, 17)),
         7: (1, (7, 11, 15, 19)), 8: (1, (7, 11, 15, 19)), 9: (1, (7, 11, 15, 19))}
# desplazamiento que se le da a las cifras de las filas de PV/PM (4 celdas mas)
CORRE_PV = 4


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def fila(celdas, marcas):
    """construye una fila: celdas es una lista de bytes, marcas {celda: marca}"""
    out = bytearray()
    for i, c in enumerate(celdas):
        out += marcas.get(i, c)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    assert st[TPL:TPL + 2] == M5, 'la plantilla de COMBATE no esta donde creo'
    assert st[TPL + 182:TPL + 186] == SALTO + SALTO, 'no veo la linea vacia'

    nueva = bytearray()
    off = {}
    # --- fila 0: titulo con iconos ---
    off[('fila', 0)] = len(nueva)
    nueva += M5 + ICONO.to_bytes(2, 'big') + fw('COMBATE') + ICONO.to_bytes(2, 'big') + SALTO
    # --- fila 1: cabeceras. ATAQUE empieza en la celda 10 (x=89) y cada etiqueta va
    #     separada por un espacio; los valores se cuelan debajo de sus letras centrales ---
    nueva += M5 + ESP * 10 + fw('ATAQUE') + ESP + fw('DEFENSA') + ESP + fw('VEL') + SALTO
    # --- filas 2,3,4: datos de ATAQUE. La marca $7 va en la celda 12 (la 11 es su hueco,
    #     que no esta en la fila) y las tres cifras en las celdas 12, 20, 25 ---
    REFS_ATA = {2: (12, 20, 25), 3: (12, 20, 25), 4: (13, 21, 26)}
    for fila_i in (2, 3, 4):
        c = [ESP] * 30
        c[0] = M4
        c[12] = M7
        off[('fila', fila_i)] = len(nueva)
        for k, cel in enumerate(REFS_ATA[fila_i]):
            c[cel] = D0
            c[cel + 1] = D0
            off[('cif', fila_i, k)] = off[('fila', fila_i)] + 2 * cel
        off[('nom', fila_i)] = off[('fila', fila_i)] + 2
        nueva += fila(c, {}) + SALTO
    # --- fila 5: linea vacia ---
    nueva += SALTO
    # --- fila 6: cabeceras SALUD / MAGIA (sin cambios) ---
    off[('fila', 6)] = len(nueva)
    nueva += ESP * 11 + M5 + fw('SALUD') + ESP * 3 + fw('MAGIA') + SALTO
    # --- filas 7-9: datos de PV/PM (sin cambios) ---
    for fila_i in (7, 8, 9):
        off[('fila', fila_i)] = len(nueva)
        nueva += (M4 + ESP * (5 + CORRE_PV) + M7 + D0 * 3 + SL + D0 * 3 + ESP
                  + D0 * 3 + SL + D0 * 3 + (SALTO if fila_i < 9 else b'\x00'))
        off[('nom', fila_i)] = off[('fila', fila_i)] + 2
        for i, c in enumerate(FILAS[fila_i][1]):
            off[('cif', fila_i, i)] = off[('fila', fila_i)] + 2 * (c + CORRE_PV)
    print('  plantilla nueva: %d B (antes %d)' % (len(nueva), 0x143D0 - TPL))
    for fila_i in (2, 3, 4):
        print('   fila %d: nombre en celda 1, cifras en %s' % (fila_i, REFS_ATA[fila_i]))

    # --- mapa viejo -> nuevo (direcciones de RAM) ---
    def ram(x):
        return x + 0x10000
    mapa = {ram(TPL + 0): ram(TPL + off[('fila', 0)]),
            ram(TPL + 186): ram(TPL + off[('fila', 6)])}
    VIEJAS = {2: (58, (9, 13, 17)), 3: (100, (9, 13, 17)), 4: (142, (9, 13, 17)),
              7: (224, (7, 11, 15, 19)), 8: (270, (7, 11, 15, 19)),
              9: (316, (7, 11, 15, 19))}
    for fila_i, (base, cifras) in VIEJAS.items():
        mapa[ram(TPL + base + 2)] = ram(TPL + off[('nom', fila_i)])
        for i, c in enumerate(cifras):
            mapa[ram(TPL + base + 2 * c)] = ram(TPL + off[('cif', fila_i, i)])

    st[TPL:TPL + len(nueva)] = nueva
    n = 0
    o = 0
    while o < len(st) - 4:
        v = int.from_bytes(st[o:o + 4], 'big')
        if v in mapa:
            st[o:o + 4] = mapa[v].to_bytes(4, 'big')
            n += 1
        o += 2
    print('  %d referencias reapuntadas (%d direcciones)' % (n, len(mapa)))

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
