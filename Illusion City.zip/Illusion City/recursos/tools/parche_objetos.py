#!/usr/bin/env python3
"""parche_objetos.py - menu de OBJETOS: titulo y las tres opciones.

MEDIDO (28/09) sustituyendo las 6 entradas de la tabla por etiquetas de prueba
(Ee1..Ee6, Aaa..Fff) y midiendo en pantalla donde sale cada una:
```
   tabla de punteros en START 0x13E16  (6 longs de RAM, 4 B cada uno)
   entrada 0 -> x=36, linea de ARRIBA, 1a columna   (JP: ［Ｉｔｅｍ］)  <- el TITULO
   entrada 1 -> x=96, linea de ARRIBA, 2a columna   (JP: Ｕｓａｒ)     <- residuo
   entrada 2 -> x=156, linea de ARRIBA, 3a columna  (JP: Ｕｓａｒ)     <- residuo
   entrada 3 -> x=36, linea de ABAJO,  1a columna   (JP: Ｃａｍｂｉａｒ)
   entrada 4 -> x=96, linea de ABAJO,  2a columna   (JP: Ｔｉｒａｒ)
   entrada 5 -> x=156, linea de ABAJO, 3a columna   (JP: ＶＲ　ｔｒａｎｓｐ)
```
  (Las entradas de abajo se pintan un caracter a la izquierda: por eso en el menu de
   David se leia «sar», «ambiar», «irar» — le falta la primera letra, que cae fuera
   del recuadro. El original japones esta igual de roto.)
  Las tres SELECCIONABLES son las de abajo (3, 4 y 5).
  La caja del recuadro va de x=18 a x=205 y el marco de 0x176.. es una ventana de
  30 columnas: la linea util va de x=36 (columna 0) a x=205 (columna 21).

MAQUETA
   entrada 0:  ◊Objetos◊  con la palabra en AMARILLO (los rombos en blanco)
   entrada 3:  Usar        -> al comienzo de la linea
   entrada 4:  Cambiar     -> en el centro
   entrada 5:  Tirar       -> al final, sin desbordarse
   entradas 1 y 2: vacias (los dos residuos que no son seleccionables)

Uso: python3 parche_objetos.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
TABLA = 0x13E16
M_BLANCO, M_AMAR = b'\x26\x37', b'\x26\x34'
ROMPO = b'\x96\x5f'
ESP = b'\x81\x40'

# espacios delante de cada palabra para colocarla en su sitio
PAD_TIRAR = 1          # «Tirar» empieza en la celda 3 (x=157) + 1 espacio (8 px)
                       # => x=165..204: acaba justo en el borde del recuadro (206)


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += ESP
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def tira(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    # hueco: el primer tramo de >=200 bytes libres (0xFF) a partir de 0x17CC2.
    # (antes era fijo en 0x17DB0; con la plantilla de Magia restaurada delante se
    #  mueve todo y tiene que buscarse, como hace parche_sistema)
    libre = 0x17CC2
    while libre < len(st) - 200:
        if all(st[libre + k] == 0xFF for k in range(200)):
            break
        libre += 1
    assert libre < len(st) - 200, 'no hay hueco libre para las cadenas de Objetos'
    if libre % 2:
        libre += 1
    # OJO: cada OPCION va en su PROPIA entrada (3, 4 y 5). El cursor del juego es una
    # caja que se mueve con IZQUIERDA/DERECHA entre las tres celdas de la fila de
    # abajo (medido: caja en x=37..70, x=97..130 y x=157..190). Si las tres palabras
    # van en una sola cadena, el cursor no puede pasar de la primera.
    titulo = M_BLANCO + ROMPO + M_AMAR + fw('Objetos') + M_BLANCO + ROMPO
    trozos = [titulo,                                # 0: el titulo de la ventana
              b'',                                   # 1: residuo (arriba, centro)
              b'',                                   # 2: residuo (arriba, derecha)
              M_BLANCO + fw('Usar'),                 # 3: alineado con el rombo del titulo (x=37)
              M_BLANCO + fw('Cambiar'),              # 4: caja 85..142, llena (es la mas larga)
              M_BLANCO + ESP * 1 + fw('Tirar')]      # 5: caja 145..191, palabra centrada (153..190)
    o = libre
    for i, t in enumerate(trozos):
        st[o:o + len(t) + 1] = t + b'\x00'
        (st[TABLA + 4 * i:TABLA + 4 * i + 4]) = (o + 0x10000).to_bytes(4, 'big')
        print('  entrada %d -> $%06X  %r' % (i, o + 0x10000, t))
        o += len(t) + 1
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    tira(sys.argv[1], sys.argv[2])
