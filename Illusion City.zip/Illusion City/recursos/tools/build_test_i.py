#!/usr/bin/env python3
"""build_test_i.py - TEST_I: fuente de 8 px + titulo arreglado + textos del menu.

QUÉ LLEVA
  1. FUENTE: los glifos latinos se recolocan a la IZQUIERDA de su celda
     (78 celdas en INIT.BIN + 78 en OPEN.BIN). Necesario para el paso de 8 px.
  2. TITULO (SSTART): 'CARGAR PARTIDA' / 'CON INTRO' / 'SIN INTRO' en MAYUSCULAS,
     paso de 8 px, caja de 128 px ($04=8, $08=16) y margen interno $32=2.
  3. MENU (START): "Estado" en la fila 5 y "Dinero" en la etiqueta del dinero.

QUÉ NO LLEVA (a proposito)
  - El paso de 8 px NO se aplica al texto del juego (dialogos): ahi hay KANJI, que
    son celdas de 12x12, y con paso de 8 se solapan. El pintor de START se queda
    con su avance de 12 px hasta que se resuelva el paso MIXTO.
"""
import hashlib
import importlib.util
import os

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)

spec = importlib.util.spec_from_file_location('p', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)

def pon(buf, off, data, cual):
    """Escritura SEGURA: exige que el trozo tenga la MISMA longitud.
    (Tres veces he metido 14 bytes en un hueco de 8: eso INSERTA y desplaza todo.)"""
    assert off + len(data) <= len(buf), cual + ': se sale'
    n = len(buf)
    buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': EL FICHERO CAMBIO DE TAMANO (insercion)'


G = f.glifos_david()
dest = f.destinos()
raw = bytearray(open(os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"), 'rb').read())
st = bytearray(m.region(raw, m.LBA_START, m.SZ_START))
ss = bytearray(m.region(raw, m.LBA_SSTART, m.SZ_SSTART))

# 1) fuente a la izquierda
for nombre, (lba, sz, base) in f.TABLAS.items():
    tabla = bytearray(f.region(raw, lba, sz))
    n = 0
    for rel, ch in dest.items():
        off = base + rel * f.CELL
        if 0 <= off and off + f.CELL <= len(tabla):
            tabla[off:off + f.CELL] = f.a_celda12(G[ch], 0)
            n += 1
    f.escribe_region(raw, lba, bytes(tabla))
    print('  fuente %-5s: %d celdas' % (nombre, n))

# 2) titulo
# 'NUEVA SIN INTRO' mide 120 px y el buffer de linea del titulo es $08*8 px: con
# $08=15 (120 px) la linea daba la vuelta (la muesca de la N que ve David). El arreglo
# es ENSANCHAR el buffer a 128 px ($08=16, parche_titulo.py), no quitar el espacio.
TITULO = ['CARGAR PARTIDA', 'PARTIDA NUEVA', 'NUEVA SIN INTRO']
for k, (ram, txt) in enumerate(zip(m.STRING_RAMS, TITULO)):
    d = m.fw(txt) + b'\x00\x00'
    pon(ss, ram - 0x10000, d + b'\x00' * (0x20 - len(d)), 'titulo %d' % k)
    pon(ss, m.OFF_TABLA_TIT + k * 4, ram.to_bytes(4, 'big'), 'puntero %d' % k)
ss[0x0AC7] = 8        # $04 = 8  -> caja en x=64 (centrada)
ss[0x0AD3] = 16       # $08 = 16 -> 128 px
ss[0x0AB5] = 2        # $32 = 2  -> margen interno 8 px
ss[0x242A:0x242A + 12] = bytes.fromhex('54680014') + bytes.fromhex('4e71') * 4   # 8 px

# 3) menu
# los textos van en el hueco libre 0x17AA0+ con su terminador; el hueco de cada
# uno se reserva de 8 en 8 y se escribe SIN desplazar nada
# OJO: 'Dinero' ocupa 14 B desde 0x17AA0 -> 'Estado' NO puede ir en 0x17AB0
ESTADO_OFF = 0x17AC0
pon(st, ESTADO_OFF, m.fw('Estado') + b'\x00\x00', 'Estado')
pon(st, m.MARC_FILA_FICHA, (0x10000 + ESTADO_OFF).to_bytes(4, 'big'), 'fila 5')
pon(st, m.OFF_DINERO_ST, m.fw('Dinero') + b'\x00\x00', 'Dinero')
for off in m.LEA_DINERO:
    pon(st, off, bytes.fromhex('43f9') + (0x10000 + m.OFF_DINERO_ST).to_bytes(4, 'big'), 'lea')

# plantilla del menu de Velocidad (palabras nuevas de David)
assert st[m.OFF_TPL_VEL:m.OFF_TPL_VEL + len(m.TPL_VEL)] == b'\xff' * len(m.TPL_VEL) or \
       st[m.OFF_TPL_VEL:m.OFF_TPL_VEL + 2] == b'&5', 'la zona de la plantilla no cuadra'
pon(st, m.OFF_TPL_VEL, m.TPL_VEL, 'plantilla Velocidad')
pon(st, m.PTR_TPL_VEL, m.RAM_TPL_VEL.to_bytes(4, 'big'), 'puntero plantilla')
print('  plantilla Velocidad: %d B en $%X' % (len(m.TPL_VEL), m.RAM_TPL_VEL))

m.escribe_region(raw, m.LBA_START, bytes(st))
m.escribe_region(raw, m.LBA_SSTART, bytes(ss))
raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
out = os.path.join(PROY, 'TEST_I.bin')
open(out, 'wb').write(bytes(raw))
print('TEST_I.bin  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
v = m.edcecc.verifica_imagen(out, verbose=False)
print('EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))
