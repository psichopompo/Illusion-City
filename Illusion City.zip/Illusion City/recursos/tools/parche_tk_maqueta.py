#!/usr/bin/env python3
"""parche_tk_maqueta.py - TECNICAS: maqueta fina de David.

Base: TEST_BL (nombres ya de 8). Las 6 filas de valores se reconstruyen con los
campos "000%" en las celdas de la maqueta: v1@12, v2@19, v3@26, v4@32 (la fila
se rellena de espacios hasta la celda 35). Las refs de valores se reapuntan.
Uso: python3 parche_tk_maqueta.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'
FILAS = [76, 130, 184, 284, 338, 392]
CAMPOS_VIEJOS = [10, 14, 18, 22]          # celdas de campo en BL
CAMPOS_NUEVOS = [12, 19, 26, 32]          # celdas de campo en la maqueta
LARGO_FILA_V = 54                          # bytes de fila en BL (incl. terminador)

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    tpl = bytearray(st[T0:T0+LEN])
    base = T0 + 0x10000

    # 1) mapa de offsets: recorrer la plantilla vieja y componer la nueva
    nueva = bytearray()
    mapa = {}
    i = 0; posn = 0; idx = 0
    while i < len(tpl):
        if idx < len(FILAS) and i == FILAS[idx]:
            F = i; Fn = posn
            term = tpl[F+52:F+54]
            fila_n = bytearray(bytes.fromhex('2634') + ESP*8 + bytes.fromhex('2637'))
            fila_n += ESP * 2                     # celdas 10-11
            fila_n += bytes.fromhex('824f824f824f8193')   # campo v1: celdas 12-15
            fila_n += ESP * 3                     # celdas 16-18
            fila_n += bytes.fromhex('824f824f824f8193')   # campo v2: celdas 19-22
            fila_n += ESP * 3                     # celdas 23-25
            fila_n += bytes.fromhex('824f824f824f8193')   # campo v3: celdas 26-29
            fila_n += ESP * 2                     # celdas 30-31
            fila_n += bytes.fromhex('824f824f824f8193')   # campo v4: celdas 32-35
            fila_n += term
            for j, cv in enumerate(CAMPOS_VIEJOS):
                mapa[F + 2 + (cv-1)*2] = Fn + 2 + (CAMPOS_NUEVOS[j]-1)*2
            # mapear TODA la fila vieja a la nueva (celdas 1-8 = 1:1; el terminador
            # viejo (off F+52..53) va al final (Fn+72..73); el resto: celda a celda)
            for k in range(54):
                if F+k in mapa:
                    continue
                if k <= 17:                       # marca + espacios + 2637 (hasta off F+18? no: 16)
                    mapa[F+k] = Fn + k
                elif k >= 52:                     # terminador
                    mapa[F+k] = Fn + 72 + (k - 52)
                else:
                    # cuerpo viejo (off F+16..F+51 = celdas 9..26): celda vieja -> nueva
                    cv = (k - 16)//2 + 9
                    nueva_c = CAMPOS_NUEVOS[CAMPOS_VIEJOS.index(cv)] if cv in CAMPOS_VIEJOS else None
                    if nueva_c:
                        mapa[F+k] = Fn + 2 + (nueva_c - 1)*2 + ((k-16) % 2)
                    else:
                        mapa[F+k] = Fn + k
            nueva += fila_n
            i += LARGO_FILA_V; posn += len(fila_n); idx += 1
            continue
        mapa[i] = posn
        nueva.append(tpl[i]); i += 1; posn += 1
    print('  plantilla: %d -> %d B' % (LEN, len(nueva)))
    print('  DEBUG: idx=%d, i=%d' % (idx, i))
    assert idx == 6

    extra = len(nueva) - LEN
    assert all(st[T0+LEN+k] == 0xFF for k in range(extra)), 'sin 0xFF detras'

    # 2) reapuntar refs
    n = 0
    for k in range(4, len(st) - 4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        off = v - base
        if base <= v < base + LEN and k % 2 == 0 and off in mapa:
            st[k:k+4] = (base + mapa[off]).to_bytes(4, 'big')
            n += 1
    print('  refs reapuntadas: %d' % n)

    st[T0:T0+len(nueva)] = nueva
    st[T0+len(nueva):T0+LEN+extra] = b'\xff' * (LEN + extra - len(nueva))
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
