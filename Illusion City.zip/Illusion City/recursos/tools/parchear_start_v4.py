#!/usr/bin/env python3
"""Parche de menús/sistema de START.BIN — v4 (reubicación limpia).

Diagnóstico v3 (ver DIARIO.md):
  - Z5/Z19/Z21 se reescribieron cambiando LONGITUDES DE FILA → los writes
    absolutos del motor (lea.l $XXXX + writer) caen sobre etiquetas y
    rompen la plantilla. REGLA: mantener longitudes exactas O reubicar la
    plantilla entera con parche de puntero.
  - Z22: v3 recortó filas (Mens./Mov.) y no cumplía la spec de celdas.
  - [アイテム] quedó en japonés (offset con errata 0x13E2C en vez de 0x13E2E).
  - Strings del menú sistema en ASCII 1B → kanji basura (font sin ASCII).

v4 (los offsets del hueco libre se calculan en tiempo de ejecución,
   layout: Z22 -> Z5 -> EFG -> IT -> SY -> redirects, base 0x17500):
  * Z5  → hueco (RAM = file + 0x10000) + 7 parches de inmediato (base,
    nombre, d2 5→7, now, ind, max, grp). Filas según spec:
      L0  ［Ｍａｇｉａ］ + nombre dinámico (7 celdas, write +16, d2=7)
      L2  ＰＭ (7-8), Ｃｏｓｔｅ (10-14)
      L3  Ａｈｏｒａ (1-5) + val (6-8, 3 dígitos der. → ≤99 en 7-8)
          Ｉｎｄ (10-12) + val (13-14, 2 dígitos)
      L4  Ｍａｘ (1-3) + val (6-8) + val (10-11) + Ｇｒ (13-15)
  * Z22 → hueco + 1 parche (base @0x139B0).
      L0 Ｖｅｌｏｃｉｄａｄ 1-9 | L2 Ｒáｐｉｄｏ 4-9, Ｌｅｎｔｏ 11-15 (&4/&7)
      L3 dígitos 8-15 | L4 Ｔｅｘｔｏ 1-5 | L5 Ｍｏｖｅｒｓｅ 1-7 | L6 Ｃｏｍｂａｔｅ 1-7
  * Ventana objetivo (EFG): 3 strings al hueco + 3 parches de tabla
    (0x13DEA/DEE/DF2). La tabla (referenciada en 0x12028) queda en su sitio.
  * Ventana de objetos: 4 strings al hueco + 6 parches de tabla
    (0x13E16+4k), conservando la semántica de puntero "a mitad de cadena"
    de las entradas 4-6 del original.
  * Menú sistema: 3 strings FULLWIDTH al hueco + 3 parches de tabla
    (0x14472+4k). El ASCII de v3 salía kanji basura (font sin ASCII). El
    estado ON/OFF vive en slots 0x244B4-0x244CF (independiente) → seguro.
  * Z19: ORIGINAL + 4 swaps byte-neutros (ＮＶ, Ｎｅｘｔ, ＰＶ, ＰＭ)
    → los 16 writes absolutos vuelven a ser válidos.
  * Z21: ORIGINAL + 3 swaps (&5Ｃｏｍｂａｔｅ, Ｖ, ＰＭ) → writes válidos.
  * Z20, Z10-Z18, HUD, Z23/24, 0xEEE3, 0x1187A, menú principal: se copian
    de la pieza v3 (longitudes idénticas al original, verificadas).
  * Redirecciones de desborde (misma política v3) tras las cadenas fijas.

Salida: analisis/START_CAST.BIN (misma longitud que extraidos/START.BIN).
"""
import csv
import os
import re
import struct
import importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    'cod', os.path.join(HERE, 'codificador_castellano.py'))
cod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cod)

SRC = 'extraidos/START.BIN'
V3 = 'analisis/START_CAST_V3.BIN'   # pieza v3 LIMPIA (fuente de las zonas copiadas;
DST = 'analisis/START_CAST.BIN'     # no self-referencial: un run corrupto no envenena los siguientes)
CSV_IN = 'textos_dumper.csv'
RAM = 0x10000          # RAM = file + 0x10000
FW = '\u3000'

# --- hueco libre (0xFF, 0 refs) ---------------------------------------------
# Layout secuencial calculado en tiempo de ejecución (evita errores aritméticos):
#   Z22 -> Z5 -> EFG -> IT -> SY -> redirects.  Verificación al final.
HUECO0 = 0x17500
FIN_LIBRE = 0x17F7F   # 0x17F80-0x17F87 contiene datos; no tocar

MARK = re.compile(r'[&$#?/>][0-9A-Za-z]')
PUNCT = {':': '：', '.': '。', ',': '、', '!': '！', '-': '－',
         '(': '（', ')': '）', '%': '％', '+': '＋', '=': '＝',
         '<': '＜', '*': '＊', "'": '’'}


def enc(s):
    """Fullwidth + marcadores de control ASCII (misma política que v3)."""
    out = bytearray()
    i = 0
    while i < len(s):
        m = MARK.match(s, i)
        if m:
            out += m.group(0).encode('ascii')
            i = m.end()
            continue
        ch = s[i]
        i += 1
        if ch in cod.HIJACK:
            out += cod.HIJACK[ch]
        elif ch in '[]［］':
            out += ('［' if ch in '[［' else '］').encode('shift_jis')
        elif ch == ' ' or ch == FW:
            out += FW.encode('shift_jis')
        elif ch in PUNCT:
            out += PUNCT[ch].encode('shift_jis')
        else:
            fw = cod._fw(ch)
            if fw:
                out += fw
            else:
                out += ch.encode('shift_jis')
    return bytes(out)


def main():
    d = bytearray(open(SRC, 'rb').read())
    orig_len = len(d)
    ORIG = bytes(d)
    v3 = open(V3, 'rb').read()
    assert len(v3) == orig_len, 'pieza v3 con longitud distinta'
    informe = []

    def chk(where):
        if len(d) != orig_len:
            print(f'*** len(d)={len(d)} tras {where} ***')
            raise SystemExit(1)

    def put(off, data, tag):
        d[off:off + len(data)] = data
        chk(f'put {tag}')

    def patch32(off, new_ram, tag):
        """Parchea un u32 BE en `off` con valor de RAM, verificando el original."""
        cur = int.from_bytes(ORIG[off:off + 4], 'big')
        d[off:off + 4] = struct.pack('>I', new_ram)
        chk(f'patch32 {tag}')
        informe.append(f'  parche u32 {off:#06x}: {cur:#08x} -> {new_ram:#08x}  ({tag})')

    def swap(off, old, new, tag):
        """Sustitución byte-neutra: el original DEBE coincidir."""
        assert ORIG[off:off + len(old)] == old, \
            f'{tag}: original {off:#06x} != {old.hex()}'
        d[off:off + len(new)] = new
        chk(f'swap {tag}')
        informe.append(f'  swap {off:#06x}: {tag}')

    def copy_v3(a, b, tag):
        d[a:b] = v3[a:b]
        chk(f'copy_v3 {tag}')
        informe.append(f'  copiado de v3: {a:#06x}-{b:#06x} ({tag})')

    # ------------------------------------------------------------------
    # 0. Sanity: hueco libre íntegro
    # ------------------------------------------------------------------
    assert d[HUECO0:FIN_LIBRE + 1] == b'\xff' * (FIN_LIBRE + 1 - HUECO0), \
        'hueco libre no es todo 0xFF'

    # ------------------------------------------------------------------
    # 1. Zonas probadas en v3 (longitudes idénticas al original)
    # ------------------------------------------------------------------
    copy_v3(0x0CB20, 0x0CC10, 'HUD nombres + PV/PM')
    copy_v3(0xEEE3, 0xEF45, 'menú batalla')
    copy_v3(0x1187A, 0x118F0, 'tienda')
    copy_v3(0x13D12, 0x13D60, 'menú principal + tabla punteros')
    copy_v3(0x13E6E, 0x13F5A, 'Z10-Z15 equipo')
    copy_v3(0x13F6A, 0x13F88, 'Z16-Z18 pestañas')
    copy_v3(0x140DE, 0x14267, 'Z20 técnicas (L0 v3, 26B)')
    copy_v3(0x144C4, 0x144DA, 'Z23/24 SanaPV/SanaPM')

    # ------------------------------------------------------------------
    # 2. Z19 FICHA: original + 4 swaps byte-neutros
    #    (los 16 writes absolutos vuelven a apuntar a celdas de valor)
    # ------------------------------------------------------------------
    # códigos SJIS reales: Ｌ=826B Ｖ=8275 Ｎ=826D ｎ=828E 体=91CC 力=97CD 術=8F70 気=8B43
    swap(0x13FAC, bytes.fromhex('826b8275'), bytes.fromhex('826d8275'), 'ＬＶ→ＮＶ')
    swap(0x13FEC, bytes.fromhex('828e'), bytes.fromhex('826d'), 'ｎｅｘｔ→Ｎｅｘｔ (1ª letra)')
    swap(0x1400E, bytes.fromhex('91cc97cd'), bytes.fromhex('826f8275'), '体力→ＰＶ')
    swap(0x1402C, bytes.fromhex('8f708b43'), bytes.fromhex('826f826c'), '術気→ＰＭ')
    informe.append('  Z19: original restaurado + NV/Next/PV/PM (writes válidos)')

    # ------------------------------------------------------------------
    # 3. Z21 COMBATE: original + 3 swaps byte-neutros
    # ------------------------------------------------------------------
    # L0: 16B = &5 + 7 celdas. 'Combate' (7 celdas) sin corchetes (misma
    # solución que v3; con corchetes haría falta una 8ª celda).
    swap(0x14268, b'\x26\x35' + '［戦力データ］'.encode('shift_jis'),
         b'\x26\x35' + 'Ｃｏｍｂａｔｅ'.encode('shift_jis'), 'Z21 L0 →&5Ｃｏｍｂａｔｅ (16B)')
    swap(0x14332, bytes.fromhex('91cc97cd'), bytes.fromhex('826f8275'), 'Z21 体力→ＰＶ')
    swap(0x14342, bytes.fromhex('8f708b43'), bytes.fromhex('826f826c'), 'Z21 術気→ＰＭ')
    informe.append('  Z21: original restaurado + Combate/PV/PM (writes válidos)')

    # ------------------------------------------------------------------
    # 3b. Ventana de magia EN COMBATE (0x14F18, 39B):
    #     術気/n&5〔個〕&7００/n&5〔集〕&7００/n  ->  術気→ＰＭ (4B, byte-neutro)
    #     Sin refs u32: el motor accede por offset dentro de la plantilla.
    # ------------------------------------------------------------------
    swap(0x14F18, bytes.fromhex('8f708b43'), bytes.fromhex('826f826c'), 'ventana magia combate 術気→ＰＭ')

    # ------------------------------------------------------------------
    # 4. Construir todos los blobs del hueco libre
    # ------------------------------------------------------------------
    fw = FW.encode('shift_jis')
    OFF3 = 'ＯＦＦ'.encode('shift_jis')
    z22 = (b'\x26\x35' + enc('Velocidad')                       # L0: 20B
           + b'\x2f\x6e' + b'' + b'\x2f\x6e'                    # /n L1 /n
           + b'\x26\x34' + fw * 3
           + enc('Rápido') + fw
           + enc('Lento') + b'\x26\x37'                         # L2: 34B
           + b'\x2f\x6e' + fw * 7
           + '１２３４５６７８'.encode('shift_jis')               # L3: 30B
           + b'\x2f\x6e' + enc('Texto') + fw                     # L4: 12B
           + b'\x2f\x6e' + enc('Moverse')                        # L5: 14B
           + b'\x2f\x6e' + enc('Combate')                        # L6: 14B
           + b'\x00\x00')
    assert len(z22) == 138, f'Z22 {len(z22)} != 138'
    z5 = (enc('[Magia]') + fw                                   # L0: 30B (nombre +16, 7 celdas)
          + fw * 7
          + b'\x2f\x6e' + b'' + b'\x2f\x6e'                     # /n L1 /n
          + fw * 6 + b'\x26\x34' + enc('PM') + fw + enc('Coste')  # L2: 30B
          + b'\x2f\x6e'
          + b'\x26\x35' + enc('Ahora') + b'\x26\x37'
          + '０００'.encode('shift_jis') + fw                    # val 6-8 (+80)
          + b'\x26\x35' + enc('Ind') + b'\x26\x37'
          + '００'.encode('shift_jis')                           # val 13-14 (+98)
          + b'\x2f\x6e'
          + b'\x26\x35' + enc('Max') + fw * 2 + b'\x26\x37'
          + '０００'.encode('shift_jis') + fw                    # val 6-8 (+118)
          + '００'.encode('shift_jis') + fw                      # val 10-11 (+126)
          + b'\x26\x35' + enc('Grp') + b'\x26\x37'              # label 13-15
          + b'\x00\x00')
    assert len(z5) == 144, f'Z5 {len(z5)} != 144'
    efg_blobs = [(enc(t) + b'\x00', t) for t in ('Efecto', 'Ind', 'Grupo')]
    it_blobs = [(enc(t) + b'\x00', t) for t in ('[Item]', 'Usar', 'Cambiar', 'Tirar')]
    sy_blobs = [(enc(t) + fw + OFF3 + b'\x00', t)
                for t in ('VR transp', 'Autoesquiva', 'Conversación')]

    # ------------------------------------------------------------------
    # 5. Alocación secuencial en el hueco (sin aritmética manual)
    # ------------------------------------------------------------------
    fp = [HUECO0]

    def alloc(n, tag):
        off = fp[0]
        assert off + n <= FIN_LIBRE + 1, f'hueco insuficiente para {tag} ({n}B en {off:#06x})'
        fp[0] = off + n
        return off

    Z22_NUEVO = alloc(len(z22), 'Z22')
    Z5_NUEVO = alloc(len(z5), 'Z5')
    efg_offs = [alloc(len(b), 'EFG ' + t) for b, t in efg_blobs]
    it_offs = [alloc(len(b), 'IT ' + t) for b, t in it_blobs]
    sy_offs = [alloc(len(b), 'SY ' + t) for b, t in sy_blobs]
    REDIR0 = fp[0]
    informe.append(f'  layout hueco: Z22={Z22_NUEVO:#06x} Z5={Z5_NUEVO:#06x} '
                   f'EFG={[hex(x) for x in efg_offs]} IT={[hex(x) for x in it_offs]} '
                   f'SY={[hex(x) for x in sy_offs]} redir0={REDIR0:#06x} fin=0x{FIN_LIBRE:x}')

    # ------------------------------------------------------------------
    # 6. Colocar blobs + parches de punteros
    # ------------------------------------------------------------------
    # Z22 (1 parche de base; el init @0x139A2 escribe $22(a0) = base)
    put(Z22_NUEVO, z22, 'Z22 nueva')
    patch32(0x139B0, RAM + Z22_NUEVO, 'Z22 base (init 0x139A2)')
    d[0x143EE:0x14472] = b'\x00' * (0x14472 - 0x143EE)
    chk('Z22 old zero')

    # Z5 (7 parches: base, nombre, d2, now, ind, max, grp)
    put(Z5_NUEVO, z5, 'Z5 nueva')
    Z5B = RAM + Z5_NUEVO
    patch32(0x11DEA, Z5B,          'Z5 base (init 0x11DE8)')
    patch32(0x11E02, Z5B + 16,     'Z5 nombre (lea 0x11E00)')
    # d2: move.w #$5, d2 @0x11E06-0x11E09 = 34 3C 00 05 (inmediato en 0x11E08)
    assert ORIG[0x11E06:0x11E0A] == bytes.fromhex('343c0005'), 'fmt d2'
    d[0x11E08:0x11E0A] = b'\x00\x07'
    chk('Z5 d2')
    informe.append('  parche d2 0x11E08: #5 -> #7 (nombre hasta 7 celdas)')
    patch32(0x11E16, Z5B + 80,     'Z5 ahora (lea 0x11E14, writer $18722 3 dígitos)')
    patch32(0x11E58, Z5B + 98,     'Z5 ind (lea 0x11E56, writer $186D6 2 dígitos)')
    patch32(0x11E68, Z5B + 118,    'Z5 max (lea 0x11E66, writer $18722)')
    patch32(0x11E9A, Z5B + 126,    'Z5 grp (lea 0x11E98, writer $186D6)')
    d[0x13D60:0x13DE8] = b'\x00' * (0x13DE8 - 0x13D60)
    chk('Z5 old zero')

    # EFG: tabla in-situ @0x13DEA (referenciada por código @0x12028)
    for off, (b, t) in zip(efg_offs, efg_blobs):
        put(off, b, f'EFG {t}')
    for t_off, s_off in zip((0x13DEA, 0x13DEE, 0x13DF2), efg_offs):
        patch32(t_off, RAM + s_off, f'EFG tabla -> {s_off:#06x}')

    # IT: 6 entradas de tabla; las 4-6 del original apuntaban a +2 (1er char):
    # se conserva el mismo desplazamiento
    for off, (b, t) in zip(it_offs, it_blobs):
        put(off, b, f'IT {t}')
    for t_off, s_off in [(0x13E16, it_offs[0]), (0x13E1A, it_offs[1]), (0x13E1E, it_offs[1]),
                         (0x13E22, it_offs[1] + 2), (0x13E26, it_offs[2] + 2),
                         (0x13E2A, it_offs[3] + 2)]:
        patch32(t_off, RAM + s_off, f'IT tabla -> {s_off:#06x}')

    # SY: menú sistema (ON/OFF independiente, slots 0x244B4-0x244CF)
    for off, (b, t) in zip(sy_offs, sy_blobs):
        put(off, b, f'SY {t}')
    for t_off, s_off in zip((0x14472, 0x14476, 0x1447A), sy_offs):
        patch32(t_off, RAM + s_off, f'SY tabla -> {s_off:#06x}')

    # ------------------------------------------------------------------
    # 9. Redirecciones de desborde (misma política v3: solo con refs u32)
    # ------------------------------------------------------------------
    def refs_be32(val):
        pat = struct.pack('>I', val)
        res, i = [], 0
        while True:
            i = ORIG.find(pat, i)
            if i < 0:
                return res
            res.append(i)
            i += 1

    free_ptr = [REDIR0]
    redirects = {}

    def slot_end(off):
        e = ORIG.find(b'\x00', off)
        return (e + 1) if e >= 0 else off + 1

    def zona(items, nombre):
        for old_off, txt in items:
            b = enc(txt)
            need = len(b) + 1
            e_old = slot_end(old_off)
            refs = refs_be32(RAM + old_off)
            if need <= e_old - old_off:
                d[old_off:old_off + len(b)] = b
                d[old_off + len(b):e_old] = b'\x00' * (e_old - old_off - len(b))
                informe.append(f'  {nombre}: {old_off:#06x} in-situ {txt!r}')
            elif refs:
                fp = free_ptr[0]
                assert fp + need <= FIN_LIBRE, f'{nombre}: sin hueco libre'
                d[fp:fp + len(b)] = b
                d[fp + len(b)] = 0
                redirects[RAM + old_off] = RAM + fp
                informe.append(f'  {nombre}: {old_off:#06x} -> LIBRE {fp:#06x} {txt!r} (refs x{len(refs)})')
                free_ptr[0] = fp + need
            else:
                informe.append(f'  {nombre}: {old_off:#06x} sin refs ni hueco -> japones ({txt!r})')
            chk(f'zona {nombre} {old_off:#06x}')

    zona([(0xEEE3, 'Atacar'), (0xEEEA, 'Defender'), (0xEEF1, 'Huir'),
          (0xEEF8, 'Magia'), (0xEEFF, 'Objetos')], 'batalla-pj')
    zona([(0xEF08, 'Mutar'), (0xEF11, 'Garras'), (0xEF18, 'Qi'),
          (0xEF21, 'Cañón'), (0xEF28, 'MBH'), (0xEF2F, 'Curar'),
          (0xEF36, 'Ametralladora'), (0xEF3D, 'Pasar')], 'habilidades')
    zona([(0x13D30, 'Objetos'), (0x13D3A, 'Equipo'), (0x13D42, 'Hablar'),
          (0x13D4A, 'Ficha'), (0x13D56, 'Sistema')], 'menu-ppal')
    zona([(0x11888, '(Mun x100)'), (0x118A0, 'Cualquiera'), (0x118AA, 'Equipar'),
          (0x118B4, 'x 1'), (0x118BC, 'x 10'), (0x118C4, 'Todos'),
          (0x118E2, 'Sí'), (0x118EA, 'No')], 'tienda')

    n_red = 0
    for old, new in redirects.items():
        for p in refs_be32(old):
            d[p:p + 4] = struct.pack('>I', new)
            n_red += 1
    chk('redirects')
    informe.append(f'redirecciones u32 aplicadas: {n_red} (free_ptr final {free_ptr[0]:#06x})')

    # ------------------------------------------------------------------
    # 10. Resto de traducciones del CSV (in-situ, zonas no propias)
    # ------------------------------------------------------------------
    owned = [(0x0CB20, 0x0CC10), (0xEEE3, 0xEF45), (0x1187A, 0x118F0),
             (0x13D12, 0x13E60), (0x13E6E, 0x13F5A), (0x13F6A, 0x13F88),
             (0x13F8A, 0x140DD), (0x140DE, 0x14267), (0x14268, 0x143D8),
             (0x143D8, 0x144B4), (0x144C4, 0x144DA),
             (HUECO0, FIN_LIBRE + 1)]
    rows = list(csv.DictReader(open(CSV_IN, encoding='utf-8-sig')))
    ok = skip = err = 0
    for row in rows:
        if row['archivo'] != 'START.BIN':
            continue
        trad = row['traduccion_castellano'].strip()
        if not trad:
            continue
        off = int(row['offset_archivo'], 16)
        if any(a <= off < b for a, b in owned):
            skip += 1
            continue
        end = d.find(b'\x00', off)
        if end < 0:
            continue
        slen = end - off + 1
        try:
            new = cod.encode_spanish(trad)
        except cod.EncodeError:
            err += 1
            continue
        if len(new) + 1 > slen:
            err += 1
            informe.append(f'  CSV no cabe: {off:#06x} {trad!r}')
            continue
        d[off:off + slen] = new + b'\x00' + b'\x00' * (slen - len(new) - 1)
        chk(f'csv {off:#06x}')
        ok += 1
    informe.append(f'CSV passthrough: ok={ok} zona_propia={skip} errores={err}')

    if len(d) != orig_len:
        raise SystemExit(f'AVISO: longitud {len(d)} != {orig_len}; no escribo')
    os.makedirs('analisis', exist_ok=True)
    open(DST, 'wb').write(bytes(d))
    print('\n'.join(informe))
    print(f'{DST} escrito ({len(d)} B, sin cambio de tamaño)')


if __name__ == '__main__':
    main()
