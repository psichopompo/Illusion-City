"""mide_tabla_nombres.py - mide la tabla de nombres de la party (OPEN.BIN) y la cabida
del canon castellano.

La tabla esta en OPEN.BIN a partir de 0xF00B: entradas [00] nombre [00] seguidas.
Se mide el hueco real de cada una (hasta el byte 0x80 de la siguiente entrada).

Uso: python3 mide_tabla_nombres.py
"""
import os

SECTOR = 2352
PROY = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RAW = open(os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"), 'rb').read()
OPEN_LBA, OPEN_SZ = 285, 69258
CANON = {'天人': 'Tianren', '美紅': 'Meifan', 'ホウメイ': 'Houmei', 'シュウ老師': 'Maestro Shu',
         'アイザック': 'Isaac', 'カッシュ': 'Cash', '薬師カイ': 'Kai', 'リー': 'Lee',
         'ドク': 'Doc', 'アイレン': 'Airén', 'シャオメイ': 'Xiao Mei'}


def extrae(lba, sz):
    d = bytearray()
    for k in range(0, sz, 2048):
        b = lba + k // 2048
        d += RAW[b * SECTOR + 16: b * SECTOR + 16 + min(2048, sz - k)]
    return bytes(d)


OPEN = extrae(OPEN_LBA, OPEN_SZ)


def main():
    print('  TABLA DE NOMBRES (OPEN.BIN 0xF00B) — entradas [00] nombre [00]:')
    o = 0xF00B
    filas = []
    while o < 0xF0C0:
        assert OPEN[o] in (0x00, 0x80), 'estructura inesperada en 0x%X' % o
        ini = o + 1
        fin = OPEN.find(b'\x00', ini)
        s = OPEN[ini:fin]
        # el hueco va desde ini hasta el inicio de la siguiente entrada
        nxt = fin + 1
        while nxt < len(OPEN) and OPEN[nxt] == 0x00:
            nxt += 1
        hueco = nxt - ini
        try:
            t = s.decode('shift_jis')
        except Exception:
            t = '{%s}' % s.hex()
        filas.append((o, t, len(s), hueco))
        print('   %05X  %-12s %2d B de texto | hueco %2d B -> caben %d glifos'
              % (o, t, len(s), hueco, (hueco) // 2))
        o = nxt
    print()
    print('  CABIDA DEL CANON CASTELLANO (cada glifo = 2 B):')
    for off, t, lg, hueco in filas:
        if t in CANON:
            cs = CANON[t]
            n = len(cs)
            cabe = 2 * n <= hueco
            print('   %-12s -> %-13s %2d glifos = %2d B en hueco de %2d B   %s'
                  % (t, cs, n, 2 * n, hueco, 'CABE' if cabe else 'NO CABE -> ' + cs[:hueco // 2]))


if __name__ == '__main__':
    main()
