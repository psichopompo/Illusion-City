#!/usr/bin/env python3
"""Parchea GFONT.BIN con los glifos castellanos y regenera track01.iso + .bin.

- Slots 420-435 de GFONT.BIN <- 16 glifos castellanos 12x12
- Emitirá también la tabla de códigos SJIS para el codificador de texto
"""
import codecs, shutil
from PIL import Image, ImageDraw
import importlib.util

spec = importlib.util.spec_from_file_location("g", "tools/glifos_castellanos.py")
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)

def encode_glyph(rows):
    bits = ''.join('1' if c == '#' else '0' for row in rows for c in row)
    return bytes(int(bits[i:i+8], 2) for i in range(0, 144, 8))

def main():
    font = bytearray(open('extraidos/GFONT.BIN','rb').read())
    chars = list(G.GLYPHS.keys())
    # Slots REALES verificados visualmente (hoja original 415-439):
    # 422=方 423=北 424=本 425=魔 426=民 427=無 428=命 429=滅 430=目
    # 431=冒 432=優 433=誘 434=誉 435=予 436=様 437=用
    # El orden NO es SJIS-ascendente: es el orden de uso en el texto.
    HIJACK_SLOTS = {'Á':422,'É':423,'Í':424,'Ó':425,'Ú':426,'Ñ':427,
                    'Ü':428,'¿':429,'¡':430,'á':431,'é':432,'í':433,
                    'ó':434,'ú':435,'ü':436,'ñ':437}
    slot_codes = []
    for i, ch in enumerate(chars):
        slot = HIJACK_SLOTS[ch]
        off = slot * 18
        font[off:off+18] = encode_glyph(G.GLYPHS[ch])
        # SJIS code of the hijacked kanji
        kanji = G.HIJACK_KANJI[i]
        code = codecs.encode(kanji, 'shift_jis')
        slot_codes.append((ch, code))
    open('analisis/GFONT_CAST.BIN','wb').write(bytes(font))
    print("GFONT_CAST.BIN escrito:", len(font), "bytes")

    with open('informes/tabla_castellano.txt','w') as f:
        for ch, code in slot_codes:
            f.write(f"{ch}\t{code.hex().upper()}\n")
    print("informes/tabla_castellano.txt escrito")


if __name__ == '__main__':
    main()
