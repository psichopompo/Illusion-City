#!/usr/bin/env python3
"""parche_magia2.py - menu de MAGIA: maqueta castellana (peticion de David).

MODELO DE COLUMNAS (MEDIDO, ver DIARIO 80ª tanda)
    celda_en_pantalla = indice_del_elemento_visible + 2      x = 1 + 8*celda
  - Cada elemento VISIBLE de la plantilla avanza 1 columna (8 px).
  - Los saltos '|' (2f 6e) pasan de linea; las marcas 26 xx (color) NO cuentan.
  - Los escritores de numeros escriben N caracteres SEGUIDOS (alineados a la
    IZQUIERDA del campo): $18722 -> 3 (' ' + 2 digitos), $186D6 -> 2 (' ' + 1).
    => el digito cae en la ULTIMA celda del campo.
  - La ventana mide $8 columnas; el texto se corta si se pasa (por eso el panel
    se ensancha: $8 = 0x17 en el original).

MAQUETA PEDIDA
    dc:      2  3  4  5  6  7  8  9 10 11 12 13 14 15 ... 22 23 24 25
    linea2:                             P  M     C  o  s  t  e
    linea3:  A  h  o  r  a        1  0           I  n  d  i  v  i  d  u  a  l    2
    linea4:  M  a  x  i  m  o     1  0           G  r  u  p  o                   8
    - PM en dc 9-10 (una columna a la derecha del original)
    - Coste en dc 13 (dos espacios a la derecha de PM)
    - Individual/Grupo empiezan en dc 14 = la 'o' de Coste
    - los dos valores de arriba (Ahora/Maximo) en dc 9-10 (una columna mas)
    - el valor 2 y el 8 en dc 25 (justo uno debajo del otro)

Uso:
    python3 parche_magia2.py <entrada.bin> <salida.bin> [ancho] [sinacento]
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
TPL = 0x1758A                  # plantilla actual
LIBRE = 0x17CC2                # hueco libre 0x17CC1-0x17F7F. PAR a proposito: el 68000
                               # tira el bit 0 de las direcciones, asi que TODAS las
                               # referencias (base + offset) tienen que ser pares.
ICONO = b'\x96\x5f'
ACENTOS = {'á': 0x9660, 'é': 0x9744, 'í': 0x9755, 'ó': 0x975F, 'ú': 0x975C,
           'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF}
ESP = b'\x81\x40'
SALTO = b'\x2f\x6e'
M_BLANCO, M_AMAR, M_AZUL = b'\x26\x37', b'\x26\x34', b'\x26\x35'
MAX_NOMBRE = 8
ANCHO_DEF = 25                 # $8: columnas de la ventana. Medido: con 24 el motor
                               # corta y baja el valor de Individual a la linea de
                               # abajo; 25 es el minimo que lo deja todo en su sitio
                               # (marco derecho en x=221, el mas estrecho posible)

# columnas (INDICES de elemento visibles) de la maqueta de David
#   celda = indice + 2      x = 1 + 8*celda
#   PM            +1      -> celdas 10-11
#   Coste         2 a la derecha de PM -> celdas 13-17 (la 'o' en la 15)
#   Ahora/Maximo  su campo (3) -> celdas 9-11 (el '10' en 10-11, debajo de PM)
#   Individual    bajo la 'o' de Coste -> celdas 15-24
#   Grupo         bajo la 'o' de Coste -> celdas 15-19
#   sus valores   1 espacio despues de Individual -> campo 26-27, digito en la 27
C_PM, C_COSTE = 8, 11
C_LAB, C_VAL2 = 11, 22   # la 'I' de Individual y la 'G' de Grupo justo debajo de la
                         # 'C' de Coste (celda 13); el valor NO se mueve: celda 24, el
                         # digito en la 25
C_VAL = 7
ANCHO_DEF = 25
ESPACIO_FINAL = 28


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += ESP
        elif ch in ACENTOS:
            out += ACENTOS[ch].to_bytes(2, 'big')
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


class Linea(bytearray):
    def __init__(self):
        super().__init__()
        self.col = 0
        self.pos = {}

    def esp(self, n=1):
        self += ESP * n
        self.col += n
        return self

    def txt(self, t):
        self += fw(t)
        self.col += len(t)
        return self

    def marca(self, m):
        self += m
        return self

    def a_col(self, c):
        assert c >= self.col, 'la columna %d ya ha pasado' % c
        return self.esp(c - self.col)

    def campo(self, n, donde, marca=M_BLANCO):
        self.marca(marca)
        self.pos[donde] = len(self)
        return self.esp(n)

    def fin(self):
        self += SALTO
        return self


def monta(acento=True):
    L = []
    l = Linea()                                   # 0: titulo + nombre
    l.marca(M_BLANCO)
    l += ICONO; l.txt('MAGIA'); l += ICONO
    l.esp(1)
    l.pos['nombre'] = len(l); l.esp(MAX_NOMBRE)
    l.fin(); L.append(l)

    l = Linea(); l.fin(); L.append(l)              # 1: vacia

    l = Linea()                                    # 2: PM / Coste
    l.a_col(C_PM).marca(M_AMAR).txt('PM')
    l.a_col(C_COSTE).txt('Coste')
    l.fin(); L.append(l)

    l = Linea()                                    # 3: Ahora / Individual
    l.marca(M_AZUL).txt('Ahora')
    l.a_col(C_VAL).campo(3, 'val_ahora')
    l.a_col(C_LAB).marca(M_AZUL).txt('Individual')
    l.a_col(C_VAL2).campo(2, 'val_ind')            # dc 24-25 -> el '2' en la 25
    l.fin(); L.append(l)

    l = Linea()                                    # 4: Maximo / Grupo
    l.marca(M_AZUL).txt('Máximo' if acento else 'Maximo')
    l.a_col(C_VAL).campo(3, 'val_max')
    l.a_col(C_LAB).marca(M_AZUL).txt('Grupo')
    l.a_col(C_VAL2).campo(2, 'val_grp')            # mismo sitio: el '8' bajo el '2'
    l.esp(1)
    l += b'\x00\x00'
    L.append(l)

    off, base = {}, 0
    for lin in L:
        for k, v in lin.pos.items():
            off[k] = base + v
        base += len(lin)
    tpl = b''.join(bytes(x) for x in L)
    return tpl, off


def aplica(entrada, salida, ancho=ANCHO_DEF, acento=True):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    assert st[TPL:TPL + 2] == ICONO, 'no reconozco el titulo de MAGIA'
    tpl, off = monta(acento)
    print('  plantilla nueva: %d B' % len(tpl))
    for k, v in off.items():
        print('    %-10s +0x%02X  -> dc %d  (x=%d)' % (k, v, (v // 2) + 2, 1 + 8 * ((v // 2) + 2)))
    s2 = importlib.util.spec_from_file_location('lp', os.path.join(AQUI, 'lee_plantilla.py'))
    lp = importlib.util.module_from_spec(s2); s2.loader.exec_module(lp)
    print('  texto: %s' % lp.dec(tpl))
    assert st[LIBRE:LIBRE + len(tpl)] == b'\xff' * len(tpl), 'el hueco no esta libre'
    st[LIBRE:LIBRE + len(tpl)] = tpl
    refs = {0x2758A: LIBRE + 0x10000,
            0x2759A: LIBRE + off['nombre'] + 0x10000,
            0x275DA: LIBRE + off['val_ahora'] + 0x10000,
            0x275EC: LIBRE + off['val_ind'] + 0x10000,
            0x27600: LIBRE + off['val_max'] + 0x10000,
            0x27612: LIBRE + off['val_grp'] + 0x10000}
    n = 0
    for o in range(0, len(st) - 4, 2):
        v = int.from_bytes(st[o:o + 4], 'big')
        if v in refs:
            st[o:o + 4] = refs[v].to_bytes(4, 'big')
            n += 1
    print('  %d referencias reapuntadas' % n)
    # ancho de la ventana ($8) y limite del nombre
    assert st[0x11EB8:0x11EBE] == bytes.fromhex('317c00170008'), st[0x11EB8:0x11EBE].hex(' ')
    st[0x11EBA:0x11EBC] = int(ancho).to_bytes(2, 'big')
    print('  ancho de la ventana: 0x17 -> 0x%02X (%d columnas)' % (ancho, ancho))
    assert st[0x11E06:0x11E0A] == bytes.fromhex('343c0007')
    st[0x11E08:0x11E0A] = MAX_NOMBRE.to_bytes(2, 'big')
    print('  limite del nombre: 7 -> %d glifos' % MAX_NOMBRE)
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    ancho = int(sys.argv[3], 0) if len(sys.argv) > 3 else ANCHO_DEF
    acento = not (len(sys.argv) > 4 and sys.argv[4] == 'sinacento')
    aplica(sys.argv[1], sys.argv[2], ancho, acento)
