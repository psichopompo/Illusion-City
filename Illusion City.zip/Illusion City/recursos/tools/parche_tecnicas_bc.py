#!/usr/bin/env python3
"""parche_tecnicas_bc.py - el menu de TECNICAS con la maqueta del log de David.

OBJETIVO (log Tecnicas.txt, lineas 2416-2433; titulo = TECNICAS a peticion de David):
```
   ∆TÉCNICAS∆                        <- palabra AMARILLA, rombos BLANCOS
            ARMA RIFLE OBÚS CAÑÓN    <- los nombres COMPLETOS
   Tian Ren   65%   49%   0%    0%   <- un % detras de CADA cifra (tambien la 4a col.)
   Mei Hong   46%   62%  37%    0%
              0%    0%   0%    0%
           GARRA  VARA ESP.  HILO
   Tian Ren    0%    0%  58%    0%
   Mei Hong    0%    0%   0%   71%
              0%    0%   0%    0%
```

ESTRATEGIA (medido sobre TEST_BC):
- La plantilla vive en START 0x140DE-0x14267. El codigo la referencia con 71 longs
  absolutos en START (36 direcciones) + 2 en SSTART. Ni INIT ni OPEN la tocan.
- Mudar la plantilla ENTERA al hueco libre de 0x15410 (8.6 KB de 0xFF) y reapuntar
  LAS 73 referencias (la 88ª solo reapunto 2: por eso aquello revento).
- Al estar en hueco libre, las inserciones (crecer) no desplazan a COMBATE ni a nada.
- Crecimientos: titulo +2 B (los rombos y el color), fila de rótulos 1 +2 B (CAÑÓN
  = 21 celdas), y +2 B en CADA fila de valores (el % de la 4a columna). Total +16 B.
- Los separadores entre campos de cifra (8140) pasan a % (8193); el digito cae en
  la ULTIMA casilla de su campo, asi que el % queda pegado a la cifra.

Uso: python3 parche_tecnicas_bc.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
LBA_S, SZ_S = 43, 32644
OLD = 0x140DE                   # plantilla actual (file offset), RAM $240DE
OLD_END = 0x14268
RAM_OLD, RAM_OLD_END = OLD + 0x10000, OLD_END + 0x10000
NEW = 0x15410                   # hueco libre grande, PAR, RAM $25410
RAM_NEW = NEW + 0x10000

AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD, 'á': 0x9660, 'é': 0x9744, 'í': 0x9755,
      'ó': 0x975F, 'ú': 0x975C, 'ü': 0x976C, 'ñ': 0x9770}
ROMBO = b'\x96\x5f'
M_BLANCO, M_AMAR, M_AZUL = b'\x26\x37', b'\x26\x34', b'\x26\x35'
ESP = b'\x81\x40'
PORC = b'\x81\x93'
SALTO = b'\x2f\x6e'
CERO = b'\x82\x4f'


def fw(ch):
    if ch in AC:
        return AC[ch].to_bytes(2, 'big')
    if 'A' <= ch <= 'Z':
        return bytes([0x82, 0x60 + ord(ch) - 65])
    if 'a' <= ch <= 'z':
        return bytes([0x82, 0x81 + ord(ch) - 97])
    if ch == '.':
        return b'\x81\x42'
    raise SystemExit('sin glifo: %r' % ch)


def fwa(t):
    out = bytearray()
    for ch in t:
        out += ESP if ch == ' ' else fw(ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    tpl = bytearray(st[OLD:OLD_END])
    assert len(tpl) == OLD_END - OLD == 394
    assert st[NEW:NEW + 440] == b'\xff' * 440, 'el hueco de destino no esta libre'

    # ---------- mapa de la plantilla original (lineas por 2f6e) ----------
    lineas = []
    ini = 0
    i = 0
    while i < len(tpl) - 1:
        if tpl[i:i+2] == SALTO:
            lineas.append([ini, i + 2])
            ini = i + 2
        i += 1
    lineas.append([ini, len(tpl)])
    titulo, lab1 = lineas[0], lineas[1]
    g1, lab2, g2 = lineas[2:5], lineas[6], lineas[7:10]
    assert tpl[0:2] == M_AZUL and tpl[2:18] == m.fw('Tecnicas')
    assert tpl[lab1[0]:lab1[0]+2] == M_AZUL
    assert tpl[lab2[0]:lab2[0]+2] == M_AZUL
    for r in g1 + g2:
        assert tpl[r[0]:r[0]+2] == M_AMAR

    # ---------- inserciones ( offsets locales, de mayor a menor ) ----------
    ins = [r[1] - 2 for r in g1 + g2]     # delante del salto/terminador de cada fila
    ins.append(lab1[1] - 2)               # sitio para CAÑON (21 celdas)
    ins.append(titulo[1] - 2)             # sitio para el titulo con rombos (26 B)
    ins.sort(reverse=True)
    print('  inserciones locales: %s' % ' '.join('0x%02X' % p for p in ins))
    for p in ins:
        tpl[p:p] = ESP                    # placeholder; el caminador lo convierte en %

    def d(off):
        return 2 * sum(1 for p in ins if p <= off)

    # ---------- textos ----------
    # (las marcas &5 se BUSCAN en la plantilla ya insertada: los offsets de
    #  lineas son de ANTES de crecer y estan viejos)
    t = 2                                 # el texto del titulo (tras la marca &5)
    cad = M_BLANCO + ROMBO + M_AMAR + fwa('TÉCNICAS') + M_BLANCO + ROMBO
    assert len(cad) == 26
    tpl[t:t+26] = cad
    marcas = [i for i in range(0, len(tpl) - 2, 2) if tpl[i:i+2] == M_AZUL]
    assert len(marcas) == 3, marcas       # titulo(0), lab1, lab2
    l1 = marcas[1] + 2
    cad = fwa('ARMA RIFLE OBÚS CAÑÓN')
    assert len(cad) == 42, len(cad)
    tpl[l1:l1+42] = cad
    l2 = marcas[2] + 2
    cad = fwa('GARRA VARA ESP. HILO')
    assert len(cad) == 40, len(cad)
    tpl[l2:l2+40] = cad
    print('  titulo ∆TÉCNICAS∆ + rótulos ARMA RIFLE OBÚS CAÑÓN / GARRA VARA ESP. HILO')

    # filas de valores: caminar desde cada marca &4; 8140 tras cifras -> %
    filas = []
    i = 0
    while i < len(tpl) - 4:
        # las filas de valores son las marcas &4 SEGUIDAS de espacio (el campo
        # del nombre); el &4 del titulo va seguido de la 'T' de TECNICAS
        if tpl[i:i+2] == M_AMAR and tpl[i+2:i+4] == ESP:
            filas.append(i)
        i += 2
    assert len(filas) == 6, filas
    for a in filas:
        i = a + 2
        grupos = 0
        prev_dig = False
        while i < len(tpl) - 1:
            par = tpl[i:i+2]
            if par == SALTO or par == b'\x00\x00':
                break
            if par == CERO:
                prev_dig = True
            elif par == ESP and prev_dig:
                tpl[i:i+2] = PORC
                grupos += 1
                prev_dig = False
            else:
                prev_dig = False
            i += 2
        assert grupos == 4, (hex(a), grupos)
    print('  6 filas de valores: 3 separadores -> %% y %% final (4a columna)')

    # ---------- colocar la plantilla nueva y liberar la vieja ----------
    assert len(tpl) == 394 + 16
    st[NEW:NEW + len(tpl)] = tpl
    st[OLD:OLD_END] = b'\xff' * (OLD_END - OLD)
    print('  plantilla mudada: 0x%05X -> 0x%05X (%d B) y la vieja liberada' %
          (OLD, NEW, len(tpl)))

    # ---------- reapuntado de las referencias (SOLO las de verdad) ----------
    # MEDIDO sobre TEST_BC: 6 lea $24xxxx,aN + 1 move.l #$240DE,(An,Dw) del setup
    # + una tabla dc.l en 0x13150-0x131C4. Los demas matches del escaneo son
    # casualidades (operandos partidos, offsets impares): REAPUNTARLOS ROMPE EL
    # JUEGO (asi murio TEST_BH #1: ni siquiera cargaba la partida).
    def nueva_dir(v):
        off = v - RAM_OLD
        return RAM_NEW + off + d(off)

    OPC = set()
    for hi in (0x20, 0x22, 0x24, 0x26, 0x28, 0x2A, 0x2C, 0x2E):
        OPC.add(bytes([hi, 0x79]))          # move.l $abs,Dn/An
    for hi in (0x21, 0x23, 0x25, 0x27, 0x29, 0x2B, 0x2D):
        OPC.add(bytes([hi, 0xFC]))          # move.l #imm,(abs)/(An)
        OPC.add(bytes([hi, 0x7C]))          # move.l #imm,(An,Dw)
    for hi in (0x41, 0x43, 0x45, 0x47, 0x49, 0x4B, 0x4D, 0x4F):
        OPC.add(bytes([hi, 0xF9]))          # lea $abs,An

    def es_ref(stl, i):
        v = int.from_bytes(stl[i:i+4], 'big')
        if not (RAM_OLD <= v < RAM_OLD_END) or i % 2:
            return False
        if bytes(stl[i-2:i]) in OPC:
            return True
        # entrada de tabla dc.l: el long vecino (anterior o siguiente) tambien
        # apunta a la plantilla (asi entra la PRIMERA entrada de la tabla)
        pv = int.from_bytes(stl[i-4:i], 'big')
        nv = int.from_bytes(stl[i+4:i+8], 'big') if i + 8 <= len(stl) else 0
        return (RAM_OLD <= pv < RAM_OLD_END) or (RAM_OLD <= nv < RAM_OLD_END)

    # decidir PRIMERO (sobre los bytes originales; si reapunto en el mismo
    # bucle, la cadena de la tabla se rompe con la 2a entrada)
    objetivos = [i for i in range(4, len(st) - 4, 2) if es_ref(st, i)]
    sst0 = m.region(bytes(raw), LBA_S, SZ_S)
    st2 = [i for i in range(4, len(sst0) - 4, 2) if es_ref(sst0, i)]
    for i in objetivos:
        st[i:i+4] = nueva_dir(int.from_bytes(st[i:i+4], 'big')).to_bytes(4, 'big')
    sst = bytearray(sst0)
    for i in st2:
        sst[i:i+4] = nueva_dir(int.from_bytes(sst[i:i+4], 'big')).to_bytes(4, 'big')
    n = len(objetivos) + len(st2)
    print('  referencias reapuntadas (solo lea/move.l/tabla): %d (START %d + SSTART %d)'
          % (n, len(objetivos), len(st2)))

    m.escribe_region(raw, LBA, bytes(st))
    m.escribe_region(raw, LBA_S, bytes(sst))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
