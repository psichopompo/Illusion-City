#!/usr/bin/env python3
"""Glyph identification v2: multi-size reference rendering + best match."""
from PIL import Image, ImageFont, ImageDraw
import os, json

GLYPH = 18

def parse_glyph(d, idx):
    tile = d[idx*GLYPH:(idx+1)*GLYPH]
    bits = ''.join(f'{b:08b}' for b in tile)
    return [[1 if bits[y*12+x] == '1' else 0 for x in range(12)] for y in range(12)]

def render_ref(ch, font, ox, oy, thresh):
    img = Image.new('L', (12, 12), 0)
    dr = ImageDraw.Draw(img)
    dr.text((ox, oy), ch, fill=255, font=font)
    px = img.load()
    return [[1 if px[x, y] >= thresh else 0 for x in range(12)] for y in range(12)]

def score(a, b):
    s = 0
    for y in range(12):
        for x in range(12):
            if a[y][x] and b[y][x]: s += 2
            elif a[y][x] != b[y][x]: s -= 1
    return s

def main():
    d = open('extraidos/GFONT.BIN', 'rb').read()
    n = len(d)//GLYPH
    chars = set()
    for f in ['INIT.BIN', 'START.BIN', 'A00.BIN', 'B00.BIN', 'C00.BIN']:
        t = open(f'extraidos/{f}','rb').read()
        i = 0
        while i < len(t)-1:
            b = t[i]
            if (0x81 <= b <= 0x9F or 0xE0 <= b <= 0xEF) and (0x40 <= t[i+1] <= 0xFC):
                try: chars.add(bytes(t[i:i+2]).decode('shift_jis'))
                except: pass
                i += 2
            else: i += 1
    cand = [' '] + [chr(c) for c in range(0x20, 0x7F)] + sorted(chars)
    fontpaths = ['/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc',
                 '/System/Library/Fonts/ヒラギノ明朝 ProN.ttc']
    refs = []
    n_var = 0
    fp = fontpaths[0]
    font = ImageFont.truetype(fp, 12)
    for ch in cand:
        for ox in (0,):
            for oy in (-1, 0):
                for th in (120,):
                    refs.append((12, render_ref(ch, font, ox, oy, th)))
                    n_var += 1
    print("ref variants:", n_var // max(len(cand),1))
    mapping = {}
    for g in range(n):
        bm = parse_glyph(d, g)
        if sum(sum(r) for r in bm) == 0:
            mapping[g] = ' '
            continue
        best, bs = None, -10**9
        for ch in cand:
            s = 0
            for sz, rb in refs:
                pass
            # match only the single variant of this ch
            break
        # simple: single variant per char
        for i, ch in enumerate(cand):
            rb = refs[i][1]
            s = score(bm, rb)
            if s > bs:
                bs, best = s, (ch, 12)
        mapping[g] = best if best else ('?', 0)
    json.dump({str(k): list(v) for k, v in mapping.items()},
              open('font_map2.json','w', encoding='utf-8'), ensure_ascii=False)
    print(''.join((mapping[g][0] if mapping[g] else '?') for g in range(n)))

main()
