#!/usr/bin/env python3
"""lista_iso.py - lista los ficheros del ISO9660 de un .bin de 2352 B/sector.

Uso:  python3 lista_iso.py [fichero.bin] [offset_a_localizar]
"""
import os, struct, sys

SECTOR = 2352
BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                    "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")


def leer(d, lba, n):
    return d[lba * SECTOR + 16: lba * SECTOR + 16 + n]


def main():
    f = sys.argv[1] if len(sys.argv) > 1 else BASE
    objetivo = int(sys.argv[2], 0) if len(sys.argv) > 2 else None
    d = open(f, 'rb').read()
    pvd = None
    for lba in range(16, 40):
        blk = leer(d, lba, 2048)
        if blk[1:6] == b'CD001':
            pvd = blk
            print('PVD en LBA %d' % lba)
            break
    root = pvd[156:190]
    rlba = struct.unpack('<I', root[2:6])[0]
    rsize = struct.unpack('<I', root[10:14])[0]
    print('raiz: LBA %d, %d B' % (rlba, rsize))
    salida = []

    def recorre(lba, size, prefijo=''):
        nsec = (size + 2047) // 2048
        for k in range(nsec):
            buf = leer(d, lba + k, 2048)
            pos = 0
            while pos + 1 < len(buf) and buf[pos] > 0:
                ln = buf[pos]
                r = buf[pos:pos + ln]
                if len(r) < 34:
                    break
                flags = r[25]
                ext = struct.unpack('<I', r[2:6])[0]
                sz = struct.unpack('<I', r[10:14])[0]
                nl = r[32]
                nombre = r[33:33 + nl].decode('ascii', 'replace').split(';')[0]
                pos += ln
                if nombre in ('\x00', '\x01'):
                    continue
                if flags & 2:
                    recorre(ext, sz, prefijo + nombre + '/')
                else:
                    inicio = ext * SECTOR + 16
                    fin = inicio + sz
                    salida.append((prefijo + nombre, ext, sz, inicio, fin))
                    if objetivo is not None and inicio <= objetivo < fin:
                        print('  *** %s esta en 0x%X..0x%X : el offset 0x%X esta en +0x%X ***'
                              % (prefijo + nombre, inicio, fin, objetivo, objetivo - inicio))
    recorre(rlba, rsize)
    for nombre, ext, sz, ini, fin in salida:
        print('  %-22s LBA %-7d 0x%08X..0x%08X  %8d B' % (nombre, ext, ini, fin, sz))
    print('total %d ficheros' % len(salida))


if __name__ == '__main__':
    main()
