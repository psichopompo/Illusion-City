#!/usr/bin/env python3
"""mapa_caracteres.py - la tabla definitiva: caracter castellano -> codigo -> celda.

Fuentes de la verdad:
  - Los SIMBOLOS que el propio motor escribe en sus plantillas (START): se sacan
    barriendo los textos del disco por los codigos del bloque 0x81xx.
  - La correspondencia que usa el CODIFICADOR de los textos ya traducidos
    (recursos/tools/codificador_castellano.py, PUNCT_CANDIDATES).
  - La rutina del juego codigo->celda (celdas_fuente.py), validada contra las
    celdas medidas una a una.

Uso: python3 mapa_caracteres.py [--csv]
"""
import codecs
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('cf', os.path.join(AQUI, 'celdas_fuente.py'))
cf = importlib.util.module_from_spec(spec); spec.loader.exec_module(cf)

BASE_INIT = 0x14E0

# caracter castellano -> (codigo del motor, de donde sale)
CARACTERES = [
    # --- fila 1 del PNG ---
    ('.',  0x8142, 'codificador: 。'),
    (',',  0x8141, 'codificador: 、'),
    (':',  0x8146, 'codificador: ：'),
    (';',  0x8147, 'codificador: ；'),
    ('!',  0x8149, 'codificador: ！'),
    ('?',  0x8148, 'codificador: ？'),
    ('(',  0x8169, 'codificador: （'),
    (')',  0x816A, 'codificador: ）'),
    ('[',  0x816D, 'plantillas del motor'),
    (']',  0x816E, 'plantillas del motor'),
    ('%',  0x8193, 'plantilla de PRE (91%)'),
    ('+',  0x817B, 'plantilla de ATA (4+ 75)'),
    ('-',  0x817C, 'codificador: －'),
    ('/',  0x818E, 'codificador: ／'),
    ('=',  0x8181, 'codificador: ＝'),
    ('*',  0x8196, 'codificador: ＊'),
    ('~',  0x815E, 'plantilla de PV/PM (12 ~ 12)'),
    ('—',  0x815C, 'codificador: ―'),
    ('"',  0x8171, 'codificador: 」'),
    ('$',  0x8190, 'la linea del dinero'),
]


def celda_de(cod):
    c = cf.celda(cod)
    return c if isinstance(c, int) and c < 4000 else None


def main():
    print('  %-4s %-8s %-7s %-9s %s' % ('chr', 'codigo', 'celda', 'offset', 'procedencia'))
    mal = []
    for ch, cod, donde in CARACTERES:
        try:
            c = celda_de(cod)
        except Exception:
            c = None
        if c is None:
            mal.append((ch, cod, donde))
            print('  %-4s U+%04X  NO SE PUEDE CALCULAR           %s' % (ch, cod, donde))
            continue
        print('  %-4s U+%04X  %-7d 0x%05X   %s' % (ch, cod, c, BASE_INIT + c * 18, donde))
    print()
    if mal:
        print('  SIN CELDA: %s' % mal)
    # caracteres del PNG sin codigo en el juego
    print('  --- caracteres de tu PNG que necesitan una celda secuestrada ---')
    for ch in ('¿', '¡', '«', '»', '◊', '÷', '#', '∆'):
        print('    %s' % ch)


if __name__ == '__main__':
    main()
