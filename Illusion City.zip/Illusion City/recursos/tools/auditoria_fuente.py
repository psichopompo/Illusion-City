#!/usr/bin/env python3
"""auditoria_fuente.py - QUE caracteres de la fuente original siguen sin sustituir.

Para cada caracter de la fuente de David (Fuente Illusion City.png) se busca el
codigo SJIS que el juego usa para ESE caracter, se calcula su celda con la rutina
del juego (celdas_fuente.py) y se dibuja el glifo que hay HOY en esa celda, para
ver de un vistazo si ya lleva el de David o sigue el original.

Uso: python3 auditoria_fuente.py [--todo]
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('cf', os.path.join(AQUI, 'celdas_fuente.py'))
cf = importlib.util.module_from_spec(spec); spec.loader.exec_module(cf)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)

BASE_INIT = 0x14E0            # tabla de fuente de los menus (INIT)


def dibuja(celda, base=BASE_INIT):
    """glifo de la fuente del juego en esa celda, en ASCII art"""
    o = base + celda * 18
    d = cf.INIT[o:o + 18]
    filas = []
    for r in range(12):
        fila = ''
        for c in range(12):
            bit = 12 * r + c
            fila += '#' if (d[bit // 8] >> (7 - bit % 8)) & 1 else '.'
        filas.append(fila)
    # recorta
    cols = [c for c in range(12) if any(filas[r][c] == '#' for r in range(12))]
    fils = [r for r in range(12) if '#' in filas[r]]
    if not cols:
        return ['(vacia)']
    return [filas[r][min(cols):max(cols) + 1] for r in range(min(fils), max(fils) + 1)]


def dibuja_david(ch):
    G = f.glifos_david()
    g = G[ch]
    rows = [''.join('#' if g[r, c] else '.' for c in range(8)) for r in range(8)]
    cols = [c for c in range(8) if any(g[r, c] for r in range(8))]
    fils = [r for r in range(8) if g[r].any()]
    if not cols:
        return ['(vacia)']
    return [rows[r][min(cols):max(cols) + 1] for r in range(min(fils), max(fils) + 1)]


# caracter de la fuente de David -> codigos SJIS que el juego usa para el
# (medido: los textos del disco estan en fullwidth, 0x81xx)
MAPA = {
    '.': [0x8144], ',': [0x8141], ':': [0x8146], ';': [0x8147],
    '!': [0x8149], '?': [0x8148], '(': [0x8169], ')': [0x816A],
    '[': [0x816D], ']': [0x816E], '"': [0x8168], '%': [0x8193],
    '$': [0x8190], '+': [0x817B], '-': [0x817C], '~': [0x8160],
    '—': [0x815C], '/': [0x818E], '=': [0x8181], '*': [0x8196],
}


def main():
    print('  %-4s %-8s %-6s %s' % ('chr', 'codigo', 'celda', 'lo que hay HOY en esa celda'))
    for ch, cods in MAPA.items():
        for cod in cods:
            try:
                c = cf.celda(cod)
            except Exception as e:
                print('  %-4s %04X     ERROR %s' % (ch, cod, e)); continue
            gl = dibuja(c)
            dj = dibuja_david(ch)
            print('  %-4s U+%04X  celda %-5d  %s' % (ch, cod, c, gl[0] if gl else ''))
            for r in range(1, max(len(gl), len(dj))):
                izq = gl[r] if r < len(gl) else ''
                der = dj[r] if r < len(dj) else ''
                print('                              %-14s | %s' % (izq, der))
            print('                              %-14s' % ('(izquierda = juego, derecha = tu PNG)'))


if __name__ == '__main__':
    main()
