#!/usr/bin/env python3
"""parche_cursor_objetos_v2.py - cursor del menu de OBJETOS: caja a medida por opcion.

MEDIDO (28/09, v2)
  El pintor del recuadro (RAM $20430) calcula d2 = $2e - 3 y dibuja d2+1 columnas
  de 12 px + una esquina de 8 px. El ancho total es 20 + 12*(d2+1) px.

  El gancho se inserta en el punto donde el pintor lee $2e (file 0x1048A, 6 B:
  `move.w $2e(a0),d2 + subq.w #3,d2`). Los 6 B se cambian por `bsr gancho` (4 B)
  + `nop` (2 B). El gancho pone d2 con el valor de la tabla y vuelve.

  El gancho SOLO actua si la ventana es la de Objetos ($22(a0)=$23E16 y
  $24(a0)=$0002). Los demas menus siguen por el camino de siempre ($2e-3).

  Tabla de 4 entradas de 4 B (en RAM $27F10):
    [0] dummy ($2c empieza en 1)
    [1] Usar:    d2=0 (34 px)
    [2] Cambiar: d2=2 (58 px)
    [3] Tirar:   d2=1 (46 px)

Uso: python3 parche_cursor_objetos_v2.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
PINTOR = 0x1048A                    # `move.w $2e(a0),d2 + subq.w #3,d2` (6 B) en RAM $2048A
G = 0x17F20                         # hueco libre (file) = RAM $27ED2

# Bytes del gancho, escritos a mano y verificados con capstone:
#   +$00  48E7 4000        movem.l d1,-(a7)
#   +$04  2268 0022        movea.l $22(a0),a1
#   +$08  0C69 3E16        cmpi.w #$3E16,(a1)      <- palabra baja de $22
#   +$0C  66 08            bne.s .comun            (+$08 desde la instr siguiente)
#   +$0E  0C69 0002 0002   cmpi.w #$0002,$2(a1)    <- palabra alta de $22
#   +$14  66 0A            bne.s .comun            (+$0A desde la instr siguiente)
#   +$16  3228 002C        move.w $2C(a0),d1
#   +$1A  D241             add.w d1,d1
#   +$1C  D241             add.w d1,d1
#   +$1E  43F9 0027 F110   lea $27F10,a1           <- la tabla
#   +$24  D3C1             adda.w d1,a1            <- a1 = tabla + opcion*4
#   +$26  3410             move.w (a1),d2          <- d2 = ancho
#   +$28  6004             bra.s .fin              (+$04 desde la instr siguiente)
#   .comun:
#   +$2A  3428 002E        move.w $2E(a0),d2
#   +$30  5742             subq.w #3,d2
#   .fin:
#   +$32  4E71             nop                     <- (el pintor sigue normalmente)
#   tabla:
#   +$34  0000 0000        [0] dummy
#   +$38  0000 0000        [1] Usar: d2=0
#   +$3C  0002 0000        [2] Cambiar: d2=2
#   +$40  0001 0004        [3] Tirar: d2=1
#   total: $44 = 68 B


def gancho_bytes():
    g = bytearray()
    g += bytes.fromhex('48e74000')                 # movem.l d1,-(a7)
    g += bytes.fromhex('22680022')                 # movea.l $22(a0),a1
    g += bytes.fromhex('0c693e16')                 # cmpi.w #$3e16,(a1)
    g += bytes([0x66, 0x08])                       # bne.s .comun (+8)
    g += bytes.fromhex('0c6900020002')             # cmpi.w #$0002,$2(a1)
    g += bytes([0x66, 0x0a])                       # bne.s .comun (+$0a)
    g += bytes.fromhex('3228002c')                 # move.w $2c(a0),d1
    g += bytes.fromhex('d241')                     # add.w d1,d1
    g += bytes.fromhex('d241')                     # add.w d1,d1
    g += bytes.fromhex('43f9') + (0x27F10).to_bytes(4, 'big')  # lea $27f10,a1
    g += bytes.fromhex('d3c1')                     # adda.w d1,a1
    g += bytes.fromhex('3410')                     # move.w (a1),d2
    g += bytes([0x60, 0x04])                       # bra.s .fin (+4)
    g += bytes.fromhex('3428002e')                 # .comun: move.w $2e(a0),d2
    g += bytes.fromhex('5742')                     # .comun: subq.w #3,d2
    g += bytes.fromhex('4e71')                     # .fin: nop
    # tabla
    g += bytes.fromhex('00000000')                 # [0] dummy
    g += bytes.fromhex('00000000')                 # [1] Usar: d2=0
    g += bytes.fromhex('00020000')                 # [2] Cambiar: d2=2
    g += bytes.fromhex('00010004')                 # [3] Tirar: d2=1
    return bytes(g)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    assert st[PINTOR:PINTOR + 6] == bytes.fromhex('3428002e5742'), \
        'el pintor no tiene los bytes esperados: %s' % st[PINTOR:PINTOR + 6].hex(' ')
    assert st[G:G + 2] == b'\xff\xff', 'el hueco no esta libre'

    g = gancho_bytes()
    st[G:G + len(g)] = g
    off = (0x10000 + G) - (0x10000 + PINTOR + 2)
    st[PINTOR:PINTOR + 6] = bytes([0x61, 0x00]) + (off & 0xffff).to_bytes(2, 'big') \
        + bytes.fromhex('4e71')
    print('  gancho en 0x%05X (%d B) -> RAM $%06X ; bsr %+d' % (G, len(g), 0x10000 + G, off))

    import capstone
    cs = capstone.Cs(capstone.CS_ARCH_M68K, capstone.CS_MODE_BIG_ENDIAN | capstone.CS_MODE_M68K_000)
    print('  --- gancho ---')
    for i in cs.disasm(bytes(st[G:G + len(g)]), 0x10000 + G):
        print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                      i.mnemonic + ' ' + i.op_str))
    print('  --- pintor parcheado ---')
    for i in cs.disasm(bytes(st[PINTOR - 4:PINTOR + 14]), 0x10000 + PINTOR - 4):
        print('    %06X  %-14s %s' % (i.address, ' '.join('%02x' % b for b in i.bytes),
                                      i.mnemonic + ' ' + i.op_str))

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
