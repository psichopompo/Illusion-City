#!/usr/bin/env python3
"""Disassemble 68000 code from an offset in the ISO."""
import sys
import capstone as cs

path = sys.argv[1]
off = int(sys.argv[2], 0)
count = int(sys.argv[3]) if len(sys.argv) > 3 else 40
base = int(sys.argv[4], 0) if len(sys.argv) > 4 else 0  # logical base address (e.g. 0x8C000 + off)

data = open(path, 'rb').read()
md = cs.Cs(cs.CS_ARCH_M68K, cs.CS_MODE_M68K_000)
code = data[off:off+count*6]
for insn in md.disasm(code, off + base):
    print(f"{insn.address:08X}: {insn.bytes.hex():<12} {insn.mnemonic} {insn.op_str}")
