#!/usr/bin/env python3
"""parche_tk_rotulos7.py - TECNICAS: rótulos de armas +7 celdas a la derecha.

Base: TEST_BL. SOLO se tocan los dos rótulos (ARMA/RIFLE/OBÚS/CAÑÓN y
GARRA/VARA/ESP./HILO): se desplazan 7 celdas (14 B) hacia la derecha.

Las filas de valores se desplazan TAMBIÉN 14 B dentro de la plantilla (mismo
contenido, mismas celdas de pantalla) porque los rótulos crecidos pisarían sus
primeros bytes, y SUS referencias (blanker + campos) se actualizan +14.
El render lee la plantilla EN ORDEN (título, rótulo, filas...), así que todo
tiene que seguir dentro del bloque de la plantilla.

Layout nuevo (viejo -> nuevo):
  rotulo1: 30..75 (46 B)   -> 30..89  (60 B)
  fila v1: 76..129 (54 B)  -> 90..143
  fila v2: 130..183        -> 144..197
  fila v3: 184..237        -> 198..251
  rotulo2: 240..283 (44 B) -> 254..311 (58 B)
  fila v4: 284..337        -> 312..365
  fila v5: 338..391        -> 366..419
  fila v6: 392..445        -> 420..473
(entre fila v3 y rótulo2 hay 2 B de hueco; el total crece 28 B sobre los 0xFF
que había detrás de la plantilla)

Uso: python3 parche_tk_rotulos7.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA, SZ = 59, 98184
T0, LEN = 0x15410, 446
ESP = b'\x81\x40'
DESPLAZ = 14

# (off_viejo, largo) de cada bloque, EN ORDEN: rotulos y filas de valores
BLOQUES = [
    (30, 46, 'rotulo1'),   # 30..75
    (76, 54, 'fila v1'),   # 76..129
    (130, 54, 'fila v2'),  # 130..183
    (184, 54, 'fila v3'),  # 184..237
    (240, 44, 'rotulo2'),  # 240..283
    (284, 54, 'fila v4'),  # 284..337
    (338, 54, 'fila v5'),  # 338..391
    (392, 54, 'fila v6'),  # 392..445
]
# bloques que crecen (+14): los dos rótulos
CRECEN = {0, 4}

def aplica(ent, sal):
    raw = bytearray(open(ent, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    base = T0 + 0x10000
    tpl = bytearray(st[T0:T0+LEN])

    # 1) calcular el layout nuevo y el mapa de offsets
    nueva = bytearray()
    mapa = {}                     # off_viejo -> off_nuevo (por byte)
    posn = 0
    for idx, (F, ln, nombre) in enumerate(BLOQUES):
        crece = DESPLAZ if idx in CRECEN else 0
        # hueco entre el bloque anterior y este:
        hueco = (F - (BLOQUES[idx-1][0] + BLOQUES[idx-1][1])) if idx > 0 else F
        if hueco > 0:
            nueva += tpl[posn:posn+hueco] if False else b'\xff' * hueco
            for k in range(hueco):
                mapa[F - hueco + k] = posn + k
            posn += hueco
        # mapear byte a byte el bloque viejo:
        for k in range(ln):
            mapa[F+k] = posn + (k + crece if k >= 2 else k)
        # copiar el bloque: cabecera (2 B marca) inmediata, cuerpo desplazado
        nueva += tpl[F:F+2]                     # la marca (&5/&4) en su sitio
        nueva += ESP * (crece//2)               # los 7 espacios extra (rótulos)
        nueva += tpl[F+2:F+ln-2]                # el cuerpo original
        nueva += tpl[F+ln-2:F+ln]               # el terminador
        posn += ln + crece
    print('  plantilla: %d -> %d B' % (LEN, len(nueva)))
    extra = len(nueva) - LEN
    assert all(st[T0+LEN+k] == 0xFF for k in range(extra)), 'sin 0xFF detras'

    # 2) reapuntar refs
    n = 0
    for k in range(4, len(st)-4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        off = v - base
        if 0 <= off < LEN and k % 2 == 0 and off in mapa:
            st[k:k+4] = (base + mapa[off]).to_bytes(4, 'big')
            n += 1
    print('  refs reapuntadas: %d' % n)

    st[T0:T0+len(nueva)] = nueva
    st[T0+len(nueva):T0+len(nueva)+16] = b'\xff' * 16
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(sal, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())

if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
