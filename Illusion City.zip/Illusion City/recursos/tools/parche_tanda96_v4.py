#!/usr/bin/env python3
"""parche_tanda96_v2.py - los cambios menores de David, AHORA sin romper nada.

Base: TEST_BH. Salida: TEST_BJ2. CERO inserciones netas (las que hay se compensan
restando en la misma cadena, para no mover ni un puntero del resto del modulo).

1) MAGIA: cabeza con &5 en la palabra y los DOS iconos en blanco. La cadena original
   es [26 37][rombo]MAGIA[rombo][9 espacios][||]...; meto &5 delante de MAGIA y
   QUITO UN ESPACIO de la cola: longitud identica, el nombre que el codigo escribe
   mas adelante cae EXACTAMENTE donde caia (el fallo "∆MAGIATian Ren" de la BJ v1).
2) OBJETOS (menu): palabra "Objetos" -> "OBJETOS" (in-place, 7 letras = 7 letras)
   y su marca 2634 -> 2635.
3) OBJETOS: columna de Cambiar 17 -> 16 (un espacio mas a la izquierda).
4) VELOCIDAD popup: la cadena vuelve a ser la de BH ("Velocidad" a secas); NO se toca.
5) VELOCIDAD pantalla: la palabra "Velocidad" del titulo interior se colorea.
   (la marca concreta se calibra fuera, con capturas; aqui se deja preparado el sitio)
6) EQUIPO (menu): la cadena se rehace en sus ceros de cola con &5 y los dos iconos,
   actualizando su unica referencia. (La ventana de nombres del EQUIPO, eso es la
   siguiente tarea; aqui solo el titulo del menu.)
7) COMBATE: el titulo crece 4 B hacia la IZQUIERDA (la zona FF que dejo la mudanza
   de Tecnicas) y se rellena con [26 37][rombo][26 35]COMBATE[26 37][rombo][|];
   la unica referencia al titulo (el setup) se actualiza. Nada posterior se mueve.
8) DINERO: "Dinero: " pasa a AMARILLO (&3): la referencia del menu (0x10B06) se
   apunta a una cadena nueva [&3]Dinero:  en hueco libre; la vieja se libera.
9) TECNICAS: la marca de la palabra ya esta a &5 desde parche_tecnicas_bc... NO:
   en BH la palabra lleva 2634 delante (el titulo se escribio con M_AMAR); se
   cambia a 2635 in-place.

Uso: python3 parche_tanda96_v2.py <entrada.bin> <salida.bin> [marca_velocidad]
  marca_velocidad: hex de la marca para el titulo de la pantalla Velocidad
  (calibracion; por defecto 35)
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
AZUL = bytes.fromhex('2635')
BLANCO = bytes.fromhex('2637')
AMARILLO = bytes.fromhex('2634')
ROMBO = bytes.fromhex('965f')
ESP = b'\x81\x40'
AC = {'Á': 0x95FB, 'É': 0x966B, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
      'Ñ': 0x96B3, 'Ü': 0x96BD}


def fw(s):
    out = bytearray()
    for ch in s:
        if ch in AC:
            out += AC[ch].to_bytes(2, 'big')
        elif 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += ESP
        elif ch == '.':
            out += b'\x81\x42'
        elif ch == ':':
            out += b'\x81\x46'
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def escribe(st, off, data, cual):
    n = len(st)
    st[off:off + len(data)] = data
    assert len(st) == n, cual + ': cambio de tamano'
    print('  %-10s 0x%05X ok' % (cual, off))


def aplica(entrada, salida):
    marca_vel = bytes.fromhex(sys.argv[3]) if len(sys.argv) > 3 else AZUL
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    n0 = len(st)

    # ---------- 1. MAGIA (cirugia exacta: +2 delante de MAGIA, -2 en el espacio
    # de off 16 = el que hay ANTES del campo del nombre). Todo lo que vive en off>=16
    # (el nombre y su referencia, las 5 refs de valores) NO SE MUEVE: +2-2=0.
    CAB = 0x17CC2
    assert st[CAB:CAB+2] == BLANCO and st[CAB+2:CAB+4] == ROMBO
    assert st[CAB+4:CAB+14] == fw('MAGIA') and st[CAB+14:CAB+16] == ROMBO
    assert st[CAB+16:CAB+18] == ESP, 'off 16 no es el espacio'
    st[CAB+4:CAB+4] = AZUL          # +2 (todo lo de off>=4 se desplaza +2)
    del st[0x17CD4:0x17CD6]         # -2: AHORA el espacio de off16 vive en 0x17CD4
                                    # (borrar en 0x17CD2 se comia el rombo de cierre:
                                    #  por eso "∆MAGIATian Ren" en la v3)
    assert len(st) == n0
    # la referencia del nombre apuntaba a $27CD4 (off 18); el nombre sigue en off 18
    assert int.from_bytes(st[0x11E02:0x11E06], 'big') == 0x27CD4
    print('  MAGIA   : &5 en la palabra; nombre y valores EXACTAMENTE donde estaban')

    # ---------- 2. OBJETOS menu: mayusculas + &5 ----------
    p = fw('Objetos')
    i = st.find(p, 0x17D98)
    assert i > 0 and st[i-2:i] == AMARILLO and st[i-4:i-2] == ROMBO
    st[i-2:i] = AZUL
    st[i:i+14] = fw('OBJETOS')
    print('  OBJETOS : "Objetos" -> "OBJETOS", marca &5')

    # ---------- 3. OBJETOS: columna de Cambiar 17 -> 16 ----------
    assert st[0x12358:0x1235E] == bytes.fromhex('317c00120034'), st[0x12358:0x1235E].hex(' ')
    assert st[0x1235E:0x12364] == bytes.fromhex('317c00210036')
    st[0x1235B] = 0x10              # Cambiar: 17 -> 16
    # (Tirar se queda en 32: la fila queda Usar|16 Cambiar|32 Tirar)
    print('  OBJETOS : columna de Cambiar 17 -> 16')

    # ---------- 4. VELOCIDAD popup: no se toca (queda la cadena de BH) ----------

    # ---------- 5. VELOCIDAD pantalla: NO se toca en v3 ----------

    # ---------- 6. EQUIPO menu: cadena nueva en los ceros de cola ----------
    p = fw('EQUIPO')
    i = st.find(p)
    assert i == 0x13E72 and st[i-2:i] == ROMBO, (hex(i), st[i-6:i+18].hex(' '))
    EQ = i - 2
    nueva_eq = BLANCO + ROMBO + AZUL + p + BLANCO + ROMBO + ESP + b'\x00\x00'
    DST = EQ + 0x14
    assert all(st[DST + k] == 0x00 for k in range(len(nueva_eq) + 2)), 'cola de EQUIPO no libre'
    st[DST:DST + len(nueva_eq)] = nueva_eq
    st[EQ:EQ + 0x14] = b'\x00' * 0x14
    assert int.from_bytes(st[0x13E54:0x13E58], 'big') == EQ + 0x10000
    st[0x13E54:0x13E58] = (DST + 0x10000).to_bytes(4, 'big')
    print('  EQUIPO  : cadena azul en 0x%05X, ref -> $%05X' % (DST, DST + 0x10000))

    # ---------- 7. COMBATE: titulo crecido a la izquierda ----------
    p = fw('COMBATE')
    i = st.find(p)
    assert i == 0x1426C and st[i-2:i] == ROMBO and st[i-4:i-2] == BLANCO
    S = i - 4
    r2 = st.find(ROMBO, i + len(p))
    nl = st.find(b'\x2f\x6e', r2)
    R = nl + 2
    viejo = bytes(st[S:R])
    assert viejo[:2] == BLANCO and viejo[2:4] == ROMBO
    nuevo_t = viejo[:4] + AZUL + viejo[4:r2 - S] + BLANCO + viejo[r2 - S:]
    assert all(st[S - 4 + k] == 0xFF for k in range(4)), 'la zona FF previa no esta libre'
    st[S - 4:S - 4 + len(nuevo_t)] = nuevo_t
    st[S:R] = b'\xff' * (R - S)
    NS = S - 4
    # refs al titulo: el byte bajo del long del setup ($24268 -> $24264)
    movidas = 0
    for k in range(4, len(st) - 4, 2):
        v = int.from_bytes(st[k:k+4], 'big')
        if S + 0x10000 <= v < R + 0x10000 and k % 2 == 0:
            o = v - (S + 0x10000)
            nv = (NS + 0x10000) + (o if o < 2 else o + 4)
            st[k:k+4] = nv.to_bytes(4, 'big')
            movidas += 1
            print('  COMBATE : ref 0x%05X $%06X -> $%06X' % (k, v, nv))
    print('  COMBATE : titulo azul en 0x%05X (%d B), %d refs movidas' % (NS, len(nuevo_t), movidas))

    # ---------- 8. DINERO: "Dinero: " en amarillo ----------
    ref = 0x10B06
    assert st[ref:ref+4] == bytes.fromhex('000279c0')
    vieja = 0x279C0 - 0x10000
    HUECO = 0x155AA
    while not all(st[HUECO + k] == 0xFF for k in range(24)):
        HUECO += 2
    cad = bytes.fromhex('2633') + fw('Dinero: ') + b'\x00\x00'
    st[HUECO:HUECO + len(cad)] = cad
    st[ref:ref+4] = (HUECO + 0x10000).to_bytes(4, 'big')
    st[vieja:vieja + 18] = b'\xff' * 18
    print('  DINERO  : "Dinero: " en amarillo (&3) en 0x%05X' % HUECO)

    # ---------- 9. TECNICAS: marca de la palabra -> &5 ----------
    p = fw('TÉCNICAS')
    i = st.find(p)
    assert st[i-2:i] == AMARILLO and st[i-4:i-2] == ROMBO
    st[i-2:i] = AZUL
    print('  TECNICAS: marca &4 -> &5 en 0x%05X' % (i-2))

    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
