"""Extrae glifos de una captura nativa del emulador y los busca en los módulos.

Uso:
  python3 tools/glifos_desde_captura.py              # volcado ASCII de todas las capturas
  python3 tools/glifos_desde_captura.py --buscar X.png 5 7   # busca el glifo (fila 5, col 7) en extraidos/*.BIN

La captura es 320x224 (1:1), texto de 12x12 blanco sobre fondo oscuro.
"""
import sys, os, glob
from PIL import Image

GW, GH = 12, 12

def binarizar(path, umbral=200):
    im = Image.open(path).convert('L')
    w, h = im.size
    px = im.load()
    vals = [[px[x, y] for x in range(w)] for y in range(h)]
    media = sum(sum(f) for f in vals) / (w * h)
    if media > 128:  # fondo claro -> invertir (texto oscuro)
        vals = [[255 - v for v in f] for f in vals]
    return [[1 if v > umbral else 0 for v in f] for f in vals], w, h

def bandas_y_glifos(bits, w, h):
    """Devuelve [(y0, [(x0, bitmap12x12), ...]), ...]"""
    # filas con tinta
    rowsum = [sum(bits[y]) for y in range(h)]
    bands = []
    y = 0
    while y < h:
        if rowsum[y] >= 3:
            y0 = y
            while y < h and rowsum[y] >= 1:
                y += 1
            if y - y0 >= 6:          # banda de texto plausible
                bands.append((y0, y))
        else:
            y += 1
    out = []
    for y0, y1 in bands:
        if not (5 <= y1 - y0 <= 20):
            continue                      # banda demasiado alta/baja: no es texto
        colsum = [sum(bits[yy][x] for yy in range(y0, y1)) for x in range(w)]
        glyphs = []
        x = 0
        while x < w:
            if colsum[x] >= 1:
                x0 = x
                while x < w and colsum[x] >= 1:
                    x += 1
                if 4 <= x - x0 <= 20:   # ancho de glifo 12px +- separaciones
                    bm = [[bits[yy][xx] for xx in range(x0, x0 + GW)]
                          for yy in range(y0, min(y0 + GH, y1))]
                    # normaliza a GH filas
                    while len(bm) < GH:
                        bm.append([0] * GW)
                    glyphs.append((x0, bm))
            else:
                x += 1
        if glyphs:
            out.append((y0, glyphs))
    return out

def art(bm):
    return [''.join('#' if v else '.' for v in fila) for fila in bm]

def dist(a, b):
    return sum(1 for ra, rb in zip(a, b) for ca, cb in zip(ra, rb) if ca != cb)

def buscar_en_modulos(bm, tol=6):
    """Busca el bitmap (12x12) en todos los extraidos/*.BIN como 1bpp empaquetado
    por filas de 2 bytes (12 bits usados) con recortes horizontales 0..7 y en
    rejillas de 18 B (12x12+pad) y 16 B (16x16)."""
    target = [''.join(str(v) for v in fila) for fila in bm]
    results = []
    for path in sorted(glob.glob('extraidos/*.BIN')):
        data = open(path, 'rb').read()
        n = len(data)
        # pre: bytes como cadenas de bits
        # Estrategia A: filas de 16 bits (2 B), 12 bits usados (MSB first), 12 filas => 24 B por celda
        for rowbytes, used in ((2, 12),):
            stride = rowbytes * GH
            for rowcut in range(0, 1):
                pass
        # Alineado a 24 B (12x12 en 2B/fila) y a 18 B (12 bits + 4 pad por fila)
        for cellsize, rowsize_bits in ((24, None), (18, 12)):
            if n < cellsize:
                continue
            for off in range(0, n - cellsize + 1, 1):
                pass
        # (búsqueda eficiente abajo)
    return results

def buscar_eficiente(bm, tol=6):
    """Busca por filas: cada fila objetivo (12 bits) como 2 bytes; exigimos que
    las 12 filas aparezcan consecutivas con stride fijo (16, 18 o 24 B)."""
    targets = [''.join(str(v) for v in fila) for fila in bm]
    hits = []
    for path in sorted(glob.glob('extraidos/*.BIN')):
        data = open(path, 'rb').read()
        n = len(data)
        for stride in (16, 18, 24):
            if n < stride * (GH - 1) + 2:
                continue
            # índice de primera fila objetivo
            t0 = targets[0]
            tb0 = int(t0, 2)
            for rowcut in range(8):   # desalineación horizontal en bits
                mask = (0xFFF << (4 - rowcut if stride == 18 else 4 - rowcut)) & 0xFFFF
                # simplificación: sólo cut=0 para 16/24, cut=0..4 para 18
                if stride != 18 and rowcut:
                    continue
                hi = (tb0 >> 8) & 0xFF
                lo = tb0 & 0xFF
                if stride == 18:
                    # fila = 12 bits + 4 pad: byte0 = 12 bits>>4, byte1=(12bits<<4)&0xF0
                    b0 = tb0 >> 4
                    b1 = (tb0 << 4) & 0xF0
                    pat = bytes((b0, b1))
                    # posición inicial candidata: buscar patrón de fila
                    start = 0
                    while True:
                        i = data.find(pat, start)
                        if i < 0:
                            break
                        # verificar todas las filas
                        ok = True
                        for r in range(1, GH):
                            tr = int(targets[r], 2)
                            pr = bytes(((tr >> 4) & 0xFF, (tr << 4) & 0xF0))
                            if data[i + r * stride:i + r * stride + 2] != pr:
                                ok = False
                                break
                        if ok:
                            hits.append((path, i, stride, 0))
                        start = i + 1
                else:
                    pat = bytes((hi, lo))
                    start = 0
                    while True:
                        i = data.find(pat, start)
                        if i < 0:
                            break
                        ok = True
                        for r in range(1, GH):
                            tr = int(targets[r], 2)
                            if data[i + r * stride:i + r * stride + 2] != bytes(((tr >> 8) & 0xFF, tr & 0xFF)):
                                ok = False
                                break
                        if ok:
                            hits.append((path, i, stride, 0))
                        start = i + 1
    return hits

if __name__ == '__main__':
    caps = sorted(glob.glob("Gen'ei Toshi*CASTELLANO*.png")) + ['demo_texto_castellano.png']
    if len(sys.argv) > 1 and sys.argv[1] == '--buscar':
        png, fila, col = sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
        bits, w, h = binarizar(png)
        bands = bandas_y_glifos(bits, w, h)
        y0, glyphs = bands[fila]
        x0, bm = glyphs[col]
        print(f'Glifo en y={y0} x={x0}:')
        print('\n'.join(art(bm)))
        hits = buscar_eficiente(bm)
        print('HITS:', hits if hits else 'ninguno')
        sys.exit(0)
    for cap in caps:
        if not os.path.exists(cap):
            continue
        bits, w, h = binarizar(cap)
        bands = bandas_y_glifos(bits, w, h)
        print('=' * 70)
        print(cap, f'{w}x{h}', f'{len(bands)} bandas')
        for bi, (y0, glyphs) in enumerate(bands):
            print(f'-- banda {bi} (y={y0}, {len(glyphs)} glifos) --')
            arts = [art(bm) for _, bm in glyphs]
            for r in range(GH):
                print('  '.join(a[r] for a in arts))
            print('   x0s:', [x for x, _ in glyphs])
