#!/usr/bin/env python3
"""Parche de menús/sistema de START.BIN v3 — FULLWIDTH correcto.

v1 escribió ASCII de 1 byte → el motor lo emparejó como SJIS → kanji basura.
v3 codifica como el codificador castellano (que sí se vio bien): letras y
dígitos a fullwidth 2B, ñ/acentos por HIJACK, marcadores de control (&4,
?4, >L, /n, $1...) en ASCII de 1 byte.

Reubicación de desborde al hueco libre 0x17500-0x17DFF (cola 0xFF sin
ninguna referencia u32) SOLO si la cadena tiene >=1 referencia u32 en el
propio archivo (descriptores RAM = off + 0x10000); si no, se deja en
japonés y se informa.

Salida: analisis/START_CAST.BIN (misma longitud que extraidos/START.BIN).
"""
import csv
import os
import re
import struct
import sys
import importlib.util

spec = importlib.util.spec_from_file_location(
    'cod', os.path.join(os.path.dirname(__file__), 'codificador_castellano.py'))
cod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cod)

SRC = 'extraidos/START.BIN'
DST = 'analisis/START_CAST.BIN'
CSV_IN = 'textos_dumper.csv'
RAM_BASE = 0x10000
FREE = 0x17500
FREE_END = 0x17D00
FW = '\u3000'

MARK = re.compile(r'[&$#?/>][0-9A-Za-z]')

PUNCT = {':': '：', '.': '。', ',': '、', '!': '！', '-': '－',
         '(': '（', ')': '）', '%': '％', '+': '＋', '=': '＝',
         '<': '＜', '*': '＊', "'": '’'}


def enc(s):
    """Fullwidth: letras/digitos 2B; marcadores de control ASCII; ñ->HIJACK.
    `raw:` se reserva para etiquetas cortas de una sola celda lógica.
    """
    if s.startswith('raw:'):
        return s[4:].encode('ascii')
    out = bytearray()
    i = 0
    while i < len(s):
        m = MARK.match(s, i)
        if m:
            out += m.group(0).encode('ascii')
            i = m.end()
            continue
        ch = s[i]
        i += 1
        if ch in cod.HIJACK:
            out += cod.HIJACK[ch]
        elif ch in '[]［］':
            out += ('［' if ch in '[［' else '］').encode('shift_jis')
        elif ch == ' ' or ch == FW:
            out += FW.encode('shift_jis')
        elif ch in PUNCT:
            out += PUNCT[ch].encode('shift_jis')
        else:
            fw = cod._fw(ch)
            if fw:
                out += fw
            else:
                out += ch.encode('shift_jis')
    return bytes(out)


def main():
    d = bytearray(open(SRC, 'rb').read())
    orig_len = len(d)
    ORIG = bytes(d)
    informe = []
    redirects = {}

    def refs_be32(val):
        pat = struct.pack('>I', val)
        res, i = [], 0
        while True:
            i = ORIG.find(pat, i)
            if i < 0:
                return res
            res.append(i)
            i += 1

    def _chk(where):
        if len(d) != orig_len:
            print(f'*** len(d)={len(d)} tras {where} ***')
            raise SystemExit(1)

    free_ptr = [FREE]

    def fit(lines, total, nombre):
        t = b'/n'.join(enc(line) for line in lines)
        if len(t) > total:
            raise SystemExit(f'{nombre}: contenido {len(t)} > hueco {total}')
        while len(t) < total:
            t += FW.encode('shift_jis') if total - len(t) >= 2 else b' '
        assert len(t) == total
        return t

    def slot_end(off):
        e = ORIG.find(b'\x00', off)
        return (e + 1) if e >= 0 else off + 1

    def zona(items, nombre):
        """items: [(old_off, txt)]. Politica por cadena:
        - cabe en su slot -> in-situ (sin redirect)
        - no cabe pero tiene refs u32 -> reubica a zona libre + redirect
        - no cabe y sin refs -> se deja en japones (informe)"""
        for old_off, txt in items:
            b = enc(txt)
            need = len(b) + 1
            e_old = slot_end(old_off)
            refs = refs_be32(RAM_BASE + old_off)
            if need <= e_old - old_off:
                d[old_off:old_off + len(b)] = b
                d[old_off + len(b):e_old] = b'\x00' * (e_old - old_off - len(b))
                informe.append(f'  {nombre}: {hex(old_off)} in-situ {txt!r}')
                _chk(f'zona {nombre} {hex(old_off)}')
            elif refs:
                fp = free_ptr[0]
                assert fp + need <= FREE_END, f'{nombre}: sin hueco libre'
                d[fp:fp + len(b)] = b
                d[fp + len(b)] = 0
                redirects[RAM_BASE + old_off] = RAM_BASE + fp
                informe.append(f'  {nombre}: {hex(old_off)} -> LIBRE {hex(fp)} {txt!r} (refs x{len(refs)})')
                free_ptr[0] = fp + need
                _chk(f'zona {nombre} {hex(old_off)}')
            else:
                informe.append(f'  {nombre}: {hex(old_off)} sin refs ni hueco -> japones ({txt!r})')

    def inplace(off, length, new, nombre):
        b = enc(new)
        assert len(b) <= length, f'{nombre}: {len(b)} > {length}'
        if len(b) < length:
            b = b + b'\x00' * (length - len(b))
        d[off:off + length] = b
        _chk(f'inplace {nombre} {hex(off)}')
        informe.append(f'  {nombre}: {hex(off)} {new!r} ({length}B)')

    # ------------------------------------------------------------------
    # Zonas de cadenas
    # ------------------------------------------------------------------
    zona([(0xEEE3, 'Atacar'),
          (0xEEEA, 'Defender'),
          (0xEEF1, 'Huir'),
          (0xEEF8, 'Magia'),
          (0xEEFF, 'Objetos')], 'batalla-pj')

    zona([(0xEF08, 'Mutar'),
          (0xEF11, 'Garras'),
          (0xEF18, 'Qi'),
          (0xEF21, 'Cañón'),
          (0xEF28, 'MBH'),
          (0xEF2F, 'Curar'),
          (0xEF36, 'Ametralladora'),
          (0xEF3D, 'Pasar')], 'habilidades')

    zona([(0x13D30, 'Objetos'),
          (0x13D3A, 'Equipo'),
          (0x13D42, 'Hablar'),
          (0x13D4A, 'Ficha'),
          (0x13D56, 'Sistema')], 'menu-ppal')

    zona([(0x11888, '(Mun x100)'),
          (0x118A0, 'Cualquiera'),
          (0x118AA, 'Equipar'),
          (0x118B4, 'x 1'),
          (0x118BC, 'x 10'),
          (0x118C4, 'Todos'),
          (0x118E2, 'Sí'),
          (0x118EA, 'No')], 'tienda')

    zona([(0x13E2C, '>L[Items]'),
          (0x13E3C, 'Usar'),
          (0x13E44, 'Cambiar'),
          (0x13E4C, 'Tirar')], 'item-win')

    # ------------------------------------------------------------------
    # Plantillas grandes (longitud EXACTA preservada)
    # ------------------------------------------------------------------
    # Z5: plantilla [術] (0x13D60, 136 B)
    # El motor inserta el nombre del personaje en este encabezado mediante
    # una posición fija; no debe escribirse Tianren literalmente aquí porque
    # lo sobrescribe y produce "[Mag天人...ianren".
    z5 = ['[Magia]' + FW * 3,
          '',
          FW * 6 + '&4PM' + FW + 'Coste',
          '&5Ahora' + FW + '&7' + '００' + FW + '&5Ind' + '&7' + '００',
          '&5Max' + FW * 3 + '&7' + '００' + FW + '１０' + FW + '&5Grp' + '&7' + '００']
    d[0x13D60:0x13D60 + 136] = fit(z5, 136, 'Z5')
    _chk('Z5')
    informe.append('  [Magia]: plantilla 136B')

    # Z6..Z8
    # Estos tres campos son ranuras fijas de 10/9/9 B. No se puede meter
    # Efecto/Individual sin desplazar la tabla de punteros siguiente; dejamos
    # las etiquetas completas que caben para que la ventana conserve sus tres
    # filas y no se rompa el marco.
    inplace(0x13DF6, 10, 'Efect', 'efectos')
    inplace(0x13E02, 9, 'Ind', 'indiv')
    inplace(0x13E0C, 9, 'Grp', 'grupo')

    # Z10: cabecera [装備] (24 B)
    inplace(0x13E6E, 24, '?4[Equipo]', 'equip-hdr')

    # Z11..Z15: lineas de equipamiento (40 B c/u)
    # Equipamiento: cabecera fija 8B + campo nombre referenciado a +8.
    # Cirugia byte-neutra: cada cambio ocupa exactamente los mismos bytes.
    for off, repls in [(0x13E8C, [('武：', 'Arma'), ('攻', 'At')]),
                       (0x13EB6, [('防：', 'Prot'), ('防', 'De')]),
                       (0x13EE0, [('他：', 'Otro'), ('早', 'Vl')]),
                       (0x13F0A, [('他：', 'Otro'), ('ス', 'Sk')]),
                       (0x13F34, [('他：', 'Otro'), ('率', 'Ac')])]:
        ln = ORIG[off:off + 40].decode('shift_jis')
        for a, b in repls:
            ln = ln.replace(a, b, 1)
        nb = ln.encode('shift_jis')
        assert len(nb) == 40, f'equip {hex(off)}: {len(nb)} != 40'
        d[off:off + 40] = nb
        _chk(f'equip {hex(off)}')
        informe.append(f'  equip {hex(off)}: {repls}')

    # Z16..Z18: pestanas de la ficha
    inplace(0x13F6A, 11, 'Char', 'tab-pj')
    inplace(0x13F76, 9, 'Tec', 'tab-tec')
    inplace(0x13F80, 9, 'Comb', 'tab-com')

    # Z19: plantilla FICHA (0x13F8A, 338 B) — NV/PV/PM
    ficha_rows = [
        ('NV',       '００'),
        ('EXP',      '０００００００'),
        ('Next',     '０００００００'),
        None,
        ('PV',       '０００／０００'),
        ('PM',       '０００／０００'),
        ('Ataque',   '０００＋０００'),
        ('Defensa',  '０００＋０００'),
        ('Agilidad', '０００＋０００'),
        ('Pericia',  '０００％'),
        ('Acierto',  '０００％'),
    ]
    ficha_lines = [FW * 2, '']
    for row in ficha_rows:
        if row is None:
            ficha_lines.append('')
            continue
        lab, val = row
        ficha_lines.append('&5' + lab + FW * (7 - len(lab)) + '&7' + val)
    d[0x13F8A:0x13F8A + 338] = fit(ficha_lines, 338, 'Z19')
    _chk('Z19')
    informe.append('  Ficha: plantilla 338B (NV/PV/PM)')

    # HUD de los tres personajes: los huecos incluyen el relleno original.
    # Tianren y Meifan ocupan exactamente 14 B con un espacio final; Isaac,
    # 12 B. Las etiquetas japonesas de recurso se convierten a PV/PM.
    inplace(0x0CB5E, 14, 'Tianren', 'HUD nombre 1')
    inplace(0x0CB6E, 14, 'Meifan' + FW, 'HUD nombre 2')
    inplace(0x0CB7E, 12, 'Isaac' + FW, 'HUD nombre 3')
    for i, off in enumerate((0x0CB8C, 0x0CB98, 0x0CBA4), 1):
        inplace(off, 4, 'PV', f'HUD PV {i}')
    for i, off in enumerate((0x0CBB0, 0x0CBBC, 0x0CBC8), 1):
        inplace(off, 4, 'PM', f'HUD PM {i}')

    # Z20: plantilla TECNICAS (0x140DE, 392 B) — solo la cabecera; las
    # columnas de armas tienen anchos fijos (3-4 celdas), se quedan como están.
    orig20 = ORIG[0x140DE:0x140DE + 392].decode('shift_jis')
    lines = orig20.split('/n')
    assert len(lines) == 10, f'Z20: {len(lines)} lineas'
    lines[0] = '&5Tecnicas' + 'Unid'
    d[0x140DE:0x140DE + 392] = fit(lines, 392, 'Z20')
    _chk('Z20')
    informe.append('  Tecnicas: cabecera (columnas japonesas pendientes)')

    # Z21: plantilla COMBATE (0x14268, 360 B) — labels sobre columnas fijas
    orig21 = ORIG[0x14268:0x14268 + 360].decode('shift_jis')
    lines = orig21.split('/n')
    assert len(lines) == 10, f'Z21: {len(lines)} lineas'
    lines[0] = '&5Combate'
    lines[1] = '&5' + FW * 4 + 'Ataque' + FW * 2 + 'Def' + FW + 'Agi'
    lines[6] = FW * 7 + '&5PV' + FW * 5 + 'PM'
    d[0x14268:0x14268 + 360] = fit(lines, 360, 'Z21')
    _chk('Z21')
    informe.append('  Combate: plantilla 360B')

    # Z22: plantilla VELOCIDAD (0x143EE, 130 B)
    orig22 = ORIG[0x143EE:0x143EE + 130].decode('shift_jis')
    lines = orig22.split('/n')
    assert len(lines) == 7, f'Z22: {len(lines)} lineas'
    lines[0] = '&5Velocidad'
    # &5 solo pertenece a la cabecera; el original resalta las dos opciones
    # con &4 y deja las cuatro preferencias inferiores en blanco.
    # Geometría del motor (verificada con el original y las capturas):
    # la flecha del nivel N se dibuja en la celda 7+N (rango 8-15; nivel
    # por defecto 4 -> celda 11). La escala ocupa las celdas 8-15, la
    # posición original japonesa: cada dígito cae bajo su flecha.
    # 'Rápido' (cel 4-9) y 'Lento' (11-15) con la L sobre el dígito 4.
    # 'Texto' (cel 1-5) no colisiona con la flecha en NINGÚN nivel 1-8
    # (Mensajes, 8 celdas, rozaba la flecha del nivel 1) y cierra el
    # presupuesto exacto de 130 B.
    lines[2] = '&4' + FW * 3 + 'Rápido' + FW + 'Lento' + '&7'
    lines[3] = FW * 7 + '１２３４５６７８'
    # El intérprete no admite ASCII literal como texto: lo lee como pares
    # SJIS y aparecen kanjis. Conservamos texto fullwidth y usamos etiquetas
    # compactas que caben en el bloque fijo sin desplazar los campos superiores.
    lines[4] = 'Mens.'
    lines[5] = 'Mov.'
    lines[6] = 'Combate'
    d[0x143EE:0x143EE + 130] = fit(lines, 130, 'Z22')
    _chk('Z22')
    informe.append('  Velocidad: plantilla 130B')

    # Z23..Z24: menus de recuperacion
    inplace(0x144C4, 13, 'SanaPV', 'recup-pv')
    inplace(0x144D2, 13, 'SanaPM', 'recup-pm')

    # ------------------------------------------------------------------
    # Redirigir descriptores u32
    # ------------------------------------------------------------------
    n_red = 0
    sin_refs = []
    for old, new in redirects.items():
        hits = refs_be32(old)
        if not hits:
            sin_refs.append(hex(old - RAM_BASE))
            continue
        for p in hits:
            d[p:p + 4] = struct.pack('>I', new)
            n_red += 1
    _chk('redirects')
    informe.append(f'redirecciones u32 aplicadas: {n_red}')
    if sin_refs:
        informe.append(f'ATENCION descriptores sin refs (no redirigidos): {sin_refs}')

    # ------------------------------------------------------------------
    # Resto de traducciones del CSV para START.BIN (in-situ, zonas no propias)
    # ------------------------------------------------------------------
    owned = [(0xEEE3, 0xEF45), (0x1187A, 0x118F0), (0x13D30, 0x13D60),
             (0x13D60, 0x13DE9), (0x13DF6, 0x13E16), (0x13E2C, 0x13E55),
             (0x13E6E, 0x13F5A), (0x13F6A, 0x13F88), (0x13F8A, 0x140DD),
             (0x140DE, 0x14267), (0x14268, 0x143D8), (0x143EE, 0x14470),
             (0x144C4, 0x144DA), (FREE, FREE_END)]
    rows = list(csv.DictReader(open(CSV_IN, encoding='utf-8-sig')))
    ok = skip = err = 0
    for row in rows:
        if row['archivo'] != 'START.BIN':
            continue
        trad = row['traduccion_castellano'].strip()
        if not trad:
            continue
        off = int(row['offset_archivo'], 16)
        if any(a <= off < b for a, b in owned):
            skip += 1
            continue
        end = d.find(b'\x00', off)
        if end < 0:
            continue
        slen = end - off + 1
        try:
            new = cod.encode_spanish(trad)
        except cod.EncodeError:
            err += 1
            continue
        if len(new) + 1 > slen:
            err += 1
            informe.append(f'  CSV no cabe: {hex(off)} {trad!r}')
            continue
        data = new + b'\x00' + b'\x00' * (slen - len(new) - 1)
        d[off:off + slen] = data
        _chk(f'csv {hex(off)}')
        ok += 1
    informe.append(f'CSV passthrough: ok={ok} zona_propia={skip} errores={err}')

    if len(d) != orig_len:
        print(f'AVISO: longitud {len(d)} != {orig_len}; NO escribo el archivo')
        raise SystemExit(1)
    os.makedirs('analisis', exist_ok=True)
    open(DST, 'wb').write(bytes(d))
    print('\n'.join(informe))
    print(f'{DST} escrito ({len(d)} B, sin cambio de tamano)')


if __name__ == '__main__':
    main()
