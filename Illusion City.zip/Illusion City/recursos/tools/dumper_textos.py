#!/usr/bin/env python3
"""Dumper de textos: recorre los archivos ISO9660 de track01.iso y extrae
las cadenas Shift-JIS terminadas en 00, validadas por densidad de kana/kanji.

Salida: textos_dumper.csv
  id, archivo, offset_archivo, offset_iso, japones, marcadores, traduccion_castellano
"""
import csv
import re
import struct
import sys
import unicodedata

ISO = 'track01.iso'
CSV_OUT = 'textos_dumper.csv'

# ---------------------------------------------------------------- ISO9660

def read_files(data):
    """Devuelve [(nombre, extent, size)] desde el PVD."""
    pvd = None
    for i in range(0, 64):
        blk = data[i*2048:(i+1)*2048]
        if blk[0:1] == b'\x01' and blk[1:6] == b'CD001':
            pvd = blk
            break
    if pvd is None:
        raise SystemExit('No PVD')
    root = pvd[156:190]
    files = []

    def read_dir(lba, size, prefix=''):
        nsec = (size + 2047) // 2048
        buf = data[lba*2048:(lba+nsec)*2048]
        pos = 0
        while pos < len(buf):
            ln = buf[pos]
            if ln == 0:
                pos = (pos // 2048 + 1) * 2048
                continue
            rec = buf[pos:pos+ln]
            flags = rec[25]
            extent = struct.unpack('<I', rec[2:6])[0]
            fsize = struct.unpack('<I', rec[10:14])[0]
            name = rec[33:33+rec[32]]
            if name in (b'\x00', b'\x01'):
                pos += ln
                continue
            name = name.decode('ascii', 'replace').split(';')[0]
            full = prefix + name
            if flags & 2:
                read_dir(extent, fsize, full + '/')
            else:
                files.append((full, extent, fsize))
            pos += ln

    read_dir(struct.unpack('<I', root[2:6])[0],
             struct.unpack('<I', root[10:14])[0])
    return files

# ---------------------------------------------------------------- scanner

def char_class(ch):
    """categoría de un caracter decodificado para validar texto de juego"""
    o = ord(ch)
    if 0x3040 <= o <= 0x30FF:      # kana
        return 'k'
    if 0x4E00 <= o <= 0x9FFF:      # kanji
        return 'k'
    if 0x3000 <= o <= 0x303F:      # puntuación CJK 、。「」
        return 'p'
    if 0xFF00 <= o <= 0xFF65:      # fullwidth
        return 'p'
    if ch in '$#':                 # marcadores del motor
        return 'm'
    if 0x20 <= o < 0x7F:           # ASCII legible
        return 'a'
    return 'x'                     # desconocido / control


def valid_string(s):
    """True si parece una cadena real del guion."""
    if not (4 <= len(s) <= 400):
        return False
    classes = [char_class(c) for c in s]
    if classes.count('x') > max(1, len(s) // 16):   # tolera poco ruido
        return False
    jp = classes.count('k')
    if jp == 0:
        return False                                 # exige contenido japonés
    # demasiada mezcla aleatoria kanji-ASCII suele ser código, no texto
    if jp < 2 and classes.count('a') > len(s) // 2:
        return False
    # tiles de gráficos: un mismo caracter repetido muchas veces seguidas
    if re.search(r'(.)\1{5,}', s):
        return False
    # demasiado ruido
    if len(s) >= 8 and not re.search(r'[\u3040-\u309f]', s):
        return False
    # los caracteres de control nunca aparecen en texto real del guion
    if any(ord(c) < 0x20 and c not in '$#' for c in s):
        return False
    # halfwidth: solo opcodes conocidos y solo en las dos primeras posiciones
    for i, c in enumerate(s):
        if HALFWIDTH_KANA.match(c):
            if i > 1 or c not in HW_OPCODES:
                return False
    # ASCII suelto entre kanji = binario; el guion real solo usa marcadores $#, /n
    limpio = MARK.sub('', s)
    limpio = re.sub(r'/[a-zA-Z]', '', limpio)
    if re.search(r'[!-~]', limpio):   # cualquier ASCII imprimible restante
        return False
    return True


MARK = re.compile(r'[$#][0-9A-Za-z]')
# kana halfwidth (0xA1-0xDF en SJIS): el guion real solo usa opcodes al inicio
HALFWIDTH_KANA = re.compile(r'[\uff61-\uff9f]')
HW_OPCODES = set('｡ﾇﾊﾋﾌﾍﾎﾏﾐﾑ')          # vistos como prefijos de líneas reales
FW_KANA = re.compile(r'[\u3040-\u30ff]')
# hiragana ultracomún en partículas/terminaciones: presencia ⇒ casi seguro texto
HIRA_COMUN = set('のはをたしにいなかっでがとするまれナ')

def confianza(s):
    return 'alta' if any(c in HIRA_COMUN for c in s) else 'media'

def scan_file(buf):
    """Rinde (offset, texto) de cada cadena SJIS terminada en 00."""
    out = []
    pos = 0
    n = len(buf)
    while pos < n:
        end = buf.find(b'\x00', pos)
        if end < 0:
            break
        raw = buf[pos:end]
        if len(raw) >= 4:
            try:
                s = raw.decode('shift_jis')
            except (UnicodeDecodeError, ValueError):
                s = None
            if s is not None and valid_string(s):
                out.append((pos, s))
        pos = end + 1
    return out

# ---------------------------------------------------------------- main

def main():
    data = open(ISO, 'rb').read()
    files = read_files(data)
    rows = []
    for name, extent, size in files:
        buf = data[extent*2048:extent*2048+size]
        for off, s in scan_file(buf):
            rows.append({
                'archivo': name,
                'offset_archivo': f'0x{off:05X}',
                'offset_iso': f'0x{extent*2048+off:07X}',
                'japones': s,
                'marcadores': ' '.join(sorted(set(MARK.findall(s)))),
                'confianza': confianza(s),
                'traduccion_castellano': '',
            })
    rows.sort(key=lambda r: (r['archivo'], int(r['offset_archivo'], 16)))
    for i, r in enumerate(rows):
        r['id'] = i + 1

    with open(CSV_OUT, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=[
            'id', 'archivo', 'offset_archivo', 'offset_iso',
            'japones', 'marcadores', 'confianza', 'traduccion_castellano'])
        w.writeheader()
        w.writerows(rows)

    by_file = {}
    for r in rows:
        by_file.setdefault(r['archivo'], 0)
        by_file[r['archivo']] += 1
    alta = sum(1 for r in rows if r['confianza'] == 'alta')
    print(f'Total cadenas: {len(rows)} en {len(by_file)} archivos  (confianza alta: {alta})')
    for k, v in sorted(by_file.items(), key=lambda kv: -kv[1])[:15]:
        print(f'  {k:20s} {v}')
    tot = sum(len(r['japones']) for r in rows)
    print(f'Caracteres japoneses totales: {tot}')

if __name__ == '__main__':
    main()
