#!/usr/bin/env python3
"""parche_submenu.py - el submenu del menu Estado: Char / Tec / Comb -> castellano.

MEDIDO
  Las tres etiquetas son cadenas sueltas en START y las apunta una tabla de 4 bytes:
      0x13F5E -> $23F6A  «Char»  (0x13F6A, 12 B de hueco)
      0x13F62 -> $23F76  «Tec»   (0x13F76, 10 B)
      0x13F66 -> $23F80  «Comb»  (0x13F80,  9 B)
  El castellano necesita 17 + 23 + 15 = 55 B, asi que se mudan al hueco que dejo libre
  la plantilla de la ficha de Estado al moverse a 0x17ADA (0x13F8A..0x140DE, 340 B).
  El submenu se dibuja DENTRO de la ventana flotante, que ahora mide 92 px: con el paso
  de 8 px por letra, «Habilidades» (11) ocupa 88 px -> entra justo.

Uso: python3 parche_submenu.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184
TABLA = 0x13F5E                       # 3 punteros de 4 B (los long $23F6A, $23F76, $23F80)
DESTINO = 0x152B4                     # hueco de 0xFF (332 B) al principio del bloque libre del START
NUEVAS = ['Perfiles', 'Técnicas', 'Combate']
VIEJAS = [(0x13F6A, 'Char'), (0x13F76, 'Tec'), (0x13F80, 'Comb')]


ACENTOS = {'é': 0x9744, 'á': 0x9660, 'í': 0x9755, 'ó': 0x975F, 'ú': 0x975C,
           'É': 0x966B, 'Á': 0x95FB, 'Í': 0x967B, 'Ó': 0x9682, 'Ú': 0x96AF,
           'ñ': 0x9770, 'Ñ': 0x96B3, 'ü': 0x976C, 'Ü': 0x96BD}


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch in ACENTOS:
            out += ACENTOS[ch].to_bytes(2, 'big')
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))

    # comprobar que las cadenas viejas siguen donde creo (se acepta que el build ya
    # lleve una version anterior del submenu: lo que importa es el sitio del hueco)
    for off, txt in VIEJAS:
        if st[off:off + len(fw(txt))] != fw(txt):
            print('  (0x%05X ya no tiene «%s»: el build viene de una pasada anterior)' % (off, txt))

    # escribir las nuevas y reapuntar la tabla
    pos = DESTINO
    for k, txt in enumerate(NUEVAS):
        d = fw(txt) + b'\x00'
        if k == 0:
            viejo_hueco = st[pos:pos + 60]
            ok = set(viejo_hueco) <= {0x00, 0xFF} or b'P' in bytes(0x82 for _ in [0]) or True
            # el hueco puede tener ya una version anterior del submenu (es el mismo sitio)
            assert viejo_hueco[:1] == b'\x82' or set(viejo_hueco[:8]) <= {0x00, 0xFF}, \
                'el hueco 0x%05X no esta libre: %s' % (pos, viejo_hueco[:16].hex(' '))
        st[pos:pos + len(d)] = d
        ptr = pos + 0x10000
        sitio = TABLA + 4 * k
        viejo = int.from_bytes(st[sitio:sitio + 4], 'big')
        st[sitio:sitio + 4] = ptr.to_bytes(4, 'big')
        print('  %-12s en 0x%05X (offset 0x%04X)   puntero $%06X -> $%06X  (%d px de texto)'
              % (txt, pos, pos, viejo, ptr, 8 * len(txt)))
        pos += len(d)
    print("  hueco usado: %d B de 332" % (pos - DESTINO))

    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
