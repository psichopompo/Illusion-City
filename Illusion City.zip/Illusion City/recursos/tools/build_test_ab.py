#!/usr/bin/env python3
"""build_test_ab.py - TEST_AC: la cadena completa, en orden.

  1. build_test_i.py      fuente de 8 px (INIT+OPEN) + titulo + textos del menu
  2. dinero_formato.py    «Dinero: » con el espacio y la moneda «ＨＫ＄»
  3. fuente_dinero.py     los glifos de David en la fuente del dinero
  4b. fuente_simbolos  los simbolos (puntuacion, + % ~ -)
  5. paso_mixto.py        paso mixto (letras 8 px / kana 12 px) + el icono a 8 px
  5. parche_cajas.py 8 20 ancho de las cajas (menu 8, dinero 20)
  6. parche_selector_vel.py   el recuadro azul del menu de Velocidad
  7. arregla_selectores.py    el cursor de los recuadros flotantes
  8. parche_titulo.py         geometria del menu del titulo
  9. traduce_nombres.py       NOMBRES COMPLETOS de la party (tabla + reubicacion)
10. parche_rotulos.py        icono de David en los rotulos + limite de Equipo +
                              corchetes del menu de Estado
11. traduce_clases.py        clases / habilidades / zonas de combate al castellano

Uso: python3 build_test_ab.py           (deja TEST_AF.bin en la raiz del proyecto)
"""
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
T = AQUI
PASOS = [
    (['build_test_i.py'], None, None),
    (['dinero_formato.py'], 'a', 'b'),
    (['fuente_dinero.py'], 'b', 'c'),
    (['fuente_simbolos.py'], 'c', 'c2'),
    (['paso_mixto.py'], 'c2', 'd'),
    (['parche_cajas.py'], 'd', 'e', '8', '20'),
    (['parche_selector_vel.py'], 'e', 'f'),
    (['arregla_selectores.py'], 'f', 'g'),
    (['parche_titulo.py'], 'g', 'h'),
    (['traduce_nombres.py'], 'h', 'i'),
    (['parche_rotulos.py'], 'i', 'j'),
    (['traduce_clases.py'], 'j', 'k'),
    (['parche_estado.py'], 'k', 'l'),
    (['parche_ventana.py'], 'l', 'm'),
]
BASE = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
SALIDA = os.path.join(PROY, 'TEST_AH.bin')


def corre(script, args):
    cmd = [sys.executable, os.path.join(T, script)] + [a for a in args if a]
    r = subprocess.run(cmd, cwd=PROY, capture_output=True, text=True)
    ok = r.returncode == 0 and 'MAL' not in r.stdout
    print('  [%s] %s' % ('ok ' if ok else 'MAL', script))
    for l in (r.stdout or '').strip().splitlines():
        if l.strip():
            print('        ' + l)
    if not ok:
        print(r.stderr[-2000:])
        raise SystemExit('paso %s fallo' % script)
    return r.stdout


def main():
    prev = None
    for paso in PASOS:
        script = paso[0][0]
        ent, sal = paso[1], paso[2]
        extra = paso[3:]
        if ent is None:                       # escribe TEST_I.bin
            corre(script, [])
            prev = os.path.join(PROY, 'TEST_I.bin')
        else:
            corre(script, [prev, '/tmp/ab_%s.bin' % sal] + list(extra))
            prev = '/tmp/ab_%s.bin' % sal
    shutil.copy(prev, SALIDA)
    raw = open(SALIDA, 'rb').read()
    print('\n  TEST_AH.bin  %d B  MD5 %s' % (len(raw), hashlib.md5(raw).hexdigest()))


if __name__ == '__main__':
    main()
