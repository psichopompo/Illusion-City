#!/usr/bin/env python3
"""build_test_ba.py - TEST_BA: la cadena COMPLETA desde la base japonesa.

  1-14  (la cadena de build_test_ab.py)  -> TEST_AH (base de menus + nombres)
  15    parche_submenu.py                 -> submenus Perfiles/Tecnicas/Combate
  16    parche_maqueta_estado.py          -> ficha de Estado maquetada
  17    parche_combate.py                 -> menu de COMBATE castellano
  18    parche_combate_v2.py              -> columnas de COMBATE alineadas
  19    parche_titulo_combate (inline)    -> titulo de COMBATE en blanco
  20    parche_sistema.py                 -> menu de SISTEMA (Velocidad/Ajustes)
  21    parche_objetos.py                 -> menu de OBJETOS castellano
  22    parche_cursor_objetos.py          -> cursor de OBJETOS a medida
  23    parche_tecnicas.py (inline)       -> menu de TECNICAS castellano

Uso: python3 build_test_ba.py    (deja TEST_BA.bin en la raiz del proyecto)
"""
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
T = AQUI

# Primera parte: la cadena de build_test_ab (14 pasos)
CADENA_AB = [
    (['build_test_i.py'], None, None),
    (['dinero_formato.py'], 'a', 'b'),
    (['fuente_dinero.py'], 'b', 'c'),
    (['fuente_simbolos.py'], 'c', 'c2'),
    (['paso_mixto.py'], 'c2', 'd'),
    (['parche_cajas.py'], 'd', 'e', '8', '20'),
    (['parche_selector_vel.py'], 'e', 'f'),
    (['arregla_selectores.py'], 'f', 'g'),
    (['parche_titulo.py'], 'g', 'h'),
    (['parche_si_no.py'], 'h', 'h2'),
    (['traduce_nombres.py'], 'h2', 'i'),
    (['parche_rotulos.py'], 'i', 'j'),
    (['traduce_clases.py'], 'j', 'k'),
    (['parche_plantillas.py'], 'k', 'kp'),     # 63a: Tecnicas/Combate in-situ (HABILIDADES %, ARMA RIFLE OBUS CAN.)
    (['parche_estado.py'], 'kp', 'l'),
    (['parche_ventana.py'], 'l', 'm'),
]
# Segunda parte: los parches de menus de rejilla y extras
CADENA_EXTRA = [
    (['parche_submenu.py'], 'm', 'n'),
    (['parche_maqueta_estado.py'], 'n', 'o'),
    (['parche_combate.py'], 'o', 'p'),
    (['parche_combate_v2.py'], 'p', 'q'),
]

BASE = os.path.join(PROY, "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
SALIDA = os.path.join(PROY, 'TEST_BA.bin')


def corre(script, args):
    cmd = [sys.executable, os.path.join(T, script)] + [a for a in args if a]
    r = subprocess.run(cmd, cwd=PROY, capture_output=True, text=True)
    ok = r.returncode == 0 and 'MAL' not in r.stdout
    print('  [%s] %s' % ('ok ' if ok else 'MAL', script))
    for l in (r.stdout or '').strip().splitlines():
        if l.strip():
            print('        ' + l)
    if not ok:
        print(r.stderr[-3000:])
        raise SystemExit('paso %s fallo' % script)
    return r.stdout


def main():
    prev = None
    print('=== CADENA BASE (14 pasos) ===')
    for paso in CADENA_AB:
        script = paso[0][0]
        ent, sal = paso[1], paso[2]
        extra = paso[3:]
        if ent is None:
            corre(script, [])
            # TEST_I.bin se genera en la raiz del proyecto: moverlo a /tmp para
            # que NO reviva en el workspace cada vez que se reconstruye la cadena
            import shutil as _sh
            prev = '/tmp/ba_i.bin'
            _sh.move(os.path.join(PROY, 'TEST_I.bin'), prev)
        else:
            tmp = '/tmp/ba_%s.bin' % sal
            corre(script, [prev, tmp] + list(extra))
            prev = tmp
    print('=== CADENA EXTRA (menus de rejilla) ===')
    for paso in CADENA_EXTRA:
        script = paso[0][0]
        ent, sal = paso[1], paso[2]
        tmp = '/tmp/ba_%s.bin' % sal
        corre(script, [prev, tmp])
        prev = tmp
    # copiar a la raiz del proyecto
    shutil.copy(prev, SALIDA)
    raw = open(SALIDA, 'rb').read()
    print('\n  TEST_BA (base para menus extra)  %d B  MD5 %s' % (len(raw), hashlib.md5(raw).hexdigest()))


if __name__ == '__main__':
    main()
