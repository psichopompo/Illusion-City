#!/usr/bin/env python3
"""parche_titulo.py - geometria del menu de la PANTALLA DE TITULO (SSTART).

MEDIDO (26/09)
  El menu del titulo lo monta el setup de SSTART 0x0A90 y sus cuatro campos son
  (offset del fichero -> campo del descriptor):
      0x0AC7  $04  X de la caja        (pasos de 8 px: 41 + 8*$04)
      0x0AD3  $08  ANCHO de la caja    (paso de 8 px: ancho = 8*$08 + 14)
      0x0AB5  $32  margen del texto    (paso de 4 px)
      0x0AC1  $2e  nº de trozos del selector azul (cada trozo mide 12 px)
  Barrido medido:
      $04=8 $08=16 $32=3 -> caja x=57..198 (142 px, centro 127.5) texto margenes 7/7
      $04=9 $08=16 $32=3 -> caja x=65..206 (¡se sale por la derecha!)
      $04=9 $08=15 $32=0 -> caja x=65..198 (134 px, centro 131.5) texto margenes 8/8
      ...y con $2e=9 el selector mide 116 px (x=64..179) -> no cubre «NUEVA SIN INTRO»
      ...y con $2e=10 el selector mide 128 px (x=64..191) -> la cubre entera (acaba en 190)

PUESTO ASI (lo que pidio David: una celda menos, texto centrado y selector que cubra
la opcion mas larga):
      $04 = 8    (caja centrada: x=57..198, centro 127.5 = centro de pantalla)
      $08 = 16   (buffer de 128 px: es el minimo para que la linea de 120 px no de
                  vuelta; con 15 (120 px) la linea se descuadraba)
      $32 = 2    (el texto queda a 16 px del borde izquierdo y 11 del derecho)
      $2e = 10   (selector de 128 px: cubre «NUEVA SIN INTRO», que acaba en x=190)
  NOTA: estrechar la caja (una celda menos) obliga a bajar $08 a 15 y entonces el
  buffer vuelve a 120 px y la linea se descuadra. **No se puede estrechar y que el
  texto entre**: manda el buffer, no la caja.

Uso: python3 parche_titulo.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

OFF_X, OFF_A, OFF_T, OFF_S = 0x0AC7, 0x0AD3, 0x0AB5, 0x0AC1
# MEDIDO 26/09 (segunda vuelta): el buffer de linea del titulo mide $08*8 px.
#   $08=15 -> 120 px y «NUEVA SIN INTRO» mide EXACTAMENTE 120 px -> vuelta de linea
#             (el ultimo glifo se descuadraba 4 px: la muesca que ve David en la N).
#   $08=16 -> 128 px -> la linea cabe con 8 px de sobra.  <- como en el menu principal
# Con $08=16 la caja mide 142 px y queda CENTRADA (x=57..198, centro 127.5).
VALORES = ((OFF_X, 0x08, 0x08, 'X de la caja'),
           (OFF_A, 0x10, 0x10, 'ancho de la caja (buffer 128 px)'),
           (OFF_T, 0x02, 0x02, 'margen del texto'),
           (OFF_S, 0x09, 0x0A, 'trozos del selector'))


def pon(buf, off, data, cual):
    assert off + len(data) <= len(buf), cual
    n = len(buf); buf[off:off + len(data)] = data
    assert len(buf) == n, cual + ': INSERCION'


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    ss = bytearray(m.region(raw, m.LBA_SSTART, m.SZ_SSTART))
    for off, viejo, nuevo, nom in VALORES:
        actual = ss[off]
        assert actual == viejo, '%s: en 0x%X esperaba $%02X y hay $%02X' % (nom, off, viejo, actual)
        pon(ss, off, bytes([nuevo]), nom)
    m.escribe_region(raw, m.LBA_SSTART, bytes(ss))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    for off, viejo, nuevo, nom in VALORES:
        print('  %-24s 0x%05X  $%02X -> $%02X' % (nom, off, viejo, nuevo))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
