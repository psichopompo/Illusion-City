#!/usr/bin/env python3
"""Render GFONT.BIN: 12x12 glyphs, 2 bytes/row, 24 B/glyph, to PNG."""
from PIL import Image
import sys

path = sys.argv[1] if len(sys.argv) > 1 else 'extraidos/GFONT.BIN'
out = sys.argv[2] if len(sys.argv) > 2 else 'gfont.png'
first = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0
count = int(sys.argv[4]) if len(sys.argv) > 4 else 330

d = open(path, 'rb').read()
GLYPH = 24
cols = 16
rows = (count + cols - 1) // cols
scale = 4
img = Image.new('P', (cols*13*scale, rows*12*scale), 0)
img.putpalette([17,17,17, 255,255,255] + [0]*254)
px = img.load()
for g in range(count):
    idx = first + g
    tile = d[idx*GLYPH:(idx+1)*GLYPH]
    if len(tile) < GLYPH: break
    gx, gy = (g % cols)*13*scale, (g // cols)*12*scale
    for y in range(12):
        w = (tile[y*2] << 8) | tile[y*2+1]
        for x in range(12):
            if w & (0x800 >> x):
                for sy in range(scale):
                    for sx in range(scale):
                        px[gx + x*scale + sx, gy + y*scale + sy] = 1
img.save(out)
print("saved", out)
