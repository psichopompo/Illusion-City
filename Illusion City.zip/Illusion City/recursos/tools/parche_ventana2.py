#!/usr/bin/env python3
"""parche_ventana2.py - ANCHO de la ventana flotante de nombres y de su selector azul.

MEDIDO (28/09, con la ventana abierta desde el menu de Magia)
  La ventana la montan TRES rutinas (misma firma: $26=1, $28=3, $18=0):
      0x0C86A   ($4=7,  $6=0xE, $8=0x14)   <- NO es la de personajes (ancho 20)
      0x13590   ($4=0xA, $6=8, $8=8)       <- la del menu de Estado
      0x13672   ($4=0xA, $6=8, $8=8)       <- la del menu de Magia
  Campos:
      $8  = ancho de la ventana en celdas  -> marco = 8*$8 + 12 px
      $2e = largo del SELECTOR azul        -> marco = 12*$2e - 2 px
            (y el selector no puede pasar del ancho de la ventana)
  Estado de partida (TEST_AZ, ya con la tanda anterior): $8 = 10 -> 92 px ;
  $2e = 7 -> 82 px (medidos 84 en pantalla por David).
  David: "les sobra al menos una celda por la derecha, a la ventana y al recuadro".
      ventana:  10 -> 9   ( 92 -> 84 px = 1 celda de 12)  -> sitios 0x135A2 y 0x13684
      selector:  7 -> 6   ( 82 -> 70 px = 1 celda de 12)  -> sitios 0x13590 y 0x13672
  El selector NO puede bajar de 64 px: es lo que mide «Mei Hong».
  (El tercer sitio del selector, 0x0C86A, es de otra ventana: no se toca.)

Uso: python3 parche_ventana2.py <entrada.bin> <salida.bin> [ancho_ventana] [ancho_selector]
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
SITIOS_8 = (0x135A2, 0x13684)          # ancho de la ventana
SITIOS_2E = (0x13590, 0x13672)         # ancho del selector azul
VENTANA_DEF = 9                        # $8
SELECTOR_DEF = 6                       # $2e  (12*6-2 = 70 px: cubre «Mei Hong», 64 px)


def pon(st, off, valor, campo, nombre):
    w = st[off:off + 6]
    esperado = bytes.fromhex('317c') 
    assert w[:2] == esperado and w[4:6] == campo.to_bytes(2, 'big'), \
        'en 0x%05X esperaba move.w #$n,$%x(a0): %s' % (off, campo, w.hex(' '))
    viejo = int.from_bytes(w[2:4], 'big')
    st[off + 2:off + 4] = int(valor).to_bytes(2, 'big')
    print('  0x%05X  %-8s $%x = %d -> %d' % (off, nombre, campo, viejo, valor))


def aplica(entrada, salida, ventana=VENTANA_DEF, selector=SELECTOR_DEF):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    for off in SITIOS_8:
        pon(st, off, ventana, 8, 'ventana')
    for off in SITIOS_2E:
        pon(st, off, selector, 0x2e, 'selector')
    print('  ventana %d px (antes %d)   selector %d px (antes %d)'
          % (8 * ventana + 12, 8 * 10 + 12, 12 * selector - 2, 12 * 5 - 2))
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2],
           int(sys.argv[3]) if len(sys.argv) > 3 else VENTANA_DEF,
           int(sys.argv[4]) if len(sys.argv) > 4 else SELECTOR_DEF)
