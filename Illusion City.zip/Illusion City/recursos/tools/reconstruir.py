#!/usr/bin/env python3
"""Reconstructor de archivos de guion con reubicación de texto.

Modelo descubierto:
- Los archivos de guion tienen una zona de texto al final del archivo,
  precedida de una zona de ceros. BASE = inicio de esa zona.
- Los registros `c6 <id> 00 <texto> 00` son bloques de texto con etiqueta:
  id + BASE apunta a la posición del siguiente bloque (la mayoría de las
  veces exactamente al `c6` siguiente).
- Los `c5 <id> 00 00 00` tras un texto repiten el id del c6 precedente.

Reconstrucción:
1. Recorre el segmento de texto [S, E) byte a byte: los tramos que son
   cadenas del dump se sustituyen por su traducción codificada; el resto
   (comandos) se copia literal.
2. Mapa old->new de offsets para reajustar los IDs de los c6 (y los c5 que
   repiten el id del c6 precedente).
3. El delta de tamaño se añade al final del segmento (los bytes posteriores
   al segmento se desplazan intactos).

El archivo completo puede crecer -> el llamador puede reubicarlo al final
del disco parcheando el directorio ISO9660 y la tabla interna en INIT.BIN.
"""
import re
import sys
import csv
import struct
import importlib.util

sys.path.insert(0, 'tools')
spec = importlib.util.spec_from_file_location('cod', 'tools/codificador_castellano.py')
cod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cod)


def c6_records(d):
    """Registros c6 'reales' (id, pos, fin_de_texto) validados."""
    recs = []
    for m in re.finditer(rb'\xc6(..)\x00', d, re.DOTALL):
        p = m.start()
        end = d.find(b'\x00', p + 4)
        if end < 0 or end - (p + 4) < 6 or end - (p + 4) > 600:
            continue
        try:
            t = d[p + 4:end].decode('shift_jis')
        except Exception:
            continue
        if sum(1 for c in t if 0x3000 <= ord(c) <= 0x9FFF or 0xFF00 <= ord(c) <= 0xFF65) >= 3:
            recs.append((int.from_bytes(m.group(1), 'big'), p, end))
    return recs


def find_segment(d):
    """Devuelve (S, BASE, E): zona de texto, base de ids y fin del segmento.

    S: primer byte de la zona de ceros antes del primer c6.
    BASE: mediana de pos(c6_{i+1}) - id_i.
    E: fin del último bloque de texto + hasta 32 bytes de comandos finales.
    """
    recs = c6_records(d)
    if not recs:
        return None
    first_pos = recs[0][1]
    # S: retrocede sobre ceros
    S = first_pos
    while S > 0 and d[S - 1] == 0:
        S -= 1
    # BASE: mediana
    bases = sorted(recs[i + 1][1] - recs[i][0] for i in range(len(recs) - 1))
    BASE = bases[len(bases) // 2] if bases else first_pos - recs[0][0]
    # E: fin de la ÚLTIMA cadena del archivo (puede haber varios bloques de
    # texto separados por comandos) + tramo de comandos posterior
    from dumper_textos import scan_file
    last_end = first_pos
    for off, _txt in scan_file(d):
        if off >= first_pos:
            end = d.find(b'\x00', off)
            if end > last_end:
                last_end = end
    E = last_end
    p = E
    while p < len(d):
        b = d[p]
        if b == 0:
            p += 1
            continue
        if 0xC0 <= b <= 0xDF and p + 3 < len(d) and d[p + 2] == 0 and d[p + 3] == 0:
            p += 4
            continue
        # intenta decodificar un string SJIS corto
        e2 = d.find(b'\x00', p, p + 600)
        if e2 > p:
            try:
                t = d[p:e2].decode('shift_jis')
                if sum(1 for c in t if 0x3000 <= ord(c) <= 0x9FFF) >= 2:
                    p = e2 + 1
                    E = e2 + 1
                    continue
            except Exception:
                pass
        break
    E = min(len(d), p)
    # los ids pueden apuntar más allá del último texto (comandos finales):
    # el segmento debe cubrir al menos el último objetivo
    E = min(len(d), max(E, max(oid + BASE for (oid, _, _) in recs)))
    return S, BASE, E


def rebuild(d, translations, S, BASE, E):
    """Reconstruye el archivo. translations: {offset_abs: nuevo_texto_castellano}.
    Devuelve (new_bytes, informe)."""
    # spans de cadenas a reemplazar: usa el dumper para validar las originales
    from dumper_textos import scan_file
    strings = scan_file(d[S:E])           # (off_rel, texto)
    plan = []                              # (start_abs, end_abs_excl_terminador, new|None)
    for off_rel, txt in strings:
        off_abs = S + off_rel
        if off_abs in translations:
            end = d.find(b'\x00', off_abs)
            plan.append((off_abs, end, translations[off_abs]))
    plan.sort()

    # emitir con mapa de segmentos lineales old->new
    out = bytearray()
    segs = []                              # (old_a, old_b, new_a, new_b) inclusive-exclusivo
    pos_old = S
    pos_new = S
    informe = []
    for start, end, new in plan:
        if start > pos_old:
            segs.append((pos_old, start, pos_new, pos_new + (start - pos_old)))
            out += d[pos_old:start]
            pos_new += start - pos_old
        if new is None:
            nb = d[start:end + 1]
        else:
            try:
                nb = cod.encode_spanish(new) + b'\x00'
                old_len = end + 1 - start
                if len(nb) < old_len:
                    # relleno con ceros hasta el tamaño original: el comando
                    # siguiente conserva su offset exacto -> el archivo SOLO
                    # puede crecer, nunca encoger
                    nb += b'\x00' * (old_len - len(nb))
            except cod.EncodeError as e:
                informe.append(f'ERROR {start:#x}: {e}')
                nb = d[start:end + 1]
        informe.append(f'texto @{start:#x}: {end+1-start}B -> {len(nb)}B')
        segs.append((start, end + 1, pos_new, pos_new + len(nb)))
        out += nb
        pos_new += len(nb)
        pos_old = end + 1
    if E > pos_old:
        segs.append((pos_old, E, pos_new, pos_new + (E - pos_old)))
        out += d[pos_old:E]
        pos_new += E - pos_old
    seg_len_delta = pos_new - E

    def map_old(o):
        if o < segs[0][0] or o >= E:
            return o              # fuera del segmento: sin cambio
        for oa, ob, na, nb2 in segs:
            if oa <= o < ob:
                if ob == oa:
                    return na
                return na + int((o - oa) * (nb2 - na) / (ob - oa) + 0.5)
        # o == fin de un tramo: usar el inicio del siguiente
        for oa, ob, na, nb2 in segs:
            if o == ob and ob < E:
                idx = segs.index((oa, ob, na, nb2))
                if idx + 1 < len(segs):
                    return segs[idx + 1][2]
                return na
        return o

    # INVARIANTE clave (sobre el texto ya sustituido, ANTES de los fixups de
    # ids, porque los fixups alteran bytes dentro de los propios targets):
    # cada target de id (id+BASE) debe conservar sus bytes, salvo (a) los
    # bytes-ID de c5/c6 que el fixup remapea y (b) rangos traducidos.
    old_recs = c6_records(d)
    labels = {oid for (oid, _, _) in old_recs}
    id_bytes_old = set()
    for (oid, opos, oend) in old_recs:
        id_bytes_old.update(range(opos + 1, opos + 3))
    for m in re.finditer(rb'\xc5(..)\x00', d[S:E], re.DOTALL):
        p = S + m.start()
        if int.from_bytes(m.group(1), 'big') in labels:
            id_bytes_old.update(range(p + 1, p + 3))
    trans_ranges = [(t, d.find(b'\x00', t) + 1) for t in translations]
    inv_errs = 0
    for i, (oid, opos, oend) in enumerate(old_recs):
        T = oid + BASE
        Tn = old_recs[i + 1][1] if i + 1 < len(old_recs) else E
        if not (S <= T < Tn <= E):
            continue
        if any(t < Tn and te > T for (t, te) in trans_ranges):
            continue  # solapa traducción: los bytes cambian por diseño
        nb = map_old(T) - S
        nn = map_old(Tn) - S if Tn < E else len(out)
        a, b = d[T:Tn], bytes(out[nb:nn])
        if len(a) != len(b) or any(
            a[j] != b[j] and (T + j) not in id_bytes_old
            for j in range(min(len(a), len(b)))
        ):
            inv_errs += 1
            if inv_errs <= 3:
                informe.append(f'INVARIANTE ROTO rec{i}: old {d[T:Tn][:16]!r} vs new {bytes(out[nb:nn])[:16]!r}')

    # reajustar ids c6 y etiquetas c5
    out = bytearray(out)
    newrecs = c6_records(bytes(out))
    # reconstruir la lista de ids en orden con sus posiciones nuevas
    old_recs = c6_records(d)
    # para cada c6 viejo: target viejo T=id+BASE -> nuevo id = map(T)-BASE
    fixups = {}
    for (oid, opos, oend) in old_recs:
        T = oid + BASE
        nT = map_old(T)
        nid = nT - BASE
        if 0 <= nid <= 0xFFFF:
            fixups[opos + 1] = nid   # posición del u16 en el archivo viejo
        else:
            informe.append(f'AVISO: id de c6@{opos:#x} fuera de rango tras fixup')
    # aplicar fixups: las posiciones de los c6 en el archivo nuevo = map(pos vieja)+1
    new_recs = c6_records(bytes(out))
    # emparejar por orden
    applied = 0
    old_ids = [(opos, oid) for (oid, opos, _) in old_recs]
    new_pos_by_order = [(npos, nend) for (_, npos, nend) in newrecs]
    if len(old_ids) == len(new_pos_by_order):
        for (opos, oid), (npos, _) in zip(old_ids, new_pos_by_order):
            nid = fixups.get(opos + 1)
            if nid is None:
                continue
            out[npos + 1:npos + 3] = struct.pack('>H', nid)
            applied += 1
    # c5 <etiqueta> dentro del segmento: remapear todo id conocido
    labels = {oid for (oid, _, _) in old_recs}
    c5_fixups = []
    for m in re.finditer(rb'\xc5(..)\x00', d[S:E], re.DOTALL):
        p_abs = S + m.start()
        lab = int.from_bytes(m.group(1), 'big')
        if lab in labels:
            nid = map_old(lab + BASE) - BASE
            if 0 <= nid <= 0xFFFF:
                c5_fixups.append((p_abs + 1, nid))
    n_c5 = 0
    for old_pos, nid in c5_fixups:
        new_pos = map_old(old_pos) - S   # out es relativo al segmento
        out[new_pos:new_pos + 2] = struct.pack('>H', nid)
        n_c5 += 1

    # reconstruir el archivo: la cola [E:) queda SIEMPRE en su offset absoluto
    # (con el relleno in-situ de cadenas cortas el segmento nunca encoge:
    #  solo puede crecer -> relleno al final del archivo)
    new_file = bytes(d[:S]) + bytes(out) + d[E:] + b'\x00' * seg_len_delta
    if seg_len_delta < 0:
        # no debería ocurrir (solo crece), pero por seguridad reporta
        informe.append(f'AVISO: delta negativo {seg_len_delta}')

    informe.append(f'delta segmento: {seg_len_delta:+d} B; c6 fixups: {applied}; c5: {n_c5}; targets con bytes distintos: {inv_errs}')
    return new_file, informe


def main():
    # TEST 1: reconstrucción sin cambios debe ser byte-idéntica
    fname = sys.argv[1] if len(sys.argv) > 1 else 'A00.BIN'
    d = open(f'extraidos/{fname}', 'rb').read()
    S, BASE, E = find_segment(d)
    print(f'{fname}: S=0x{S:X} BASE=0x{BASE:X} E=0x{E:X} seg={E-S}B de {len(d)}B')

    # TEST 1: reconstrucción sin cambios debe ser byte-idéntica
    new, inf = rebuild(d, {}, S, BASE, E)
    identical = new == d
    print(f'TEST sin cambios: {"IDÉNTICO ✓" if identical else "¡DIFIERE! ✗"}')
    if not identical:
        for i in range(min(len(d), len(new))):
            if d[i] != new[i]:
                print(f'  primera diferencia @0x{i:X}: {d[i]:02X} vs {new[i]:02X}')
                break
        print(f'  len: {len(d)} vs {len(new)}')

    # TEST 2: crecimiento con traducciones; los targets de id deben
    # seguir apuntando a los mismos bytes (salvo bytes-ID remapeados
    # y rangos traducidos, que cambian por diseño)
    from dumper_textos import scan_file
    strings = scan_file(d[S:E])
    translations = {}
    for k, (off_rel, _txt) in enumerate(strings[:3]):
        translations[S + off_rel] = f'Prueba castellana numero {k + 1}.'
    new, inf = rebuild(d, translations, S, BASE, E)
    print(f'TEST crecimiento: delta={len(new) - len(d):+d}B')
    old_recs = c6_records(d)
    new_recs = c6_records(new)
    labels_o = {oid for (oid, _, _) in old_recs}
    labels_n = {oid for (oid, _, _) in new_recs}
    id_bytes_old = set()
    for (oid, opos, _) in old_recs:
        id_bytes_old.update(range(opos + 1, opos + 3))
    for m in re.finditer(rb'\xc5(..)\x00', d[S:E], re.DOTALL):
        p = S + m.start()
        if int.from_bytes(m.group(1), 'big') in labels_o:
            id_bytes_old.update(range(p + 1, p + 3))
    id_bytes_new = set()
    for (oid, npos, _) in new_recs:
        id_bytes_new.update(range(npos + 1, npos + 3))
    for m in re.finditer(rb'\xc5(..)\x00', new[S:S + (E - S) + (len(new) - len(d))], re.DOTALL):
        p = m.start()
        if int.from_bytes(m.group(1), 'big') in labels_n:
            id_bytes_new.update(range(p + 1, p + 3))
    trans_ranges = [(t, d.find(b'\x00', t) + 1) for t in translations]
    errs = 0
    if len(old_recs) != len(new_recs):
        errs = -1
        print(f'  nº de registros c6 cambió: {len(old_recs)} -> {len(new_recs)}')
    else:
        import re as _re
        mseg = _re.search(r'delta segmento: ([+-]?\d+)', '\n'.join(inf))
        seg_delta = int(mseg.group(1)) if mseg else len(new) - len(d)
        for i, (oid, _opos, _oend) in enumerate(old_recs):
            T = oid + BASE
            Tn = old_recs[i + 1][1] if i + 1 < len(old_recs) else E
            if not (S <= T < Tn <= E):
                continue
            if any(t < Tn and te > T for (t, te) in trans_ranges):
                continue
            nb = new_recs[i][0] + BASE
            nn = (new_recs[i + 1][1] if i + 1 < len(new_recs)
                  else max(new_recs[i][1], E) + seg_delta)
            a, b = d[T:Tn], new[nb:nn]
            bad = len(a) != len(b) or any(
                a[j] != b[j] and (T + j) not in id_bytes_old
                and (nb + j) not in id_bytes_new
                for j in range(min(len(a), len(b)))
            )
            if bad:
                errs += 1
                if errs <= 3:
                    print(f'  target {i} no conservado: old={d[T:Tn][:20]!r} new={new[nb:nn][:20]!r}')
    print(f'Verificación de targets: {"OK ✓" if errs == 0 else f"FALLOS: {errs}"}')
    for line in inf[-3:]:
        print(' ', line)


if __name__ == '__main__':
    main()
