#!/usr/bin/env python3
"""fuente_simbolos.py - los SIMBOLOS de la fuente de David que faltaban.

QUE FALTABA (auditoria del 22/09)
  `fuente_8px.py` solo escribia las letras, los digitos, los 16 acentos y el `$`.
  Todo lo demas seguia siendo la fuente ORIGINAL del juego: de ahi el «+» de
  «ATA 4+ 75», el «%» de «PRE 91%» y la virgulilla de «PV 10 ~ 10».

COMO SE SABE QUE CELDA ES CADA SIMBOLO
  `recursos/tools/celdas_fuente.py` imita la rutina del juego (START $1922C +
  $191BE) y devuelve la celda; comprobado dibujando la celda en la fuente VIRGEN
  y leyendo el glifo (celda 40 = '+', 50 = '%', 14 = '~', 26/27 = '[ ]', ...).

  Caracter -> codigo del motor -> celda (INIT 0x14E0 + celda*18):
      ,  0x8141 ->   1        .  0x8142 ->   2        :  0x8146 ->   6
      ;  0x8147 ->   7        ?  0x8148 ->   8        !  0x8149 ->   9
      —  0x815C ->  13        ~  0x815E ->  14        (  0x8169 ->  22
      )  0x816A ->  23        [  0x816D ->  26        ]  0x816E ->  27
      "  0x8171 ->  30        +  0x817B ->  40        -  0x817C ->  41
      %  0x8193 ->  50
  (`/` 0x818E y `$` 0x8190 comparten la celda 49: la del dinero, que ya escribe
   fuente_dinero.py. `＊` 0x8196 comparte la celda 52 con el '0': no se toca.)

Uso: python3 fuente_simbolos.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
REC = os.path.dirname(AQUI)
PROY = os.path.dirname(REC)
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
spec2 = importlib.util.spec_from_file_location('f', os.path.join(AQUI, 'fuente_8px.py'))
f = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)

CELL = 18
# OJO: hay DOS tablas de fuente y los SIMBOLOS de las lineas de numeros salen de la
# SEGUNDA (la del dinero):
#   tabla A (menus)  INIT 0x4ED0 / OPEN 0xA710
#   tabla B (dinero) INIT 0x14E0 / OPEN 0x6D20   <- la que formatea «4+ 75», «91%», «10 ~ 10»
# Medido el 22/09: con el «+» de David en la tabla A la pantalla NO cambiaba; los
# digitos de esa misma fila (que si vienen de la tabla B) ya eran suyos. => se escriben
# los simbolos en LAS DOS, que es lo que hace fuente_dinero.py con el '$' y los digitos.
TABLAS = (('INIT', 107, 149400, 0x4ED0), ('OPEN', 285, 69258, 0xA710),
          ('INIT-B', 107, 149400, 0x14E0), ('OPEN-B', 285, 69258, 0x6D20))
# caracter del PNG -> celda de la fuente
SIMBOLOS = {',': 1, '.': 2, ':': 6, ';': 7, '?': 8, '!': 9, '—': 13, '~': 14,
            '(': 22, ')': 23, '[': 26, ']': 27, '"': 30, '+': 40, '-': 41,
            '%': 50}


def aplica(entrada, salida):
    G = f.glifos_david()
    raw = bytearray(open(entrada, 'rb').read())
    for nombre, lba, sz, base in TABLAS:
        d = bytearray(m.region(raw, lba, sz))
        for ch, celda in sorted(SIMBOLOS.items(), key=lambda kv: kv[1]):
            off = base + celda * CELL
            glifo = f.a_celda12(G[ch], 0)
            viejo = bytes(d[off:off + CELL])
            assert len(glifo) == CELL
            d[off:off + CELL] = glifo
            print('  %-5s celda %2d  «%s»   antes %s' % (nombre, celda, ch, viejo[:6].hex(' ')))
        m.escribe_region(raw, lba, bytes(d))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())
    v = m.edcecc.verifica_imagen(salida, verbose=False)
    print('  EDC/ECC: %s' % ('OK' if not any(v.values()) else 'MAL'))


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
