#!/usr/bin/env python3
"""Render a region in several tile formats to PNGs for font identification."""
import sys
from PIL import Image

def render(data, off, ntiles, w, h, fmt, scale=3):
    if fmt == '1bpp':      bpt = 1
    elif fmt == '2bpp':    bpt = 2
    else:                  bpt = 4
    stride = w // 8 * bpt * h // 8 // h * h  # bytes per tile
    # bytes per tile = (w/8)*bpt*(h/8)
    stride = (w // 8) * bpt * (h // 8)
    img = Image.new('P', (16*w*scale, ((ntiles+15)//16)*h*scale), 0)
    pal = [(17,17,17),(255,255,255),(255,120,120),(120,200,255)] + [(0,0,0)]*252
    img.putpalette([c for rgb in pal for c in rgb])
    px = img.load()
    for t in range(ntiles):
        tile = data[off + t*stride : off + t*stride + stride]
        if len(tile) < stride: break
        tx, ty = (t % 16)*w*scale, (t // 16)*h*scale
        for y in range(h):
            for x in range(w):
                v = 0
                for p in range(bpt):
                    byi = (y // 8)*(w//8)*bpt + p*(h//8) + (y % 8)
                    if byi < len(tile):
                        v |= ((tile[byi] >> (7 - (x % 8))) & 1) << p
                v &= 3
                for sy in range(scale):
                    for sx in range(scale):
                        px[tx+x*scale+sx, ty+y*scale+sy] = v
    return img

def main():
    path, off, ntiles = sys.argv[1], int(sys.argv[2],0), int(sys.argv[3])
    prefix = sys.argv[4]
    data = open(path,'rb').read()
    for fmt in ('1bpp','2bpp','4bpp'):
        for (w,h) in ((8,8),(8,16),(16,16)):
            img = render(data, off, ntiles, w, h, fmt)
            img.save(f"{prefix}_{fmt}_{w}x{h}.png")
    print("saved 9 renders with prefix", prefix)

main()
