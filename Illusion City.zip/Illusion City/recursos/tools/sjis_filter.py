#!/usr/bin/env python3
"""Filter sjis_scan output: keep only blocks dominated by real Japanese chars."""
import sys, re

KANA = re.compile(r'[\u3040-\u30ff]')
KANJI = re.compile(r'[\u4e00-\u9fff]')
BAD = re.compile(r'[\ufffd\u3000-\u303f\uff00-\uffef]')

def main():
    path = sys.argv[1]
    min_jp = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    min_ratio = 0.6
    kept = []
    for line in open(path, encoding='utf-8'):
        m = re.match(r"0x([0-9A-F]+)-0x([0-9A-F]+) \((\d+) B\): (.*)", line.rstrip('\n'))
        if not m:
            continue
        s, e, nb, text = int(m.group(1), 16), int(m.group(2), 16), int(m.group(3)), m.group(4)
        # text is repr'd; strip quotes
        inner = text.strip("'\"")
        n_kana = len(KANA.findall(inner))
        n_kanji = len(KANJI.findall(inner))
        n_bad = len(BAD.findall(inner))
        jp = n_kana + n_kanji
        total = max(len(inner), 1)
        if jp >= min_jp and jp / total >= min_ratio and n_bad <= 2:
            kept.append((s, e, nb, inner))
    for s, e, nb, t in kept:
        print(f"0x{s:08X}-0x{e:08X} ({nb} B): {t}")
    print(f"\nTotal kept: {len(kept)}", file=sys.stderr)

if __name__ == '__main__':
    main()
