#!/usr/bin/env python3
"""Parse ISO9660 from track01.iso and extract files."""
import sys, struct, os

ISO = 'track01.iso'

def sectors(data, lba, count=1):
    return data[lba*2048:(lba+count)*2048]

def main():
    data = open(ISO, 'rb').read()
    mode = sys.argv[1] if len(sys.argv) > 1 else 'list'
    pvd = None
    # find PVD: in raw .bin, but our iso is sector-aligned 2048 if extracted properly
    for i in range(0, 64):
        blk = data[i*2048:(i+1)*2048]
        if blk[0:1] == b'\x01' and blk[1:6] == b'CD001':
            pvd = blk
            print(f"PVD at LBA {i}")
            break
    if pvd is None:
        print("No PVD found in 2048-granularity; data may not be sector aligned")
        return
    root = pvd[156:190]
    lba = struct.unpack('<I', root[2:6])[0]
    size = struct.unpack('<I', root[10:14])[0]
    print(f"Root dir: LBA {lba}, size {size}")

    files = []

    def read_dir(lba, size, prefix=''):
        nsec = (size + 2047) // 2048
        buf = sectors(data, lba, nsec)
        pos = 0
        while pos < len(buf):
            ln = buf[pos]
            if ln == 0:
                # rest of sector
                pos = (pos // 2048 + 1) * 2048
                continue
            rec = buf[pos:pos+ln]
            flags = rec[25]
            extent = struct.unpack('<I', rec[2:6])[0]
            fsize = struct.unpack('<I', rec[10:14])[0]
            name_len = rec[32]
            name = rec[33:33+name_len]
            if name in (b'\x00', b'\x01'):
                pos += ln
                continue
            name = name.decode('ascii', 'replace').split(';')[0]
            full = prefix + name
            if flags & 2:
                read_dir(extent, fsize, full + '/')
            else:
                files.append((full, extent, fsize))
            pos += ln

    read_dir(lba, size)
    for name, extent, fsize in files:
        print(f"{name:24s} LBA {extent:6d}  0x{extent*2048:08X}  {fsize} B")

    if mode == 'extract':
        outdir = 'extraidos'
        os.makedirs(outdir, exist_ok=True)
        for name, extent, fsize in files:
            buf = sectors(data, extent, (fsize + 2047)//2048)[:fsize]
            safe = name.replace('/', '_')
            with open(os.path.join(outdir, safe), 'wb') as f:
                f.write(buf)
        print(f"\nExtracted {len(files)} files to {outdir}/")

main()
