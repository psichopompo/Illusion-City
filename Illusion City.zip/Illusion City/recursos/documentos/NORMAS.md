# NORMAS del proyecto (nacidas de errores reales)

Reglas de obligado cumplimiento. Cada una cita el error que la motivó. **Archivo limpiado 2026-09-19**: se eliminan referencias a ficheros ya borrados (track01_original.bin, [ORIGINAL].bin, track01_castellano.iso, minimal_v2, START_CAST_V3.BIN, SD.BIN.ok, etc.).

## 0. Entregable
- **El bin generado SIEMPRE se llama `Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin`** — 18M, 7842 sectores raw 2352. No cambiar el nombre cada vez. (Petición explícita 2026-09-19)
- El .bin que carga el .cue es raw 2352, nunca ISO 2048 (la BIOS no la lee y cae al reproductor de CD).

## 1. Texto y plantillas
1. **NUNCA cambiar la longitud de una línea de plantilla sin actualizar TODAS las referencias absolutas** (lea/move inmediatos en código Y tablas de datos) que caigan dentro de la zona desplazada. → Error: Z5/Z19/Z21 sesión 1 cambiaron largos; valores numéricos pisaban etiquetas.
2. **Un escaneo de u32 da FALSOS POSITIVOS**: `XX 2C 00 02 43 YY` (move.w $2(an)+lea.l) o `61 00 02 44 4A` (bsr+tst) o `02 44 00 FF` (andi.w) se lee como u32 sin ser referencia. Verificar decodificando instrucción.
3. **Texto de plantillas es SIEMPRE fullwidth SJIS 2B** (A=8260-Z=8279, a=8281-z=829A, 0=824F-9=8258, sp=8140, ：=8146). ASCII 1B sale como kanji basura. → Error: "Mens." raw ASCII → kanji.
4. **Conservar marcadores de color (&4/&5/&7) y posición EXACTA** respecto al original; &7 al final cuando el original lo tiene. → Error: menú Velocidad todo azul.
5. **Fullwidth ０-９ = 824F..8258: ０=824F, １=8250.** Campos "０００" = 824F 824F 824F. Nunca escribir de memoria: `encode('shift_jis').hex()`.
6. **Fullwidth en START = bloque SJIS 8260-829A**, no GFONT (82C9...). Buscar con códigos correctos o da 0 hits falsos. → Error: "Magia" parecía no existir.
7. **Al asignar slice de bytearray, `assert len(nuevo)==len(slice)`** antes. Asignación más corta encoge buffer y corrompe lecturas posteriores.
8. **Writes de valor del engine van a offset de byte FIJO dentro de la línea** (demostrado Grp byte 24, celdas 9-10), NO al placeholder ００. Mover placeholders no mueve write; hay que parchear código del write (aún no localizado). Diseñar layout poniendo campo del write donde se quiera el número.
9. **Plantillas vivas de Velocidad/magia/sistema/combate/principal están en zona 0x17500-0x177AE de START.BIN** (únicas copias, verificado con find). 0x13D60 es bloque de CEROS, 0x11D28/0x11D58/0x11D88 es CÓDIGO, no tablas de punteros. Confirmar con find antes de parchear.
10. **術/魔術/ステータス/アイテム/会話 no existen como texto en disco.** Filas sin traducir y iconos 忌/瞬/哀/僕/渡 son bitmaps pre-renderizados, no plantillas. No perseguir texto donde no lo hay.
11. **Tabla maestra de nombres INIT 0x22900-0x22CA0**: entradas NUL-sep variable (4B-26B), lectura secuencial. Alargar desplaza resto del archivo y no hay bytes libres en cola (dialogs hasta final). No tocar sin verificar TODAS las refs y aprobación explícita. Menú magia copia máx 5 chars desde $bd00 → Tianren (7) se truncaría.

## 2. Construcción
12. **Verificar SIEMPRE bytes en .bin final publicado** (no intermedio) antes de enviar a David. → Error: "no veo cambio" sin verificar bin final.
13. **Pipeline actual seguro**: restauración desde state bueno via `parchea_cast_bin.py` + escritura en sitio LBA59 `(59+off//2048)*2352+16+off%2048` sin tocar sync/modo/MSF/EDC/ECC, sin reconstruir ISO. Si se necesita rebuild completo, usar `track01.iso` (16M) + `textos_dumper.csv` + `parchear_start.py` → START_CAST.BIN + `reconstruir_iso.py`. El rebuild global rompió INIT (GAME OVER) en el pasado → modo seguro por defecto.
14. **No acumular parches sobre binarios ya parcheados** salvo que sea escritura en sitio controlada (caso START_correcto). Regenerar desde base limpia cuando sea posible.
15. **Mapeo raw .bin ↔ ISO**: raw = n*2352+16+r para cada offset ISO n*2048+r. Un slice continuo `raw[base:base+size]` multi-sector es BASURA (sync+header entre sectores). Extracción por sectores: `for k in range(0,size,2048): base=(lba+k//2048)*2352+16; chunk=raw[base:base+2048]`. Comparar bin↔ISO solo con extracción por sectores. → Error: 94% diffs falsos, SD.BIN fantasma (OPEN desplazado 76KB por usar fórmula raw sobre ISO).
16. **Leer ISO de 2048 B/LBA siempre `iso[lba*2048:+sz]`**, nunca `lba*2352+16` (desplaza 304B por LBA). Fórmula raw solo para .bin crudo 2352.
17. **Aritmética hex: NUNCA manual para layout.** Offsets de zona libre con alocador secuencial en código. → Errores: 0x176B4+31B=0x176D3 escrito 0x176CB → SY3 pisó SY2.
18. **Códigos SJIS: siempre cp932, nunca memoria.** 冒=0x9660, 膨=0x9663 (intercambiados de celda en fuente del juego). Verificar con codec.

## 3. Fuente
19. **Fuente del menú velocidad lee INIT.BIN** (experimento discriminador: INIT David / OPEN 8 / GFONT 3 → David vio David). Tablas: celdas 12×12, 18B (144 bits continuos bit=12r+c MSB), en INIT+0x4ED0 y OPEN+0xA710 (no 0xA740). Orden JIS fila-major. Bloque fullwidth Latin ０-９ A-Z a-z en INIT 0x1888-0x1CC2.
20. **Glifo 8×8 centrado en celda 12×12 en (2,2) → gap 4px entre letras** ("I L L U S I O N"). Off (0,2) gana 2px derecha (s de x136→134) y reduce gap a 2px, arregla clip sin tocar ventana. Decisión de David si se deja (0,2) o (2,2).
21. **Antes de diagnosticar "glifo mal pintado", zoom 16× pixel-a-pixel.** 冒 a 0.8× parece 膨; zoom 16× desmontó un día de búsquedas.
22. **Fuzzy de glifos sobre ISO completo = inestable** (miles hits falsos). Para localizar tabla: densidad bitcount + tiras 16 celdas a 4×.
23. **Celda 12×12 = 144 bits CONTINUOS**, no 2 bytes por fila. Validar round-trip sobre celda conocida (術) antes de pintar.
24. **Artefactos en recursos/, no /tmp** (/tmp no persiste entre turnos).

## 4. Gestión y nombres
25. **Workspace ligero (128MB)**: estructura actual 2026-09-19:
   - `illusion-city/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin` 18M (entregable, nombre fijo)
   - `illusion-city/recursos/` → `tools/` (pipeline), `textos_dumper.csv` (330K, 2981 líneas, usado por parchear_start.py/reconstruir_iso.py — NO borrar, es fuente de traducción), `extraidos/START.GFONT.INIT.OPEN.BIN` (inputs), `analisis/START_CAST.BIN` (96K traducido), `documentos/` (antes `informes/`: DIARIO.md, NORMAS.md, GUIA_FULLWIDTH.md, INFORME_TRADUCCION.md, CUE, etc.)
   - Intermedios borrados: `track01.iso` 16M (regenerable desde [CAST].bin via LBA*2048), `iso_map.json` ×2 (5.8K/1.1K, no usado por ningún tool, borrados 2026-09-19), zips, PNGs debug, uploads/
   - `textos_dumper.csv` SÍ vale: es la base de 147 traducciones in-situ + 329 no_cabe; debe quedarse en `recursos/` porque `tools/*.py` lo buscan como `CSV_IN='textos_dumper.csv'` relativo a `recursos/`.
26. **DIARIO.md al día**: al empezar leer entero; al terminar cada tarea actualizar hecho/bien/mal/pendiente.
27. **Nada está "arreglado" hasta que David confirma en emulador.** Yo verifico bytes; él pantalla.
28. **Nombres canon (solo estos)**: Tianren, Meifan (NO Meihong), Maestro Shu, Houmei, Cash, Isaac, Doc, Airén, Xiao Mei, Kai, Rey Maten, Lee/Fei/Vaara/Dai/Ark/Meshmer/Yama/Aya, Liu-Kei, Durand, Kurogane, Sumeragi, Raiden, Wadatsumi, Neoticus, Elphas, McGregor, Rey Deva, Flamenco, Ejecutivo de SIVA, Noi, Tao Ho, R. Mortimer, Tetsu. HUD/batalla solo nombres personales; títulos largos solo en diálogo.
29. **HUD**: LV→NV, HP→PV, MP→PM; unificar "chakra" antiguo a PM.
30. **ASCII 1-byte dentro de START.BIN en plantillas fijas = RECHAZADO** (renderiza japonés). Solo fullwidth. Excepción: etiquetas equip "Arma/Prot/Otro" pre-existentes ASCII → dejar byte-a-byte intactas.
31. **Header**: "Magia de <name>" / "Equipo de <name>" sin colon ni corchetes. Tianren completo.
32. **Efecto window: título debe ser AMARILLO** (&4). Importante diferenciarse de opciones inferiores.
33. **Menú principal fila 術: "Magia".** System fix = ensanchar caja+frame, no acortar palabras.
34. **Equip aprobado**: 忌→MAL, 瞬→VEL, 哀→PENA/TRIS, 僕→AFIN, 渡→PASO/TRAN; ハンドガン→Pistola, スーツ→Traje.
35. **0x9660 = 膨** (David 4× zoom) — aceptado. Unaccented "Rapido" NO aceptable.
36. **"Nada es imposible"**: nunca declarar plantilla cerrada visible; siempre buscar código/modo.
37. **Wraparound modelo**: overflow derecha pasa al lado contrario misma altura (s perdida alinea con O muesca). Caja invisible tiene límite anchura; ampliar con px libres, no múltiplos. Solo 1-2px necesarios. Box row pitch mucho más ajustado que visible 12px.
38. **Velocidad**: texto donde estaba, solo ampliar caja pintable, nunca mover texto. X=0 suelo (4px grid), X=-1 rompe (M desaparece, wrap derecha).
39. **Guardar parches si no ocupan mucho** para revertir a mejor versión (queja 2026-09-19: no guardar impidió revertir).
