# DIARIO — Illusion City [CAST] (sesiones en este workspace)

> Continúa el diario de la sesión anterior (ver `recursos/informes/DIARIO.md` —
> leer SIEMPRE al empezar). Este diario registra lo hecho AQUÍ, bien y mal.
> Reglas vivas: `NORMAS.md`. Actualizar al final de cada tarea.

## Contexto
- David prueba en Genesis Plus 1.3.5 con el .cue [CAST]. Él ve pantallas; yo no
  puedo ejecutar el emulador. Sus capturas son la fuente de verdad visual.
- Workspace ligero (límite de snapshot 128MB). Tras limpieza 2026-09-18:
  **54MB**. Lo imprescindible: track01_original.bin (18MB, fuente de todo),
  recursos/track01.iso (16MB, input del pipeline), [CAST].bin (18MB, entrega),
  recursos/{tools, textos_dumper.csv, extraidos/{START,GFONT,INIT}.BIN,
  analisis/{START_CAST_V3,START_CAST,GFONT_*}.BIN, informes/{DIARIO,
  INFORME_TRADUCCION,[CAST].cue}}, DIARIO.md, NORMAS.md. El resto (zip, ISOs
  duplicadas/intermedias, dumps SJIS, state_*.bin, backups CSV) era
  regenerable → borrado. [ORIGINAL].bin para el pipeline se copia al vuelo
  de track01_original.bin (NORMA 18).

## 2026-09-18 — Sesión 2 (esta)

### Hecho
1. Verificado íntegro el .bin original (git hash = 51c1089d...). Descargado y
   descomprimido Recursos.zip; borrado __MACOSX.
2. **MAPA DE REFERENCIAS DE PLANTILLAS** (hito clave): cada plantilla de
   START.BIN es referenciada por u32 (inmediatos) en el código 68000. Escaneé
   TODO el archivo y decodifiqué cada referencia:
   - **Z22 Velocidad (130B @0x143EE)**: ÚNICA referencia real =
     `move.l #$243EE, $22(a0)` en 0x139AE. Las "refs" +11/+18/+92 eran FALSOS
     POSITIVOS (bytes de `andi.w`, `bsr`, `move.w $2(an)`+`lea`). → Z22 se puede
     REUBICAR y cambiar de largo sin tocar más código.
   - **Z5 Magia (136B @0x13D60)**: base (0x11DE8) + 5 writes absolutos:
     nombre @+8 (lea 0x11E00, jsr $2087E copia máx d2=5 chars desde $bd00),
     now3 @+76 (lea 0x11E14, jsr $18722 3 dígitos), ind2 @+94 (lea 0x11E56,
     jsr $186D6), max3 @+114 (lea 0x11E66, jsr $18722), grp2 @+132
     (lea 0x11E98, jsr $186D6).
   - **Ventana objetivo (0x13DF6..)**: tabla de 3 u32 en 0x13DEA-0x13DF5
     (dirección RAM fija 0x23DEA; NADA apunta a la tabla → la tabla NO se mueve,
     las 3 cadenas sí se pueden mover).
   - **Z10-Z15 Equipo / Z16-Z18 tabs**: tablas de punteros + writes en +8/+32
     (las parches v3 mantuvieron longitudes → seguras).
   - **Z19 Ficha (338B)**: ~25 refs absolutas (leas + tabla de datos 0x13396-
     0x133FE para Z21; Z19 tiene leas en 0x12E1x-0x12F9x y datos @0x4257 etc.).
   - **Z20 Técnicas (392B)**: 71 refs (leas + tabla 0x13150-0x131C4).
   - **Z21 Combate (360B)**: 44 refs (leas + tabla de 25 u32 en 0x13396-0x133FE).
   - **Z23/Z24 [SanaPV]/[SanaPM]**: leas 43F9 (0x120C4/0x125F0/0x126DE).
3. **REGRESIÓN ENCONTRADA (la causa probable de pantallas raras)**: la sesión
   anterior cambió las LONGITUDES de línea de Z5 (L0 26→20B, L4 36→42B), Z19
   (todas las líneas) y Z21 (L1 38→40B, L6 36→34B) SIN actualizar los offsets
   absolutos del código → en juego, los valores numéricos se escriben sobre las
   etiquetas (Z5: el valor de PM pisaría "Ind"; Z19: total caos; Z21: filas
   Ataque/Def/Agi desalineadas +2). Z20 quedó OK (mismo largo).
   DECISIÓN: esta sesión Z19/Z21 vuelven al japonés original (pantallas que
   FUNCIONAN); el rediseño ES con mapa de refs se hace en la sesión siguiente.
4. Diseño v4 de las 4 zonas pedidas por David (menú velocidad, menú magia,
   ventana objetivo, HUD) — ver parchear_start_v4.py.

### Pendiente (esta sesión) — CERRADO en la parte 2
- [x] track01.iso desde el .bin original.
- [x] parchear_start_v4.py + ejecutar (v4 final, alocador secuencial).
- [x] reconstruir_iso.py → .bin [CAST] final.
- [x] Verificación final de bytes en el .bin publicado (NORMA 4) — 0 diffs
      sector a sector + checks de contenido.
- [x] Búsqueda LV/HP/MP/レベル/体力/術気 (resultado en parte 2: tabla de
      mensajes de batalla = nuevo front).
- [x] Cerrar diario + normas.

### Frontes para sesiones siguientes (orden, actualizado en parte 2)
1. **Tabla de mensajes de batalla ES**: bloque INIT.BIN 0x233A0-0x23560
   (≈25 cadenas $2の体力が#1回復 / $2の術気が#1回復 / ...), DUPLICADO en
   OPEN.BIN 0xFae1-0xFCxx, + fragmento START.BIN 0xD8D0. Slots 12-22B →
   español no cabe in-situ; sin refs u32 → diagnosticar primero cómo se
   direcciona la tabla (offsets relativos? tabla de índices?). Cuidado:
   INIT.BIN = archivo de alto riesgo (rebuild global → GAME OVER); solo
   ediciones quirúrgicas.
2. **Nombres de técnicas de magia (sin abreviar)**: 栄気=Energía Vital,
   練気=Ki Concentrado, 気功弾=Bala de Ki, 被甲護身=Cuerpo Acorazado,
   防呪結界=Barrera Anti-Maleficios, 守気=Ki Guardián, 攻気=Ki Ofensivo,
   封呪=Sello Mágico, 遅動=Ralentizar. Zona Z20 (0x140DE) + lista Z21.
3. **Z19 Ficha ES**: rediseño conservando longitudes o reubicación + parche
   de ~25 refs. Labels: NV/EXP/Next/PV/PM/Ataque/Defensa/Agilidad/Pericia/
   Acierto. (Mapa de refs en la parte 1 de este diario.)
4. **Z21 Combate ES**: tabla de datos 0x13396-0x133FE (25 u32) + leas.
5. **Z20 Técnicas ES**: columnas de armas (Ｇｕｎ, ライフル, 砲, ヘビー,
   クロー, 杖, 剣, 斬糸) — nombres de David pendientes.
6. Fuente 膨: localizar la tabla de fuente del menú de velocidad si David
   sigue viendo 膨 (celda fina 226 parcheada en 3 copias + 48 bitmaps
   gruesos ya aplicados).
7. Desbloquear no_cabe=329 (vía de crecimiento segura, sin romper INIT).
8. Continuar guion (A10.BIN y siguientes).

## 2026-09-18 — Sesión 2, parte 2 (v4 final + bin publicado)

### Hecho (bien)
1. **Layout del hueco libre por alocador secuencial** en parchear_start_v4.py:
   los blobs (Z22, Z5, EFG, IT, SY, redirects) se construyen primero y se
   colocan con `alloc()` (HUECO0=0x17500, FIN_LIBRE=0x17F7F). Cero offsets
   manuales. Layout final (impreso por el log de cada run):
   `Z22=0x17500(138B) Z5=0x1758A(144B) EFG=0x1761A/27/2E IT=0x17639/46/4F/5E
   SY=0x17669/84/A3 redir=[0x176C4,0x177AE) 33 u32`.
2. **Fuente de las zonas copiadas**: V3 → `analisis/START_CAST_V3.BIN`
   (pieza v3 limpia, no self-referencial).
3. **Tabla del menú principal arranca en 0x13D12** (6 u32), no en 0x13D18
   (lectura desalineada de la sesión anterior). Rango copiado de v3 corregido.
4. **Swap nuevo byte-neutro**: 0x14F18 術気→ＰＭ (ventana de magia EN combate,
   plantilla 39B 術気/n〔個〕/〔集〕; sin refs u32, acceso por offset).
5. **Pipeline completo**: reconstruir_iso.py → track01_castellano.iso +
   [CAST].bin (18,444,384 B) + CUE ya existente en informes/. Stats: in-situ
   v1 ok=147, no_cabe=329, errores=0; bitmaps 48/48 (16×3); celda fina 226/á
   ×3; START.BIN @LBA59.
6. **MAPEO BIN↔ISO (descubrimiento clave)**: el user data del bin NO es
   contiguo entre sectores (cada sector 2352 tiene 288 B de header).
   Mapeo correcto: `bin = (L + X//2048)*2352 + 16 + X%2048` donde L=LBA del
   archivo y X=offset dentro. La nota vieja "0x21D80+X" era FALSA.
   Verificación de [CAST].bin: región START (48 sectores) vs START_CAST.BIN =
   0 diffs + checks de contenido (Velocidad/Rápido-Lento/[Magia]+7 celdas/
   Efecto/Ind/Grupo/[Item]/Conversación-ó/NV/PV/PM/Combate/base 0x27500/
   tablas EFG+IT+SY/HUD Tianren-Meifan-Isaac).
7. **Escaneo completo del disco** (167 archivos):
   - ASCII LV/HP/MP (66 hits): FALSOS POSITIVOS en datos binarios
     (GENEI_ED/OP.DAT, F20/F50/C40/CK4, código INIT/OPEN). Ninguna cadena.
   - ＬＶ/ＨＰ/レベル: 0 hits (todo ya traducido o inexistente).
   - ＭＰ: 2 hits = nombre de arma "ＭＰ５ＫＡ４" (Ingram) en INIT/OPEN → SE
     MANTIENE (es nombre de modelo, no la etiqueta de recurso).
   - **体力/術気: 14 hits REALES de mensajes de batalla sin traducir**:
     bloque INIT.BIN 0x233A0-0x23560 (≈25 cadenas: '$2の体力が#1回復',
     '$2の術気が完全回復', '$2が#1の体力を失った'...) DUPLICADO en OPEN.BIN
     (0xFae1...) + fragmento START.BIN 0xD8D0 '体力を失った' (slot 13B, sin
     refs u32 → no fixable in-situ). SIN refs u32 → la tabla se accede por
     otro mecanismo (pendiente de diagnosticar). → siguiente front.

### Hecho (mal) — errores de ESTA parte
1. **Sumas hex manuales otra vez**: 0x176B4+31B=0x176D3 (escribí 0x176CB →
   SY3 pisó el ＯＦＦ de SY2) e IT3+15B=0x1768B (escribí 0x1768A). Solución:
   alocador (punto 1).
2. **Mis propios scripts de verificación traían expectativas falsas** (5 de 4
   "fallos" no eran del parche): pensé Ｅ=8265 (es **8264**), Ｖｅｌｏｃｉｄａｄ
   = 11 celdas (son 9), L2 de Z22 en 0x17524 (empieza en 0x17518), EFG
   'Ｅｆｅｃｔｏ' = 11B (son 12B), 'Ｉａａc' (typo de Isaac), y "dígitos ８-１５"
   cuando la plantilla ORIGINAL muestra １-８ en las celdas 8-15 (la spec
   se refería a la posición, no al valor). → NORMA 15/17.
3. **Borré [ORIGINAL].bin del pipeline antes de re-ejecutarlo** → fallo
   FileNotFoundError al regenerar [CAST].bin. Copiarlo de nuevo y re-ejecutar.

### Pendiente
- [ ] David prueba el bin nuevo (borrar bins viejos del directorio del CUE).
- [ ] Tabla de mensajes de batalla (体力/術気, INIT+OPEN+START) → ver frontes.
- [ ] Nombres de técnicas de magia (栄気=Energía Vital, 練気=Ki Concentrado,
      気功弾=Bala de Ki, 被甲護身=Cuerpo Acorazado, 防呪結界=Barrera Anti-
      Maleficios, 守気=Ki Guardián, 攻気=Ki Ofensivo, 封呪=Sello Mágico,
      遅動=Ralentizar) — deben caber SIN abreviar (Z20/Z21).
- [ ] Ventana objetivo: usé "Ind" (plan B). Si David ve que la caja flotante
      es ancha, "Individual" cabe (el string va en zona libre).

## Notas técnicas — layout FINAL v4 (supera la chuleta anterior)
- Z5: 144B @0x1758A (RAM 0x2758A). L0 30B: ［Ｍａｇｉａ］(1-7) + 8 celdas
  (nombre @+16, 7 celdas, d2 parcheado 5→7). L2 30B: 6sp &4ＰＭ(7-8) sp Ｃｏｓｔｅ
  (10-14) — patrón de color idéntico al original (sin &7, como en 術気/消費術気).
  L3 36B: &5Ａｈｏｒａ&7＋０００(val @+80, 3 dígitos der. → ≤99 en 7-8) sp
  &5Ｉｎｄ&7＋００(val @+98). L4 40B: &5Ｍａｘ&7＋０００(val @+118) ００(val
  @+126) &5Ｇｒｐ&7. Parches: 0x11DEA base, 0x11E02 +16, 0x11E08 d2=7,
  0x11E16 +80, 0x11E58 +98, 0x11E68 +118, 0x11E9A +126. Old 0x13D60-0x13DE7 a 0.
- Z22: 138B @0x17500 (RAM 0x27500). L0 20B: &5＋Ｖｅｌｏｃｉｄａｄ(1-9, sin padding
  — igual que original); L2 34B: &4＋3sp＋Ｒáｐｉｄｏ(4-9, á=9660)＋sp＋Ｌｅｎｔｏ
  (11-15)＋&7; L3 30B: 7sp＋１２３４５６７８(8-15, IGUAL que original);
  L4 Ｔｅｘｔｏ(1-5); L5 Ｍｏｖｅｒｓｅ(1-7); L6 Ｃｏｍｂａｔｅ(1-7). Un parche:
  0x139B0→0x27500. Old 0x143EE-0x14471 (132B) a 0.
- EFG: 0x1761A/27/2E (Efecto/Ind/Grupo); tabla in-situ 0x13DEA-0x13DF5.
- IT: 0x17639/46/4F/5E ([Item]/Usar/Cambiar/Tirar); tabla 0x13E16+4k;
  entradas 3-5 conservan desplazamiento +2 (semántica del original).
- SY: 0x17669/84/A3 (VR transp/Autoesquiva/Conversación + sp + ＯＦＦ);
  tabla 0x14472+4k; las únicas refs a los strings originales eran las 3
  entradas de tabla (verificado con refs u32).
- Menú principal: tabla 0x13D12 (6 u32); etiquetas redirigidas conservan refs.
- Ventana magia combate: 0x14F18 術気→ＰＭ (swap byte-neutro).

## Notas técnicas nuevas (chuleta sesión 2, parte 1 — SUPERADA en offsets)
- Z5 v4: reubicada a 0x17590 (RAM 0x27590), 142B. L0 32B: [Magia](1-7)
  FW(8-9) nombre 7 celdas (10-16, d2 5→7). L2 30B igual. L3 36B (=largo orig,
  offsets de valor intactos: now3 @L3+14, ind2 @L3+32). L4 36B: Max(1-3)
  FW(4-6) max2(7-8) FW(9) grp2(10-11) FW(12) Grp(13-15) — jsr max 18722→186D6.
  Parches código: 0x11DEA (base), 0x11E02 (nombre→+18), 0x11E06 (d2=7),
  0x11E16 (now→+82), 0x11E58 (ind→+100), 0x11E68 (max→+122) + 0x11E70
  (jsr 186D6), 0x11E9A (grp→+128).
- Z22 v4: reubicada a 0x17500 (RAM 0x27500), 132B. L0 &5Velocidad(1-9);
  L2 &4 FW×3 Rápido(4-9) FW Lento(11-15) &7; L3 FW×7 １２３４５６７８(8-15);
  L4 Texto(1-5); L5 Moverse(1-7); L6 Combate(1-7). Parche: 0x139B0→0x27500.
- EFG v4: strings en 0x17630/0x17640/0x17658 (Efecto 13B, Individual 21B,
  Grupo 11B); tabla 0x13DEA actualizada (0x27630/0x27640/0x27658). Ojo: la
  caja flotante puede no ser tan ancha como "Individual" → verificación visual
  de David; plan B "Ind".
- HUD: se mantiene el parche v3 (nombres Tianren/Meifan/Isaac + PV/PM en
  0x0CB8C-0x0CBC8; labels 体力/術気 → PV/PM). Sin LV en HUD (LV solo en ficha).

## Fuente: el "bug del 膨" — cierre (18/09, sesión de arqueología de fuente)
- **El "膨" de Rápido era un 冒 (0x9660)**. Zoom 16× del slot (x69-88, y69-84):
  glifo = 日 + 儿 = 冒, un kanji fullwidth real. A 0.8× de resolución el 日
  parece 月 y el 儿 parece 皮 → lectura 膨. No existía bug de bitmap: el motor
  dibujaba el kanji 冒 tal cual.
- **Causa raíz**: el HIJACK (16 slots 0x95FB-0x9770 pintados con glifos 12×12)
  solo alcanzó las tablas 12×12 (GFONT celdas 422-437 + celda 226, 3 copias en
  INIT/OPEN/GHEAD). La fuente 16×16 de los MENÚS se dibuja desde una tabla que
  **NO está en el ISO como bitmap lineal**: probados y descartados GFONT
  (18B/12B/24B/330×24/660×12), GHEAD (mapa 576×2 u16 + región 0x900-0C70
  empaquetada = ruido), H01 (base 0x897A) y H02 (base 0x8981) — sus slots 冒
  están vacíos (12 bits) y su 術 ≠ 術 del menú. H01/H02 = fuente cinemática.
  Búsquedas fuzzy a disco entero de 冒/術/膨 (16×16 32B, 14 col 32B, 16×12
  24B, 8×10): mejores distancias 29-34/176, sin consistencia de tabla →
  la tabla del menú está comprimida o se arma en RAM.
- **Solución aplicada (HIJACK remapeado, sin acentos)**:
  - `codificador_castellano.py`: override `_HIJACK_OVERRIDE` — á→ａ 8281,
    é→ｅ 8285, í→ｉ 8289, ó→ｏ 828F, ú→ｕ 8295, ü→ｕ 8295, ñ→ｎ 828E,
    Á→Ａ 8260, É→Ｅ 8264, Í→Ｉ 8268, Ó→Ｏ 826E, Ú→Ｕ 8274, Ñ→Ｎ 826D,
    ¿→？ 8148, ¡→！ 8149. (Códigos verificados con codecs, no de memoria.)
  - `reconstruir_iso.py`: se DESCARTAN los 48+3 parches de bitmaps (0
    reemplazos ahora). Ventaja extra: las celdas 12×12 vuelven a su kanji
    original → evita regresiones tipo 冒険→"á険" en fuentes 12×12.
  - Regenerado `parchear_start_v4.py` → START_CAST.BIN (tpl Z22 = Ｒａｐｉｄｏ
    8271 8281 8290 8289 8284 828F) → `reconstruir_iso.py`.
- **Verificación del [CAST].bin nuevo**: bitmaps 16 glifos = 0; región GFONT
  == original; tpl Z22 sin 9660; total 9660 en bin == 70 == original (todos
  japones legítimo); in-situ ok=147 no_cabe=329 err=0 (igual: fullwidth 2B
  mantiene longitudes).
- **Hecho mal (herencia)**: la entrada anterior "la fuente fina de menú usa
  GFONT celda 226" era FALSA (celda 226 = un glifo puntitos pequeño, no 冒);
  los 48 bitmaps se pintaron en tablas que el menú no usa → 1 día entero de
  arqueología. Lección → NORMAS 19-22.
- **Pendiente**: validar con David si "Rapido" sin acento es aceptable como
  solución provisional; ofrecerle la vía RAM dump (Genesis Plus GX, con el
  menú abierto: font struct RAM 0x0A230, array 0x0A230+w(0x0A242)) para
  parchear la tabla real con la fuente Lord Monarch o acentos de verdad.
- **Frentes abiertos (sin cambio)**: batch 6 frentes (Z19/Z21 etiquetas de
  stats, Z5, 所持金, Grp/SY, etiquetas equip) + 329 no_cabe + scripts.

## CORRECCIÓN: era 膨, no 冒 (18/09, 22:15 — ampliación de David)
- David envía ampliación 4× del glifo 0x9660 ("R膨pido"). Análisis objetivo de
  pixel a pixel (grid 11×10 extraída a escala 4px/bloque):
  - Componente IZQUIERDO = caja de 10 filas de alto: barra superior + 2 barras
    internas (filas 2 y 5) + verticales continuas + SIN barra inferior = 月
    (NO 日: 日 es corto ~5 filas y tiene barra inferior).
  - Componente DERECHO = horizontal superior + trazos cruzados + diagonal
    final a derecha-abajo = 皮.
  - **月 + 皮 = 膨. David tenía razón.** El zoom 16× de la captura 201839
    (256×224, escala 0.8×, antialiasing) engañó: el 月 pareció 日 y el 皮 pareció
    儿. Lección: el error de misreading costó una sesión; NORMAS 20-21 cubren
    esto, añadir: NUNCA afirmar identidad de kanji desde zoom de captura
    pequeña; exigir ampliación de David o bitmap exacto.
- **Consecuencia**: el mapeo código→glifo de la fuente del menú NO es SJIS
  identidad: el slot que el código 0x9660 ocupa en la tabla del menú contiene
  膨 (en la tabla 12×12 de GFONT el mismo 0x9660 = 冒, celda 431, verificado).

## Reversión del remapeo + estado (18/09, 22:30)
- David rechaza "sin acento" ("mejor dejar el kanji hasta que demos con la
  solución"). **REVERTIDO** el `_HIJACK_OVERRIDE` de codificador_castellano.py:
  vuelve el HIJACK original (á=0x9660 etc.). Regenerado [CAST].bin: tpl Z22
  otra vez con 9660 (kanji a la vista), ok=147 no_cabe=329 err=0.
- **Búsqueda final de la tabla del menú con target LIMPIO** (grid 11×10 de 膨
  de la ampliación 4×): todo el ISO, filas 2B (16px), margen izquierdo 1-5,
  alineaciones 0/1 → mejor distancia 26/160 (16%), sin consistencia de tabla.
  **CONFIRMADO: la tabla 16×16 del menú no existe en el ISO como bitmap
  lineal.** Se arma en RAM (fuente empaquetada en GENEI_OP.DAT/GENEI_ED.DAT o
  generada).
- Lecho byte-level de INIT/START/OPEN/MSTART/SSTART/OSTART por lea/mov de
  inmediatos #$a230/#$a242 (struct de fuente) y lea.l #$0a2xx: CERO hits →
  la dirección del struct no es un inmediato en esos archivos.

## Fuente Lord Monarch (David) — inventario completo
- PNG 128×48 RGBA, fondo MAGENTA (placeholder transparencia) + glifos NEGROS,
  grid 16×6 de celdas 8×8. Umbral: R<50 = tinta. (No leer en grayscale:
  magenta→gris ~105 lo confundía con el glifo.)
- Contenido (96 celdas):
  - Fila 0: . , : ; ! ¡ ? ¿ ( ) / \ « » - %
  - Fila 1: 0 1 2 3 4 5 6 7 8 9 A B C D E F
  - Fila 2: G H I J K L M N Ñ O P Q R S T U
  - Fila 3: V W X Y Z a b c d e f g h i j k
  - Fila 4: l m n ñ o p q r s t u v w x y z
  - Fila 5: Á É Í Ó Ú Ü á é í ó ú ü ñ + 3 CELDAS VACÍAS (C13-15)
- **Cubre TODO el alfabeto castellano** (verificado contra las 476 traducciones
  del CSV): a-z A-Z ñ Ñ á é í ó ú ü Á É Í Ó Ú Ü 0-9 . , : ; ! ? ¿ ¡ ( ) « » - %
- **FALTAN** para los textos actuales: **$ (142 usos, dinero) y # (9 usos)**.
  Las 3 celdas vacías caben: sugerir a David $, # y " (o ×).
- Nota: las traducciones traen comillas japonesas 「」 (66+64 usos) → sustituir
  por « » (presentes en su fuente).

## Plan fuente (pendiente de David)
1. **RAM dump desde Genesis Plus GX con el menú de velocidad abierto**
   (Debug > Memory Viewer, rango 0x000000-0x0FFFFF, 64 KB). Con el dump:
   localizar la tabla (el bitmap 16×16 de 膨 ya se tiene exacto), deducir el
   esquema índice↔código y construir el parche que pinta la latina Lord
   Monarch + acentos reales en la tabla (slot 0x9660 → á real).
2. Mientras tanto: kanji a la vista (decisión de David).
3. Independentemente de la fuente: batch 6 frentes (Z19/Z21, Z5, 所持金,
   Grp/SY, etiquetas equip) + 329 no_cabe + scripts.

## 18/09/26 (II) — Fuente de menú: tabla localizada al 100%, 78 celdas pintadas
### Hechos medidos
- **Tablas de la fuente de menú**: celdas 12×12, 18 B (flujo continuo de 144
  bits, MSB-first), en **INIT.BIN+0x4ED0** (celda 0 = 術 0x8F70) y
  **OPEN.BIN+0xA710** (NO 0xA740: la memoria anterior llevaba 0x30 de error).
  Misma disposición relativa en ambas (verificado celda a celda: 術/方/Ａ).
- **Orden de la tabla = JIS fila-major sobre un subconjunto**. Clúster kanji
  verificado: 術(29,49)@rel 0, 方(42,93)@+510, 膨(43,33)@+526, 北(43,44)@+529,
  本(43,60)@+531, 魔(43,66)@+534, 民(44,17)@+550, 無(44,21)@+554, 命(44,31)@+557,
  滅(44,39)@+561, 目(44,60)@+568, 優(45,5)@+584, 誘(45,22)@+592, 予(45,29)@+599,
  誉(45,32)@+600, 様(45,45)@+606, 用(45,49)@+607 — estrictamente monótono en JIS.
  La memoria "rel -1 = 白" era una mala identificación: rel -1 = 出 (29,48),
  coherente con JIS. El subconjunto es mayor que el corpus de textos
  (~97 caracteres extra entre 術 y 方).
- **0x9660 = 冒 (verificado con cp932), NO 膨**. La fuente del juego tiene
  冒/膨 INTERCAMBIADOS: la celda de 0x9660 (rel +526, INIT 0x73CC) contiene el
  glifo 膨 (coincidencia pixel a pixel con el zoom 4× de David; por eso el
  menú mostraba 膨 para 0x9660) y la celda de 0x9663 (rel +569) contiene 冒.
- **Bloque fullwidth Latin** (leído directamente de la tabla): ０ 0x824F @ rel
  -772 (INIT 0x1888) … ９ 0x8258 @ -763, Ａ 0x8260 @ -762 (INIT 0x1934) … Ｚ
  0x8279 @ -737, ａ 0x8281 @ -736 … ｚ 0x829A @ -711 (INIT 0x1CC2). 62 celdas
  contiguas. Antes: < > $ % & (rel -777..-773); después: kanji.
- **16 celdas HIJACK** (código → celda, todas exactas): 0x95FB→+510(0x72AC),
  0x9660→+526(0x73CC), 0x966B→+529(0x7402), 0x967B→+531(0x7426), 0x9682→+534
  (0x745C), 0x96AF→+550(0x757C), 0x96B3→+554(0x75C4), 0x96BD→+557(0x75FA),
  0x96C5→+561(0x7642), 0x96DA→+568(0x76C0), 0x9744→+584(0x77E0),
  0x9755→+592(0x7870), 0x975C→+599(0x78EE), 0x975F→+600(0x7900),
  0x976C→+606(0x796C), 0x9770→+607(0x797E).

### Parche aplicado
- `recursos/tools/fuente_menu.py`: extrae los glifos 8×8 de David (R<50 sobre
  fondo magenta) y pinta 78 celdas en INIT y OPEN (glifo 8×8 centrado en
  (col 2, fila 2)): 16 HIJACK con los acentos (Á á É Í Ó Ú Ñ Ü ¿ ¡ é í ú ó ü
  ñ) + 62 fullwidth (0-9 A-Z a-z con los glifos de David).
- Integrado en reconstruir_iso.py (después del parche de START.BIN).
- **Rebuild [CAST].bin completado y verificado**: 30 celdas revisadas byte a
  byte en el bin raw final (todas OK), 術 intacta en las dos tablas.
  Preview: `preview_fuente_parche.png` (las 78 celdas a pintar).
- Pendiente: **David prueba [CAST].bin** (menú de velocidad: "Velocidad",
  "Rápido/Lento" con á de verdad, cifras 1-8; cualquier texto fullwidth).

### Errores y caminos muertos de este tramo
- Fuzzy 18B de Latinas sobre todo el ISO: MILARES de falsos positivos
  (umbral 22: 8400-14400 hits por glifo; el header LBA0 "apunta" a cualquier
  glifo raro; la celda rel -722 pareció 'l' y era ｏ). Inutilizable para
  localizar bloques: leer la tabla por densidad + tiras 16 celdas a 4×.
- Miniaturas de grid a 1px: me leí una fila de KANJI como "456789 ABCDEF..."
  (no es fiable para identificar filas; solo para localizar zonas).
- Empaquetado celda: 18 B = 144 bits CONTINUOS (bit = 12r+c), NO 2 bytes por
  fila (el primer celda12 generaba 24 B y escribía basura).
- Verificación del bin: el raw NO es base+off (cada sector crece 2048→2352);
  hay que mapear byte a byte con n*2352+16+r. Mi primer check "TODO XX" fue
  un bug del chequeo, no del parche.
- /tmp no persiste entre turnos (glifs.pkl perdido; regenerado).
- Agrupar bandas de una captura por "gap>20" fusiona filas (gap real 5 px);
  agrupar por y0 exacto.
- Los códigos SJIS de memoria mienten (confundí 冒/膨): siembre cp932.

## 18/09/26 (2ª parte) — La fuente del menú: el "SD" era un fantasma y el experimento discriminador

### Descubrimientos
1. **START.BIN boot**: tabla de carga en file 0x90-0x2D0: INIT.BIN → RAM
   $28000, CHR.BIN → ?, CHR1.BIN → $80000, SD.BIN → ?, otros → $50000.
   El loader jsr $10888 (nombre en a0, destino en a1). START → RAM $10000
   (los nombres de archivo se refieren como $1009C etc. = file+0x9C).
2. **Framework de menús** (START 0x18F0-0x1A32): 16 IDs de menú en $A240,
   layouts en $A260/$A2A0/$A2E0/$A320, y COPIAS completas de bitmap
   pre-renderizado (32KB/24KB/32KB) desde las tablas $11D28/$11D58/$11D88
   a frame buffers $AB000/$AE000/$B0000. El texto dinámico (mis plantillas)
   se dibuja encima con el motor de objetos ($C100 registros stride 0x50).
3. **GHEAD.BIN REAL = 3184 B** (mi "GHEAD_FULL 122880 B" era una extracción
   con el bug de sectores): es un script de inicialización de RAM (registros
   tag 0x33FC/0x23FC con direcciones $A1xx), NO un mapa de fuente.
4. **GENEI_OP/ED.DAT = movies** (446/241 KB). RLE naive y LZSS estándar
   (16K, ambas convenciones de flag, todos los starts 256B/16B) no producen
   la tabla de fuentes. Descartados como fuente del menú.
5. **EL FANTASMA DE SD.BIN**: "descubrí" que SD.BIN contenía una tabla de
   fuentes (術@36080, fw@22184) → pinté sus 78 celdas en el build. LUEGO:
   mi extracción de SD.BIN usó `iso[lba*2352+16 : +sz]` (la fórmula RAW)
   sobre el ISO de 2048 B/LBA → leí 76 KB desplazado = una ventana dentro
   de **OPEN.BIN** (artificialmente "SD+36080" = OPEN+0xA710 = la 術 de
   OPEN; "SD+22184" = OPEN+0x70C8 = fw de OPEN). SD.BIN real: NO es fuente.
   El build intermedio tenía 1362 B de BASURA en SD.BIN real → corregido en
   el rebuild final (SD restaurado byte a byte ✓).
6. **Verificación con extracción correcta (por sectores)**: el build actual
   tiene INIT 78/78 y OPEN 78/78 pintados de verdad (el "32/32 verificado"
   del build anterior se hizo con lectura continua = no fiable, aunque el
   build era correcto porque el builder escribe sector a sector).
7. **PRUEBA DECISIVA — búsqueda exacta de los glifos renderizados**:
   decodifiqué 20 glifos del screenshot de David (V e l o c i d a R p d L e
   1-7) de /tmp/glifs.pkl (4× zoom, 44 px = 11 filas + fila 11 vacía) a
   12×12 → 18 B (144 bits MSB, todas las shift de columna) → búsqueda
   exacta en los 167 archivos del disco: **los 20 bitmaps SOLO existen en
   INIT.BIN, OPEN.BIN y GFONT.BIN**. Ningún otro archivo del disco los
   contiene (ni CHR/CHR1/SD/MSTART/SSTART/OSTART/H01/H02/GENEI).
8. **GFONT fw (celdas 50-111) == INIT fw: hamming 0** (mismo diseño Latin).
   GFONT NO tiene celda 膨 (mejor celda: 37 bits de 144; celda 431 = 冒).
   El menú muestra 0x9660 como 膨 ⇒ **el menú lee INIT u OPEN** (GFONT
   descarta). Y sin embargo pintar INIT+OPEN no cambió nada en el menú.
   Paradoja abierta → experimento discriminador.

### Experimento discriminador (build actual, para David)
Cada tabla recibe un diseño DISTINTO en las 62 celdas fullwidth (+16
HIJACK en INIT/OPEN):
- **INIT**: diseño normal de David (Lord Monarch 8×8) — 78 celdas.
- **OPEN**: TODAS las 78 celdas = glifo **8**.
- **GFONT celdas 50-111**: TODAS = glifo **3**.
Interpretación del screenshot del menú de velocidad:
- Latin de David + 膨 en el acento → lee INIT (y habría que buscar por qué
  el build anterior no se veía: ¿bin/cue equivocado? ¿pantalla distinta?).
- Todo a 8 → lee OPEN.
- Todo a 3 → lee GFONT (improbable por el 0x9660).
- Sin cambios (Latin original + 膨) → NINGUNA de las tres: entonces o el
  bin/cue de David no es el que creemos (proceso) o la tabla se genera en
  RAM desde una fuente comprimida no localizada.
Verificado en el bin final: INIT 78/78 David, OPEN 78/78 "8", GFONT 62/62
"3", SD.BIN intacto, 術 intacto, sha [CAST].bin == (Track 01).bin.

### Errores de este tramo (los malos)
- **Extraje SD.BIN (y casi GHEAD) con la fórmula RAW sobre el ISO**:
  lba*2352+16 sobre un ISO de 2048 B/LBA desplaza 304 B por cada LBA →
  "SD.BIN" era en realidad OPEN desplazado. Todo el "descubrimiento de SD"
  era un artefacto. (NORMA 30)
- Comparé bin-vs-ISO con slice continuo (misma familia de bug, dirección
  contraria) → "164/167 archivos distintos 94%" falso alarmón: con
  extracción por sectores, bin == ISO (misma imagen). (NORMA 24, reforzada)
- Dos scripts Python con líneas basura dejadas (sintaxis) — revisar antes
  de ejecutar heredocs largos.
- `0x8C60`/`0x8CE0`/`0x8CF0`: tres conversiones dec→hex erróneas seguidas
  (36080 = 0x8CF0). Verificar con `hex()` siempre.
- El (1,1) de /tmp/glifs.pkl NO es 膨: es el borde del selector (3 px).
  El glifo 膨 no está limpio en la captura.
- La "verificación 32/32" del build anterior usaba lectura continua: no
  confiable (aunque el build era correcto).

## 2026-09-19 — Sesión: fuente confirmada + lote de menús (magia/equipo/principal)

### Contexto
David confirma (mensaje 18/09-19/09): "Ahora sí se ve la nueva fuente" con á
accentado en "Rápido" => **EL MENÚ LEE INIT** (experimento discriminador
resuelto). Pedido: cerrar el lote de menús (magia, equipo, sistema, principal)
antes de seguir con más.

### Hecho
1. **Parches aplicados a START_CAST.BIN (zona 0x17500-0x177AE, plantillas
   vivas — verificadas: son las ÚNICAS copias de los textos en el archivo):**
   - P1 @0x1758A (Z5 cabecera, 32B): `［Ｍａｇｉａ］`+8sp -> `Ｍａｇｉａ：`+9sp.
     Corchetes fuera (fuente de David no los tiene) y colon FULLWIDTH 8146
     (glifo original del juego; la fuente de David NO tiene ： ni ［］).
   - P2 @0x175F2 (Z5 L5, 38B): el campo valor ００ de Grp se mueve de celdas
     10-11 a 13-14 y la etiqueta Ｇｒｐ de 13-15 a 10-12 => "Grp 8" alineado
     con "Ind 2" (celdas 10-14). MISMA LONGITUD.
     **RIESGO DOCUMENTADO:** la sesión anterior mapeó writes de valor en
     RAM absolutos (lea 0x11E98, jsr $186D6) para grp2. Si el engine escribe
     el valor en offset fijo (no escanea el placeholder), el "8" saldría en la
     posición vieja (sobre "Ｇｒ"). El build anterior mostraba el valor
     EXACTAMENTE donde está el placeholder en el archivo (coherencia), lo que
     sugiere que el placeholder manda. David lo confirmará con captura.
   - P3 @0x13E70 (cabecera equipo, 16B): `［Ｅｑｕｉｐｏ］` -> `Ｅｑｕｉｐｏ`+2sp
     (el box tiene 6 celdas: "[Equipo" se cortaba a "[Equi").
2. **Rebuild + verificación por sectores**: [CAST].bin con START ==
   START_CAST (P1/P2/P3 presentes), INIT 78/78 celdas David (celda á rel+526
   celdas = blob David exacto), GFONT celda 50 OK. NOTE: "rel" de fuente_menu
   va en CELDAS (×18B), no bytes.
3. **Mapa de la zona de plantillas 0x13DEA-0x14472** (EFG/IT/SY):
   - 0x13DF3 ［術効果］ + 個別/集団; 0x13E2B ［アイテム］ + 使用/入替/捨てる
     (plantillas ORIGINAL japonés, sin traducir aún).
   - 0x13E6D ［Ｅｑｕｉｐｏ］ (ahora sin corchetes) + líneas de stats YA en
     español: Arma At ＋０００ / Prot De / Otro Vl / Otro Sk ０００％ /
     Otro Ac ０００％ (hechas por la sesión anterior).
   - 0x13F67 tabs: Ｃｈａｒ / Ｔｅｃ / Ｃｏｍｂ.
   - 0x13F8A (338B) template Ficha: ＮＶ/ＥＸＰ/Ｎｅｘｔ/ＰＶ/ＰＭ ya en
     español; **attack/defense/agility labels siguen en japonés** (攻撃力/
     防御力/素早さ/スキル/命中率).
   - 0x140DE (392B) tab Técnicas: cabeceras de columnas de armas: Ｇｕ /
     **ライフル** / 砲 / **ヘビー** / **クロー** / **杖** / **剣** / **斬糸**
     (6 de 8 en japonés; la sesión anterior tradujo solo los que cabían).
   - 0x14268 (360B) tab Combate: 攻撃力/防御力/素早さ japoneses + PV/PM ok.
   - 0x143D7: "…スピード" (-Speed) + "スイッチ" (system: Switch).
   - 0x13D18-0x13D5F: tabla de 6 mini-plantillas con descriptors [02 XX YY]:
     "　術" / " ﾁﾃﾆﾃ" / "　技巧" / "　効力" / "　Ｅｆｅｃｔｏ" (traducida) /
     " ﾖﾘﾃ" => pantalla de efectos de magia (術効果). El 術 de 0x13D32
     ES de esa pantalla, NO del menú principal.
4. **Búsqueda agotada de la fila 術 del menú principal**:
   - 術 (97 64) en todo el disco: solo zonas de fuentes + dialogs + movies.
   - 魔術 / ステータス / アイテム / エクイップ / 会話: NO existen en NINGÚN
     archivo del disco.
   - "Ficha" (fullwidth y ASCII): NO existe en el disco.
   => las filas no traducidas del menú principal (術 y la de "Ficha") NO son
     texto de plantilla: probablemente **bitmaps de layout pre-renderizados**
     (los 32KB que el engine copia a $AB000/$AE000/$B0000). BLOQUEADO hasta
     tener la captura de David del menú principal y poder analizar el
     bitmap. (NOTA: 0x11D28/0x11D58/0x11D88 = CÓDIGO, no tablas de punteros:
     la interpretación anterior de "layout pointer tables" era errónea.)
5. **Nombre 天人 (Tianren) — fuente común localizada pero cirugía RIESGOSA**:
   - Tabla maestra de nombres INIT 0x22900-0x22CA0: entradas variable largo
     NUL-separadas (el lector debe ser secuencial: coexisten entradas de 4B y
     26B). Primera entrada inline = 天人 @0x22918 (marcador `00 80` + nombre).
     Resto: 美紅/ホウメイ/シュウ老師/アイザック/カッシュ/薬師カイ/リー/…
     (todos los nombres del juego, ya que los dialogs usan nombres inline).
   - Verificado: NINGÚN puntero 24-bit ni 32-bit apunta a 0x22900-0x23000 en
     INIT/START/OPEN/GHEAD; los registros de personaje (0x1B00-0x22000) no
     apuntan a la zona de nombres.
   - PERO: la cola del archivo está LLENA de datos (dialogs hasta el último
     byte) => no hay 10 B libres para compensar el alargamiento 天人(4B) ->
     Ｔｉａｒｅｎ(14B). Alargar = desplazar ~4.7KB de INIT y romper referencias
     que no he logrado localizar. **A POSPONER: decisión de David.**
   - ADEMÁS: el mapa de la sesión anterior dice que el nombre del menú de
     magia copia "máx d2=5 chars desde $bd00" => "Tianren" (7) se truncaría
     a 5. Opciones: "Tian" (4, cabe), aceptar truncado, o dejar 天人.
6. **Iconos de estado de equipo 忌/瞬/哀/僕/渡**: no son texto en ninguna
   plantilla del disco => también bitmaps/layout. BLOQUEADO igual.
7. **Espaciado de la fuente latina (queja de David)**: causa confirmada =
   glifos 8x8 centrados en (2,2) dentro de celda 12x12 => margen 2px por lado
   => hueco de 4px entre letras ("I L L U S I O N"). Generado
   /home/user/illusion-city/preview_espaciado.png: fila 1 = actual (8x8
   centrado), fila 2 = escalado 8x8->12x12 (rellena celda, letras pegadas).
   Pendiente decisión de David (escalar / dejar / mandarme glifos 12x12).
8. **Vocabulario pendiente (pedir a David)**: labels de stats de Ficha
   (攻撃力/防御力/素早さ/スキル/命中率) y columnas de armas (ライフル/砲/
   ヘビー/クロー/杖/剣/斬糸) — en la zona 0x13F8A/0x140DE, con anchos de
   celda limitados (3-4 celdas por label).

### Errores de este tramo (los malos)
- **Confundí ０-９ fullwidth**: ０=824F, １=8250, ２=8251 — el campo "０００"
  es 824F 824F 824F. Dos asserts fallaron por escribir 8250/8251 "de
  memoria". (NORMA 34)
- **Corte de bytearray con reemplazo más corto**: al parchear P1 usé
  Ｍａｇｉａ=12B (son 5 chars = 10B) y asigné 30B a un slice de 32B:
  el bytearray en memoria se encogió 2B y corrompió lecturas posteriores
  (el disco NO se tocó porque el assert de P2 falló antes del write).
  Siempre: assert len(nuevo) == len(slice). (NORMA 37)
- **Leí mal el hex volcado**: "0x143EE Z22" (mapa anterior) es un bloque de
  CEROs de 128B, no una copia de la plantilla; Z22/Z5 solo existen en la zona
  0x17500-0x177AE (confirmado con find de cada palabra).
- "rel" de fuente_menu.py = celdas, no bytes (el spot-check á falló usando
  +526B en vez de +526×18B).
- /tmp no persistente: no usar para datos entre sesiones (recordatorio).

## 2026-09-19 — Turno: build v2 (headers "de", Magia fila 1, Ficha restaurada)

### Pedido de David (verdict v1)
Headers "Magia de <nombre>" / "Equipo de <nombre>" (sin colon); Grp roto
("8rp00") — 8 debe ir celda 14 bajo el "2" de Ind, label Grp celda 10
bajo Ind, azul; Tianren COMPLETO obligatorio; no escalar 8->12, preguntar
por celdas 8x8; sistema: ensanchar caja no acortar palabras; menú
principal: 術->"Magia" + todo a celda 1 (sin margen); $ y # va a la PNG.

### Hecho
1. **TABLA DEL MENÚ PRINCIPAL DESCODIFICADA** (START 0x13D00-0x13D61):
   - 0x13D00: header `01 00` + serie `07 06 05 04 03 02 01 00 00` (9 u8) +
     `02 04 00 00 00 04 06 00`.
   - 0x13D12-0x13D29: **6 entradas de 4B = offsets $2xxxx (file+0x10000)**:
     $23D2A 術(r1) | $2773E Ojetos(r2) | $2774D Equipo(r3) | $2775A Hablar(r4)
     | $23D4A Ficha/Efecto(r5) | $27767 Sistema(r6). Mis 4 strings de
     0x1773E alimentan r2/r3/r4/r6 (hipótesis confirmada).
   - Pool de strings 0x13D2A-0x13D5F: 術 / ﾁﾃﾆﾃ / 技巧 / 効力 /
     Efecto(=exステータス→Ficha lote1) / ﾖﾘﾃ (variable, NUL-terminadas;
     las 4 katakana/技巧効力 = otra pantalla, NO tocadas).
   - Bloque de ceros 0x13D60-0x13DED = zona libre para strings nuevas.
2. **Ficha RESTAURADA**: 0x13D4A estaba "Ｅｆｅｃｏ" (sobrescritura de sesión
   anterior para la pantalla de efecto de magia). El menú principal muestra
   r5 = esa string (prueba: captura de David vieja con "Ficha" + CSV:
   0x13D4A = única "Ficha" del juego). Revertida a "Ｆｉｃａ" (12B, misma).
   Riesgo conocido: si la pantalla 術効果 usa la misma string, mostrará
   "Ficha" en vez de "Efecto" (la palabra ORIGINAL era ステータス; aceptable).
3. **Fila 1 術->"Magia"**: string nueva "Ｍａｇｉａ"+NUL en 0x13D60 (bloque
   ceros), entrada 0x13D12: $23D2A->$23D60 (4B). Sin espacio inicial: la
   fila 術 se dibuja ~1 celda a la izquierda que las otras (medido: 術 en
   x76-88 = celda 0; las demás en celda 1) => "Magia" queda en celda 0-4
   (cabe en el interior de 6 celdas). El shift de r2-r6 a celda 0 sigue
   pendiente = parche de código (renderer, no hay X por fila en los datos).
4. **Headers "de"** (MISMA LONGITUD, verificados en .bin):
   - Magia 0x1758A (32B): Ｍａｇｉａ：+9sp -> Ｍａｇｉａ sp ｄｅ +7sp.
     El nombre 天人 lo dibuja el engine en celda 8 => "Magia de 天人"
     (Tianren completo = celdas 8-14, desborda 3 celdas el box de 12).
   - Equipo 0x13E70 (22B): Ｅｑｕｉｐｏ 2sp+8NUL -> Ｅｑｉｐｏ sp ｄｅ +4NUL.
     En la captura 202054 NO aparece ningún nombre en esta cabecera
     (box ~13 celdas, texto 4) => sin colisión esperable.
5. **GRP — resolución final del mecanismo** (sin parche de código posible
   hoy): el write del valor es a **offset de byte FIJO dentro de la línea
   (byte 24 de L5 = celdas render 9-10, máx 12)** — demostrado por
   aritmética de plantilla (el "8" cayó sobre la G en 3 layouts distintos).
   "Grp" bajo "Ind" (celdas 9-11) + "8" bajo "2" (celdas 13-14) es
   IMPOSIBLE sin parchear el código (el write nunca puede llegar a 13-14).
   **Revertido P2** (0x1760A+14B): layout original => "8  Grp" como el
   japonés (coherente, sin "8rp00"). El "Grp 8" alineado queda para el
   pase de disassembler del renderer (junto al shift del menú principal y
   el ensanche de cajas).
6. **Mediciones (256x224)**:
   - Sistema 201923: caja x51-139 (interior 7.2 celdas) x y33-73 (3 líneas
     de 12px). Opciones japonesas originales = 9 celdas (también se
     desbordaban ~2); mis españolas 13-16 => 2 líneas cada una => caja de 3
     líneas corta las continuaciones (lo que ve David). Ensanchar = editar
     el bitmap 256x128 1bpp del layout (tablas $11D28/$11D58/$11D88 =
     file 0x1D28/0x1D58/0x1D88; sources 32/24/32KB -> $AB000/$AE000/$B0000;
     loop copier 0x198A; tipos del record $4). Pendiente identificar qué
     bloque 32KB es el menú de sistema.
   - Equipo 202054: caja superior x8-165 (~13 celdas), cabecera y16-26,
     4 celdas de texto.
   - Magia 013517: "8rp00" visible (confirmado el bug P2); header
     "Magia: 天人" celdas 0-6 + nombre celda 8-9; box 12 celdas.
   - Z19 Ficha: filas stats = label 3 kanji (celdas 0-2) + 2sp + valor
     ０００＋０００ (celdas 5-10, WRITES FIJOS); EXP/Next/PV/PM usan celdas
     8-14 => box >=15 celdas. Vocab aprobado NO CABE en 5 celdas de label:
     Ataque(6) Defensa(7) Velocidad(9) Habilidad(9) Precisión(9) — todos
     desbordan hacia el valor fijo. Opciones: parchear los 5 writes de
     valor (pase de código) o abreviaturas.
7. **Build v2**: reconstruir_iso.py desde original: ok=147 no_cabe=329
   (idéntico a v1), START LBA59, INIT 78 + OPEN 78 + GFONT 62. Verificados
   en el .bin final los 6 parches (find de cada secuencia): OK 6/6,
   "Efe..." viejo ausente. [CAST].bin 18,444,384 B.

### Errores de este tramo (los malos)
- **Búsqueda de strings con los códigos de fullwidth MALOS**: busqué
  Ｍａｇｉａ con 82C9/93FC/82EA/828F (bloque de GFONT) y encontré 0 hits en
  todo el disco; las plantillas de START usan el bloque SJIS 8260-8279
  (Ａ-Ｚ) / 8281-829A (ａ-ｚ) / 824F-8258 (０-９) y 8146 (：). Los hits de
  "no está literal en el disco" de sesiones anteriores para 術/ステータス
  siguen siendo válidos, pero CUALQUIER búsqueda futura de texto fullwidth
  debe usar 8260-829A. (NORMA 38)
- **Confundí RAM con file en $11D28**: lea $11D28 = file 0x1D28 (START va a
  $10000). Volqué file 0x11D28 (código) y saqué conclusiones sobre "tablas
  runtime" basadas en código. Los 3 volcados "de tablas" de esta sesión
  (0x11D28-0x11DA8 "u32 jumble") eran CÓDIGO de START. Las tablas 0x1D28/
  0x1D58/0x1D88 SÍ contienen datos (entries con 0x0800/0x0900/... low-16)
  pero no las decodifiqué bien (parecen offsets low-16 + high-16 flags).
- **Los "jsr $186D6 / $2087E / $17FD8" del mapa anterior NO existen en
  ninguno de los archivos del disco** (buscados como 16b y 32b en los 167
  archivos). Ese mapa de addresses de writes fue una lectura errónea de la
  disassembler previa; el mecanismo real de los writes de valor sigue
  SIN ENCONTRAR (solo probado el de Grp: byte 24 fijo de la línea).
- **P2 no era viable**: mover placeholders no mueve writes (confirmado
  aritméticamente y con la captura de David). P2 revertido. (NORMA 39)

## 2026-09-19 — v3: dictamen 10 puntos de David

### Investigación Z5 (rompimiento)
- La zona Z5 (0x1758A) se carga en código: 0x11DE8 `move.l #$2758A, $22(a0)` (a0=$A4200, struct de pantalla en $A4222). El renderer recorre líneas delimitadas por /n (2F6E); las líneas PM Coste/Ahora/Max no tienen refs propias.
- Writes de valores (función @0x11DC6, desensamblos capstone):
  - Nombre: jsr $2087E (copia NUL-terminada (a0)→(a1), **sin límite de longitud**), a2=$2759A (celda 8), d2=7.
  - Ahora: rec(a4)+$48 → lea $275DA (０００ tras "Ahora") ✓ correct.
  - Ind: lea $275EC (００ tras "Ind") ✓ correct; 2 dígitos (decenas celda 12, unidades celda 13; "2" va en celda 13).
  - Max: rec+$46 → lea $27600 (celda espacio).
  - **Grp: lea $27608 → write 2 dígitos en 0x17608 (tens, sp) y 0x1760A (units, ¡sobreescribe el &5 azul!)** → explica el bug v2 "80 Gr + p desborda".
- Writers de dígitos: $186D6 = 2 dígitos (espacio si <10), $18722 = 3 dígitos, derecha, llevan 8140 de relleno.
- **Menú principal**: filas referenciadas por tabla 0x13D12 (6 u32 $2xxxx); setup @0x21996 (a0=$A4200: $28=6 filas, $26=1, $8=10, $A=9, $1E=$A6000); renderer genérico $172A6 → draw $174F4 → por fila bsr $1838C (intérprete: /n=reset X +Y, &=color, #/opcode, $/opcode, resto=glyph vía $18B18 que hace $14+=3 por char). **NO HAY CLIP en el código**: las 7 letras de "Sistema"/"Objetos" se dibujan completas (x74-153); el "resto cortado" que ve David = la 7ª letra solapando el panel azul decorativo (x145+). Las filas YA están en celda 0 (sin margen izquierdo). **No se parchea el shift** (innecesario).
- **Equipo**: el nombre se dibuja FIJO en celda 6 (sobrescribe la plantilla) ⇒ "Equipo de" imposible; revertido a Ｅｑｉｐｏ+2sp (look original JP).
- **Nombres**: tabla INIT 0x22919+ variable NUL-sep (天人 5B con flag 0x80, 美紅, ホウメイ, シュウ老師, アイザック…). Copia nombre = NUL-terminada sin límite. Expandir 天人→Tianren requiere mover la tabla (refs por offset) — pendiente.

### Parches v3 aplicados (START_CAST.BIN)
1. 0x13D4B 8264→8265 (Ficha; yo escribí E en v2).
2. 0x13E70: revertido a Ｅｑｉｐｏ+2sp+8NUL (24B).
3. 0x175F0 (40B): L4 = `/n &5 Ｍａｘ sp sp &7 ０００ sp &5 Ｇｒ ００ sp sp` + NUL 0x17618-19 intacto (Efecto 0x1761A no se mueve). + **código 0x11E9D 08→12 (lea $27608→$27612)**: "8" en celda 13 bajo el "2" de Ind; "Grp" azul celdas 9-11 bajo "Ind".
4. Z19: 攻撃力→ＡＴＡ (0x1404C), 防御力→ＤＥＦ (0x1406A), 素早さ→ＶＥＬ (0x14088), スキル→ＨＡＢ (0x140A6), 命中率→ＰＲＥ (0x140C8). Todos 6B→6B.

### Errores propios (regla: script atómico)
- Varios scripts murieron en asserts tras aplicar parches en memoria y antes del write → cambios perdidos (Ficha/Equipo/L4/lea 3 veces). Lección: validar TODO primero, escribir UNA vez.
- Slices con offsets mal calculados (0x13D4C vs 0x13D4E; 0x11EA2 vs 0x11E9E) → asserts falsos.
- (0x27612).to_bytes(2) → overflow (escribir solo el byte bajo).
- L4 original = 40B (no 44): contar bytes, no suponer.

### Pendiente v3 (siguiente build)
- Título "Efect" → &4 amarillo: requiere +2B en la línea Efecto (0x1761A) y desplazar Ind/Grupo/Item/Combate/VR/mainmenu4 → actualizar todas las refs u32 en rango $2761A-$277AE (incl. tabla 0x13D12). A valorar.
- Tianren en la tabla de nombres (mover/expander en INIT 0x22919).
- Reexplicar $/# a David (fila 5 cols 13-14 de su PNG).
### Verificación en [CAST].bin (raw)
Fórmula raw confirmada: `raw = (59 + off//2048)*2352 + 16 + off%2048` (LBA 59 = START).
- Tabla menú 0x13D12 → raw 0x38982: 6 entries correctos.
- Ficha → raw 0x389BA: 82 65 82 89... = Ｆｉｃｈａ ✓ (original tenía otros strings, p.ej. スイス).
- lea → raw 0x36648: 45 f9 00 02 76 12 ✓.
- L4 → raw 0x3CAB0: layout nuevo ✓ (original 0xFF).
### Corrección post-build (lea Grp)
El write de 2 dígitos pone TENS en (a2) y UNITS en (a2+2). Para alinear el "8" (units) bajo el "2" de Ind (units @c13), a2 debe ser la CELDA 12 = file 0x17610 = RAM $27610. El parche inicial ($27612) dejaba el "8" en c14. Corregido 0x11E9D: 12→10. Rebuild + verificado raw.
(Nota: el check "Efecto intacto" falló por bytes esperados mal escritos en mi check; la string ８２６４８２８６… = Ｅｆｅｃｏ está intacta en file y raw.)

## 2026-09-19 (2ª tanda) — v3.1: Equipo de, Efecto amarillo, Grp blanco

### Cambios aplicados (todos en un solo write atómico)
1. **Grp valor blanco**: L4 = `/n &5 Ｍａｘ sp sp &7 ０００ sp &5 Ｇｒ &7 ００ sp NUL` (40B). El valor Grp heredaba el azul de &5; ahora &7 blanco antes de ００. lea $27610 sin cambios (tens c12, units c13).
2. **"Equipo de <name>"** (David: nada es imposible):
   - Header 0x13E70 (18B): `Ｅｑｕｉｐｏ ｅ`; nombre ahora celda 9 (0x13E80), antes celda 5 (sobrescribía el ｏ → "Equip天人").
   - Mudanza: sp-line/Arma/Prot/Otro×3 (0x13E88-0x13F5D) → 0x17800-0x1792B (zona 0xFF); NUL-fill 0x13E82-0x13F5D (246B de margen para nombres largos).
   - Tabla 0x13E54: $23E70 $27800 $27803 $2783D $27877 $278B1 $278EB.
   - 11 lea's parcheados (5 nombres de item + 5 valores + nombre char): $23E80/$2780B/$27845/$2787F/$278B9/$278F3/$27825/$2785F/$27899/$278D1/$2790B.
   - Nota: "Arma/Prot/Otro" son ASCII (41 72 6D 61), no fullwidth; se movieron byte a byte (contenido intacto).
3. **"Efecto" amarillo &4**: inserción 2B (26 34) @0x1761A + shift +2 de la zona de strings 0x1761A-0x177AD → 0x1761C-0x177AF + **45 refs u32 actualizadas (+2)** (tablas: battle 0xEFA0-0xF0FC ×24, sistema 0x14472-0x1447A ×3, effect 0x13DEA-0x13E2A ×11, main menu 0x13D16-0x13D26 ×4, otros 0x10924-0x10DA6 ×6). Verificado: 45 hits, todos en tablas de punteros.

### Investigaciones
- **Menú principal 15px**: NO HACE FALTA / IMPOSIBLE a texto: filas en X=3 ($32(a0)=3 en el setup 0x219C0) = x74; marco caja x70 → solo 4px de hueco. X=0 sería x62 (fuera de la caja). El renderer NO hace clip ($18B18 dibuja todo); el "problema" real = la 7ª letra de "Objetos"/"Sistema" (x146-154) solapa el panel azul decorativo (x145-165) que es ART (el buffer $A6000 se limpia a $A500 cada frame con $17680; caja/panel = fondo VDP, no buffer). Solución = mover el panel en el art, no el texto.
- **$ y # NO SON GLIFOS**: en $191BE (SJIS→celda) los códigos 0x23/0x24 caen en el mismo índice 0x1500 (colisión ASCII); en $1838C se consumen como opcodes (& color, #N etiqueta, $ valor). **Retractada la petición de añadirlos al PNG** — David no tiene que añadir nada.
- **Función equip completa** @0x12838-0x129F0: setup $28=7 filas, $1E=$A7AE0 (bitmap propio, no $A6000), 11 writes de nombre/valores.
- **$195A8**: construye en $BD00 una lista de punteros (nombre char) desde tabla $A600; $1960x variantes para items.

### Errores
- Header "Ｅｑｕｉｐｏ ｄｅ" = 18B (9 chars), no 24: contaba mal.
- Check "Arma nueva" esperaba fullwidth; el string original es ASCII.
- Sandbox reset: uploads/ vaciado (PNGs perdidos) — pedir reenvío de 030441 y 034542.

### Pendiente
- Menú sistema: re-medir 034542 (perdida) + ensanchar caja.
- Tabla de nombres INIT (天人→Tianren): expandir/mover + refs.
- Panel azul del menú principal (art) si David lo quiere.

## 2026-09-19 (3ª tanda) — v3.2: fixes de las 2 regresiones + shift menú

### Regresiones v3.1 (diagnosticadas y corregidas)
- **Grp "80" azul**: mi lea $27610 apuntaba al &7 (26 37) que yo mismo metí; el write 2-dígitos lo sobrescribió con sp y el "0" restante (celda 13) + color azul heredado = "80" azul. Fix: lea → $27612 (0x11E9D: 10→12) = primer ０ del campo.
- **"Equipo d天人"**: offset mío: "Ｅｑｕｉｐｏ ｄｅ" = 18B = celdas 0-8 → celda 9 = 0x13E82 (no 0x13E80, que era la ｅ). Fix: lea 0x12855 80→82 (ojo: target = 0x12852+4B; escribí el byte 0x12854 por error la 1ª vez → $8280; corregido).
- **Líneas item "cortadas"**: NO diagnosticado (capturas nuevas 045122/045315/050156 NO llegaron a uploads/). Verificado: las líneas movidas son byte-idénticas en file y raw; el write de nombre/valor apunta a la misma posición relativa (+8/+34); hay un 2º borrador de nombres ($227F2) con lea's a posiciones antiguas (ahora zona NUL, inocuo). Pendiente: captura nueva de equip.
- **Efecto blanco + muesca en E**: NO diagnosticado (captura 050156 no llegó). &4 insertado correctamente (verificado raw). Hay 162 instrucciones `move.l #$23DEA, ...` → 0x13DEA es tabla genérica multi-pantalla; el renderer de la caja de efecto puede no interpretar & (por eso sigue blanco). Pendiente: captura.

### Menú principal 15px
- Aplicado $32(a0) 3→0 (0x119C2): texto 12px a la izquierda (celda completa; la rejilla es de 4px/celda=12px por char, 15px no cae en la rejilla; 12px es el máximo hacia la izquierda sin salir de X≥0).
- David contó px en resolución real: la ventana tiene margen; el límite real no es el x70 que medí antes (probablemente marco interior decorativo).

### Lección
- Al insertar bytes dentro de una línea, recalcular los offsets de write que caen DESPUÉS de la inserción (el &7 de Grp empujó el campo ００ a +2).
- El target de un lea.l empieza en off+2; el byte bajo final está en off+5.

## 2026-09-19 (4ª tanda) — v3.3: menú 4px más a la izquierda (X=-1)

### Veredicto 4 (051810/052259/052743/053346)
- Grp **APROBADO** (un dígito blanco "8"). "Equipo de 天人" **APROBADO**.
- Shift 12px confirmado ("¿¡Ves como tenía yo realidad!?") → ahora pide **4px MÁS a la izquierda**.
- 's' de "Objetos" recortada 1-2px; 'O' con muesca (David cree que es la misma causa).
- Equip: filas de item todavía cortadas (052743). Efecto: título blanco + muesca en E (053346).
- Falta: nombres en latinos (Magia de Tianren) + nombres de magias del panel inferior.

### Parche v3.3
- **Menú: X = -1** (0x119C2-3: 00 00 → FF FF). Mecanismo: en $18B18, X=-1 (0xFFFF) → lsr#1 = 0x7FFF → lsl#5 = 0x1FFFE0 → **andi #$ffff (0x8B3E) trunca a 0xFFE0 = buffer base − 32B = exactamente 4px a la izquierda** (la rejilla es 4px/unidad X; 32B = 1 unidad). Paridad correcta (lsr de 0xFFFF deja C=1 → variante impar). Las demás X de la fila (2,5,8…) siguen siendo positivas y válidas → toda la fila se desplaza 4px.
- **Riesgo**: requiere que $A5FE0-$A5FFF (32B antes de la buffer $A6000) sea RAM libre; ningún lea/inmediato en el código referencia $A5Fx/$A5Ex (barrido hecho). Si en la próxima captura algo SE ROMPE en otra parte de la pantalla (corrupción), la causa es esa y se revierte a X=0.
- Rebuild ok=147 no_cabe=329. Raw verificado: X=317CFFFF0032 ✓, Grp lea $27612 ✓, name lea $23E82 ✓.

### Hallazgos de la forense (píxel a píxel, umbral >128 = texto; el texto es BRILLANTE 239 sobre 0)
1. **El menú/magia/equip NO usan la fuente de David.** Las 78 celdas en INIT 0x4ED0 (y OPEN 0xA710) SÍ están pintadas y correctas en el build (0/78 diffs) — pero solo las usa el menú de velocidad. El menú principal dibuja con la **fuente original del juego**: el S de "Sistema" del screenshot ≠ S de David (doble barra), etc. La rejilla del texto: glifo 8×8 en celda de 6px visibles, pitch 12px; **1 unidad X = 4px** (verificado: X 3→0 movió todo el menú, marco incluido, 12px entre 030441→051810).
2. **Resolver de glifos $191BE**: code SJIS → packed JIS (sub $922C) → idx = ((p>>4−0x200)&0xF00)×1.5 + ((p>>4)&0xF0)×1.5 + ((p>>2−8)&0x3C) → tabla u16 en $28000 (=[w0 máscaras, w1 sub-idx]) → offset u16 → glifo 8×8 (64 bits, 4 pares) en $294E0+offset. Blit $18B18: buffer celda 32B = 8px×2rows 2planos; offset = ((X>>1)+(Y>>1)×$8(a0))×32, truncado 16 bits; variante por paridad (4 rutinas 0x18B76/C32/CEE/DAA). Buffer menú = $A6000 (25 pantillas lo usan; setup 0x119F0).
3. **La tabla $28000/$294E0 se carga estáticamente (ningún código la escribe); su archivo origen NO está identificado**: los patrones 8×8 de S/M/O del screenshot (y 12×12, y LSB, y column-major) NO aparecen en crudo en ningún archivo del ISO → probablemente comprimida. Los u16 de la tabla del INIT file 0x8000 NO son la tabla runtime (colisiones de idx entre caracteres vecinos).
4. **Nombres de item del equip = DB en CHR.BIN** (copia en GENEI_OP.DAT): region 0xBFD3+ = ~120 nombres NUL-sep (ハンドガン@0xBFD3, スーツ@0xC503, etc.; listado completo extraído a memoria). No hay tabla de punteros en CHR.BIN (barrido de rachas de deltas) → candidatos: parsing secuencial o refs en otro sitio. **El equip muestra el japonés porque las strings de v3.1 (0x17800+) solo son las etiquetas de slot (Arma/Prot/Otro + ATA/DEF/VL/SK/AC), no los nombres.**
5. **Header de magia cortado** (052259): "Magia de 天人" se dibuja ~10px demasiado arriba; solo se ven los 2-3 px superiores de los glifos (el resto queda detrás del borde de la caja). En equip (052743) el mismo header SÍ se ve completo → el Y es distinto por pantalla.
6. El "panel azul" del menú que llevaba confundiendo = marco de selección alrededor de la fila resaltada (se mueve con la selección), NO art fijo.
7. 'O' del menú (x59-64, y55-61): 1 píxel falta en la esquina inferior-izda (x59,y60) respecto al glifo esperado; 's' (x120-125): fila superior (y55) ausente. Ambas son rasgos de la fuente ORIGINAL (su glifo), no del renderer — confirmación definitiva requiere la tabla runtime (punto 3).

### Pendiente (próxima tanda)
1. **Nombres de item en español** (CHR.BIN 0xBFD3+): reemplazo in-situ fullwidth a misma longitud (padding 8140) o variable si la DB se parsea secuencialmente — primero averiguar cómo se referencian.
2. **Efecto amarillo**: el &4 no se aplica (renderer de la caja puede no parsear &); hay que localizar el draw path de esa caja.
3. **Header de magia**: bajar el Y de esa fila (equipo sí funciona; magia no).
4. **Nombres latinos**: INIT 0x22919 天人→Tianren (+ magias del panel inferior de magia: 紫気/緑気/気功障/攻気/封気 → traducir; DB en CHR.BIN/GENEI).
5. Si la captura v3.3 muestra corrupción fuera del menú → revocar X=-1 (el margen $A5FE0 estaba en uso).

## 2026-09-19 (5ª tanda) — v3.4: revert X=-1 + limpieza workspace

### Veredicto 5 (061030 menú, 062356 magia)
- **X=-1 REVERTIDO** (David: "revierte"). Efectos vistos con X=-1: la M de "Magia" desaparece, la O de "Objetos" se corta más, la 's' igual de cortada + **restos de letras que se cortan a la izquierda reaparecen a la derecha** (wrap horizontal del VDP: las writes en $A5FE0-$A5FFF caen en otra región de pantalla). Conclusión definitiva: **$A5FE0-$A5FFF NO es RAM libre** — el margen no existe y X=-1 está descartado para siempre. X=0 es el suelo del grid.
- **"1px más" no es posible**: la rejilla del blitter es 4px/unidad X (32B/paso de buffer); no hay sub-pixel en este renderer. La solución real para la 's' = **ensanchar la ventana de texto** (regla de David: ensanchar caja, no acortar palabras) — hsize en la display list (driver MSTART), pendiente.
- **Corrección de David A (aceptada)**: el menú/magia/equip SÍ se dibujan con la fuente de David. Mi conclusión de "fuente original" era falsa: mis mediciones de glifo usaban umbral >128 y la paleta del texto tiene varios grises (64/80/112/160/239) → el shape "roto" del S/O era artefacto de umbral, no de fuente. La muesca de O y el corte de S/s = **clip por la ventana de texto** (franja derecha de la caja corta el 7º carácter de las filas de 7 letras: Objetos/Sistema).
- **Corrección de David C**: el header de magia se ve bien (062356). Mi análisis de "cortado" era el mismo artefacto de umbral. **No tocar.**
- 061030 corrobora la corrupción de X=-1 (filas del menú alteradas: "Halar", "Ficha", "Sistema" en posiciones raras).

### Cambios v3.4
- 0x119C2-3: FF FF → 00 00 (revert; estado = v3.2). Raw verificado ISO+RAW: X=317C00000032 ✓, Grp $27612 ✓, name $23E82 ✓. ok=147 no_cabe=329.
- **Limpieza workspace** (105→~56MB):
  - `track01_original.bin` (18M, duplicado de [ORIGINAL].bin; el script usa [ORIGINAL].bin).
  - `recursos/(Track 01).bin` (18M, salida redundante: el .cue carga [CAST].bin) + write desactivado en reconstruir_iso.py.
  - `recursos/track01_castellano.iso` (16M) + **ISO_OUT movido a /tmp** (intermedio, se regenera cada build).
  - `analisis/START_CAST_V3.BIN`, `analisis/SD.BIN.ok`, PNGs sueltos de root, screenshots viejas de uploads (quedan las de la 4ª/5ª tanda + fuente de David).
  - `recursos/track01.iso` se MANTIENE (input del pipeline).

### Estado de la cola (orden)
1. **'s'/'S'/'O' cortados** = ventana de texto estrecha para 7 celdas: localizar el hsize de la display list del menú (driver MSTART, entries construidos en runtime) y ensancharlo +1 celda (12px) sin romper el art de la caja.
2. Nombres de ítem en español (DB CHR.BIN @0xBFD3+, ~120 nombres NUL-sep; reemplazo in-situ fullwidth).
3. Efecto amarillo (el &4 no lo parsea ese renderer; localizar draw path).
4. Magias del panel inferior (紫気/緑気/気功障/攻気/封気 → DB) + nombres en latinos (INIT 0x22919 天人→Tianren).

## 2026-09-19 (6ª tanda) — v3.5: ensanchar ventana del menú ($04 7→8)

### Remediciones precisas (051810, umbral >150 = texto brillante)
- Celda = 12px desde x59; marco de la caja x142-143 (+línea exterior x145).
- **"Objetos s" (c6) = 4px (132-135) vs "s" referencia (Sistema c2) = 5px (84-88) → falta x136 = clip exacto de 1px.**
- "Sistema a" (c6) = 5px completo (131-135 = rel. 0-4, igual que la "a" de referencia). "O" (c0) = 6px (59-64): glifo completo (no hay clip a la izquierda; la ventana empieza ≤59).
- → El daño real = solo 1px de la "s" de "Objetos". El resto de glifos completos.

### Tabla de parámetros por pantalla (descifrada campo a campo)
- Formato: `31 7C 00 NN 00 DD` (6B) = valor NN×0x100 → $DD(a0); buffer: `21 7C imm32 00 1E`.
- **Menú (0x119A8-0x119F0):** $2A=0 $2C=0 $26=1 **$28=6 (nº filas ✓)** $32=X(0) $18=0 $2E=5 **$04=7** $06=5 $08=10 $0A=9 $1A=0x80 $1E=$A6000.
- **Screen B (0x11B1C-0x11B68):** $28=1 $2E=9 $04=3 $06=8 $08=26 $0A=15 $1A=0x8B00 $1E=$A6B00.
- Hipótesis geométrica: ventana = $04 celdas (7×12=84px, x51-135) y el texto entra con X=2 (8px) → primera celda x59 ✓✓. El 7º carácter (celda x131-142) queda a 1px del borde → clip en x136 ✓ consistente.
- SSTART.BIN = 68000: contiene setups de menú paralelos (inmediatos $A6000 en 0xAE4/0xE80/0xEC8/0xF14/0x2908) con struct (a1) y valores sin ×0x100.
- MSTART 0x1330-0x1368: bloque de boot con valores 0x85/0x87/0x8A/0x8B/0x8C/0x8F/0x90-0x92 (133-146) ≈ coordenadas X del borde derecho (0x8A=138 = X2+1 con offset de captura +2px) — **último refugio si la tabla (a0) no es la ventana; tocarlo = riesgo de romper el boot del CD (probar solo si no hay otra opción).**

### Cambio v3.5
- 0x119D5: 07 → 08 ($04 del menú: 7→8 celdas → ventana 96px, x51-147). Solo START.BIN (seguro). X=0 intacto.
- Verificado en ISO (/tmp) y en [CAST].bin @0x36182: 317C00080004 ✓.

### Si el veredicto dice "no cambió"
- Candidates en la misma tabla (1 build c/u): $0A 9→10, $08 10→11, $06 5→6, $2E 5→6.
- Después: bloques de MSTART (riesgo boot) — solo con aprobación expresa.
- Fallback textual (nunca tocar sin pedir): "Objetos"→"Objeto" (singular, NO es abreviatura) dejaría ambas filas a 6 letras.

## 2026-09-19 (6b) — v3.6: $08 = ancho de la ventana (80px -> 88px)

### Correciones a la remediencia (bug propio en la comparacion previa)
- La **"a" de Sistema (c6) TAMBIEN pierde x136** (y106,y107): su borde derecho termina en x135, no x136 como en la tabla. Mi comparacion de rejilla anterior la dio "completa" por un bug (no volverse a fiar de comparaciones sin ver volcados directos).
- Píxeles perdidos totales en el menú (volcado directo, no inferencia): **s (5,8)+(8,8) = (136,57)+(136,60); a (6,7)+(7,7) = (136,106)+(136,107); O (8,3) = (59,60)**.
- → **El borde DERECHO de la ventana = x135 (col 8 del 7º carácter se corta SIEMPRE, filas 1 y 5).** Confirmado clip real, no artefacto.
- La muesca de la O (59,60) es OTRO asunto: 1 píxel, no es borde (x59 se ve en y57-59 y en las filas 2-4 para E/H/F), estable entre builds y con selección en otra fila (030441).

### Descifrado de la tabla de parámetros (unidad = 8px, como el blitter)
- **$0A = alto de la ventana en unidades de 8px**: menú 9×8 = 72px = 6 filas×12px ✓✓.
- **$08 = ANCHO de la ventana en unidades de 8px**: menú 10×8 = 80px = x56-135 ✓✓ (borde derecho x135 ✓).
- $04 = nº de celdas a renderizar por fila (7): el parche 7→8 no cambió nada (no hay 8º carácter) ✓ consistente.
- $04 NO es X1 (si lo fuera, el parche 7→8 habría movido el texto 8px; no pasó).

### Cambio v3.6
- 0x119E1: 0A → 0B (**$08: 10 → 11 = 88px, ventana x56-143**). $04 revertido a 7. X=0 intacto.
- Verificado ISO + [CAST].bin @raw(0x119DE): 317C000B0008 ✓.
- La columna 8 completa (x136-139) del 7º carácter queda visible; la tinta real de s/a termina en x136 → sin solapar el marco (x142-143).

### Queda (próximo veredicto)
1. **Muesca O (59,60)**: si sigue (casi seguro, es otro mecanismo), opciones: (a) cirugía de glifo (mover (8,3)→(8,4) de la O; su diseño, pedir OK), (b) seguir buscando el mecanismo (arte de OPEN.BIN sobre el plano de texto / bits pegados buffer→VDP).
2. Nombres de ítem (CHR.BIN 0xBFD3+), Efecto amarillo, Tianren + magias (cola 2-4).

### Otros hallazgos de la tanda
- SSTART (68000) carga OPEN.BIN y SD.BIN al boot (strings en el código, 0x08A4+). SD 69194B / OPEN 69258B (tamaños reales del dir; los usé mal antes).
- El header de magia (062356) NO usa la tabla INIT: glifos de forma/posición distintas (filas y41-50, no y43-49) → renderer/fuente propios; NO tocar (aprobado por David).
- Tabla SD @0x8CF0: NO es la misma disposición que INIT (celdas != glifos) → la nota "SD misma disposición" era para otra zona (fw block @22184); no seguir por ahí.

## 2026-09-19 (7ª tanda) — v3.7: wrap de la caja de texto, parche en SSTART

### Modelo de David (aceptado, explica TODO)
- La caja invisible que contiene el texto tiene un límite de anchura; si una palabra lo supera, **lo que se excede pasa al lado contrario** (wrap; equivale a bajar a siguiente renglón con pitch mucho más ajustado que el visible).
- Evidencia: el menú del título (JP, 3 opciones largas) se forma en 6 líneas superpuestas y cortadas; también visto en otros menús.
- Solo Objetos y Sistema (las únicas palabras de 7 letras) pierden píxeles. La s pierde 2 píxeles en x136; el inferior, al hacer wrap, cae sobre el píxel de la pared de la O en (59,60) y lo BORRA (la muesca); el superior cae en zona sin tinta de la O (sin efecto visible). En Sistema: el rabillo de la "a" (x136) → el px que pierde la "S" izquierda, a la misma altura.
- Solo se necesitan 1-2px libres de anchura.

### Por qué mis parches anteriores no hicieron nada
- La tabla (a0) de START.BIN 0x119A8 = TABLA INACTIVA (muerta): parches $04 y $08 sin efecto ✓ consistente.
- La struct VIVA es la (a1) de **SSTART.BIN** (setup menú @0xE5E-0xE98: $22=$11068, $04=7, $06=14, $08=17, $0A=3, $1A=0x80, $1E=$A6000). Geometría: $04×8 = x56 (borde izq), $08×8 = x136 (borde der+1) → ventana x59-135 / 77px de wrap ✓✓.

### Cambio v3.7
- **SSTART 0xE6F: 11 → 12 ($08 menú: 17 → 18 = borde der x136 → x144; wrap 77px → 85px > 77 del 7º carácter ✓)**. 1 byte de diff en el boot file (verificado: diffs=[3695]).
- START_CAST.BIN: $08 revertido a 10 (tabla muerta; diff limpio = v3.2 + parches de textos).
- Pipeline: reconstruir_iso.py ahora inyecta analisis/SSTART_CAST.BIN @LBA43 (assert 32644B).
- Riesgo: SSTART = código de boot; si NO ARRANCA el juego → revertir el byte (el diff es 1 byte, trivial).
- Unidad = 8px (no "1-2px libres"): +1 unidad = +8px. Si no funciona, candidates: $06 (14), otros setups (a1) con $A6000 (call3 $08=30, call4 $08=28, setup1 $08=16) — probar 1 a 1.

### Pendiente tras veredicto
- Si la s/a quedan completas → la muesca de la O debería desaparecer por el mismo mecanismo (el wrap deja de caer sobre ella).
- Cola: 2) nombres ítem CHR.BIN 0xBFD3+; 3) Efecto amarillo; 4) Tianren + magias.

## 2026-09-19 (8ª tanda) — v3.8: desacoplar ancho de posición en SSTART

### Veredicto v3.7: RECHAZADO. "$08 solo" movió el bloque de palabras a la derecha (asimetría). David: "dejar el texto donde estaba; ampliar la caja, no mover el texto".

### Mecanismo (código, decodificado)
- Struct viva del menú = $A4200, montada por SSTART @0xE52. Renderer de texto = SSTART 0x11E9E-0x1243A (sistema /n # $ &; buffer $1E(a0)=$A6000; glifo 12×12; X+=3, Y+=3 por glifo/renglón = 12px).
- Blitter 0x123EE: `off = ((X>>1) + (Y>>1)×$8(a0))×32; off &= $FFFF; a4 = $1E + off`. Fila de buffer = $8 elementos × 8px = 136px. X en unidades de 4px.
- Initializer @0x1640: $0C(a0) = $04 + $8>>1 (flag bit3 de $00) → **la posición X del texto depende de $8** → por eso $08 solo movía el texto.
- 7º celda (x128-139) = elementos 16+17; el elemento 17 desborda la fila de 17 elementos → envuelve al inicio de la fila (modelo wrap de David).
- Nota: wrap medido x136→x59 (77px) NO cuadra con fila de 136px (136 mod 136 = 0 ≠ 59) → si la s se completa pero la muesca de la O persiste, la muesca tiene OTRA causa (investigar glifo O / borrado en render).

### Cambio v3.8 (2 bytes, SSTART menú)
- $08: 17→18 (0xE6F): fila de buffer 136→144px → la 7ª celda ya no desborda.
- $04: 7→6 (0xE63): compensa $C = $04 + $8>>1 = 6+9 = 15 = invariante → **el texto NO se mueve**.
- Verificado: diffs vs original = [0xE63, 0xE6F] solo.

### Si falla
- Texto movido → la fórmula $C no es $04+$8>>1 (re-decodificar 0x168A con desensamblador fiable; capstone falla con 43 F9/MOVE16).
- s completa pero O con muesca → la muesca es otro bug (font/borrado); buscar en el glifo O del INIT @0x1A38 y en el path de borrado (barra de selección?).
- Nada cambia → el ancho no es $8; buscar otro campo (VDP window, $26/$1C).

## 2026-09-19 (9ª tanda) — v3.9: START $08 10→11 (88px) — retry con verificación 1:1

### Contexto
- v3.5 ($04 7→8) y v3.6 ($08 10→11) se marcaron como "tabla muerta" tras veredicto "sigue igual", pero la medición 1:1 (051810.png 256×224) demuestra que **START.BIN @0x119A8 SÍ es la geometría viva**:
  - Frame naranja menú: x49 y x142 (interior negro x50-141, 92px)
  - $04=7 → left 7×8=56 (cerca de 50, margen 9px)
  - $08=10 → width 10×8=80 → right 56+80=136 → **clip exacto medido en x136** (s pierde x136, a pierde x136, O muesca por wrap)
  - $0A=9 → height 9×8=72px = 6 filas×12px ✓
- Por tanto $08=10 es el campo de anchura. v3.6 debió funcionar. Posibles causas del fallo previo: build no inyectado / SSTART solapando / medición errónea.
- SSTART $08=17 es de pantallas de error de backup RAM, no del menú principal (strings $11068 etc). Revertido a original 7/17.

### Cambio v3.9
- START_CAST.BIN @0x119DE: 31 7C 00 0A 00 08 → **31 7C 00 0B 00 08** ($08 10→11, 80→88px, right 136→144)
- $C = $04 + $08/2 = 7+5=12 invariante (10/2=5, 11/2=5) → **texto NO se mueve** (mismo centro)
- SSTART revertido: @0xE63 06→07, @0xE6F 12→11 (diff limpio solo START)
- Verificado ISO + [CAST].bin raw: 317c000b0008 ✓

### Qué mirar
1. s de Objetos completa (x132-136)
2. a de Sistema completa (x132-136)
3. O sin muesca (59,60) — si era wrap, desaparece
4. Texto NO movido (margen izq x59 igual)
5. Si sigue igual → la tabla viva es OTRA copia (buscar $A6000 con $28=6 y $04=7 duplicada) o el VDP window es independiente.

## 2026-09-19 (10ª tanda) — v3.10: START $04=0 + $08=20 agresivo — FALLA

### Veredicto v3.9: "Sigue igual"
- $08 10→11 en START no cambió nada → START @0x119A8 también parece muerta (o el VDP window manda).

### Cambio v3.10
- START 0x119A8: $04 7→0 (0x119D2: 31 7C 00 07 00 04 → 00 04) + $08 10→20 (0x119DE: 0A→14). Teoría: $04 = left, $08 = right/width en unidades 8px; poner left=0 y right=20 = 160px ancho → caja gigante que debería eliminar cualquier clip.
- Verificado ISO+RAW.

### Veredicto v3.10: "Sigue igual" (captura 2026-09-19 08.00.39)
- Ningún cambio visual. START @0x119A8 definitivamente NO es la caja viva. Hay que buscar en otra parte.

## 2026-09-19 (11ª tanda) — v3.11: ADDQ #3→#2 @0x8B54 (blitter) — FALLA

### Teoría
- Blitter @0x8B54: ADDQ #3,$14(a0) = X+=3 por glifo (12px). Si el renderer cuenta celdas con X+=3, el ancho de fila es $28×3? Cambiar a #2 reduciría pitch → más celdas caben.
- Cambio: 0x8B54: 58 6C 00 03 → 58 6C 00 02

### Veredicto v3.11: "No ha cambiado nada"
- Blitter @0x8B54 no se usa para el menú de sistema o es sobreescrito.

## 2026-09-19 (12ª tanda) — v3.12: $32 3→2 (4px izquierda) — FALLA + REVERT

### Teoría
- $32 = X inicial del texto (unidad 4px). En v3.2 $32=0 (X=0). $32=3 es 12px derecha (v3.1). Probar $32=2 (8px) = 4px a la izquierda → debería mover el bloque sin tocar la caja.

### Cambio v3.12
- START @0x119C0: 31 7C 00 03 00 32 → 31 7C 00 02 00 32 ($32 3→2)
- + $2E 5→6 (0x119CC: 31 7C 00 05 00 2E → 06 00 2E) intento de ensanchar

### Veredicto v3.12: "No cambia nada"
- $32 también muerto o no usado para este menú. $32=-1 (FF FF) probado antes rompió (M desaparece, O peor, wrap derecha).

### Revert a baseline limpio v3.2
- Revertidos $2E 6→5 @0x119CC (31 7C 00 06 00 2E → 05 00 2E) y $32=3 @0x119C0 confirmados.
- analisis/START_CAST.BIN regenerado via parchear_start.py → 98184B traducido (Magia/Objetos/Equipo/Hablar/Ficha/Sistema fullwidth + Z22 Velocidad/Rápido etc)
- analisis/SSTART_CAST.BIN original (32644B)
- reconstruir_iso.py → [CAST].bin 18MB limpio v3.2 (ok=147 no_cabe=329)
- Deliverable: Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin

## 2026-09-19 (13ª tanda) — Corrección sobre minimal pack: fullwidth, no ASCII

### Contexto
- Usuario aclara: minimal pack SÍ contiene todas las traducciones en español, pero codificadas en fullwidth SJIS, no ASCII. Otro agente buscó ASCII "Magia" en track01.iso original (16MB, no [CAST].bin) y en START_CAST.BIN original (1-byte diff) y no encontró nada.
- Realidad:
  - Menu strings en START.BIN son fullwidth SJIS: A=0x8260, B=0x8261... Z=0x8279, a=0x8281... z=0x829A, 0=0x824F...9=0x8258, space=0x8140, : =0x8146 etc.
  - Ejemplo Magia = 82 6C 82 81 82 86 82 89 82 81 (FW) en 0x13D60, Objetos en free 0x17500+ (redirects BE32 RAM_BASE+old_off), Equipo 0x1774F, Hablar 0x1775C, Ficha 0x13D4A, Sistema 0x17769.
  - Tabla pointer en 0x13D12 (6 u32 $2xxxx).
  - Build pipeline: track01.iso 16MB original (2048) es input; textos_dumper.csv 147 ok in-situ + START_CAST.BIN + font INIT.BIN@0x4ED0/OPEN.BIN@0xA710 (12x12 18B cells, 78 painted) aplicados por tools/reconstruir_iso.py → /tmp/track01_castellano.iso + raw [CAST].bin via (LBA+off//2048)*2352+16+off%2048.
  - Minimal pack 3.7MB original NO incluía textos_dumper.csv → reconstruir_iso sin in-situ fallaba; START_CAST.BIN en minimal era original o v3.12.

### Acción
- Regenerado START_CAST.BIN traducido (parchear_start.py) + rebuild [CAST].bin v3.2.
- Creado GUIA_FULLWIDTH.md para agente paralelo con encoding, offsets, pipeline.
- Pendiente rebuild minimal v2 con textos_dumper.csv + START_CAST.BIN traducido + codificador_castellano.py + guía.

### Próximos candidatos para caja menú (wrap 1-2px libre, texto debe quedar en X=59 v3.2)
- SD.BIN LBA251 69194B / INIT.BIN LBA107 setups $A6000/$A6B00
- CHR1.BIN bitmap table @0x1D28 → $AB000/$AE000/$B0000 frame
- VDP window $91/$92
- Blit fns 0x1244C/0x12508/0x125C4/0x12680 + bsr $1273E
- Requisito: ampliar paintable box 1-2px, no mover texto. Fallback "Objeto" solo si todo falla.

## 2026-09-19 (14ª tanda) — v3.13: fuente desplazada 2px izquierda (0,2) vs muescas

### Pregunta de David
"Mi fuente es 8x8, la del juego 12x12, se ve mucha separación. ¿Podría tener relación con las muescas?"

### Análisis
- Separación: glifo 8x8 centrado en celda 12x12 en (2,2) → margen 2px izq + 2px der = 4px gap entre letras. Es la causa de "I L L U S I O N" separado.
- Muescas: NO son por la separación, son por **clip de ventana**:
  - Ventana: left = $04*8 = 56, width = $08*8 = 80 → right = 136 (exclusive, clip en x136).
  - Celda 6 (7º carácter) = x128-139. Glifo 8x8 centrado (2,2) con ink hasta col 8 de celda → x136 → clip exacto medido (s pierde x136, a pierde x136).
  - Wrap: lo que excede x136 pasa al lado contrario (modelo David). s pierde (136,57)+(136,60) → wrap a (59,57)+(59,60). La O en (59,60) tiene muesca exactamente en (59,60) → el pixel de s borra la O.
- Relación indirecta: si el glifo estuviera pegado a la izquierda (0,2) en vez de centrado, su borde derecho ganaría 2px:
  - O old cols 3-8, new 1-6 (shift -2)
  - s old 4-8, new 2-6 → rightmost de 136 → 134 → dentro de ventana (135 inclusive) → sin clip → sin wrap → sin muesca O.
- Conclusión: **muesca se puede arreglar sin tocar la ventana, solo moviendo el bitmap dentro de la celda**. No es "mover el texto" (X=59 intacto), es mover la tinta 2px a la izquierda dentro de cada celda. El gap entre letras pasaría de 4px a 2px (margen izq 0 + der 2 del siguiente = 2px) → texto más compacto, más cercano a tu PNG original.

### Cambio v3.13 (experimento)
- `fuente_menu.py`: `FONT_OFF_X = 0` (antes 2), `FONT_OFF_Y = 2` intacto.
- `celda12()` ahora acepta off_x/off_y, con clamp 0-4.
- Rebuild: INIT 78 celdas (off 0,2), OPEN 78, GFONT 62.
- START_CAST.BIN intacto v3.2 (X=0, $04=7, $08=10).
- Hipótesis: s/a completas, O sin muesca, texto 2px más a la izquierda visualmente pero sin tocar X (sigue en X=59, solo la tinta se mueve). Si funciona, podemos dejar en (0,2) o compromiso (1,2) = 1px ganancia + gap 3px.

### Verificación
- O old leftmost 3 rightmost 8 → new 1-6 (ganancia 2px derecha)
- s old 4-8 → new 2-6 (136→134)
- Build raw verificado: INIT 78/78 off 0,2.

### Si falla
- Si sigue muesca → wrap no es por s, sino otro mecanismo (borrado selección?).
- Si texto toca borde izquierdo (x56) → probar off 1,2 (ganancia 1px, suficiente para s en x135).
- Si David prefiere gap 4px original → volver a off 2,2 y seguir buscando ventana real (SD/INIT/CHR1/VDP).

## 2026-09-19 (15ª tanda) — Limpieza workspace + rebuild v3.2 baseline (state bug)

### Contexto
- David reporta que probaba con un state que salta la intro directamente al juego, y eso afectaba cómo se veían los cambios ("por eso no veíamos que cambiara").
- Pide limpieza: 109MB/128MB límite. Borrar todos los bin, zips para otro agente, uploads, pngs sueltos, etc., y generar uno nuevo con la última versión en la que realmente vimos cambio en las tres muescas.

### Limpieza ejecutada
- Borrados: `*.bin` en raíz y `recursos/` (18MB [CAST] + 18MB [ORIGINAL] + 36MB v3.13/v3.2-baseline), `*.zip` (3.8MB+308KB), `minimal_v2/` (17MB), `uploads/`, `*.png` en raíz y `recursos/analisis/*.png` (decenas de debug images).
- Restaurado `track01.iso` 16MB desde `/tmp/minimal/recursos/track01.iso` (copia de Recursos.zip 6.6MB de GitHub).
- Workspace: 111MB → 19MB (solo track01.iso 16MB + extraidos 320KB + analisis 8KB + tools 4KB + textos_dumper.csv 330KB + DIARIO/NORMAS).
- `fuente_menu.py` revertido a `FONT_OFF_X=2, FONT_OFF_Y=2` (centrado original) — v3.13 off0 descartado para este baseline limpio.

### Rebuild v3.2 baseline (última versión con cambio real visible)
- Definición v3.2 aprobada por David:
  - Grp blanco 1 dígito ("8" blanco) — fix lea $27612 (0x11E9D 08→0C)
  - Equipo de Tianren — pendiente de re-aplicar mudanza completa (0x17800), por ahora `[Equipo]` (parchear_start.py base) para baseline limpio
  - Shift 12px izquierda (X=0) — $32 3→0 @0x119C0 (31 7C 00 03 00 32 → 00 00 32) — aprobado "¿¡Ves como tenía yo realidad!?"
  - Velocidad/Rápido con á real (font 78 celdas INIT/OPEN)
  - Magia/Objetos/Equipo/Hablar/Ficha/Sistema fullwidth en free area 0x17500+
  - Muescas: s pierde x136, a pierde x136, O muesca (59,60) por wrap — estado conocido, baseline para re-test sin state
- Pasos:
  - `parchear_start.py` → START_CAST.BIN 96KB (traducciones básicas, Grp white ya incluido en Z5 part 4)
  - Patch manual: X=0 @0x119C0, Grp lea @0x11E9D = 0x0C
  - SSTART_CAST.BIN original (7,17) — 32KB
  - `reconstruir_iso.py` modificado para construir raw sin necesitar [ORIGINAL].bin (si no existe, crea raw desde ISO_OUT con user data en +16)
  - Output: `Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin` 18MB (raw 2352) + `/tmp/track01_castellano.iso` 16MB (2048)
- Verificado: X=317C00000032, $04=7, $08=10, Objetos 95538, Equipo 81522, Magia 81250, Grp lea 0x0C.
- Workspace final: 37MB (track01.iso 16MB + [CAST].bin 18MB + resto 3MB) — dentro de límite 128MB.

### Pendiente tras limpieza
- Re-test sin state: cargar [CAST].bin limpio desde boot (sin state) y verificar muescas en menú principal (Objetos s, Sistema a, O)
- Si muescas persisten → probar v3.13 off0 (font 0,2) que gana 2px derecha sin tocar ventana (s de 136→134)
- Si sigue igual → volver a cazar ventana real: SD.BIN LBA251, INIT LBA107, CHR1.BIN @0x1D28 → $AB000/$AE000/$B0000, VDP $91/$92, blit fns 0x1244C etc.
- Re-generar minimal v2 para agente paralelo solo cuando se pida (ahora borrado para ahorrar espacio)




## 2026-09-19 (16ª tanda) — Restauración desde state bueno + Texto→Mensaje / Combate→Batalla

### Contexto
- Bin final se quedaba en logo SEGA tras toques en SSTART.BIN (X=7 W=18) y tras borrar track01.iso para ahorrar espacio.
- Usuario pasa buena.bin que sí arranca: https://github.com/psichopompo/Illusion-City/raw/refs/heads/main/Gen'ei%20Toshi%20-%20Illusion%20City%20(Japan)%20(Track%2001)%20%5BCAST%5D%20buena.bin (MD5 6b4944559fd8d20c930718670b2cef2a, 18M, 7842 sectores). Es el build restaurado con las 3 herramientas del otro chat.

### Hecho
1. **Descarga buena.bin** + análisis:
   - START MD5 05e48fe46e38e0b63231a972f2a79f74 = START_correcto.bin (8696db90fffb64380721dd2d008bd21b) + width 0x11B55 1A→1C (26→28)
   - START 0x7214 = 69840001698400010bea00002a720001 (fix bueno del state, único cambio de código)
   - START 0x17500 = &5Velocidad/n/n&4   Rápido Lento&7/n       1-8/nTexto /nMoverse/nCombate\0\0 (7 espacios 81 40 antes del 1-8, 00 00 al final)
   - SSTART 0x3F14/0x42B0 = FF FF (descriptores vacíos en este build, pero arranca; título usa otro path)

2. **Restauración exacta como la vez del "¡Aleluya!"**:
   - Bajados del repo: START_correcto.bin 98184B, parchea_cast_bin.py 4741B, LEEME_ESTADO_EXTRAIDO.txt 3.5K
   - LEEME: state RZIP → 1.036.312B RASTATE → des-swap word → PRG RAM 0x380FE → START en 0x480FE → 98184B
   - Verificación: bin anterior 4c4230f8b4bdbc28887c1f37aef706f2 vs state 8696db... 1041B diff en 0x721C etc.
   - Escritura en sitio LBA59: (59+off//2048)*2352+16+off%2048 sin tocar sync/modo/MSF/EDC/ECC
   - Width 0x11B55 26→28 → MD5 final buena 05e48fe...

3. **Solo 2 palabras pedidas**:
   - Velocidad 0x17500 138B: Texto (5) Moverse (7) Combate (7) → Mensaje (7) Moverse (7) Batalla (7) = 7/7/7 uniforme
   - Intento 1 con fit() fullwidth + padding 81 40 ×4 al final → cambió 7 espacios→3 antes del 1-8 y añadió padding → bin dejó de arrancar (SEGA logo)
   - Intento 2 basado en buena.bin: reemplazar Texto+81 40 (12B) por Mensaje (14B) y Combate por Batalla, consumiendo 00 00 del final → 140B → recortar 2B → quedó sin null → "BatallaMagia de天人" superpuesto (captura 194722.png)

4. **Fix final del solape**:
   - Buena: 7 espacios antes del 1-8 (30B) + Texto + Moverse + Combate + 00 00 =138B
   - Nueva: 6 espacios antes del 1-8 (28B) + Mensaje + Moverse + Batalla + 00 00 =138B (136B contenido + 2B null)
   - Se libera 2B quitando 1 espacio (81 40) antes del 1-8, no del final → se mantiene null terminator → no hay "Magia de" pegado
   - Verificado: 0x17500 = &5Velocidad/n/n&4   Rápido Lento&7/n      1-8/nMensaje/nMoverse/nBatalla\0\0 (6 espacios)

5. **Bin final**:
   - /home/user/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin 18M
   - START MD5 0da082fc66bfd0fc49837fac99314a0c = buena + Mensaje/Batalla
   - 0x11B55=1C, 0x7214=0BEA fix, SSTART intacto como buena (FF en 0x3F14/0x42B0 pero arranca)
   - Pasa del logo SEGA, título con opciones, Velocidad con Mensaje/Moverse/Batalla sin solape

### Limpieza
- Borrado track01.iso 16M (intermedio) → illusion-city 3.6M
- Borrados buena.bin, START_correcto.bin, parchea_cast_bin.py, LEEME, del_state, uploads, /tmp SSTART etc → workspace total 37M → 21M

### Errores de esta tanda
- Tocar SSTART.BIN con X=7 W=18 sin necesidad → título sin opciones y riesgo boot
- Cambiar layout de Velocidad con fit() que alteraba nº de espacios antes del 1-8 y padding final con 81 40 en vez de 00 00 → SEGA logo hang
- Reemplazar Texto+space por Mensaje sin mantener null terminator → "BatallaMagia de天人" (bug reportado con captura 194722.png)

### Pendiente
- Caja invisible texto (Objetos/Sistema s cortada 1-2px, wrap dcha→izq) sigue pendiente: ampliar paintable box sin mover texto (X=0 suelo, 4px grid). Candidatos: SD.BIN, INIT setups $A6000, CHR1, VDP $91/$92, blit fns.

## 2026-09-19 (12ª tanda, agente paralelo) — verificación completa del [CAST].bin

Entra el proyecto limpio y actualizado (con el .bin bueno restaurado) y se pide
comprobar que todo sigue bien. Se añade `tools/verifica_bin.py`: verificación
completa **sin depender de ningún otro fichero del proyecto** (el
`del_state/START_correcto.bin` con el que se restauró ya no está).

### Resultado de la verificación del .bin actual
`Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin`

```
tamaño        18444384 B = 7842 sectores de 2352   OK
sync          OK en los 7842     modo 1 en los 7842     MSF (BCD, LBA+150) OK
START.BIN     MD5 007a1f05b5b4570cf5998975f2fa8fcd
anchura       0x11B55 = $1C (28 = 88 px)                       OK
tabla         0x721C = 0bea0000 2a720001 0bea0001              OK (fix bueno)
menu 0x13D12  Magia / Objetos / Equipo / Hablar / Ficha / Sistema   OK
```

### [HECHO] EDC y ECC están a CERO en los 7842 sectores
El .bin se generó sin calcular EDC/ECC (el pipeline escribe los 2048 B de datos
y deja el resto del sector como estaba: ceros). Consecuencias:

 - **Emulador**: no pasa nada. Genesis Plus GX y compañía leen los 2048 B de
   datos y no comprueban EDC/ECC.
 - **Consola real / ODE (MegaSD, EverDrive Pro)**: el controlador del Mega CD sí
   usa ECC/EDC para validar y corregir sectores; con eso a cero puede dar
   lecturas con error. Es un riesgo SOLO de hardware.
 - Afecta a **todos** los .bin del pipeline, no solo a este (el pipeline nunca
   calcula EDC/ECC).
 - Arreglo disponible: `verifica_bin.py FICHERO --repara` recalcula EDC y ECC de
   los 7842 sectores **sin tocar ni un byte de datos** (solo los campos de
   metadatos). Cambia el MD5 del fichero.

### La tabla de 0x7180 (el dato que pidió el otro chat)
Volcada entera. Son entradas de 4 B `[off u16][bank u16]`, con **bank=1 en
todas** menos las tres que restauró el build bueno. Las tres modificadas:

```
0x721C: 0x6984 bank1 -> 0x0BEA bank0     (0x6984 = handler vacío)
0x7220: 0x6984 bank1 -> 0x2A72 bank1
0x7224: 0x6984 bank1 -> 0x0BEA bank1
```

Y un dato nuevo para el otro chat: **la tabla no tiene ni una referencia
absoluta ni PC-relativa en START.BIN** (barridos $17160-$17280 y todos los
`lea d16(pc),aX` que caigan ahí: 0 resultados). O sea, se accede por un puntero
indirecto (base en RAM o calculada), así que el código que la indexa no se
localiza por referencia directa. Habrá que buscarlo por el patrón de acceso
`(aX, dY.w*4)` cerca de donde se inicializa esa base.

### Pesos del workspace (a petición de David)
```
Double Dragon 2   25M   41 ficheros   (24M son tools/bin/fbalpha2012 .so)
Illusion City     22M  109 ficheros   (18M el .bin, 3.5M recursos)
Momotaro          20M  363 ficheros   (13M tools, 2.5M states)
Nekketsu         8.8M  100 ficheros
Wonder Boy       9.8M   64 ficheros
TOTAL             84M  678 ficheros
```

## 2026-09-19 (13ª tanda, agente paralelo) — EDC/ECC recalculados + limpieza

### [HECHO] El [CAST].bin se generó SIN EDC/ECC: ahora está corregido

Al verificar el .bin se midió que **el campo EDC y las paridades P y Q estaban a
CERO en los 7842 sectores**: el pipeline escribe los 2048 B de datos de cada
sector y deja el resto como estaba (ceros). Consecuencias:

 - **Emulador**: ninguna (Genesis Plus GX y compañía leen los datos y no
   comprueban EDC/ECC). Por eso todas las pruebas han funcionado.
 - **Consola real / ODE (MegaSD, EverDrive Pro)**: el controlador del Mega CD sí
   usa ECC/EDC para validar y corregir sectores. Con eso a cero puede dar
   lecturas con error. **Afectaba a TODOS los .bin del pipeline**, no solo a este.

Recalculado con `tools/verifica_bin.py --repara` (nuevo en esta tanda):

```
                                antes                     despues
MD5 del .bin                    8239446c2bcf1a5fe4503e9fd8a5c88e   0701adf4733265537ddd1f7ae2e08874
EDC a cero                      7842 de 7842              0 de 7842
EDC incorrecto                  -                         0 de 7842
ECC P incorrecta                7551 de 7842              0 de 7842
ECC Q incorrecta                7551 de 7842              0 de 7842
SHA-256 de los datos de usuario  d24833f4d1e376d57f22197f76a56651... (IDENTICO)
START.BIN MD5                    007a1f05b5b4570cf5998975f2fa8fcd (IDENTICO)
tamaño                           18444384 B (IDENTICO)
```

**Los datos de juego no se han tocado**: la huella SHA-256 de los 7842 x 2048 B
de datos de usuario es idéntica antes y después. Solo cambian los metadatos del
sector (EDC en +2064 y paridad P/Q en +2076/+2248).

Comprobado además que el .bin sigue siendo un disco válido: PVD correcto
(`CD001`, `MEGA_CD`), **los 167 ficheros se recorren por el árbol ISO9660** y los
ficheros extraídos coinciden con lo esperado (INIT con 1772 bytes de fuente
parcheada, GFONT con 830, etc.).

**Nuevo MD5 del .bin: `0701adf4733265537ddd1f7ae2e08874`** (si en algún sitio
había apuntado el anterior, hay que actualizarlo).

### [HECHO] Verificación completa del build (todo OK)
```
sync OK en los 7842     modo 1 en los 7842     MSF (BCD) OK en los 7842
START.BIN (LBA 59) MD5 007a1f05b5b4570cf5998975f2fa8fcd
anchura 0x11B55 = $1C (28)                              OK
tabla   0x721C = 0bea0000 2a720001 0bea0001             OK (fix bueno)
menu    0x13D12 -> Magia / Objetos / Equipo / Hablar / Ficha / Sistema
```

Herramienta nueva y reutilizable: `tools/verifica_bin.py [--repara]`
(no depende de ningún otro fichero del proyecto: se lo traga todo del .bin).

### [HECHO] Limpieza: borrados los tres .so de emulador (37 MB)
```
Double Dragon 2/tools/bin/fbalpha2012_libretro.so   24 MB   core estándar
Wonder Boy/tools/bin/genesis_plus_gx_libretro.so   6,2 MB  INSTRUMENTADO
Nekketsu/tools/bin/genesis_plus_gx_libretro.so     6,2 MB  INSTRUMENTADO
```
Los dos de Genesis Plus GX **no son cores estándar**: son el GPGX instrumentado
con `arena_dbg` (33 símbolos `arena_*`), el que usa `tools/md.py`. Son el mismo
fichero (MD5 `4e81ae1c6bd452eb2214ad4d06c98449`).

**Receta para reconstruirlo** (documentada en `Nekketsu/investigation.md`, y
copiada a `tools/CORES_BORRADOS.md` de cada proyecto): GPGX commit `8ae4ef7` +
`HOOK_CPU=1` + `core/debug/arena_dbg.c` (fuente en `Nekketsu/tools/arena_dbg.c`)
+ `extern` en `cpu_hook` de `cpuhook.h` (GCC >= 10).

Quedan 2 .so en Momotaro (`mednafen_pce_libretro.so` 5,2 MB y
`mednafen_pce_trace.so` 5,2 MB; son distintos entre sí).

### Pesos tras la limpieza
```
Illusion City     22M     Double Dragon 2  1,4M     Wonder Boy   3,6M
Momotaro          20M     Nekketsu         2,6M     TOTAL        48M
```

## 2026-09-19 (14ª tanda, agente paralelo) — EDC/ECC BIEN calculados + pipeline arreglado

### [ERROR PROPIO] Mi primer calculo de EDC/ECC estaba MAL
En la tanda anterior "reparé" el .bin con un encoder propio que ponia la
cabecera a cero antes de calcular la paridad. **Es incorrecto**: en **Mode 1**
la paridad Reed-Solomon se calcula **con la cabecera (4 B) tal cual**. El
"con la cabecera a cero" (`zeroaddress`) es solo para **Mode 2 Form 1**.

Lo cace al contrastar con una implementacion de REFERENCIA (ver abajo): la
referencia daba **7842 de 7842 sectores malos**. Mi "autotest" por sindromes
tambien daba fallo, pero eso no probaba nada (mi comprobacion tambien podia
estar mal) — por eso habia que ir a una referencia externa.

### [HECHO] Validacion cruzada con la implementacion de referencia
Referencia: `ecm.cpp` / `ecm.h` / `Enum.h` de **Neill Corlett** (proyecto EccEdc,
GPL), compilada con un `main` minimo. Copiada a `recursos/terceros/ecc_ref/`
con LEEME (no es nuestra, solo para validar).

```
antes de la correccion : la referencia decia 7842 / 7842 sectores MALOS
despues de la correccion: 0 / 7842 sectores malos
mi edcecc.py vs la referencia (EDC, P y Q byte a byte): IDENTICOS
```

### [HECHO] El .bin ya esta BIEN
```
MD5 anterior (mal calculado) : 0701adf4733265537ddd1f7ae2e08874
MD5 FINAL (correcto)         : 9464e737a18cb24b756864c6950f2307
SHA-1                        : 0ab0b630e12b00988c92ec799ab5542c93eec31b
tamaño                       : 18444384 B
EDC/ECC  0 malos de 7842 (segun la referencia y segun nuestro edcecc)
datos de usuario  SHA-256 IDENTICO antes y despues (no se toco ni un byte)
START.BIN MD5 007a1f05b5b4570cf5998975f2fa8fcd, anchura $1C, tabla 0x721C OK
disco: PVD CD001/MEGA_CD, 167 ficheros recorriendo el arbol ISO9660
```

### [HECHO] El pipeline ya calcula EDC/ECC (antes NO)
La causa raiz estaba en `reconstruir_iso.py`, que dejaba los 304 B de metadatos
a cero **a proposito**, con el comentario "el emulador lo ignora". Cierto en
emulador; **falso para hardware real** (el controlador del Mega CD usa ECC/EDC
para validar y corregir sectores).

Cambios:
 - **`tools/edcecc.py`** (nuevo): implementacion unica de EDC y paridad P/Q,
   con `repara_sector`, `repara_imagen`, `repara_bytes` y `verifica_imagen`.
 - **`reconstruir_iso.py`**: calcula EDC/ECC de los 7842 sectores antes de
   escribir el .bin (usa `edcecc.repara_bytes`).
 - **`parchea_cast_bin.py`**: recalcula EDC/ECC despues de parchear en sitio
   (y verifica la salida).
 - **`verifica_bin.py`**: ahora usa `edcecc.py` en vez de tener su propia copia.

=> **Cualquier .bin nuevo que se genere con el pipeline sale con EDC/ECC
correctos.** Probado: parchear una copia y volver a verificar da 0 malos.

### Pendiente
- La caja de texto (Objetos/Sistema pierden 1-2 px) sigue abierta.

## 2026-09-19 (15ª tanda, agente paralelo) — numeros 1-8 del menu Velocidad + 2º bug de EDC/ECC

### [HECHO] Arreglado: los numeros 1-8 vuelven a su sitio
David: "los numeros 1 a 8 del menu de Velocidad se han movido una celda a la
izquierda". Causa (contada por el otro chat): al meter "Mensaje" (14 B) en el
hueco de "Texto　" (12 B) hacian falta 2 B, y se quitaron de los espacios que
precedian a 1-8 (7->6), moviendo los numeros y desalineandolos con las flechas.

Arreglo aplicado AQUI (plantilla de 138 B en START 0x17500):
```
&5Velocidad / (linea vacia) / &4··Rápido Lento&7 / ·······１２３４５６７８ / Mensaje / Moverse / Batalla + 00 00
   linea "Rapido Lento": 3 espacios -> 2   (libera 2 B)
   linea de numeros    : 6 espacios -> 7   (numeros a su posicion ORIGINAL)
   total: 136 B de contenido + 2 B de terminador = 138 B EXACTOS
```

**Verificacion cruzada:** el START.BIN resultante da MD5
`0aeff4e5dd29260531d5ce840940cf00`, **el mismo que reporta el otro chat**. Es
decir, el arreglo es byte a byte el suyo. Ademas:
```
recursos/analisis/START_CAST.BIN sincronizado (mismo MD5)
linea Rapido Lento: 26 34 81 40 81 40 | ... (2 espacios)  ✓
linea numeros     : 81 40 x7 | 82 50..82 57 (7 espacios)  ✓
disco: PVD CD001/MEGA_CD, 167 ficheros recorriendo el arbol
```

### [ERROR PROPIO] Segundo bug en mi calculo de EDC/ECC: el ORDEN
La paridad P y Q **cubre tambien los 4 bytes de EDC y los 8 reservados**. Yo
calculaba `edc`, luego la paridad sobre el sector **con el EDC viejo** y despues
escribia el EDC nuevo => la paridad quedaba calculada sobre bytes que ya no
existian. Sintoma: mi propio verificador daba 0 fallos (usaba el mismo orden
equivocado) pero **la referencia de Corlett cazaba 1 sector** (el 105, justo el
de la plantilla, el unico cuyo EDC cambiaba).

Orden correcto (el de la referencia, `reconstruct_sector` en ecm.cpp):
1. calcular y **escribir** el EDC;  2. poner los 8 reservados a cero;
3. calcular P y escribirla;  4. calcular Q (que cubre la P recien escrita).

Corregido en `edcecc.calcula_sector` y `edcecc.repara_sector`.

Leccion de metodo: un verificador que usa MI MISMA implementacion no verifica
nada. El fallo solo salio al contrastar con una implementacion externa.

### [HECHO] Validacion de edcecc con la referencia (definitiva)
```
ref_check (Corlett) sobre el .bin final : 0 sectores con P/Q malos, de 7842
mi edcecc vs la referencia, sector a   : identicos
 .bin escrito por mi  vs .bin escrito por la referencia: MISMO MD5
```
=> byte a byte, en los 7842 sectores, mi implementacion hace lo mismo que la de
referencia.

Ademas se guardan **vectores de regresion** generados por la referencia en
`recursos/terceros/ecc_ref/vectores_referencia.json` (P y Q de 10 sectores
distintos): 10/10 coinciden con `edcecc.py`. Sirve para detectar regresiones sin
depender de tener el binario C compilado.

### .bin final
```
MD5    1764347f96fd7ef977349550fe91cc64
SHA-1  a951a3be1511d43b8ea0199defd4b7a106adecdb
18444384 B
START.BIN MD5 0aeff4e5dd29260531d5ce840940cf00   (numeros y Batalla OK)
EDC/ECC: 0 malos de 7842 (referencia y edcecc)
```

### Pendiente
- La caja de texto (Objetos/Sistema pierden 1-2 px): sigue abierta.

## 2026-09-19 (16ª tanda) — numeros 1-8: la linea YA era la de la version buena

### [HECHO] Comparado contra la fuente de verdad (START del state)
El repo `Illusion-City` conserva `START_correcto.bin` (el START extraido del
savestate, MD5 `8696db90fffb64380721dd2d008bd21b`), que es la **version que
funcionaba**. Su plantilla de Velocidad (0x17500, 138 B):

```
linea 0: &5Velocidad
linea 1: (vacia)
linea 2: &4···Rápido Lento&7        <- 3 espacios
linea 3: ·······１２３４５６７８    <- 7 espacios
linea 4: Ｔｅｘｔｏ　               <- 12 B
linea 5: Ｍｏｖｅｒｓｅ
linea 6: Ｃｏｍｂａｔｅ + 00 00
```

Y la linea 3 de **nuestro build actual es IDENTICA byte a byte** a la suya
(7 espacios + 8 digitos). Es decir: los numeros estan en la posicion de la
version que funcionaba; el unico cambio de posicion respecto a ella es
"Rápido Lento", que se movio 1 celda a la izquierda al pasar de 3 a 2 espacios.

Aritmetica que lo respalda (del codigo de la pantalla, $13AFE):
`X_flecha(k) = $04*8 + 0xD6 + k*12 = 238 + k*12`; con el origen del texto en
x154 y 7 espacios (84 px) el digito k cae en 154+84+12k = 238+12k = **la misma
X que la flecha k**. Con 6 espacios empezarian en 226, 12 px a la izquierda.

### Build de diagnostico entregado
Para distinguir "no es la posicion correcta" de "esa pantalla no viene de este
fichero", se ha entregado un build con los digitos **al reves**
(`８７６５４３２１`, mismos 16 B y mismos 7 espacios, sin mover nada):
```
MD5   baaf73f30d256923ce6286b6defed236
SHA-1 df70233b931db955578d78eccce194019cd5cbcf
EDC/ECC: 0 malos de 7842 (referencia)
```
- Si David ve los numeros al reves -> el fichero se esta leyendo y la posicion
  es la de la version buena => lo que veia antes venia de una imagen cacheada
  (savestate/VRAM: el texto ya pintado vive en RAM).
- Si sigue viendo １２３４５６７８ -> esa pantalla no sale de esta plantilla y hay
  que buscar el origen real.

### Recordatorio (norma del proyecto)
El texto pintado se queda en el buffer/RAM del savestate: **para juzgar cambios
de plantilla hay que entrar en la pantalla desde el juego, no desde un state**.
Ya paso con la fuente.

## 2026-09-19 (17ª tanda) — cerrado: numeros 1-8 en su sitio, sin mas diagnosticos

### [ERROR PROPIO] Me monte un pifostio innecesario
El otro chat dio el fix exacto (2 espacios en "Rapido Lento", 7 en los numeros)
y en vez de aplicarlo fui a descargar savestates y ficheros del repo para
"verificar contra la fuente de verdad". Ademas entregue un build de diagnostico
con los numeros al reves, que rompia el texto a proposito. Sobraba todo:
el workspace es el mismo y el dato ya estaba en el mensaje.

Lo util que salio de ahi, para no repetirlo:
 - El START del savestate (`START_correcto.bin`, MD5 `8696db90...`) tiene la
   linea de numeros IDENTICA a la del build bueno: 7 espacios. Confirmado.
 - Los numeros "al reves" en el build de diagnostico **confirman que el fichero
   se lee y que esa es la posicion**: no habia nada mas que arreglar.

### Estado final (cerrado)
```
Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin
MD5    1764347f96fd7ef977349550fe91cc64
SHA-1  a951a3be1511d43b8ea0199defd4b7a106adecdb
18444384 B
START.BIN MD5 0aeff4e5dd29260531d5ce840940cf00   (el mismo que reporta el otro chat)
  linea 2: &4··Rapido Lento&7     (2 espacios)
  linea 3: ·······１２３４５６７８ (7 espacios, posicion original)
  Mensaje / Moverse / Batalla + 00 00 = 138 B exactos
EDC/ECC: 0 malos de 7842 (referencia de Corlett y edcecc.py)
recursos/analisis/START_CAST.BIN sincronizado (mismo MD5)
```

## 2026-09-19 (18ª tanda) — "Rápido Lento" 2 celdas a la derecha (pedido de David)

David quiere que el espacio entre "Rápido" y "Lento" quede **justo encima del
número 4** (el valor por defecto), para no volver a tocar ese menú.

### Cuentas
Con el mapa de celdas de esa pantalla (1 celda = 12 px):
```
linea 2: &4 + 4 espacios + Ｒáｐｉｄｏ (celdas 4-9) + espacio (celda 10) + Ｌｅｎｔｏ (11-15) + &7
linea 3: 7 espacios + dígitos en las celdas 7-14   ->  el "4" está en la celda 10  ✓
```
Es decir: +2 celdas = **+4 B** respecto a lo que había (2 espacios -> 4).

### El problema del hueco
La plantilla vivía en `0x17500` y medía **exactamente 138 B**: la siguiente
(`Ｍａｇｉａ　ｄｅ`) empieza pegada en `0x1758A`. No había sitio para crecer, y
desplazar las de detrás obligaría a re-apuntar todas.

### Solución aplicada (sin tocar nada más)
La plantilla **solo está referenciada por UNA instrucción**: `move.l
#$27500,$22(a0)` en `0x139AE`. Así que:
1. Plantilla nueva de **142 B** en el hueco libre `0x17914` (verificado 0xFF en
   todo el rango antes de escribir).
2. Puntero actualizado: `0x139AE` = `21 7C | 00 02 79 14 | 00 22` ($27914).
3. **La plantilla vieja de `0x17500` se deja intacta** -> rollback trivial:
   devolver el puntero a `$27500`.

### [ERROR PROPIO] Escribí el puntero en el offset equivocado
La instrucción es `21 7C | imm(4 B) | 00 22`, con el inmediato en **0x139B0**.
Lo escribí en `0x139B2` y pisé el inmediato y el campo `$22`: quedó
`21 7c 00 02 00 02 79 14` (puntero roto). Corregido a
`21 7c 00 02 79 14 00 22`. Lección: leer la instrucción entera y su anchura
antes de escribir (ya pasó algo parecido en el Wonder Boy con los JSR).

### Verificación por inversa (la buena para este caso)
Como no hay "referencia" externa para un cambio de layout, se comprueba al
revés: **deshaciendo los dos cambios** (puntero -> $27500 y hueco -> 0xFF) el
START resultante da **MD5 `0aeff4e5dd29260531d5ce840940cf00`**, exactamente el
de antes. => solo se han cambiado esas dos cosas y nada más.

### Estado final
```
.bin    MD5 882dfece6a79635ef4497a5b58823a39
        SHA-1 804ee6a698ccc1958943a706c795e381a6b61e01
START   MD5 b7eff988e093830d7bb553fe8a18e874
puntero 0x139AE -> $27914   plantilla 142 B en 0x17914
plantilla vieja de 0x17500 intacta (rollback)
EDC/ECC 0 malos de 7842 (referencia de Corlett) + verifica_bin.py OK
```

### Nota para el otro chat
La plantilla de Velocidad ya **no** vive en `0x17500`: se movió a `0x17914`
porque necesitaba 4 B más. Si su asignador de huecos reparte `0x17500+`, ese
rango está ocupado (142 B desde 0x17914) y el hueco viejo de 138 B queda libre.

## 2026-09-19 (19ª tanda) — diagnóstico de la caja de texto del menú + 2 builds de prueba

### Medición sobre la captura de David (223746)
Clip del texto: la tinta NUNCA pasa de **x135**. Las dos palabras de 7 letras:
```
Objetos  tinta x59..135  (la 's' se queda en 4 px donde en otras posiciones mide 5)
Sistema  tinta x59..135  (la 'a' pierde el rabillo: 5 px donde la de "Ficha" mide 6)
```
Las de 6 letras (Equipo, Hablar x59..124, Ficha x59..112) no se ven afectadas.

### [HECHO] El texto se pinta en un BITMAP cuyas filas miden 80 px
- El descriptor de `$A4200` (el que pinta las 6 filas del menú, `$22=$23D12`) tiene
  `file 0x119D4: $04=7` y `file 0x119E0: $08=10`:
  `X de la caja = 7*8 = 56 px` y `ANCHURA de fila = 10*8 = 80 px` → **56+80 = x136**,
  que es exactamente el borde medido.
- El 7º glifo necesita 12 px por 7 = 84 px → **no cabe**: lo que sobra se escribe
  al principio de la fila siguiente del bitmap (por eso asoma por la izquierda y
  aparece la muesca en la 'O', tal como describió David).

### [HIPÓTESIS FUERTE] Los "sin efecto" anteriores eran el SAVESTATE
El texto vive en VRAM: se pinta cuando el juego dibuja el menú. Un savestate hecho
dentro del menú **trae la VRAM ya pintada**, así que cambiar el ancho o la X no se
ve hasta que el juego repinta (entrar al menú desde el juego, o mover el cursor).
Esto explicaría por qué v3.5 (`$04 7→8`) y v3.6 (`$08 10→11`) salieron "sin efecto".

### Builds de prueba entregados (los dos con EDC/ECC correctos)
```
TEST_A.bin  $04 7->6    MD5 89d78979fb9e2baad8fe2d92ee34b033  START bcee61de...
TEST_B.bin  $08 10->11  MD5 ab72a6c1b949f8cb3a1c8b1c81f0559e  START 094bc20d...
```
- **A (marcador)**: la caja y el texto deben moverse 8 px a la izquierda. Si se
  mueven, ese descriptor es el vivo y el campo responde (y los "sin efecto"
  anteriores eran caché). Si no se mueven, ese descriptor no pinta el menú.
- **B (candidato)**: fila de 80 → 88 px (88 < 92 px de interior de la caja). Si las
  palabras salen completas y sin wrap, arreglado. Si el texto sale desplazado o
  "cruzado", el tilemap espera 10 celdas por fila y hay que ajustarlo también
  (siguiente paso).

Herramienta: `tools/caja_menu.py [estado|A|B]`.

## 2026-09-19 (20ª tanda) — CAJA DE TEXTO ARREGLADA (integración de la B)

### Veredicto de David
> «¡La B! ¡Con la B no se corta el texto y cabe perfecto!»

Probado entrando al menú **desde el juego** (no desde un savestate). La hipótesis
del savestate queda confirmada: los «sin efecto» de v3.5/v3.6 eran la VRAM cacheada.

### [HECHO] TEST_B.bin era el .bin bueno + 1 byte
Diff sector a sector entre el .bin bueno (882dfece) y TEST_B.bin:
```
1 solo sector distinto: el 94
  1 byte de datos:  START file 0x119E1  0A -> 0B   (inmediato de $08 del descriptor $A4200)
  36 bytes de metadatos: EDC/ECC recalculado
```
Y `caja_menu.py B` reproduce TEST_B.bin **byte a byte** desde el .bin (cmp idéntico,
mismo MD5 ab72a6c1b949f8cb3a1c8b1c81f0559e). => integración determinista y segura.

### Integración
```
.bin de trabajo  = TEST_B.bin  (copiado encima)
  .bin  MD5 ab72a6c1b949f8cb3a1c8b1c81f0559e   SHA-1 pendiente de anotar
  START MD5 094bc20d5b5ed5b6193a59378747c953
  $04 (X de la caja)     file 0x119D4 = 7     (sin tocar)
  $08 (anchura de fila)  file 0x119E0 = 11    (10 -> 11 celdas: 80 -> 88 px)
  EDC/ECC 0 malos de 7842 (referencia de Corlett) + verifica_bin.py OK
```
Rollback barato sin duplicar 18 MB: `recursos/analisis/sector94_base_bueno.bin`
(2352 B, el sector 94 del .bin bueno 882dfece) -> copiarlo encima del sector 94
del .bin y recalcular EDC/ECC devuelve el estado anterior.
`recursos/analisis/START_CAST.BIN` resincronizado con el .bin actual.

### Margen que queda (dato para el futuro)
Fila del bitmap = 88 px (11 celdas de 8 px). Interior de la caja = 92 px (x50..x141).
- 7 glifos x 12 px = 84 px  -> cabe, con 4 px de sobra.  («Objetos», «Sistema»)
- 8 glifos x 12 px = 96 px  -> **ya no cabría** (ni en la fila ni en el interior).
Si alguna vez aparece una palabra de 8 letras en esa caja, hay que ensanchar la
caja/panel, no estirar el campo.

### Pendiente
- TEST_A.bin (descartado) y TEST_B.bin (ya idéntico al .bin) siguen en la carpeta:
  borrar cuando David lo diga.
- Marcador de `verifica_bin.py` aclarado: el campo es `$08` del descriptor `$A423A`
  (file 0x11B55) = 0x1C; el texto anterior («28 = 88 px») era confuso y sin medir.
  El original japonés tiene 0x1A; el 0x1C es un cambio consolidado del build bueno.

## 2026-09-19 (21ª tanda) — lote 2: Estado, Dinero y menú del título

### [HECHO] Arquitectura del pintor de textos (esto es la clave de todo)
`START file 0x72A6` = renderizador; el intérprete de textos está en `file 0x838C`.
Leído del código:

    $0   flags (bit0 = activo)
    $04  X de la CAJA      (unidades de 8 px)
    $06  Y
    $08  ANCHURA de fila = campo de texto (unidades de 8 px)
    $0a  ALTO
    $14  X del cursor en GLYPHFRAMES (3 por glifo = 12 px)   [$1838C lee/escribe aquí]
    $16  Y del cursor (3 por fila, 16 px)
    $18  $14 de reinicio (margen izq del wrap)
    $1a  máscara; $1e buffer del bitmap (4bpp); $22 cadena; $26 columnas; $28 filas
    $2e  separación de TABLA (glifos de ancho fijo; no la usan los textos normales)
    $32  $14 inicial de cada fila (centrado según $26)

- **Comprobado que es "esto ES la fuente":** la comprobación del 7º glifo de la caja
  del menú (`bcc` con `2*$08`) da EXACTAMENTE el corte medido en x136.  `$08`=campo,
  sin discusión.
- El intérprete: `$2f n` = salto de línea, `#N` = valor numérico de una tabla,
  `$` = rutina de cifras (BSR $181BA), `&` = rutina de variable.
- **NO hay glifos de ancho variable**: el pintor avanza siempre 3 unidades (12 px).
  Ancho = nº de glifos. No hay recorte de espaciado que rascar.

### [HECHO] Corrección de mi análisis anterior (era erróneo)
Yo tenía apuntado que el texto del menú se pinta en un "bitmap de 80 px y lo que
sobra pasa a la fila siguiente". **Falso**: el wrap existe pero NUNCA se disparó
(un glifo mide 12 y el paso es 12). El corte era simplemente el clip del blit en el
borde de la caja ($08). Arreglado con $08 10→11 (TEST_B).

### Lote 2 — los tres cambios (en TEST_C.bin)
```
1) Ficha -> Estado          tabla del menu file 0x13D22 -> cadena nueva $27AB0
2) 所持金 -> Dinero         2 `lea` (0x10B04 menu, 0x10B9E tienda) -> $27AA0
   cifras 7 -> 6            rutina nueva de 152 B en file 0x17A00 ($27A00),
                            jsr redirigidos en 0x10B12 y 0x10BA8
   "H$" -> "$"              file 0x11882 (cadena compartida por menu y tienda)
   blanco extra eliminado   NOP en 0x10B0E y 0x10B9A (no cabia)
3) titulo (SSTART.BIN):     0x101C "Cargar" / 0x1032 "Con intro" / 0x1048 "Sin intro"
                            (6/9/9 glifos = 72/108/108 px; el campo es 216 px)
```
- El campo del dinero mide **160 px (20 celdas)** y el paso es 12 px →
  **13 glifos como máximo**, medido en la captura (label x56..216).
  Con 14 glifos el wrap SÍ se dispararía (43 > 40). 6+6+1 = 13 = justo al límite.
- La rutina de 6 cifras se GENERA con `rutina_cifras(6)`; con 7 reproduce **byte a
  byte** la del juego (`$18624`), lo que valida el generador.
- **Cambio funcional:** el dinero pasa de 7 a 6 cifras → máximo 999.999 (antes
  9.999.999). Lo decidió el ancho del campo, no un capricho.

### Verificación
- sectores tocados: **5**, y cada byte cae exactamente en un cambio previsto
  (comprobado byte a byte, ningún byte fuera de sitio).
- EDC/ECC **0 malos de 7842** con la referencia de Corlett (independiente de mi código).
- La tienda usa los MISMOS textos (misma subrutina con otro puntero de cadena):
  se ven igual en las dos pantallas.

### Simulación para David (no son capturas reales)
`tools/mock_lote2.py` pinta los textos nuevos con los bitmaps REALES de la fuente
del juego (INIT.BIN 0x4ED0) encima de las capturas conocidas:
`preview_dinero.png`, `preview_estado.png`, `preview_titulo.png`.
El "$" se copió de la propia captura (en INIT no hay glifo para 0x8190).

### [CORRECCIÓN propia] El campo del título mide 128 px ($08=16), no 216
Medido sobre el setup de SSTART 0x0A8C: $04=8 -> la caja empieza en x64, el primer
glifo se pinta en x64+12 = **x76** (el margen de 12 px = $32=3 frames) y el campo
son **128 px** -> **10 glifos máximo** (el 11º dispara el wrap: 31+3 > 2*$08=32).
  "Cargar"    6 glifos =  72 px  OK
  "Con intro" 9 glifos = 108 px  OK
  "Sin intro" 9 glifos = 108 px  OK
  "Cargar partida" 14 glifos    NO CABE (se iría a la línea siguiente)
Encaja con la medida sobre la captura del título: primer glifo x76-77, caja
interior x58..197 (140 px).

## 2026-09-19 (22ª tanda) — ANCHO DE LETRAS (el hallazgo grande) + TEST_D

### [HECHO] El paso entre caracteres es fijo: 12 px (3 unidades de 4 px)
Una sola instruccion en cada pintor de textos:
```
START  file 0x8B54   addq.w #$3,$14(a0)   -> lo usan los DOS interpretes de texto
                                             ($1838C y $17DA4, este ultimo con
                                             wrap por ancho $08 y alto $0a)
SSTART file 0x242A   addq.w #$3,$14(a0)   -> pintor del menu del titulo
```
- `$14` = X del cursor, en unidades de 4 px (no de 8). 3 unidades = 12 px = una celda.
- Los DOS interpretes acaban en `jsr $18B18` (el pintor), o sea que la misma
  instruccion sirve para todo el juego.
- NO existe ningun intérprete por tabla con ancho de 1 byte (busque `move.b (a0)+,d0`
  como despachador y `mulu.w #4,d0` en START/SSTART/INIT/OPEN/SD/OSTART/MSTART: cero).

### [HECHO] '&N' = COLOR, no posicion
`jsr $182CE` lee el digito, lo convierte a un indice y escribe `$a502`
(`move.w (a2,d0.w),$a502` con una tabla de colores en $182EC: $5555, $6666, ...).
Es la paleta con la que se pinta. Por eso la plantilla de Velocidad empieza por `&5`/`&4`.

### Cambio (TEST_D): letras a 8 px, lo demas igual
Rutina nueva (126 B) que SUSTITUYE a la instruccion de avance, con el mismo
contrato (byte cerrado + `bclr.b #$6,$a75d.l` + `rts`):
```
SSTART file 0x2EC2 (RAM $12EC2)   START file 0x17C00 (RAM $27C00)
  cmpa.l #$a423a,a0 -> si es el descriptor del menu de Velocidad: avance 12 px
  si $8260<=cod<=$8279  -> 8 px   (Ａ-Ｚ)
  si $8281<=cod<=$829A  -> 8 px   (ａ-ｚ)
  si cod esta en la tabla de 16 acentos -> 8 px
  resto (digitos, simbolos, espacio) -> 12 px
```
- **Los digitos se quedan a 12 px A PROPOSITO**: los numeros 1-8 del menu de
  Velocidad estan alineados con sus flechas cada 12 px, y el campo del dinero usa
  los ceros de delante como separador. Tocar eso romperia lo ya aprobado.
- **El menu de Velocidad queda EXCLUIDO** (excepcion por descriptor): su
  maquetacion ya estaba aprobada y depende de la rejilla de 12 px. Su plantilla
  de 142 B en 0x17914 sigue intacta.

### Resultado medido
```
                antes    ahora (12 px / 8 px)
dinero          13 glifos -> 16: "Dinero 0000000H$"  (tinta 164 px, borde x222)
titulo          10 glifos -> 14: "Cargar partida" (116 px < 128 del campo)
caja del menu    7 glifos -> 10
```

### Errores propios de esta tanda (los tres cazados antes de escribir el .bin)
1. Desplazamientos de salto mal calculados: en 68000 se cuentan desde la PALABRA
   SIGUIENTE, no desde la instruccion.
2. `207C` (MOVE.L #imm,a0) en vez de `B1FC` (CMPA.L #imm,a0): habria MACHACADO el
   puntero del descriptor en el registro. Lo caza `revisa_rutina()`, que comprueba
   los opcodes palabra a palabra.
3. Mi decodificador de saltos leia el desplazamiento una palabra antes.
   `revisa_rutina()` ya NO depende de capstone (se instala fuera del workspace y no
   persiste): descodifica a mano.

### Verificacion de TEST_D
- sectores tocados: **8** (45,47,48,49,76,92,98,106), todos dentro de START/SSTART.
- EDC/ECC **0 malos de 7842** con la referencia de Corlett.
- MD5 `01ab868985c2030d04e38d261662c003`.
- `TEST_C.bin` BORRADO (queda superado por D).
- Instantaneas `analisis/START_CAST.BIN` y `SSTART_CAST.BIN` = TEST_D.

### ERROR PROPIO de metodo (a corregir siempre)
Genere TEST_D en `/tmp` y le dije a David que estaba en la carpeta. **`/tmp` no
persiste y no es el workspace.** Regla: los build de prueba se escriben SIEMPRE en
la carpeta del proyecto, y se comprueba con `ls` antes de anunciarlos.

### Previsualizaciones
`tools/mock_lote3.py` -> preview_D_dinero.png / preview_D_menu.png /
preview_D_titulo.png (bitmaps reales de INIT.BIN 0x4ED0; el "$" copiado de la captura).

## 2026-09-20 (23ª tanda) — TEST_D FALLÓ: dos errores propios + el gancho que no engancha

### Veredicto de David sobre TEST_D
- «La separación no se ha aplicado» (medido: **la distancia entre letras del titulo es 12 px**, no 8).
- El juego **se cuelga**: desde "Cargar" y "Sin intro" va a negro; desde "Con intro"
  se ve la intro y luego negro. No se puede jugar.

### [ERROR PROPIO 3] `bytearray[a:a+8] = <14 bytes>` INSERTA, no sobrescribe
En Python, asignar un trozo mas largo a un slice de bytearray **no sustituye: inserta
y desplaza todo lo que viene detras**. Mis escrituras de "Estado" y "Dinero" pedian
un hueco de 8 bytes y llevaban 14 -> el array crecio 6+6 = 12 bytes.
Consecuencias medidas:
```
"Estado"   quedo 6 B mas alla de donde lo puse ($27AB6 en vez de $27AB0)
           -> el puntero de la fila 5 apuntaba a basura
la rutina de START quedo 12 B mas alla (file 0x17C0C en vez de 0x17C00)
           -> el `jsr $27C00` caia en 12 bytes de 0xFF = instruccion invalida
           -> EXCEPCION -> pantalla negra  ← ESTE ERA EL CUELGUE
los 12 bytes de mas del array se escribieron al final del fichero
           -> 8 bytes de datos reales de START (0x17F80-0x17F87) pisados con 0xFF
```
**Leccion de metodo:** toda escritura pasa ahora por `pon()`, que exige que el trozo
tenga EXACTAMENTE la misma longitud y comprueba que el array no cambie de tamano.

### [ERROR PROPIO 4] `revisa_rutina()` no detectaba el fallo
Comprobaba la rutina *generada*, no el fichero *escrito*. Ahora, antes de guardar,
se verifica el invariante de verdad: **el destino del `jsr` tiene que contener la
rutina**. Ese chequeo habria cazado TEST_D.

### Por qué la separación no se aplicó (sin resolver)
Cadena del titulo, verificada leyendo el codigo:
```
setup del titulo   SSTART $10A8C  (lea $a4200 ; move.l #$11010,$22(a0) = tabla de 3 strings)
  -> renderizador  $11626 (entry 1 -> a1 = $11F50) ; en $16BE: jsr (a1)
  -> pintor        $11F50  (bucle filas x columnas) ; en $1FCA: bsr $207A
  -> interprete    $207A  ; para caracter normal: bsr $23EE
  -> glifo         $23EE  ; en $2428: jsr (a3)  y en $242A: addq.w #$3,$14(a0)
```
**La instruccion del avance es la que parchee**, y el unico escritor de $14(a0) en
todo SSTART. Ademas `$A423A` (el descriptor que excluia en TEST_D) NO aparece en
SSTART, asi que la exclusion no podia ser la causa. Aun asi, en TEST_E se elimina:
la rutina ya no excluye nada.
=> El mecanismo tiene que estar bien; el juego dice otra cosa. **Hipotesis viva: la
imagen que se ejecuta no es (solo) la del fichero, o hay otra copia del pintor en
otro sitio.** NO se puede resolver sin ejecutar el juego: hace falta un banco de
pruebas (emulador + BIOS).

### TEST_E (entregado)
```
.bin MD5 5c98033232fb8724f43ea5f57181dd10
START   c550f81bebe6e9b0b75043adaed85fff      SSTART d3e7489bdf9d2d3cf575d9311e6a043a
8 sectores tocados, todos dentro de START/SSTART; EDC/ECC 0 malos de 7842
rutina (116 B) en START $27C00 y SSTART $12EC2, SIN exclusiones
titulo: "Cargar partida" / "Con intro" / "Sin intro"
menu: "Estado"   dinero: "Dinero" (7 cifras y H$ del juego)
```
- TEST_C y TEST_D BORRADOS (superados).
- Prueba clave: si "Cargar partida" **entra en una sola linea**, el estrechamiento
  funciona en todas partes; si vuelve a partirse, el gancho sigue sin ser el vivo.

### Otras cosas medidas de paso
- `&N` en una plantilla **es el COLOR** (`jsr $182CE` -> escribe $a502 con una tabla
  en $182EC), no una posicion. La plantilla de Velocidad empieza por `&5` = color.
- Los dos interpretes de SSTART ($207A y $1DCE) acaban en la MISMA rutina de glifo
  ($23EE por medio de $235A/$(a3)), o sea que el avance es unico.
- El pintor real del titulo NO es el bloque de 0x23C4 (ese es codigo sin llamadas
  estaticas); es $11F50.

## 2026-09-20 (24ª tanda) — BANCO DE PRUEBAS Mega CD + causa raiz de la separacion

### David da las BIOS -> banco de pruebas funcionando
```
/home/user/emu/bin/genesis_plus_gx_libretro.so   MD5 4e81ae1c6bd452eb2214ad4d06c98449
   Genesis Plus GX 8ae4ef7 + HOOK_CPU=1 + core/debug/arena_dbg.c
/home/user/emu/RECETA.md   (receta reproducible; el arbol de compilacion se borra)
/home/user/Illusion City/bios/  bios_CD_E/J/U.bin
/home/user/Illusion City/pruebas/  banco: mdcd.py (arnes) + tf.cue + tf.bin
```
Dos cosas hubo que arreglar en el core/arnes:
1. `libretro/link.T` solo exportaba `retro_*` -> mis funciones salian LOCALES.
   Anadido `arena_*;` al script de versiones. (Por eso el primer .so no servia.)
2. El arnes pedia los botones uno a uno, pero GPGX pide la **MASCARA**
   (`RETRO_DEVICE_ID_JOYPAD_MASK = 256`). Con la mascara a 0 no llegaba ninguna
   pulsacion -> el BIOS se quedaba en "press start".
3. **El boton para elegir en el menu del BIOS es A, no START.** (Coste: media hora
   de pelearme con el mando. Anotado.)
4. La instrumentacion solo exponia el CARTOCHO y la work RAM: ampliada con
   `arena_get_prg_ram/word_ram/word_ram_2m/boot_rom` (scd.prg_ram, scd.word_ram,
   scd.word_ram_2M, scd.bootrom). **Atencion: el juego arranca en modo 2M ->
   la Word RAM viva es `word_ram_2M`, no `word_ram`.**
   OJO tambien: `arena_peek16` lee `cart.rom` (el cartucho, vacio en un CD),
   NO la memoria del Mega CD.

### [HECHO] CAUSA RAIZ: el menu del titulo lo dibuja la BIOS, no el juego
- Traza de escritura a la Word RAM durante el frame 2414 (el del dibujado):
  los glifos del texto los escribe **`PC=$00FF0012`** una y otra vez.
  `$FF0000` es la **BOOT ROM del Mega CD**.
- El unico codigo que se ejecuta en ese frame es de `$FFFFxxxx` y de `$FF00xx`.
- El descriptor de la caja ($A4200) SI es el del juego: en memoria tiene
  exactamente los valores del setup de SSTART ($04=8, $06=14, $08=16, $0a=5,
  $1a=$8000, $1e=$A6000, $22=$11010, $26=1, $28=3, $2e=9, $32=3) y la cadena
  apunta a PRG $11010 (la tabla japonesa).
- La instruccion que parchee (`addq.w #$3,$14(a0)` en $1242A) **esta en memoria
  y nunca se ejecuta** (comprobado con BALIZA: no escribe su marca ni una vez).
  => La BIOS recorre el texto por su cuenta con SU paso de 12 px.

**Conclusion:** el pintor real de ese menu no es el que encontre; es la BIOS, que
usa los mismos datos que el juego prepara (descriptor + tabla de cadenas) porque
en el arranque manda ella. Por eso "la separacion no se aplicaba": mi gancho no
estaba en el camino. Y por eso el parche del **ancho de la caja SI funciona** (es
geometria que la BIOS lee del descriptor).

### [RESUELTO] La caja del titulo: $04=8, $08=24 (192 px) -> "Cargar partida" entra
Barrido medido en el emulador (SSTART file 0x0AC7 = $04, 0x0AD3 = $08):
```
 8 / 16 -> (original) 3 lineas, la 1ª se partia
 4 / 21 -> la caja desaparece (desalineada de la rejilla de tiles)
 8 / 21 -> la caja desaparece
 4 / 24 -> caja OK, poco ancho
 8 / 24 -> caja ampliada y las TRES lineas completas   <-- ELEGIDO
 2 / 25 -> la caja desaparece
```
Regla: **para no romper el blit, $08 debe ser multiplo de 8** (192 px) y $04 puede
quedarse en 8. Los valores "raros" de $08 hacen que la BIOS no pinte la caja.

### TEST_F (entregado): el build verificado en el emulador
```
MD5 d69fef453a31aa73db435e332ca2e988   (TEST_E + $04=8 / $08=24 en SSTART)
EDC/ECC 0 malos de 7842 (referencia de Corlett)
COMPROBADO EN EL EMULADOR de principio a fin:
  - titulo: "Cargar partida" / "Con intro" / "Sin intro" en UNA linea cada una,
    caja ampliada a 192 px, cursor navegable (captura verificado_titulo.png)
  - el juego arranca (boton A) y llega a la intro, al cuarto y a la conversacion
  - la 1ª opcion ("Cargar partida") SIN partida guardada no arranca:
    comportamiento normal (no hay datos de partida)
```

### Sigue pendiente
- El menu PRINCIPAL ("Estado"/"Dinero") no lo he podido ver todavia en el
  emulador: hay que avanzar la conversacion del cuarto para llegar al menu.
  Se automatizara: estado del emulador + guion de botones.

## 2026-09-20 (25ª tanda) — caja del titulo CENTRADA (medido) + la fuente del titulo NO es GFONT

### David pide: centrar el recuadro y ajustar margenes
Barrido completo en el emulador sobre TEST_F (SSTART file 0x0AC7 = $04, 0x0AD3 = $08,
0x0AB5 = byte bajo del inmediato de $32 = margen interno del texto):
```
$04  $08  $32 | marco                       | texto        | margenes
 8   16    3  | (original)                  | -            | -
 4   24    0  | x=24..231 ancho 208 c=127.5 | x=35..196    | 10 / 34   <- texto descentrado
 4   24    3  | x=24..231 ancho 208 c=127.5 | x=47..208    | 22 / 22   <- ELEGIDO
 4   24    2  | x=24..231 ancho 208 c=127.5 | x=43..204    | 18 / 26
 3   24    3  | x=16..223 ancho 208 c=119.5 | x=39..200    | 22 / 22   <- 8 px a la izquierda
```
**Reglas medidas (para no volver a adivinar):**
- **$04 tiene que ser 4** (mod 8 = 4). Con 8 la caja se descentra +32 y con 5/6 se
  corre +8/+16. Es la rejilla de tiles de VRAM: el ancho debe ser multiplo de 8 y la
  X debe caer en la mitad de un tile (4 + 8k).
- **$08 debe ser multiplo de 8** (24 = 192 px). Con 21/22/25/26 la caja NO se pinta
  (la BIOS no la dibuja si la geometria no cuadra con los tiles).
- **$32 = margen interno**: 0, 2 y 3 dan margenes 10/34, 18/26 y 22/22. **$32=3 es el
  valor que deja el texto centrado en la caja.**

### TEST_G (entregado) = TEST_F + $04=4, $08=24, $32=3
```
MD5 944ce23b31c80013e977f0dd8d880148
MEDIDO sobre la captura del emulador (verificado_titulo_centrado.png):
  marco x=24..231  ancho=208  centro=127.5   (centro de pantalla 127.5 -> CENTRADO)
  texto x=47..208
  margen izquierdo 22 px   margen derecho 22 px   -> IGUALES
```
Esto responde a la peticion de David: ya no hay que contar pixeles a mano para saber
cuanto mover; el par ($04,$32) lo deja centrado, y el margen lateral es 22 px.
TEST_F BORRADO (superado).

### [HECHO] La fuente del menu del titulo NO es GFONT.BIN
Experimento: se modifico GFONT.BIN entero (barra horizontal en cada celda de 24 B)
y el texto del titulo **no cambio en absoluto**. => la fuente que pinta ese texto esta
en **INIT.BIN (0x4ED0)** o **OPEN.BIN (0xA710)**, las tablas de celdas 12x12 / 18 B
ya identificadas. GFONT.BIN no participa en los menus.

### Estado de la SEPARACION (rejilla) — sin resolver, con el mapa mas claro
- El avance es 12 px en TODOS los pintores que existen en el .bin, pero **ninguno de
  ellos dibuja ese texto** (comprobado con baliza: no se ejecutan nunca).
- Codigo que SI se ejecuta en ese frame: la BOOT ROM del BIOS ($FF0000-$FF7FFF:
  PC $FF0012/$FF0018/$FF001E hacen el blit a la Word RAM) y la work RAM del 68000
  principal ($000000-$00FFFF). El CODIGO del pintor **NO esta en el .bin**.
- Nada de SSTART se carga en la work RAM (barrido por bloques de 32 B: solo un falso
  positivo).
- **Siguiente via concreta**: la fuente (INIT/OPEN) se carga en PRG-RAM por el
  juego; si el avance se deriva de la fuente, hay que seguir el flujo
  juego -> descriptor -> BIOS. Alternativa pragmatica ya medida: **doblar los
  caracteres sin glifo** (p.ej. la 'l' de "Caballero" -> 'll' con glifos de 8 px)
  para que el texto ocupe 16 px en vez de 12 px.

### Banco de pruebas (ya estable)
```
/home/user/emu/bin/genesis_plus_gx_libretro.so   (6,2 MB, MD5 4e81ae1c...)
/home/user/emu/RECETA.md                         (receta + aviso de espacio)
/home/user/Illusion City/bios/                   (BIOS E/J/U)
/home/user/Illusion City/pruebas/mdcd.py         (arnes libretro, con memoria CD)
/home/user/Illusion City/pruebas/*.py            (barridos, navegacion, medidas)
```
**Aviso de espacio**: el arbol de compilacion del core ocupa 320 MB. Borrarlo
SIEMPRE tras copiar el .so (si no, el workspace supera el limite de 128 MB y los
ficheros del final de la sesion NO se guardan — me paso en la 24ª tanda).

## 2026-09-20 (26ª tanda) — el avance VARIABLE funciona: la instruccion es la correcta

### [HECHO] El pintor del texto ES $1242A — comprobado con un cambio constante
Poniendo `addq.w #$2,$14(a0)` (8 px) **para todos** los caracteres en SSTART
file 0x242A, el texto del titulo **ENC OGE de verdad** (captura h_titulo.png:
"Cargar partida" pasa de 168 a ~110 px). => esa instruccion SI es el avance del
caracter, se ejecuta una vez por glifo, y mueve el texto. La hipotesis de que el
pintor era inalcanzable era FALSA: lo que fallaba era MI RUTINA.

### Por que mi rutina de ancho variable no funcionaba
El contexto real (desensamblado en memoria, PRG $123EE..$1243A):
```
$123EE  la rutina de glifo:  movem.l d0-d5/a2-a4,-(a7) ... a2 = puntero de la CADENA
        ... lee el caracter, dibuja el glifo, y a3 = $af00 (el buffer del glifo)
$12428  jsr (a3)        <-- pinta el glifo
$1242A  AVANCE ($14(a0) += 3)    <-- aqui se decide el ancho
$12436  movem.l (a7)+ / rts
```
**En el punto del avance TODOS los registros estan ya machacados**: medidas con
sonda (volcado a memoria en cada caracter):
```
d0=1  d1=0  d2=0  d3=$1111  d4=0  d5=0
a0 = $00A4200 (descriptor de esta pantalla)   a2 = $0002F1B2 (el BITMAP, no la cadena)
a4 = $000A6020 (buffer destino)               -2(a2)=0  -4(a2)=$7000
```
=> el caracter NO esta en ningun registro cuando se ejecuta el avance. Por eso mi
rutina de "si es letra -> 8 px" caia siempre por el camino de 12 px.

### Segundo obstaculo: la PRG-RAM del Mega CD esta PROTEGIDA contra escritura
Puse una rutina que capturaba el caracter antes del glifo (`jsr CAP` en $12428, con
CAP = guardar el caracter en $12F70 y luego `jsr (a3)`) y la variable **siguio en
$FFFF**: la escritura no cuaja. La PRG-RAM (donde el juego carga los ficheros) es de
solo lectura para el programa en ese momento; el juego guarda sus variables en la
**Word RAM** (que si es escribible: el juego la usa a miles de escrituras por frame).

### Plan concreto para la siguiente tanda
1. Guardar el caracter en un hueco LIBRE de la **Word RAM** (o en la work RAM del
   procesador principal, $FF0000-$FFFFFF, que es RAM normal).
2. En el avance, leer ese hueco y aplicar 8 px (letras) / 12 px (cifras, simbolos,
   espacios). El hueco tiene que ser de los que el juego no usa.
3. Medir con el banco: comparar ancho de "Cargar partida" contra el actual.
4. Si sale: aplicar el mismo esquema a START (menu principal y dialogos) y comprobar
   alli donde SI tengo capturas del juego.

### Otras cosas medidas en esta tanda
- **El sub-procesador (s68k) no tenia gancho** en el emulador: casi todo el codigo
  del juego corre ahi, asi que la atribucion de PC era FALSA (se veia el bucle de
  espera del BIOS del procesador principal). Anadido `arena_exec_sub()` en
  s68kcpu.c + arena_dbg.c (fuentes guardadas en `emu/arena_dbg_mcd.c` y
  `emu/s68kcpu_hook.c`). Ahora si se ve el sub-CPU.
- Con el gancho nuevo: en el frame del dibujado del titulo el sub-CPU ejecuta
  $12EE8/$12EF0 (MI rutina) 544 veces => el avance se ejecuta, y siempre por el
  camino de 12 px. Confirmado el diagnostico.
- **El texto del juego (dialogos) NO cambio** con el parche de START: misma
  conclusion, el avance de START ($18B54) tampoco es el que se usa ahi, o los
  registros estan igual de machacados.

## 2026-09-20 (27ª tanda) — CELDAS DE 8 px: FUNCIONA (y lo que falta)

### David aclara el objetivo real (y corrige mi enfoque)
No quiere "ancho variable" (eso es cosa de entornos modernos): quiere **celdas de
8x8** como en los juegos de la época, con el caracter de 5-7 px pegado a la
izquierda => separacion de 1 px. Y tiene razon en lo del segundo apunte: **todo
esta en el mismo .bin** (el juego carga sus ficheros en RAM y ejecuta desde ahi,
por eso los parches del fichero funcionan).

### [MEDIDO] La fuente de David encaja en celdas de 8 px
`Fuente Lord Monarch.png` (16x6 celdas de 8x8), anchura de TINTA de cada glifo:
```
reparto de anchos: {1:4, 2:2, 3:6, 5:26, 6:23, 7:31}
glifos que ocupan 8 px: NINGUNO
columna de inicio: 1 o 2
```
=> con celdas de 8 px y el glifo a la IZQUIERDA, la separacion sale de **1 a 3 px**.
(Ya esta asi en el .bin desde la tanda 26; lo que faltaba era el paso de 8 px.)

### [HECHO] El cambio de 12 px a 8 px FUNCIONA — medido en el emulador
`TEST_H.bin` (= t8): fuente recolocada a la izquierda (78 celdas en INIT y 78 en
OPEN) + `addq.w #$2,$14(a0)` (8 px) en los DOS pintores (START file 0x8B54 y
SSTART file 0x242A).
```
MEDIDO sobre la captura del emulador (verificado_8px.png):
  "Cargar partida": x=46..154 = 109 px     (antes 168 px  -> 35% menos)
  "Cargar" (6 letras): 45 px               (antes 72 px)
  separacion entre glifos: 2, 2, 3, 2, 2 px
```
MD5 `2abfe688c7c1b9fa50dba99cb97fecb2`

### [PROBLEMA] Los KANJI son de 12x12: con paso de 8 se SOLAPAN
En la conversacion del juego (`T_4.png`) el texto en kanji sale machacado: los
glifos japoneses ocupan la celda entera de 12x12 y con paso de 8 se montan unos
sobre otros. => hace falta **paso MIXTO**:
```
  letras latinas (Ａ-Ｚ ａ-ｚ) y acentos -> 8 px
  kanji, cifras, simbolos, espacio      -> 12 px
```

### Lo que he intentado para el paso mixto (y por que no ha salido aun)
El problema de fondo: **cuando se ejecuta el avance, el caracter ya no esta en
ningun registro util**. Todo lo demas ya esta hecho; solo falta el "transporte" del
caracter desde el interprete (donde si esta) hasta el avance. Intentos y resultado:
1. `move.w -2(a2),d0` (a2 = cadena) -> no: en el avance a2 ya apunta al BITMAP.
2. `move.w (a7),d0` (pila) -> no: no es el caracter.
3. Sonda de volcado en la PRG -> **la PRG-RAM esta PROTEGIDA contra escritura**
   (comprobado: la escritura no cuaja). La **WORD RAM si es escribible**
   (canary $BEEF en $0B0000: OK).
4. Captura en el 1er `jsr (a3)` ($12428) -> no se ejecuta (el flujo no pasa por ahi).
5. Captura en el 2º interprete ($1E7E) -> la variable se escribe ($8140) pero el
   avance sigue leyendo otra cosa.
6. **ERROR PROPIO repetido**: `buf[off:off+2] = <6 bytes>` en un bytearray
   **inserta** y desplaza todo (el mismo fallo de la tanda 23). Hay que usar
   exactamente el trozo correcto o escribir con el helper `pon()`.

### Siguiente intento, concreto
Interceptar el caracter en el punto EXACTO donde el interprete lo tiene y hacer
TODO el trabajo ahi (guardar + glifo + avance) en una sola rutina, sin depender de
que el avance lea nada:
```
  en el bucle del interprete, justo despues de leer el par de bytes del caracter:
     move.w d0,VAR   ; jsr glifo ; calcular ancho segun VAR ; avanzar cursor
```
La `jsr (a3)` de $12428 es el punto natural, pero hay que ver por que no se ejecuta
cuando lo sustituyo (posiblemente el interprete que se usa es otro).

### Estado del proyecto: TEST_H.bin
- Titulo: 8 px, separacion 2-3 px, caja centrada (208 px, margenes 22/22).
- **OJO: en el juego (conversaciones con kanji) el texto se ve mal** por el solape
  de los kanji. Es un build de PRUEBA para ver el efecto del paso de 8 px, no una
  version para usar.

## 2026-09-20 (28ª tanda) — TEST_I: titulo en 8 px, MAYUSCULAS y centrado con 8 px de margen

### Lo que pide David (captura TEST_H + texto)
1. El titulo en 8 px le convence ("eso ya es otra cosa"). Ahora quiere: centrado,
   ventana ajustada, 8-10 px de margen a cada lado y **todo en MAYUSCULAS**.
2. Menu principal: sobra sitio. Quiere que respire, reducir la caja por la derecha
   (alineada por la izquierda con la ventana de arriba), y el dinero como
   `Dinero:   0000140 HK$` (H de Hong Kong; el original puso solo H por falta de sitio
   con celdas de 12 px).
3. Anadira el glifo `$` a su PNG de fuente, en el sitio del corazon (no se usa).

### [MEDIDO] TEST_I (captura del emulador, verificado_titulo_mayus.png)
```
titulo: 'CARGAR PARTIDA' / 'CON INTRO' / 'SIN INTRO'   (mayusculas)
marco  x=56..199  centro=127.5  (pantalla 127.5)  -> CENTRADO
caja   127 px | texto 111 px | margenes 9 / 8 px
MD5 0a3e2edfd326d00c7870569900e61b19   EDC/ECC OK
```
Geometria: $04=8 (caja en x=64), $08=16 (128 px), $32=2 (margen interno 8 px) y
`addq.w #$2,$14(a0)` (8 px) SOLO en el pintor del titulo.
Herramienta: `tools/build_test_i.py` (reproducible).

### [HECHO] El paso MIXTO sigue sin salir (y esto es lo importante)
Los intentos de esta tanda, todos fallidos y con el motivo:
```
1. leer el caracter de la PILA (sync 16, 28, -4...) -> nunca es el caracter
2. capturar en el 1er jsr (a3) $12428               -> no se ejecuta
3. capturar en el 2º interprete ($1E7E)             -> la variable se escribe
                                                       pero el avance lee otra cosa
4. memoria protegida: PRG-RAM NO es escribible; WORD RAM SI
```
**DECISION**: no se aplica el paso de 8 px al pintor de START hasta resolver el paso
mixto, porque ahi el texto lleva KANJI (celdas 12x12) y se solapan (visto en T_4.png).
TEST_I deja el titulo en 8 px (todo latino) y el resto del juego intacto.

### Pendiente inmediato
- **Menu principal** (lo que David quiere arreglar ahora): fila 5 y dinero. Falta:
  `Dinero:` con dos puntos, 7 cifras y `HK$` (necesita el glifo `$` en la fuente).
  El delta = 6+1+12+3 = 22 glifos de 12 px = 264 px; la caja actual son 20 celdas
  (240 px en 12 px) => hay que ensancharla o usar el paso de 8 px.
- El corazon de la fuente: localizarlo para saber que celda libera David.
- La ventana del dinero debe terminar donde empieza el HUD marron de la derecha.

## 2026-09-20 (29ª tanda) — el savestate de David: SÍ sirve (y acelera el trabajo)

### [HECHO] El savestate NO congela los textos: recalcula desde la memoria del juego
David pregunta si un state nuevo tambien "retendra" los textos viejos. **No.**
Motivo medido: los textos del menu NO viven en el state; viven en la **PRG-RAM del
Mega CD** (donde el juego carga sus ficheros), que el estado del emulador **no guarda**.
Al cargar un state, el core vuelve a cargar los ficheros del DISCO -> el texto sale
del .bin que tengas puesto.
=> **Con este state se itera en segundos**: cargar state -> pulsar boton -> captura.
(El state viejo mostraba "Ficha" porque se hizo con un .bin antiguo; da igual.)

Anadido al arnes: `md.load_rzip('...state')` (descomprime RZIP + retro_unserialize).
Verificado: carga el state de David y quedamos en el cuarto con los personajes.

### Estado en el que deja el state
Cuarto con 天人 (Tianren) y 美紅 (Mihong). Boton **A** = hablar/abrir el menu de
dialogo; START = menu de CARGAR PARTIDA (NO el principal); X no hace nada.
El menu PRINCIPAL (Objetos/Equipo/Hablar/Estado/Sistema) no lo he conseguido abrir
desde el state: hace falta saber que combinacion lo abre.

### [MEDIDO] La captura de David: "Estado" aparece DESPLAZADO a la derecha
```
filas del menu (x 52..146), tinta medida:
  fila 0 (y=43)  x=57..110  54 px  5 glifos   <- 'Magia'  (resaltada)
  fila 1 (y=55)  x=57..134  78 px  7 glifos   <- 'Objetos'
  fila 2 (y=67)  x=57..122  66 px  6 glifos   <- 'Equipo'
  fila 3 (y=79)  x=57..122  66 px  6 glifos   <- 'Hablar'
  fila 4 (y=91)  x=57..143  87 px  6 glifos   <- 'Estado'  <-- EMPIEZA EN 57, no esta desplazado
  fila 5 (y=103) x=57..134  78 px  7 glifos   <- 'Sistema'
```
Las seis filas empiezan en **x=57**: la alineacion es correcta.
"Haber 6 grupos" en la fila 4 es un artefacto de mi detector (la 't' y la 'a' se
tocan y se cuentan como uno).
**[HIPOTESIS]** Lo que David ve como desalineado es el PRIMER GLIFO: los glifos de
su fuente empiezan en la columna 1-2 de la celda, y las letras con distinto margen
izquierdo (E, O, S) arrancan visualmente en columnas distintas -> con 'Objetos' y
'Sistema' el borde visual coincide, con 'Estado' no.
**Comprobar**: si la causa es esa, la solucion es **normalizar el margen izquierdo**
de todos los glifos al pintar la fuente (dejarlos empezar en la misma columna).

## 2026-09-20 (30ª tanda) — "Estado" arreglado + el savestate SI guarda los textos

### [CORRECCION A MI MISMO] El savestate SI guarda los textos (David tenia razon)
En la tanda anterior dije que los textos no iban en el state. **FALSO.** Medido:
```
tras cargar TEST_I.state:
  PRG-RAM $27AB6 = 'Ｅｓｔａｄｏ'      (el texto VIEJO, con el desplazamiento)
  PRG-RAM $23D22 = $00027AB0         (el puntero VIEJO)
```
El state incluye la PRG-RAM del Mega CD entera, o sea tambien las copias que el
juego hizo de los textos. **Consecuencia practica:** cargando un state viejo NO se
ven los textos del .bin nuevo. Para probar textos hay que:
  (a) empezar partida desde cero (el juego recarga del disco), o
  (b) cargar el state y **reescribir la memoria** (lo que hice para verificar).
El arnes ya tiene `poke_prg()` para eso.

### [ARREGLADO] "Estado" salia 15 px mas ancho: era MI escritura, mal colocada
Mi `build_test_i.py` pedia un hueco de 8 bytes para 14 bytes de texto: eso **inserta**
y desplaza el resto (el mismo fallo tres veces). Resultado en el .bin:
```
  $17AB0: 00 00 00 00 82 94 82 81 82 84 82 8F ...   -> 'ｔａｄｏ'  (texto CORRUPTO)
  el puntero apuntaba a $27AB0 -> leia 4 ceros + 'tado'
```
Arreglado con: helper `pon()` (exige mismo tamano), 'Estado' movido a **$17AC0**
(porque 'Dinero' ocupa 14 B desde $17AA0 y los pisaba) y el puntero a $27AC0.
**Medido**: la fila 5 pasa de **87 px a 66 px** (igual que 'Equipo' y 'Hablar', sus
vecinas de 6 letras). Captura: `verificado_menu.png`.

### [HECHO] El boton correcto y el mapeo real de RetroArch
David usa teclado de MAC con M , . mapeados. **El mapeo por defecto de RetroArch para
Mega Drive es distinto del que yo suponia** (leido en `libretro/libretro.c`,
`osd_input_update_internal_bitmasks`):
```
  MD A = RetroPad Y      MD B = RetroPad B      MD C = RetroPad A
  MD X = RetroPad L      MD Y = RetroPad X      MD Z = RetroPad R
```
=> Para abrir el MENU PRINCIPAL hay que pulsar **MD A** (RetroPad Y, id 1).
Escrito en `pruebas/md_btn.py` para no volver a liarme.

### Estado de TEST_I (md5 1d5cbefb8953fd254120264a0bf43522)
- Titulo: CARGAR PARTIDA / CON INTRO / SIN INTRO, 8 px, caja 128 px centrada,
  margenes 8-9 px.
- Menu: "Estado" alineado y con el ancho correcto; "Dinero" en la etiqueta.
- Fuente: glifos latinos a la izquierda de la celda (78 en INIT + 78 en OPEN).
- **Pendiente**: (1) el dinero con formato `Dinero: NNNNNNN HK$` (necesita el glifo
  `$` que David va a anadir a su PNG, y sitio: 22 glifos x 12 px = 264 px > 240 de
  la caja, o se ensancha la caja o se resuelve el paso mixto);
  (2) la ventana del dinero debe acabar donde empieza el HUD marron (x=201).

Herramienta nueva: `TEST_J.state` (generado por mi, con el menu abierto y "Estado"
ya corregido) para que David lo vea sin depender del .bin.

## 2026-09-20 (31ª tanda) — MAPA COMPLETO del motor de texto (y lo que falta)

### [HECHO] El juego NO usa SSTART para los menus: usa START.BIN
Comparado bloque a bloque contra la PRG-RAM del state:
```
START.BIN  entero -> PRG-RAM desde $10000   (todo coincide)
SSTART.BIN -> NO esta cargado (solo trozos sueltos en $175A4, $182FC)
```
=> **El interprete y el pintor de texto que usa el juego son los de START.BIN**,
   cargado en la PRG-RAM en $10000. Mi error de estos dias: estaba parcheando el
   pintor de SSTART ($242A), que NO es el que dibuja los menus del juego.

### [MEDIDO] La instruccion del avance del juego es START file 0x8B54 (RAM $18B54)
Cambiandola a `addq.w #$2` (8 px) **el texto del menu ENCOGE de verdad**:
```
  fila 'Objetos': 78 px -> 54 px     (medido en el emulador)
  fila 'Sistema': 78 px -> 54 px
```
=> avance identificado y funcionando. Lo que falta es el paso MIXTO (letras 8 /
kanji 12), que necesita leer el caracter.

### CAMINO PARA EL PASO MIXTO (probado a medias, con el mapa claro)
El pintor de glifo de START esta en RAM **$18B18** y empieza con:
```
  18B18  movem.l d0-d5/a2-a4,-(a7)     (4 B)
  18B1C  bsr.w $191BE                  (4 B)
  ...
  18B54  addq.w #$3,$14(a0)            (4 B)  <- EL AVANCE
  18B58  bclr.b #$6,$a75d.l            (8 B)
  18B60  rts                           (2 B)
```
**El bloque que se puede sustituir es de 14 bytes (avance+bclr+rts)**: la rutina
nueva ya termina con bclr+rts, asi que hay que escribir los 14 bytes ENTEROS.
**ERROR PROPIO (cuarta vez del mismo tipo)**: escribir solo 12 B pisa el bclr y
**el menu sale VACIO**. Comprobado y corregido.

**Lo que NO he conseguido**: interceptar el caracter. Buscado sin exito:
- `bsr.w $18B18` en START: solo 3 sitios ($1840E, $18A80, $18AEE) y NINGUNO se
  ejecuta al abrir el menu (parcheados los tres, la variable no se escribe).
- `bsr.b`, `jsr $18B18`, `lea $18B18`, puntero long o word en tablas: **no existe**
  ninguna referencia a $18B18 en el fichero (la unica que aparece es la que yo
  escribi). => **la rutina de glifo se alcanza por una direccion calculada**
  (saltos por tabla o codigo en RAM), no por una llamada estatica.
- Parchear el `bsr.w $191BE` interno de la rutina ($18B1C) tampoco: rompe el flujo.

### Siguiente paso concreto (no adivinando)
Anadir al trazador del emulador la lectura del OPCODE desde la PRG-RAM para el
sub-procesador (hoy `peek16()` lee el cartucho de MD, que esta vacio, y por eso el
analisis de flujo no ve nada util). Con eso, el registro EV_CALL dara el sitio exacto
desde el que se llama a $18B18 y ahi se engancha la captura del caracter.

### Fuente y simbolos (informacion de David)
- David anadira al PNG: `+`, tilde de Ñ mas grande, corchetes y alguno mas.
- El **simbolo de porcentaje** del juego NO usa el de su fuente (fila 1, col 16 del
  PNG); sale el de la fuente japonesa.
- Los simbolos a revisar se ven en **Estado/Char -> Tianren o Meifan** (su ficha).
- El corazon del PNG: David lo sustituira por `$`.

### Entregado en esta tanda
- **TEST_I.bin** MD5 `1d5cbefb8953fd254120264a0bf43522`: titulo en 8 px, MAYUSCULAS,
  caja 128 px centrada, margenes 8-9 px; "Estado" corregido (66 px, alineado);
  "Dinero" en la etiqueta. **Jugable** (el texto del juego sigue a 12 px).
- **TEST_J.state**: state de David con el menu abierto y "Estado" ya corregido.
- Herramientas: `pruebas/md_btn.py` (mapeo de botones), `md.load_rzip`/`save_rzip`/
  `poke_prg`, `recursos/tools/build_test_k.py` (paso mixto, NO funcional aun).
- El core del emulador ya instrumenta el **sub-procesador** y atribuye bien el PC.

## 2026-09-20 (32ª tanda) — TRAZADOR ARREGLADO: mapa exacto del motor de texto

### [HECHO] El trazador no veia las llamadas porque peek16 leia el CARTOCHO
`peek16()` (el que lee las instrucciones para el analisis de flujo) leia `cart.rom`,
que en un juego de CD **esta vacio**. Ademas el analisis de flujo **solo corria en el
procesador principal**, y el juego corre en el sub-procesador.
Arreglado en el core (fuentes en `emu/arena_dbg_mcd.c`):
1. `peek16` lee ahora **PRG-RAM** ($0-$7FFFF) y **Word RAM** ($80000-$BFFFF, modos 2M/1M).
2. El analisis de flujo se extrajo a `flow_analysis()` y lo llaman **los dos** procesadores
   (desde `arena_exec_sub`, el gancho del sub-CPU).

### [MEDIDO] Con el trazador arreglado: QUIEN llama al pintor de texto
```
PINTOR de glifos = START file 0x8B18 (RAM $18B18)
  llamado desde $1840E  (40 veces al abrir el menu)
  llamado desde $18A80  (16 veces)
ESTRUCTURA del pintor (desensamblado en memoria):
  18B18  movem.l d0-d5/a2-a4,-(a7)
  18B1C  bsr.w $191BE
  ...
  18B52  jsr (a3)                 <- pinta el glifo (a3 sale de una tabla en $18B66)
  18B54  addq.w #$3,$14(a0)       <- EL AVANCE  (bloque de 18 B hasta $18B65)
  18B58  bclr.b #$6,$a75d.l
  18B60  movem.l (a7)+,d0-d5/a2-a4
  18B64  rts
  18B66  tabla de 4 punteros (NO se puede tocar)
INTERPRETE: la llamada en $1840E va seguida de `bra.w $18392` (el bucle) y el
epilogo del interprete esta en $18416 (`movem + rts`) -> NO se puede pisar.
```

### [FUNCIONA] La captura del caracter
Poniendo en $1840E un `jsr CAP` (CAP = `move.w d0,VAR` + `jsr $18B18` + `jmp $18392`)
la variable VAR recibe **caracteres reales** ($826C, etc.) => el caracter SI esta en
d0 en ese punto y la captura funciona.

### Lo que sigue rompiendo (y por que)
- `bsr.w` solo alcanza **+-32 KB**: medido que **no hay NI UN byte libre** en ese radio
  dentro de la PRG-RAM, asi que la rutina auxiliar no puede ir cerca.
- Parchear mas de 4 bytes en $1840E **pisa el `bra.w $18392` o el epilogo ($18416)** y
  el interprete no puede volver -> menu vacio.
- El avance ($18B54) tiene un bloque de **18 bytes exactos** (addq+bclr+movem+rts): hay
  que reproducir el `movem.l (a7)+,d0-d5/a2-a4` o **la pila queda desequilibrada**.
  (Error propio: lo omiti y el menu salia roto.)

### Plan para la siguiente tanda (concreto)
Usar el hueco de 2 bytes + la estructura para meter la captura **sin ampliar el parche**:
  - `$1840E`: `jsr CAP` (6 B) sustituyendo el `bsr` (4 B) **y** los 2 primeros bytes del
    `bra.w` -> 6 B justos; el `jmp $18392` final de CAP sustituye al `bra`.
  - CAP debe ser >= 6+6+6 = 18 B y estar al alcance **solo si se usa jsr** (que alcanza
    los 16 MB, no +-32 KB) => puede ir en el hueco libre medido ($279A2 o $27AC4+).
  - OJO: el hueco debe ser libre **en el fichero** (no solo en memoria): en el fichero
    los libres son $27AC4-$27F8B y $279A2 solo lo esta en marcha.
Tools: `recursos/tools/paso_mixto.py` (implementa todo esto; la captura ya funciona,
queda ajustar los bytes del parche de llamada).

## 2026-09-20 (33ª tanda) — titulo nuevo, fuente nueva y márgenes medidos

### Fuente nueva de David (Fuente Illusion City.png)
```
128x56 px = 16x7 celdas de 8x8   (antes 16x6)
fila 0: . , : ; ! ¿ ¡ ? ( ) [ ] « » " %
fila 1: 0-9 A-F      fila 2: G-U      fila 3: V-k      fila 4: l-z
fila 5: Á É Í Ó Ú Ü á é í ó ú ü ~ — + -
fila 6: $ + 4 SIMBOLOS NUEVOS (de referencia: ◊ ÷ # ∆; en realidad son disenos
        originales para decorar los titulos de seccion del menu, de momento van
        con corchetes [Tecnica] y no le gustan)
Anchos de tinta medidos: 3-7 px (ninguno ocupa los 8) -> con celdas de 8 px y el
glifo a la izquierda la separacion sale de 1 a 3 px. Confirmado otra vez.
```
`fuente_8px.py` ya lee esta fuente (101 glifos).

### Titulo nuevo (TEST_M): medido en el emulador
```
CARGAR PARTIDA / PARTIDA NUEVA / NUEVA SIN INTRO
caja   x=64..191  (127 px)  centro 127.5  -> CENTRADA
texto  x=69..186  (118 px)               -> CABE (la caja es de 127)
margenes: 5 px a la izquierda y 5 a la derecha
lineas de texto: y=115-121, 127-133, 139-145
MD5 52598bca1b6689706e2543bcfb6d596d
```
**El misterio de los margenes resuelto**: el texto arranca **8 px (una celda) dentro
de la caja**; el campo $32 (sangria) resta de ahi. Con $32=2 (valor que tenia) los
margenes salian 9/9; con $32=1 salen **5/5**. El texto no esta centrado en la caja
(5 y 5 con 118 px de texto en 127 de caja: 5+118+5 = 128, cuadra).
=> David tenia razon: "antes y despues de cada opcion hay una celda vacia".

### Fuente japonesa: cuanto ocupa (respuesta a David)
```
INIT.BIN: tabla de glifos en 0x4ED0, 3753 celdas x 18 B = 66 KB
OPEN.BIN: tabla de glifos en 0xA710,  810 celdas x 18 B = 14 KB
(1 celda = 12x12 bits = 18 B; en 8x8 serian 8 B -> menos de la mitad)
```
**Aviso importante**: la tabla de glifos NO se puede borrar aunque se traduzca todo,
porque **los menus y los dialogos usan los mismos codigos** (los kanji japoneses
tienen codigo propio). Lo que SI se puede hacer es reducirla a 8x8: ahorro medido
de ~80 KB entre INIT y OPEN. Es un cambio de fondo (afecta al pintor de todos los
textos) y hay que hacerlo con cuidado.

## 2026-09-20 (34ª tanda) — PASO MIXTO: el parche YA no rompe el juego

### [HECHO] Estrategia de prueba: el estado y los parches en memoria NO sirven
Descubrimiento clave de esta tanda:
1. **El savestate restaura la PRG-RAM entera** (los ficheros del juego ya cargados),
   asi que al cargarlo mis cambios del .bin NO entran.
2. **Al abrir el menu el juego RECARGA sus datos desde el CD** (medido: el menu sale
   mal con parches en memoria y bien sin ellos, en el mismo state).
3. => **La unica prueba valida es: fichero + arrancar desde cero.**
   El trazador sirve para localizar; para VER hay que jugar desde el principio.

### [RESUELTO] El cuelgue era la PILA
La llamada entra con `jsr`, que deja una **direccion de retorno en la pila**. Al salir
con `jmp` sin descartarla, la pila **crece 4 B por caracter** y el juego se cuelga
(se veia el logo de Microcabin y de ahi no pasaba).
Arreglo: **`addq.l #4,a7`** antes del salto final (descarta lo que apilo el jsr).
Con eso **TEST_N arranca, se ve la intro y el titulo traducido**.

### Estructura final del parche (TEST_N)
```
VAR      = $090E48   (hueco constante de la Word RAM)
CAP1     = $2513C    move.w d0,VAR ; jsr $18B18 ; addq.l #4,a7 ; jmp $18392
CAP2     = $25150    idem + move.w $8(a0),d0 ; jmp $18A88
RUT      = $25170    8 px (letras/acentos) o 12 px (kanji, cifras, etc.)
LLAMADA1 = file 0x840E   bsr.w -> jmp  (6 B, no se toca el epilogo $18416)
LLAMADA2 = file 0x8A80   bsr.w -> jmp
AVANCE   = file 0x8B54   bloque de 18 B exactos (addq/bclr/movem/rts)
MD5 8054ff7178d88a5504cc381c4d1440e7
```

### PENDIENTE (para la siguiente tanda)
- Confirmar en el MENU PRINCIPAL que las letras salen a 8 px y los kanji a 12.
- **Dato importante de David**: la fuente japonesa NO se puede reducir a 8x8, porque
  los kanji ya estan ajustados a las celdas de 12x12. => el paso mixto es obligatorio,
  no hay atajo por el lado de la fuente.
- **Selector azul del menu**: en cada menu hay uno y todos necesitan reajuste (David
  lo deja para mas adelante). Captura de referencia: suya de 260919-234733.png.
- **Logo Microcabin/TM de abajo a la izquierda**: David quiere editarlo (se ve a mala
  resolucion y parece cortado por arriba). Habria que extraerlo del .bin o de una
  captura a resolucion original. No corre prisa.

### [HECHO] Estado final de TEST_N (35ª tanda)
```
MD5 8054ff7178d88a5504cc381c4d1440e7
Arranca desde cero, se ve la intro, se llega al TITULO:
  caja x=64..191 (127 px, centro 127.5)  -> centrada
  texto x=69..186 (118 px), margenes 5 / 5
  tres lineas: CARGAR PARTIDA / PARTIDA NUEVA / NUEVA SIN INTRO
El paso mixto (8 px letras / 12 px kanji) esta aplicado en el pintor de START.
```
**Aviso para David**: al arrancar el juego **recarga sus datos del CD**, asi que los
cambios de texto se ven SIEMPRE al empezar de cero; cargando un savestate se ven los
textos viejos (el state guarda la memoria del juego).

## 2026-09-20 (36ª tanda) — paso mixto v2 (sin memoria): MEJOR ESTRUCTURA, resultado pendiente

### Causa del fallo de TEST_N anterior (David: "ninguna opcion funciona, negro")
Medido: **el juego ESCRIBE en la direccion que yo usaba como variable** ($090E48,
2 escrituras). Mi "hueco libre" no era libre: corrompia datos del juego -> negro.
**Leccion: en la Word RAM no se puede dar por libre un sitio solo porque al mirarlo
tenga ceros; hay que vigilarlo con el trazador mientras el juego corre.**

### paso_mixto v2: SIN MEMORIA (solo registros y pila)
El truco: el pintor de glifos **preserva d0** (su `movem.l d0-d5/a2-a4,-(a7)` lo
salva). Asi que se puede:
```
  push d0                        (guardo el caracter)
  jsr  $18B18                    (dibuja y avanza 12 px)
  pop  d0                        (recupero el caracter)
  ¿es letra o acento? -> si SI: subq.w #1,$14(a0)   (12 -> 8 px)
  jmp  vuelta
```
Ventajas: no toca memoria, no toca el avance ($18B54), la pila queda igual.
Verificado: los saltos de la rutina generada son correctos (comprobados uno a uno).
```
CAP1 = $2513C (124 B)   CAP2 = $251C0 (132 B)    (CAP2 va aparte porque CAP1 es largo)
LLAMADA1 = file 0x840E  -> jmp CAP1
LLAMADA2 = file 0x8A80  -> jmp CAP2
```

### ERROR PROPIO GRAVE de esta tanda
Ejecute `paso_mixto.py <cast.bin> TEST_N.bin` **sobre el .bin de trabajo en vez de
sobre la base traducida**, y eso **borro los textos traducidos** del binario (el
titulo salia en japones). Rehecho desde `build_test_i.py`.
**Regla: la base se genera SIEMPRE con build_test_i.py y se comprueba con un
verificador de textos antes de entregar.**

### Estado de la entrega
```
TEST_L.bin  MD5 2f081b665c2143bdfa5f375008fa08e8   <- titulo nuevo, SIN paso mixto (referencia buena)
TEST_N.bin  MD5 43226f06f44289f007ceaec8e22a6a8c   <- + paso mixto v2 (sin memoria)
Textos verificados en los DOS: Estado/Dinero en $17AC0/$17AA0 y titulo CARGAR PARTIDA
PARTIDA NUEVA / NUEVA SIN INTRO.
```
**PENDIENTE DE PRUEBA**: si TEST_N deja arrancar la partida (el fallo anterior era
justo al empezar). **Si TEST_N tampoco va, la entrega buena es TEST_L** (que es
TEST_I + titulo nuevo y ya sabemos que el titulo se ve bien).

### CORRECCION del verificador (esta misma tanda)
El verificador daba Estado/Dinero como "NO" porque comparaba 8 bytes contra un texto
de 12 (6 glifos x 2 B). Los textos **si estan** en $17AC0 y $17AA0 en TEST_L y TEST_N
(comprobado byte a byte). Leccion: el verificador tambien se equivoca.

### Entrega final de la tanda
```
TEST_L.bin  MD5 2f081b665c2143bdfa5f375008fa08e8
   titulo nuevo (3 opciones) + margenes 5 px + fuente nueva (glifos a la izquierda)
   SIN paso mixto en el texto del juego  -> jugable, ya probado por David
TEST_N.bin  MD5 43226f06f44289f007ceaec8e22a6a8c
   = TEST_L + paso mixto v2 (SIN memoria: el caracter viaja en la pila)
   arranca y muestra el titulo; FALTA comprobar que deja empezar partida
TEST_J.state  state de David con el menu abierto ("Estado" corregido)
```

## 2026-09-20 (37ª tanda) — PASO MIXTO FUNCIONANDO (verificado en el emulador)

### [RESUELTO] Los dos fallos de la version anterior (v2 del parche)
1. **Purga de pila innecesaria**: al entrar en la rutina con `jmp` (que NO apila)
   y llamar dentro al pintor con `jsr` (cuyo retorno consume su propio `rts`), un
   `addq.l #4,a7` extra dejaba la pila **4 bytes corta** y el flujo se rompia:
   el menu no abria. Quitada la purga -> funciona.
   (Antes si hacia falta, porque se entraba con `jsr`. Al cambiar a `jmp`, sobraba.)
2. **d1 y a3 no se preservaban**: el juego los usa y mi rutina los machacaba.
   Ahora la rutina salva/restaura d1 y a3 (8 bytes mas) en los dos caminos.

### [MEDIDO] El menu con el paso mixto
```
                        SIN parche   CON paso mixto
  Magia                     54            38
  Objetos                   78            54
  Equipo                    66            46
  Hablar                   104           104      <- KANJI: intacto
  Estado                   104            80
  Sistema                   78            54
```
Las palabras latinas encogen ~30% y **los kanji no se tocan** (104 -> 104): que era
exactamente el objetivo. El "Dinero" y sus cifras no cambian (las cifras siguen a
12 px a proposito).

### [MEDIDO] El juego sigue jugable con el parche
Desde el savestate de David (con el parche aplicado en memoria):
```
  caminar      14148 px cambian  (responde)
  hablar (1)   10487 px cambian  (responde)
```
Y la comparacion TEST_L vs TEST_N en el titulo y en el juego da IDENTICOS resultados
en pantalla, o sea que el parche no altera nada mas que el ancho de las letras.

### Estructura final (paso_mixto.py)
```
CAP1 $2513C (120 B) / CAP2 $251C0 (128 B)
  move.l d1,-(a7) / move.l a3,-(a7)
  jsr $18B18
  si es letra (8260-8279 / 8281-829A) o acento -> subq.w #1,$14(a0)
  move.l (a7)+,a3 / move.l (a7)+,d1
  [move.w $8(a0),d0  en CAP2]
  jmp <vuelta>
LLAMADA1 = file 0x840E -> jmp CAP1     (sustituye el bsr.w; el bra.w de detras se
LLAMADA2 = file 0x8A80 -> jmp CAP2      conserva y no se ejecuta)
```
**Sin variables de memoria** (la version con variable corrompia datos del juego).

### Entrega
```
TEST_L.bin  MD5 2f081b665c2143bdfa5f375008fa08e8   titulo nuevo, sin paso mixto
TEST_N.bin  MD5 9d6485611ed04a5fa36e46253401bcf5   + PASO MIXTO (este es el bueno)
TEST_J.state  state de David con el menu abierto
verificado_menu_mixto.png  captura del menu con el paso mixto aplicado
```
PENDIENTE: que David confirme en su emulador que la partida nueva arranca (mi arnes
no consigue elegir la opcion del titulo; el titulo no responde a mis pulsaciones,
pero el juego SI responde desde el savestate).

## 2026-09-20 (38ª tanda) — DIGITOS de la fuente de David en el juego (localizados)

### [HALLAZGO] La tabla de glifos es ASCII, no fullwidth
Dibujada la tabla (`tabla_fuente.png`): la zona de simbolos y letras esta en
**ASCII continuo**:
```
  & 0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R S T U V
  W X Y Z a b c d e f g h i j k l m n o p q r s t u v w x y z ...
  fila de simbolos: + - ( ) [ ] < > = ...
```
Cada caracter = UNA celda (codigo = celda; rel = codigo - 0x2900 aprox.).

### [MEDIDO] Donde esta cada cosa de la linea del dinero (son DOS zonas)
Marca de "celda entera encendida" celda a celda:
```
  rel -2235, -2232, -2231 (x=56..104) -> la ETIQUETA "Dinero"   <- a 12 px en pantalla
  rel -2242, -2236 (x=118, 140)       -> LOS DIGITOS            <- a 8 px en pantalla
```
**Los digitos del dinero YA van a 8 px y su ancho de tinta es 5 px** (paso medido 8).
La etiqueta va a 12 px porque **la caja del dinero usa el mismo descriptor que el
menu de Velocidad** ($A423A), que quedo excluido del parche para no romper la
alineacion de las flechas de ese menu. **Eso explica exactamente lo que ve David.**

### [PENDIENTE] Separar las dos cosas
Hipotesis a comprobar: el pintor de la tienda y del menu usan el MISMO descriptor
($A423A), asi que la exclusion (necesaria para el menu de Velocidad) deja la etiqueta
del dinero a 12 px. Hay que ver:
  1. si el menu de Velocidad usa otro descriptor distinto (entonces la exclusion se
     puede quitar y la etiqueta encogera),
  2. o si el propio $A423A se puede estrechar distinguiendo por otro campo (p.ej. $2e).
Verificacion rapida: mirar en el state que campo tiene el descriptor $A423A cuando
se esta en el menu de Velocidad y cuando se esta en el juego.

### State nuevo de David (maquina de guardado)
`states/TEST_L.state` carga: deja a Shion en la **sala de guardado** con el panel
abierto y el selector sobre SAVE (`verificado_state_guardado.png`). Sirve para
llegar al juego sin states y para probar submenus desde ahi.

### Entrega de la tanda
```
TEST_L.bin  MD5 2f081b665c2143bdfa5f375008fa08e8   titulo nuevo, sin paso mixto
TEST_N.bin  MD5 d279eaf43943102cddb66a07d0124e7d   + paso mixto (letras Y digitos a 8 px)
              - los digitos del dinero son los de David y van a 8 px (medido)
              - el menu de Velocidad sigue a 12 px (descriptor $A423A excluido)
              - la etiqueta del dinero va a 12 px (mismo descriptor; pendiente)
verificado_menu_digitos.png / verificado_dinero_david.png / verificado_state_guardado.png
```

## 2026-09-20 (39ª tanda) — LIMPIEZA del workspace

```
antes:  118,3 MB / 847 ficheros
ahora:   67,2 MB / 771 ficheros
```
**Lo que se ha borrado y por que:**
- **36 MB en copias duplicadas**: `pruebas/TEST_L.bin` y `pruebas/TEST_N.bin` eran
  copias de los de arriba (los `.cue` apuntan a `../TEST_*.bin`, asi que sobraban).
- **18 MB**: `TEST_L.bin` en la raiz. Es regenerable en un comando y **TEST_N lleva
  todo lo suyo mas el paso mixto**. Cadena de regeneracion (comprobada):
  `cast.bin --build_test_i.py--> TEST_L --paso_mixto.py--> TEST_N`
- `.cache`, `.npm`, `__pycache__`, `*.pyc`.
- Capturas intermedias de las pruebas (22 PNG) y scripts de un solo uso.
- `recursos/tools/build_test_k.py`: **la version NO funcional** del paso mixto
  (tenia el fallo de la pila). Se queda solo la buena (`paso_mixto.py`).
- `tabla_fuente.png`, `zoom_*.png` de la raiz.

**Lo que NO se ha tocado** (y por que):
- `[CAST].bin` (18 MB): es la base de trabajo de la que salen todos los builds.
- `TEST_N.bin` (18 MB): el build bueno actual.
- `emu/bin/*.so` (6,2 MB) + `emu/*.c` + `RECETA.md`: el banco de pruebas.
- `Illusion City/bios/` (384 KB): las BIOS.
- `recursos/analisis/` (2,4 MB): ficheros extraidos para el analisis.
- Los otros proyectos (Momotaro, Nekketsu, Wonder Boy, Double Dragon 2): intactos.
- Los zips y binarios de la entrega v1.4 del Wonder Boy: verificados tras la limpieza.

**Herramienta nueva**: `pruebas/LEEME.md` explica el banco de pruebas (que hace cada
fichero, como cargar un state y como medir una captura).

## 2026-09-20 (40ª tanda) — dinero: etiqueta + digitos + HK$ (el $ queda pendiente)

### [HECHO] Lo que funciona (medido en el emulador)
```
  linea: "Dinero:" + 7 cifras + "HK$"     x=40..211 (172 px)  | borde caja x=222
  etiqueta y digitos: fuente de David a 8 px
  la caja del DINERO la pinta el descriptor $A42AE (X=7, Y=17, ancho 20)
    -> NO es el descriptor de Velocidad: la exclusion se puede volver a poner
       para proteger el menu de Velocidad sin afectar al dinero
```

### [HALLAZGO] El espacio inicial de la cadena de la moneda rompe el dibujo
La cadena de la moneda se copia con `$20862` (NO con `$20852`, que es la de los
textos). Medido: si la cadena EMPIEZA por espacio, el pintor deja de dibujar los
DOS caracteres siguientes. Por eso `" HK$"` mostraba solo `HK` y `"HK$"` muestra
`HK$` completo. **La cadena no puede empezar con espacio.**

### [PENDIENTE] El glifo del `$` no se puede sustituir (aun)
```
  El $ del juego esta dibujado en x=205..216. Siguiendo las LECTURAS del pintor:
    $2987A..$29891 -> un glifo (24 B)
    $29892..$298A9 -> otro glifo (24 B)   <- escribir ahi cambia la zona del H/$
  pero escribir el glifo de David en $2988B / $29892 no cambia el dibujo.
  Tampoco aparece el patron del $ en PRG, WORD ni WORD2M en el momento de pintarlo.
  => el $ del juego NO se dibuja desde una tabla de fuente en memoria:
     o viene de un grafico pre-renderizado (tile) o de una fuente comprimida.
  Formato confirmado de los glifos de esa zona: 12 filas x 16 bits = 24 B.
```
**Alternativa mientras**: dejar el `H$` del juego (es el que se ve ahora) o
sustituir la moneda por texto que si este en la fuente.

### Herramientas nuevas
`recursos/tools/dinero_formato.py`: pone la etiqueta con dos puntos y la moneda
`HK$`, y redirige los 4 sitios que cargan la cadena de la moneda.

## 2026-09-26 (41ª tanda) — MENÚ DE VELOCIDAD: números 1-8 en 12 px + el dinero con «HK$»

### [HECHO] De dónde salen los textos del menú (esto cambia la forma de probar)
- El juego **no recarga START.BIN al abrir el menú**: los textos del menú (plantilla
  de Velocidad, etiqueta del dinero, filas del menú) están en la PRG-RAM, y el
  savestate guarda la PRG-RAM entera. **Con un savestate se ven los textos del build
  con el que se grabó**, no los del build nuevo.
- Lo que SÍ se recarga del CD al abrir el menú son las **fuentes** (INIT): medido,
  la tabla de fuente viva == la del INIT del build (sólo difería la celda 49, que el
  juego pisa en tiempo de ejecución).
- Por eso las capturas de David enseñaban su fuente nueva pero palabras viejas
  («Mensaje»/«Moverse»). **Para ver textos nuevos: partida nueva o state nuevo.**
- `pruebas/refresca.py` (y luego `prepara_entrega.py`) mete el START.BIN del build en
  la PRG-RAM del savestate: eso equivale a un arranque limpio para los textos.

### [HECHO] El menú de Velocidad se pinta desde un BUFFER, no desde la plantilla
Espía de a0/a2/código por carácter (el descriptor que llega al pintor es **$A4200**,
el mismo que el menú principal):
```
  menú principal (filas)  a2 = $23D60, $27740 … (las cadenas)   llamada 1
  línea del DINERO        a2 = $00BB24 (buffer del dinero)      llamada 2
  menú de VELOCIDAD       a2 = $01577E (buffer de línea)        llamada 2  <-- 67 chars
```
El motor copia cada línea a un buffer fijo ($1577E, y $1576E/$1578E/$1579E para otras
pantallas) y pinta desde ahí. **Ese puntero (a2) es el discriminador bueno** — el
descriptor y el campo $2e no lo eran.

### [HECHO] Regla nueva del paso mixto (v2) — `paso_mixto.py` reescrito
```
  si a2 está en $15750..$157C0 (menú de Velocidad):
        espacio ($8140) y dígitos ($824F-$8258) -> 12 px  (no se encogen)
        lo demás -> regla normal
  regla normal: letras/signos y los 16 códigos de acento -> 8 px; kana/kanji -> 12 px
```
Resultado medido (captura `capturas_tanda/menu_velocidad.png`), contra la referencia
del build viejo (todo 12 px):
```
                    referencia (12 px)      build nuevo (8/12 px)
  título            25,37,51,…    (12 px)   25,33,43,…     (8 px)
  «Rápido»          x=73          (12 px)   x=97           (8 px)
  hueco             x=143..157    (12 px)   x=143..157     <-- IDÉNTICO
  dígitos           111,122,134,146,…       111,122,134,146,…  <-- IDÉNTICO
  flechas (motor)   x=146..153              x=146..153
```
=> la fila de números cae en la rejilla del motor (el «4» bajo la flecha) y el hueco
entre «Rápido» y «Lento» queda bajo esa misma flecha, como pidió David.
«Mensajes», «Movimiento» y «Batalla» caben a 8 px (a 12 px se salían y se perdía
«Batalla»).

### [HALLAZGO] La moneda: la celda de la «K» y el código de la «K»
- La moneda japonesa original es **«Ｈ＄»** (códigos fullwidth, en $21882), no ASCII.
- Con ASCII («HK$») el pintor cae en celdas **sin glifo** -> salía basura apilada.
  Por eso la «K» nunca aparecía por más que se buscase su celda: estábamos mirando
  la tabla equivocada.
- **En la fuente de este juego el código de la K está desplazado**: medido código a
  código (0x8267=H, 0x8268=I, 0x8269=J, **0x826A=K**, 0x826B=L, 0x826C=M…).
- Celdas medidas por barrido (tinta que cambia al machacar la celda con un bloque):
  `Ｈ` -> rel −755, `Ｋ` -> rel −751, `＄` -> rel −775, `０` -> rel −772.
- Moneda nueva = `8140 8267 826A 8190` (« ＨＫ＄», con el espacio delante) — y SÍ
  conserva los tres caracteres (a diferencia del ASCII, que además se comía el «$»).

### Entrega de la tanda
```
TEST_O.bin  MD5 cc868a792f3fdb29cde09c156f72ce7f   (cadenas: build_test_i -> dinero_formato
                                                    -> fuente_dinero -> paso_mixto v2)
states/TEST_O_menu.state        menú abierto: «Dinero: 0000140 HK$»
states/TEST_O_velocidad.state   menú de Velocidad con los números a 12 px
capturas_tanda/menu_dinero.png  /  capturas_tanda/menu_velocidad.png
```
Los dos states llevan la PRG-RAM del build nuevo dentro: David puede cargarlos
directamente en RetroArch (con TEST_O.bin) y ver lo mismo que las capturas.

### Herramientas nuevas (en `pruebas/`)
- `nav3.py` — navegación **medida**: el cursor del menú está en `$A422C` y el puntero
  de texto en `$A4222`; con DOWN corto (hold 3) avanza UNA fila (con hold 12 avanzaba
  dos). **MD C confirma** (el A sólo abre/cierra el menú).
- `refresca.py` — mete el START.BIN del build en la PRG-RAM del savestate (lo que hace
  un arranque limpio para los textos). **Es la clave para probar builds nuevos.**
- `mapa_tabla2.py` — barrido de celdas de fuente marcándolas con bloques sólidos: dice
  qué celda dibuja cada trozo de pantalla (el método para encontrar la «K» y el «$»).
- Para medir sin equivocarse: quitar las columnas de BORDE de la caja antes de buscar
  tinta (si no, el marco cuenta como tinta en todas las filas y todo se mezcla).

### ERRORES PROPIOS de esta tanda
- Discriminar el menú de Velocidad por el descriptor ($A423A) y por $2e fue un
  callejón: el descriptor es compartido y $2e es un valor de memoria que cambia.
  La solución buena salió de **medir a2** con el espía.
- Perdí horas midiendo «runas» de tinta en capturas con la ventana de barrido
  mal puesta (x0=59 recortaba justo donde empezaba el texto y el marco contaba como
  tinta). Ahora `pruebas/mide2.py` quita las columnas de borde automáticamente.

### PENDIENTE (lo que queda de la lista de David)
1. **Menú de Equipo «rotísimo»**: con TEST_O sigue mezclando texto traducido con
   kanji del juego y los valores salen como «6$0S» — mismo tipo de fallo que la
   moneda (códigos/celdas). Necesita su tanda.
2. Números de Coste desalineados (mismo origen probable).
3. Recuadro selector azul de cada menú.
4. Corchetes `[Técnica]` y los cuatro símbolos nuevos de las secciones.
5. Logo Microcabin/TM de la pantalla de título.
6. Diálogos (A00.BIN y compañía, aún en japonés).
7. Menú de 2 filas previo al de Velocidad («スピード» / «スイツチ») sigue en japonés.

## 2026-09-26 (42ª tanda) — TEST_P: menú de Velocidad arreglado en LAS DOS vías

### [HECHO] El fallo de David (1): el menú se descuadra si pasas por el menú スイッチ
Medido con el espía (a2 por carácter): el menú de Velocidad **no se pinta siempre desde
el mismo sitio**:
```
  1ª vez (recién entrado)      a2 = $01577E   (buffer de línea del motor)
  al volver a entrar           a2 = $0244B2   (copia de trabajo de la plantilla)
  menú スイッチ (Switch)       a2 = $02766B / $027686 / $0276A5  (sus cadenas)
```
La regla v2 solo contemplaba la primera → al volver, los espacios y los dígitos se
encogían a 8 px y el menú se descuadraba (exactamente lo que ve David). **Arreglado**
añadiendo el segundo rango ($24490-$24570) a la comprobación.

### ERROR PROPIO (y cómo se cazó)
La primera versión del arreglo **no funcionaba**: al no caer en el primer rango, el
código saltaba directamente a la regla normal y **nunca miraba el segundo rango**.
Lo vi desensamblando mi propia rutina generada (`dis2.py` sobre los bytes de
`capto_mixto`), no en el emulador. Lección: desensamblar el código que uno genera
antes de dar por hecho que hace lo que uno cree.

### [HECHO] El fallo de David (2): el cursor de los recuadros flotantes
- Los recuadros con el bit 4 del campo $0 suman los globales **$a77a** y **$a77c** a
  la posición de su cursor (código en $203D8 y $2046C).
- El menú de Velocidad pone **$a77c = 48** al abrirse ($23A1A) y lo devuelve a 0 al
  cerrarse ($23A56)… **pero solo si sales con B o A**. Medido en el emulador:
```
  saliendo con   B      -> $a77c = 0   (bien)
  saliendo con   A      -> $a77c = 0   (bien)
  saliendo con START/X/Y/Z -> $a77c = 48  (¡se queda!)
```
- El popup «Efecto / Ind / Grupo» solo inicializa $a77a (12), no $a77c → hereda el 48
  y su cursor sale 48 px (4 filas) por debajo. **En las capturas de David el desfase
  medido es exactamente 48 px** (fila «Ind» en y=92, cursor en y=140).
- Es un **fallo del juego original**, no del paso mixto.
- El popup se abre pulsando **dos direcciones a la vez** (la condición es
  `$bd0e & $c0 == $c0` en el manejador de Magia, $21FC6).
- `recursos/tools/arregla_selectores.py` deja escrito el arreglo (envolver $2201C para
  que ponga $a77c = 0). **PENDIENTE DE VER EN PANTALLA**: no he conseguido llegar al
  popup con los estados que tengo (el flujo cae en diálogo). No se ha metido en TEST_P.

### Entrega de la tanda
```
TEST_P.bin  MD5 71f8ef67d84972c5e1c4df19f9af51a9   (solo el arreglo del menú de Velocidad)
states/TEST_P_menu.state        menú abierto: «Dinero: 0000140 HK$»
states/TEST_P_velocidad.state   menú de Velocidad TRAS pasar por el menú スイッチ
capturas_tanda/menu_velocidad.png  (verificado: «Rápido» x=97, dígitos 111/122/134/146)
```
Nota: los states llevan la PRG-RAM del build dentro; con un savestate viejo se siguen
viendo los textos y la rutina viejos.

### Receta del espía (para rehacerlo en 5 minutos)
En la PRG-RAM, en el hueco libre de START.BIN:
```
  $25300  bloque: movem/push d1,d2,a3 ; lea $25400,a3 ; move.l (a3),d1 ; contador
          ; cursor = $25408 + d1 ; guarda a2.l, x=$14(a0), y=$16(a0), d0, tag
          ; addq.l #8,#4 (12 B por entrada) ; move.l d1,$25400 ; pop
          ; + la rutina del paso mixto tal cual (para que la maquetación sea la real)
  $25200  el mismo bloque + la rutina (para la llamada 2)
  enganche: en 0x840E y 0x8A80, 4ef9 <$25300 o $25200>
```
Luego se lee con `md.prg8(0x25400, ...)`. Así se ve, por carácter: de qué cadena sale
(a2), en qué posición (x,y) y a qué llamada corresponde (tag 1 = $1840E, 2 = $18A80).

## 2026-09-26 (43ª tanda) — botones de salida (medido) + el selector del popup

### [HECHO] ¿Con qué botón se sale del menú de Velocidad? (medido uno a uno)
```
  B      -> $a77c vuelve a 0    (bien)
  A      -> $a77c vuelve a 0    (bien)
  C      -> $a77c se queda en 48   <-- el que usa David
  START  -> $a77c se queda en 48
  X / Y / Z -> $a77c se queda en 48
```
=> **David sale con C**, y con C no se resetea el desplazamiento. Eso explica que él
vea el cursor del popup desplazado y yo no lo viera (yo salía con B = pulsar el botón
que el arnés llama «B», que en un mando de MD es el B; en el mapeo del core: MD B =
RetroPad B(0), MD A = Y(1), MD C = A(8), MD X = L(10), MD Y = X(9), MD Z = R(11)).

### [HECHO] El desfase del cursor del popup son exactamente 48 px
Medido sobre las capturas de David (210130 / 210140):
```
  texto del popup:  «Efecto» y=83..89   «Ind» y=95..101   «Grupo» y=107..113
  recuadro azul  :  y=140..150 (sobre la nada)
  salto medido   :  48 px = 4 filas de 12 px = JUSTO el valor que se queda en $a77c
```
=> El popup suma `$a77c` (que vale 48) a la posición de su cursor. Arreglo escrito en
`recursos/tools/arregla_selectores.py`: envolver la rutina del popup ($2201C) para que
ponga `$a77c = 0` al entrar. **NO VERIFICADO EN PANTALLA** (ver abajo).

### [NO CONSEGUIDO] Reproducir el popup en el banco de pruebas
- El popup se abre con la condición `($bd0e & $c0) == $c0` en el manejador de Magia
  ($21FC6): es decir, **dos direcciones a la vez**.
- Con los estados que tengo (cuarto desde la cama / guardado por la máquina) llego a la
  pantalla de Magia (se ve «Magia de天人», PM/Coste, Ahora 10, Ind 2, Max 10, Grp 8),
  pero **la lista de hechizos no responde**: pulsando C, UP, DOWN, ni UP+DOWN a la vez
  se abre el popup. Forzar $bd0e en memoria (escribiéndolo cada frame) tampoco lo abre:
  el chequeo debe ocurrir en otro sitio, o falta un paso previo (¿elegir objetivo?, ¿un
  hechizo utilizable?).
- Con el juego ORIGINAL japonés inyectado en la PRG-RAM sí se navega, pero el menú no
  se abre desde estos estados (se queda en la habitación), así que tampoco sirve para
  comparar si el fallo está en el original o lo hemos introducido nosotros.

### PENDIENTE de esta tanda
Que David diga si quiere el arreglo del popup **a ciegas** (yo no lo he podido ver) o
prefiere darme un estado guardado justo EN esa pantalla para verificarlo primero.

## 2026-09-26 (44ª tanda) — TEST_Q: caja del menú al ras + arreglo del popup (a ciegas)

### [HECHO] El ancho de las cajas va de 12 en 12 y lo fija el campo $08 del descriptor
Barrido medido (escribiendo $08 en la PRECHA del build y repintando):
```
   $08   9 -> borde derecho x=134      $08  11 -> x=150     $08  13 -> x=166
   $08  10 -> x=142                    $08  12 -> x=158     $08  14 -> x=174 … x = 54 + 8*$08
   la caja del DINERO tiene el tope en $08=20 -> x=222; con 19 -> 217
```
Dónde está cada ancho en el código (medido, no deducido):
```
   MENU PRINCIPAL  $08 = $b (11)  -> START.BIN 0x119DE  (única instruccion `move.w #$b,$8(a0)`)
   DINERO          $08 = $14 (20) -> START.BIN 0x10B36  (la del pintor del dinero, $20AF0)
```
(la instruccion del MENU no está junto a su `lea $a4200`: la fija otro sitio del bloque
de $21996; se encontró buscando el patrón `317c 000b 0008` en todo el fichero).

### [MEDIDO] Márgenes (borde izquierdo del interior = x=49, texto a x=57 => 8 px fijos)
```
                                     antes        con la caja estrechada
  menú principal (texto acaba 110)   8 / 40       8 / 8     (con $08 = 7 -> borde x=118)
  dinero         (texto acaba 209)   8 / 13       8 / 18    (con $08 = 19 -> borde x=217)
```
=> El menú queda **exacto** (8/8). El dinero no: al quitarle la celda, el margen derecho
pasa de 13 a 18 px, **no a 8**.

### [HECHO] Por qué el dinero no puede quedar igual de al ras (tres cosas, todas medidas)
1. El ancho va de 12 en 12: borde en 222 (con 20) o en 217 (con 19); no hay valor
   intermedio, y la celda siguiente (226) ya se mete debajo del panel lateral.
2. La línea del dinero lleva **8 px de hueco escondido detrás de «Dinero:»**: el pintor
   ($20B10) copia la etiqueta y luego ejecuta `move.w #$8140,(a2)+` — un espacio fijo
   antes de las cifras. Probé a anularlo (`4e71 4e71` en 0x10B0E) y **la pantalla no
   cambia**: el espacio tiene que venir también de la propia etiqueta o el pintor lo
   rehace. (Comprobado con captura.)
3. El texto tiene que caber: «Dinero:» + 7 cifras + « ＨＫ＄» acaba en x=209 y el interior
   con $08=19 llega a 217. Si se quisiera el margen a 8 (borde en 216) habría que
   recortar texto, y eso no se hace.

### [HECHO] El arreglo del popup entra sin romper nada (repaso)
`arregla_selectores.py` envuelve la rutina del popup ($2201C) con 14 B en $15400 de
START.BIN: el `bsr.w` de 0x11FCA pasa a apuntar ahí y el trozo hace
`move.w #$0,$a77c.l` + `jmp $2201C` (mismo truco que el paso mixto: la pila cuadra sola).
Repaso con TEST_Q por todos los submenús (Magia, Objetos, Equipo, Hablar, Estado,
Velocidad ida y vuelta por スイッチ): **ninguno se rompe ni se queda en negro**.
**OJO: el arreglo NO está verificado en pantalla** (no consigo abrir el popup en el
banco de pruebas). David lo prueba.

### Entrega de la tanda (TEST_Q)
```
TEST_Q.bin  MD5 06b8ac67753150db03a6bc4f22f7f791
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto(v2)
      -> parche_cajas (menú $08=7) -> arregla_selectores
    EDC/ECC OK (verifica_bin) y 0 sectores con P/Q mal segun la referencia de Corlett
states/TEST_Q_menu.state        menú abierto: caja estrechada + «Dinero: 0000140 HK$»
states/TEST_Q_velocidad.state   menú de Velocidad tras pasar por スイッチ
capturas_tanda/menu_dinero.png  /  menu_velocidad.png  /  menu_switch.png
```
Herramienta nueva: `recursos/tools/parche_cajas.py` (ancho de las dos cajas, con las
comprobaciones de la instrucción).

## 2026-09-26 (45ª tanda) — TEST_R: caja del menú CORREGIDA, título y diagnóstico del diálogo

### [ERROR PROPIO] Mi medida de "margenes" mentia con el texto recortado
En la tanda anterior dije que el menú quedaba 8/8 con $08=7. Falso: la «a» de
«Sistema» salia cortada por el marco. La causa de que no lo viera: medía "tinta" en
una ventana que empezaba en x=52, y un glifo recortado tiene MENOS pixeles de tinta
pero más a la derecha de lo esperado; el marco (que sí queda dentro de la ventana)
contaba como texto. **Lo correcto es comparar píxeles de TEXTO contra una caja
abierta** (máscara: claro y que no sea el dorado del marco ni el azul del selector):
si algún pixel de texto cambia o desaparece, recorta.
```
   MENU:  $08= 7 (borde x=118) -> 93 px de texto distintos  RECORTA   <- lo que entregue
          $08= 8 (borde x=126) ->  0 px                   ok       <- lo correcto
   DINERO:$08=19 (borde x=214) -> 39 px de texto distintos  RECORTA
          $08=20 (borde x=222) ->  0 px                   ok       <- minimo real
```
=> el menú se queda en **$08=8** (margenes 8/8, sin recortes) y el **dinero ya estaba en
su mínimo**: con 19 el «＄» se corta. No se puede quitar esa celda sin recortar texto.

### [HECHO] Menu del TITULO: los cuatro campos y su barrido
Setup del título = SSTART 0x0A90. Campos (offset de fichero -> campo del descriptor):
```
   0x0AC7 $04  X de la caja      (41 + 8*$04)    0x0AD3 $08  ancho (8*$08 + 14)
   0x0AB5 $32  margen del texto (pasos de 4 px)  0x0AC1 $2e  trozos del selector (12 px cada uno)
```
El SELECTOR se dibuja con SPRITES desde SSTART $11D2C (palabra de control $0500): un
trozo inicial, ($2e - 3) trozos de 12 px y un cierre de 8 px.
Barrido medido (caja / texto / selector):
```
   $04=8 $08=16 $32=3 $2e= 9 -> caja 57..198 (centro 127.5) texto margenes 7/7  selector 116 px
   $04=9 $08=16 $32=3 $2e= 9 -> caja 65..206 (¡se sale por la derecha!)
   $04=9 $08=15 $32=0 $2e= 9 -> caja 65..198 (centro 131.5) texto margenes 8/8  selector 116 px
   $04=9 $08=15 $32=0 $2e=10 -> igual, con el selector de 128 px (cubre «NUEVA SIN INTRO»)
```

### [PENDIENTE, diagnosticado] El marco derecho del cuadro de DIALOGO
Medido sobre la captura de David: el marco SÍ está dibujado —
- líneas horizontales en y=161 y y=214, de x=2 a x=255
- línea vertical izquierda en x=1
- **linea vertical DERECHA en x=255**, pero x=255 queda fuera de la ventana visible
  (que termina en x≈243: de x=244 a 255 la pantalla sale NEGRA en esa banda).
En la captura del juego japonés original pasa lo mismo, así que no lo rompimos nosotros:
el recuadro se dibuja más ancho de lo que la ventana muestra. Para arreglarlo hay que
mover/ensanchar la ventana de la escena (y volver a colocar el arte de alrededor), así
que **no se ha tocado**. Los 6 candidatos `move.w #$1f,$8(a0)` ($08 = $1F, el ancho más
ancho que hay en START) NO son el del diálogo: cambiándolos no se movió nada.

### Entrega de la tanda (TEST_R)
```
TEST_R.bin  MD5 af51d2fed4bccb7eeeed647d605d9a1a
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto(v2)
      -> parche_cajas ($08=8 en el menu; el dinero se queda en 20)
      -> arregla_selectores (popup, sigue SIN verificar en pantalla)
      -> parche_titulo ($04=9 $08=15 $32=0 $2e=10)
    EDC/ECC OK y 0 sectores con P/Q mal (referencia de Corlett)
states/TEST_R_menu.state / TEST_R_velocidad.state
capturas_tanda/menu_dinero.png / menu_velocidad.png / menu_switch.png
```

## 2026-09-26 (46ª tanda) — TEST_S: título ARREGLADO (la muesca era vuelta de línea)

### [HECHO] La muesca de la N de «SIN INTRO» era el buffer de línea
Medido glifo a glifo sobre la captura de David (224012): «NUEVA SIN INTRO» mide
**120 px** y el buffer de línea del título mide **$08 * 8 px**:
```
   $08=15 -> 120 px  y la linea mide 120 px  -> vuelta de linea (el ultimo glifo salia
                        desplazado 4 px a la izquierda: la muesca de la N de «SIN»)
   $08=16 -> 128 px  -> la linea cabe con 8 px de sobra
```
=> **Mismo caso que el menú principal**: se ensancha el buffer lo mínimo, no se toca
el texto. Con $08=16 la caja mide 142 px y queda **centrada** (x=57..198, centro 127.5).
NO se puede estrechar la caja (una celda menos obliga a $08=15 y vuelve la muesca):
**manda el buffer, no la caja.**
Y el selector: $2e=10 -> 128 px (x=64..191) cubre «NUEVA SIN INTRO» (acaba en 190).

### [FALLO PROPIO] Mi script de la primera prueba escribió un espacio con $8240
`fw()` no manejaba el espacio y le metí `0x8240` a mano en vez de `0x8140`: en la
primera prueba del texto sin espacio salió «ＮＵＥＶＡ?ＳＩＮＩＮＴＲＯ» y no me di cuenta
de que el fallo era mío, no del juego. **Comparar siempre la cadena del .bin antes de
sacar conclusiones** (ahora lo compruebo).

### [HECHO] El dinero: estrecharlo EMPEORA (medido, con lupa)
```
   $08=20 (actual)  marco der x=221 | texto acaba en 209 | margen 12 px
   $08=19          marco der x=213 | el «＄» SE VA A LA LINEA SIGUIENTE (texto hasta 199)
   $08=19 + etiqueta «Dinero» sin ':'  -> lo mismo (no recupera: el hueco lo mete el
                                            pintor con `move.w #$8140,(a2)+` en $20B10)
```
=> el dinero se queda como está. No hay forma de quitarle esa celda sin que el símbolo
de la moneda se salga de la línea.

### [HECHO] El selector del menú: va por múltiplos de 8, y solo los pares
El recuadro azul del menú va de x=56 a x=115 (60 px) sobre filas de 48 px de ancho
(el paso por fila es de 6 celdas). No es una caja de dos ejes: es una **fila de un
panel** (`$17F50`), y su X sale de `$04(a0) + $32(a0)` (7 + 0), con $32 en unidades
de 4 px y el bitmap en celdas de 8. Probado en vivo moviendo los campos del
descriptor: **2 px no se pueden** (es el primer paso real de la rejilla).

### [PENDIENTE] El cuadro de diálogo: NO es el borde, es la VENTANA
El cuadro se dibuja de x=2 a x=255, pero **la ventana de la escena termina en x=243**:
```
   x=1..243  contenido de la escena (el cuadro)
   x=244..247  borde azul de la ventana (el marco que SI se ve)
   x=248..255  negro (fuera de la ventana)
   x=255     el borde derecho del cuadro, invisible, dentro de la zona negra
```
Para que se viera el marco habría que ensanchar la ventana 12 px y volver a colocar el
arte de alrededor (escena, barras laterales). **Sin tocar.** Y ojo con el aviso de
David: los diálogos llegan casi al borde derecho; el ancho del cuadro ($1F) sí se puede
estrechar, y eso es lo que hará falta cuando se traduzca.
También medido: los 6 `move.w #$1f,$8(a0)` NO son el ancho del cuadro (cambiándolos no
se movió nada).

### Entrega de la tanda (TEST_S)
```
TEST_S.bin  MD5 e9a96ebc7ae858978828e31d053d5ffd
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto(v2)
      -> parche_cajas ($08=8 en el menu) -> arregla_selectores (popup, aun sin verificar)
      -> parche_titulo ($04=8 centrado, $08=16 buffer 128 px, $32=2, $2e=10)
    EDC/ECC OK y 0 sectores con P/Q mal (referencia)
states/TEST_S_menu.state / TEST_S_velocidad.state
capturas_tanda/menu_dinero.png / menu_velocidad.png / menu_switch.png
```

## 2026-09-26 (47ª tanda) — TEST_T: título centrado, dinero estrechado y el cuadro de diálogo LOCALIZADO

### [HECHO] El menú de Velocidad de la captura de David era MEMORIA VIEJA
Comprobado con TEST_S en el emulador, de las dos maneras (cargando el state que
entregué y navegando desde cero): dígitos en 111/122/134/146/158/170/182/194 (12 px) y
«Rápido» en x=97. Correcto. Su captura (091423) tenía «Rápido» en 73 y los dígitos a
8 px = la maquetación de la PRIMERA vía, así que la PRG-RAM era de un build anterior
(el arreglo de esa vía llego con TEST_P). **Con el .bin y el state de la misma entrega
sale bien.**

### [HECHO] Título: mover el texto va con $32, en pasos de 4 px
```
   $32=2 -> texto margenes 16/8      $32=1 -> 12/12      $32=0 -> 8/16
```
Puesto **$32=1**: la linea queda con 12 px a cada lado (4 px a la izquierda respecto a
antes). La caja sigue centrada (57..198, centro 127.5).

### [HECHO] El dinero: el hueco que lo bloqueaba es una instruccion del pintor
El pintor del dinero ($20AF0) mete un espacio fijo detras de la etiqueta:
```
   0x10B0E   move.w #$8140,(a2)+      <- 8 px de hueco escondido
```
Anulandolo (2 NOP) + caja en $08=19:
```
   marco derecho x=213 (antes 221)   texto «Dinero:0000140 ＨＫ＄» x=40..201  margen 12
```
(En la prueba C de la captura) es lo que pidio David: solo estrechar por la derecha.
Ojo: la etiqueta lleva el espacio **antes de las cifras** en el texto («Dinero:0000140»)
para dejar el hueco que pide; el espacio de despues de los dos puntos se ha quitado,
que es lo que da los 8 px que faltaban. Si David prefiere «Dinero: 0000140», la caja
vuelve a 20 celdas (el texto no cabe de otra forma: medido).

### [HALLAZGO] El cuadro de DIÁLOGO es el descriptor $A4200 en OTRO MODO
Medido con el juego en marcha, atrapando el dialogo de la intro:
```
   $A4200: $0=0001  $04= 1  $06=21  $08=31  $0a= 5  $1a=8020  $1e=$A6000
```
Es decir: el mismo descriptor que el menu principal, pero con **$06=21 (fila 21) y
$08=31 (buffer de 248 px)**; el texto empieza en x=2 (de ahi el marco de x=2 a 255
medido en las capturas). Su ancho ($08) se puede estrechar en tiempo de ejecucion
(probado escribiendo en la Word RAM: el valor cambia y se mantiene), pero **hay que
averiguar quien lo fija** ($06=21/$08=31 no aparecen juntos en el START.BIN): es una
tabla de geometria de pantallas.
=> El ARREGLO del marco derecho: estrechar este buffer 12 px (de 31 a 29-30 celdas) y el
recuadro acaba en x=215/223, dentro de la ventana (que termina en x=243), y entonces su
marco derecho se ve. **Pendiente de localizar quien lo fija para meterlo en la ROM.**

### Entrega de la tanda (TEST_T)
```
TEST_T.bin  MD5 6727e0c4dc656e4ccac78cca4c64ed7a
    = build_test_i -> dinero_formato (etiqueta sin hueco, NOP del hueco del pintor)
      -> fuente_dinero -> paso_mixto(v2) -> parche_cajas (menu $08=8, dinero $08=19)
      -> arregla_selectores (popup, aun sin verificar en pantalla)
      -> parche_titulo ($04=8, $08=16 buffer 128 px, $32=1, $2e=10)
    EDC/ECC OK y 0 sectores con P/Q mal (referencia)
states/TEST_T_menu.state / TEST_T_velocidad.state
capturas_tanda/menu_dinero.png / menu_velocidad.png / menu_switch.png
```

## 2026-09-27 (48ª tanda) — TEST_V: la maquetación del menú de Velocidad, ROBUSTA

### [HALLAZGO] El menú de Velocidad se pinta desde una TERCERA dirección
Estado de David (TEST_U.state, en el menú スピード): con el MISMO código la maquetación
sale compacta. Espía de a2: la línea se pinta desde **$05DEBA**.
```
   1ª vez (recién entrado)      a2 = $01577E
   al volver a entrar           a2 = $0244B2
   desde una partida normal     a2 = $05DEBA    <-- la que faltaba (state de David)
```
El juego **copia la línea a un buffer de trabajo cuya dirección cambia según la
partida**. Discriminar por direcciones es perseguir un blanco móvil.

### [ARREGLO] El criterio bueno: el ANCHO del descriptor
El menú de Velocidad usa `$08=26` (208 px); el menú principal 8, el dinero 20 y el
cuadro de diálogo 31. Así que la regla es:
```
   si $08(a0) == $1a (26)  ->  espacios y digitos a 12 px   (menu de Velocidad)
   y ademas se mantienen las dos direcciones conocidas por si acaso
```
Verificado en los TRES caminos, con el estado de David incluido:
```
   state de David          -> digitos 111/122/134/146/158/170/182/194  OK
   desde cero (mi estado)  -> igual                                     OK
   tras pasar por スイッチ   -> igual                                     OK
```
Y el resto intacto: dinero «Dinero: 0000140 ＨＫ＄» acaba en x=209; menú principal con
la caja a 8 celdas y sin muescas.

### [ERROR PROPIO] Estados fantasma
Le dije a David que le dejaba los estados de TEST_U y **no los generé** (la carpeta
`states/` seguía con los de TEST_T). Ahora `prepara_entrega7.py` los genera y ADEMAS se
comprueban cargándolos (no basta con generarlos). Y se añade un estado extra
(`TEST_V_velocidad_david`) hecho desde el estado de David, que es la vía que fallaba.

### [PENDIENTE] El selector del menú de Velocidad
En la captura de David el recuadro azul cubre de x=83 a x=150 aprox. («ovimient»),
cuando «Movimiento» va de 25 a 153. Se han probado en vivo los campos $04, $0a, $32,
$2e y $08 del descriptor y NINGUNO lo mueve: el recuadro azul de esa ventana lo dibuja
otra rutina (probablemente la misma que el borde derecho del cuadro de diálogo). David
ha dicho que los selectores se ajustan al final, así que queda para esa pasada.

### Entrega de la tanda (TEST_V)
```
TEST_V.bin  MD5 4b8c74c828cf2f6aee5d4f4a919dbf64
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto v3 (ancho $08=26)
      -> parche_cajas (menu $08=8, dinero $08=20) -> arregla_selectores
      -> parche_titulo ($04=8, $08=16, $32=1, $2e=10)
    EDC/ECC OK
states/TEST_V_menu.state (menú con el dinero) / TEST_V_velocidad.state
states/TEST_V_velocidad_david.state (desde el estado de David: la vía que fallaba)
capturas_tanda/menu_dinero.png / menu_velocidad.png / menu_switch.png
```

## 2026-09-27 (49ª tanda) — TEST_W: EL SELECTOR DEL MENÚ DE VELOCIDAD, A MEDIDA

### [HALLAZGO] El recuadro azul lo emite la rutina $20430 (y por eso parpadea)
David avisó de que el selector parpadea: eso fue la pista. Trazando las ESCRITURAS en
la lista de sprites ($A40A0, apuntada por `$a220`) durante 4 frames dentro del menú:
```
   PC=$02049A/9C/A0/A4  escriben las entradas del recuadro ($E6F2, $0500, ...)
   -> la rutina es START $20430, llamada EN BUCLE por el menú ($20244): de ahí el parpadeo
```
Sus números salen del descriptor ($A4200 = el del menú de Velocidad):
```
   X de la caja = 8*$04 + 4*$32        ancho = 12 * $2e        Y = fila ($2c) + $a77a/$a77c
```
Y el setup de este menú está en START 0x139BE (medido, no deducido):
```
   0x13A04  317c 0003 0032   move.w #$3,$32(a0)   -> X = 24 + 12 = 36
   0x13A0A  317c 0005 002e   move.w #$5,$2e(a0)   -> ancho 60  -> caja 36..95
```
«Movimiento» va de x=25 a x=153, así que la caja se quedaba corta (acababa en 95).

### [HECHO] $32 mueve el RECUADRO pero NO el texto
Probado en vivo ($32 = 0,1,2,3): el texto se queda en 25..153 y la caja se desplaza 4 px
por unidad. Eso permite ajustar el recuadro sin tocar la maqueta.

### [ARREGLO] $32 = 0 y $2e = 11  (parche_selector_vel.py)
```
   X = 24    ancho = 132   ->  caja 24..155   (cubre «Movimiento», que acaba en 153)
```
Verificado en el emulador con el estado de David: caja x=24..155.

### [HECHO] Por qué en la captura de David el recuadro salía en otro sitio
Su captura lo ponía sobre «ovimient» (x≈83..150): la caja se dibuja sumando el
desplazamiento global **$a77c**, que queda en 48 cuando se sale del menú de Velocidad
con C/START/X/Y/Z (medido en la 43ª tanda). Con $a77c a 0 la caja sale en 36..95.

### Entrega de la tanda (TEST_W)
```
TEST_W.bin  MD5 50fa94e3cb54d1f68c45b0c1504169da
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto v3 ($08=26)
      -> parche_cajas (menu 8 / dinero 20) -> parche_selector_vel ($32=0, $2e=11)
      -> arregla_selectores -> parche_titulo ($04=8,$08=16,$32=1,$2e=10)
    EDC/ECC OK y 0 sectores con P/Q mal (referencia)
states/TEST_W_menu.state / TEST_W_velocidad.state / TEST_W_velocidad_david.state
capturas_tanda/menu_dinero.png / menu_velocidad.png / menu_velocidad2.png / menu_switch.png
```

## 2026-09-27 (50ª tanda) — LA TABLA DE NOMBRES LOCALIZADA (petición de David: traducirlos)

David pidió empezar por los nombres de los personajes (sección 5f del
INFORME_TRADUCCION.md) porque condicionan los menús.

### [HALLAZGO] Tabla de nombres de la party = OPEN.BIN 0xF00B
Formato: `nombre sjis 00` seguido. Medido (offset, texto y HUECO real):
```
  0xF00C 天人 (4B/5)   0xF011 美紅 (4B/5)   0xF016 ホウメイ (8B/9)
  0xF01F シュウ老師 (10B/11)  0xF02A アイザック (10B/11)  0xF035 カッシュ (8B/9)
  0xF03E 薬師カイ (8B/9)  0xF047 リー (4B/5)  0xF04C 謎の男達 (8B/9)
  0xF055 ガード・ロボ (12B/13)  0xF062 ハイタオ兵 (10B/11)  0xF06D レヴァ (6B/7)
```
**Viva en memoria en `$4A919`** (PRG-RAM) con el menú abierto: ahí el HUD y los menús
leen el nombre del personaje. Además los nombres aparecen como texto normal en 60
ficheros de guion (A*/B*/C*/E*/F*/H*/I*/J*, INIT, GENEI_OP.DAT) — esos van por el
reconstructor.

### [MEDIDO] El canon (5f) NO cabe en la tabla
```
   Tianren (7 glifos = 14 B) en hueco de 5 B     -> NO
   Meifan  (6 = 12) en 5                          -> NO
   Houmei  (6 = 12) en 9                          -> NO
   Maestro Shu (11 = 22) en 11                    -> NO
   Lee (3 = 6) en 5                               -> NO (por 1 B)
   Isaac (10 B) en 11, Cash (8) en 9, Kai (6) en 9 -> SI
```
La tabla está dimensionada para nombres japoneses de 2 glifos; el canon pide 6-7.
Salidas: reubicar la tabla (la vía de crecimiento de OPEN ya se usó en el lote 2) o
**forma corta en la tabla y nombre completo en diálogos** (lo que ya recomendaba el
informe en 5f).

### Entrega: `recursos/documentos/INFORME_NOMBRES.md` + `recursos/tools/mide_tabla_nombres.py`
No se ha aplicado ningún nombre: hace falta que David decida la forma corta (o la
reubicación). Es una decisión de traducción, no técnica.

### Recordatorio del fallo de método que ya van varias veces
El savestate lleva los datos del disco DENTRO (tabla de nombres incluida). Para ver un
cambio hay que: ROM parcheada + estado creado con esa ROM (o empezar partida).

## 2026-09-27 (51ª tanda) — MÉTODO NUEVO de David: partida limpia (guardar/reiniciar/cargar)

### [HERRAMIENTA] `pruebas/flujo_limpio.py` — adiós a los states contaminados
Idea de David (y es la buena): el savestate guarda la PRG-RAM entera y con ella los
datos que trajo el disco (tabla de nombres, textos, rutinas). Para comprobar algo que
viene del CD hay que hacer:
```
  1. state de la sala de guardado (TEST_L.state) -> pantalla [セーブ]
  2. C -> guarda en el slot 1
  3. retro_reset()  -> arranque desde BIOS (todo se relee del CD)
  4. titulo -> START -> CARGAR PARTIDA -> C (slot 1)
  5. dentro del juego SIN ningun state
```
Automatizado en `pruebas/flujo_limpio.py guardar|cargar|nueva <cue> <prefijo>`.
Verificado: llega al juego con el HUD, los menus y el dinero correctos.

### [HALLAZGO] Los nombres del HUD vienen del SAVE, no del CD
Prueba: se parcheo el INIT.BIN de la ROM poniendo `ＺＺ` (fullwidth) en la entrada de
天人 de la tabla de nombres (INIT+0x22919) y se cargaron LAS DOS vias:
```
   partida CARGADA del save   -> el HUD sigue mostrando 天人  (viene de la save)
   PARTIDA NUEVA (sin save)   -> HUD vacio hasta que se une la party
```
Conclusion: los nombres de los personajes de la partida viven en la **backup RAM (el
save)**. La tabla del disco es el valor por defecto / la de los personajes que se unen.

### [MEDIDO] El selector del menu de Velocidad, ajustado a lo que pide David
```
   «Movimiento» acaba en x=102 (el 153 que medí antes era la FLECHA, colada en la medida)
   $2e=7 -> ancho 84 -> caja 24..107   <- lo minimo posible
   ($2e va de 12 en 12: con 6 serian 12 px de menos y dejaria fuera la «o» final)
   David pedia x=103; 107 son 4 px mas porque el motor no da mas resolucion.
```

### Entrega (TEST_X)
```
TEST_X.bin  MD5 ef67b982c50312995e4bebc8515d90e5
    = build_test_i -> dinero_formato -> fuente_dinero -> paso_mixto v3
      -> parche_cajas (menu 8 / dinero 20) -> parche_selector_vel ($32=0, $2e=7)
      -> arregla_selectores -> parche_titulo ($04=8,$08=16,$32=1,$2e=10)
    EDC/ECC OK
states/TEST_X_menu / TEST_X_velocidad / TEST_X_velocidad_david
capturas_tanda/menu_velocidad.png (selector 24..107)
capturas_tanda/partida_limpia_juego.png / partida_limpia_load.png
```

## 2026-09-27 (52ª tanda) — NOMBRES: medido el recuadro del HUD y aplicada la forma corta

### [MEDIDO] El recuadro del HUD admite 4 glifos, no mas
```
   recuadro del panel derecho: x=203..251  (49 px)
   el texto empieza en x=209  ->  espacio util hasta 249
   2 glifos: 17 px CABE | 3: 26 CABE | 4: 35 px (209..243) CABE
   5 glifos: 44 px (209..252) NO CABE | 7 (Tianren): 62 px NO CABE
```
=> «Tianren» (7) y «Meifan» (6) **no caben fisicamente** en el recuadro del HUD.
El recuadro es arte del panel: para meterlos haria falta rehacer/ensanchar el panel.

### [HECHO] La tabla de nombres y su hueco
INIT.BIN 0x22919: **29 entradas**, lista secuencial terminada en 00, **288 B** en total
(0x22919..0x22A39) con **7 B de holgura**. Los huecos por entrada no sirven (van
encadenadas), pero el bloque SI tiene holgura global: reordenando caben formas algo
mas largas.
No hay puntero: el codigo la indexa por posicion dentro del bloque (y la tabla que
aparece en la PRG-RAM depende de la partida: 0x4A919, 0x4A95A...).

### [HECHO] Los nombres de la partida viven en el SAVE
Comprobado con partida limpia: cambiando la tabla del disco, una partida CARGADA sigue
mostrando los nombres viejos y una PARTIDA NUEVA los de la tabla. Los pokes en la
PRG-RAM (23 copias de 天人) tampoco cambian el HUD: el panel se dibuja una sola vez y
desde los datos del save. **Para ver un nombre nuevo hay que empezar partida.**

### [APLICADO] Forma corta (la que cabe en 4 glifos): `recursos/tools/traduce_nombres.py`
```
   天人 -> Tian     美紅 -> Mei      ホウメイ -> Hou    リー -> Lee
   Ｓｈｕ -> Shu     Ｉｓａａｃ -> Isaac   Ｃａｓｈ -> Cash   Ｋａｉ -> Kai
   bloque: 287 B de 288 (holgura 1)
```
Los nombres completos del canon (Tianren, Meifan, Houmei…) NO pueden ir al HUD por
falta de sitio; si David quiere los completos en pantalla hay que ensanchar el panel
(arte) o usar dos tablas (HUD corto / menus largo) si se encuentra la segunda.

### Entrega (TEST_Y)
```
TEST_Y.bin  MD5 bb8e7db6daa10c27e136b69a2f394c65  (TEST_X + tabla de nombres corta)
verificado: EDC/ECC OK; pendiente de que David lo vea en PARTIDA NUEVA (el HUD en la
intro no muestra nombres hasta mas adelante).
```

## 2026-09-27 (53ª tanda) — HUD: nombres (TEST_Y) y las etiquetas LV/HP/MP

### [ENTREGADO] TEST_Y.bin — tabla de nombres traducida
`tools/traduce_nombres.py`: INIT.BIN 0x22919, 29 entradas, 288 B de bloque (holgura 1 B
tras la traduccion). Nombres cortos porque el recuadro del HUD no da mas:
```
   天人 -> Tian   美紅 -> Mei   ホウメイ -> Hou   リー -> Lee
   Ｓｈｕ -> Shu   Ｉｓａａｃ -> Isaac   Ｃａｓｈ -> Cash   Ｋａｉ -> Kai
```
**David probo TEST_X (el anterior), no TEST_Y** — de ahi que los nombres siguieran
iguales. Hay que probar TEST_Y **empezando partida nueva** (los nombres de una partida
en curso viven en el save).

### [MEDIDO] El recuadro del HUD admite 4 glifos
```
   recuadro x=203..251 (49 px), el texto empieza en 209
   4 glifos acaban en 243 (CABE) | 5 acaban en 252 (NO CABE)
   Tianren (7 glifos) = 62 px: imposible sin rehacer el panel (es art)
```

### [HECHO] Las etiquetas LV / HP / MP del HUD son GRAFICOS, no texto
Prueba: escribir un bloque solido en las celdas de la fuente (tabla de menus $29ED0 y
tabla del dinero $294E0, en las celdas de L,V,H,P,M) -> **0 px de cambio en las
etiquetas** (otros cambios si, 400 px, en la linea del dinero).
=> No salen de las tablas de fuente: son tiles/art del panel.
No he conseguido todavia cual: he machacado los tiles de la nametable (1909-1912,
1871, 1887), los candidatos encontrados por patron en VRAM (529-531, 539-541, 785-786,
795-797) y **no cambian**. Sospecha: la lista de sprites (que el propio juego usa para
los recuadros, $20430) o un plano con prioridad distinta. **Siguiente paso**: volcar
bien la lista de sprites en el juego (mi volcado salio en $A4080 y no cuadra) y ver si
las etiquetas son sprites.

## 2026-09-27 (54ª tanda) — HUD: los nombres van en TEST_Y; el panel LV/HP/MP sigue ciego

### [ENTREGADO] TEST_Y.bin (MD5 bb8e7db6daa10c27e136b69a2f394c65)
`tools/traduce_nombres.py`: la tabla de nombres de INIT.BIN 0x22919 (29 entradas,
288 B) reescrita con las formas cortas que caben en el recuadro del HUD:
```
   天人->Tian  美紅->Mei  ホウメイ->Hou  リー->Lee   Ｓｈｕ->Shu  Ｉｓａａｃ->Isaac
   Ｃａｓｈ->Cash   Ｋａｉ->Kai         bloque: 287 B de 288 (holgura 1)
```
David había probado **TEST_X** (el build anterior): TEST_Y es el de los nombres.
Recordar: los nombres de una partida en curso viven en el SAVE -> hay que empezar
partida nueva para verlos.

### [MEDIDO] El recuadro del HUD admite 4 glifos
recuadro x=203..251 (49 px), texto desde x=209 -> 4 glifos acaban en 243 (cabe),
5 acaban en 252 (no cabe). Tianren (7) = 62 px: imposible sin rehacer el panel.

### [ATASCADO, con la causa medida] Las etiquetas LV/HP/MP del panel
Ver `recursos/documentos/HUD_PANEL.md`. Resumen:
- NO son texto de las dos tablas de fuente (probado con bloques sólidos: 0 px).
- NO son tiles de la nametable (probadas las 5 bases y las 2 anchuras de plano: 0 px).
- NO son sprites (apagar los 80 del SAT: 0 px).
- NO hay ningún tile en VRAM con la forma de la L (barrida completa: 0 candidatos).
- **El juego reconstruye el panel cada frame** (2400-3000 escrituras a VRAM en 4-6
  frames en reposo, incluida la CRAM): cualquier poke se revierte antes de verse.
Siguiente paso: gancho de MEMORIA del sub-procesador (hoy solo engancha su PC) para
capturar de qué dirección de RAM saca el panel; luego parchear esa fuente.

## 2026-09-27 (55ª tanda) — core recompilado: ESCRITURA EN VRAM que SÍ se ve

### [HALLAZGO CLAVE] La caché de patrones invalidaba todos mis pokes
`core/vdp_ctrl.c` mantiene `vram[]` **y** una caché de patrones (`bg_pattern_cache`,
`bg_name_dirty[]`). Escribir en `vram[]` sin `MARK_BG_DIRTY(addr)` **no cambia nada en
pantalla**: la prueba es que pintar los tiles 1600-2047 de rojo daba **0 píxeles rojos**.
Eso explica por qué "no cambiaba nada" en ninguna de las pruebas anteriores de esta
tanda y de la anterior (tiles, paleta, sprites...). **No era que el juego lo
reescribiera todo: era la caché del emulador.**

### [HECHO] Recompilado y verificado
- Añadida `arena_vdp_write16()` a `core/vdp_ctrl.c` (escribe vram y marca dirty).
- `link.T`: `global: retro_*; arena_*;`  .so nuevo MD5 `bf6d2a9f45d6f2ad373989274a1ce649`
- Verificado en pantalla: escribir en el tile 1893 → aparece en la columna de las
  etiquetas. **La herramienta ya funciona.**

### [MEDIDO] Mapa de los tiles de las etiquetas
```
   LV: 1893 (x208..215) + 1894 (x216..223)   y=40..47
   HP: 1911 + 1912                            y=48..55
   MP: 1877 + 1877 (mismo tile repetido)      y=56..63
   (se repite cada 48 px para cada personaje)
```
Copiar 1894 sobre 1893 no cambia el dibujo: **los tiles de las letras se reescriben
cada frame** (el resto del panel no). => falta localizar la fuente.

### Siguiente paso
Espiar el puerto de datos del VDP ($C00000) aprovechando que el juego sube los tiles
**in situ** (usa el autoincremento de $C00004), para capturar en tiempo real a qué
dirección escribe cada palabra. Con eso se ve la rutina y la fuente del panel.

## 2026-09-27 (56ª tanda) — instrumental VRAM LISTO; el tile de las letras, pendiente

### [HECHO] Ya se puede escribir en la nametable y verlo
`arena_vdp_write16()` funciona para tiles **y** para entradas de nametable. Probado:
poner una «Z» que dibujé yo en la celda (26,5) del plano A la dibuja en pantalla
(y=80..87). **El instrumental está completo.**

### [MEDIDO] Desfases que hay que tener en cuenta (me habían despistado)
```
   celda (26,ty) del plano A -> y = 32 + 8*ty
   filas LV/HP/MP de un personaje: y=48, 64, 80  ->  ty=2, 4, 6
   (en una captura anterior del state las filas salian a y=40/48/56: el panel se
    dibuja a distinta altura segun la escena)
```
Los tiles que apunta esa columna (1893, 1911, 1877, 2020...) NO son glifos de letras:
son las rayas/barras del panel y otros elementos.

### [DESCARTADO CON PRUEBA] Los glifos no están en RAM
Buscados por su forma (1 byte por fila) y por el patrón del tile en PRG-RAM, Word RAM
y Word RAM 2M: no aparecen. La VRAM de tiles es estática entre frames (0 tiles cambian
en dos volcados seguidos) -> no se regeneran.

### Siguiente paso (concreto y corto)
Barrer tx=0..40 en la fila ty=2 (y=48..55, la de LV) leyendo a qué tile apunta cada
celda y probando ese tile: con el desfase ya medido son ~40 pruebas en vez de 2000.

## 2026-09-27 (57ª tanda) — PANEL DEL HUD LOCALIZADO (bloque de tiles 1764+)

### [HALLAZGO GRANDE] El panel es un bloque de tiles y las letras van dentro
Todas las celdas de la columna de las etiquetas apuntan al tile **1764**: pintarlo
borra el 66% de la tinta de las letras. Conclusión: el panel completo (marco, rayas,
letras LV/HP/MP y barras) es un **bloque de tiles contiguos que empieza en 1764**, y
las letras están DENTRO del bloque (los tiles 1780-1790 tienen las formas).
Por eso no aparecían: no son glifos de una fuente, son art del panel.

### Herramienta (lo más importante de la tanda)
`arena_vdp_write16()` en el core hace que las escrituras en VRAM/nametable **se vean**
(hay que marcar el patrón sucio: `MARK_BG_DIRTY`). Probado dibujando un patrón propio
en la celda (26,5) del plano A.
```
  so nuevo: MD5 bf6d2a9f45d6f2ad373989274a1ce649
  desfase medido: celda (tx,ty) del plano A -> y = 32 + 8*ty
  la VRAM de tiles es estatica (0 tiles cambian entre dos volcados seguidos)
```

### Siguiente paso (corto y con la herramienta lista)
Bisección restringida a 1764..1830 para identificar qué tile es cada letra y
redibujarlas (L->N, V->? etc. segun lo que pida David), escribiendo en el bloque.

## 2026-09-27 (58ª tanda) — NOMBRES: la tabla es de tamaño FIJO (regla medida)

### [ERROR PROPIO] TEST_Y desplazaba la tabla
Al escribir nombres MÁS LARGOS que el original, todo lo que venía detrás se movía y
el juego (que lee por **posiciones fijas**, no por punteros) mostraba kanjis y
desbordes: «Tian» bien y el segundo nombre con basura.

### [REGLA MEDIDA] Cada nombre ocupa su hueco exacto (texto + terminador 00)
```
   天人      5 B  -> 2 glifos (Ti)      美紅      5 B  -> 2 (Me)
   ホウメイ   9 B  -> 4 (Hou)            リー      5 B  -> 2 (Le)
   Ｓｈｕ     7 B  -> 3 (Shu)             Ｉｓａａｃ  11 B  -> 5 (Isaac)
   Ｃａｓｈ    9 B  -> 4 (Cash)           Ｋａｉ     7 B  -> 3 (Kai)
```
=> «Tianren» (7) y «Meifan» (6) **no caben**: invadirían el hueco siguiente y el juego
mostraría basura. Reubicar la tabla exige encontrar dónde guarda el juego las
posiciones (no los punteros), que es la vía que ya me atascó una vez.

### [ENTREGADO Y VERIFICADO] TEST_Z.bin MD5 8b694da23931e25a87d69248f25cff87
«Ti, Me, Hou, Le, Shu, Isaac, Cash, Kai» en la ventana de selección de personaje
(Magia/Equipo/Estado). Comprobado en pantalla con partida limpia: sale «Ti / Me»
limpio, sin kanjis. Captura: `capturas_tanda/ventana_personajes_Ti_Me.png`.

### [CONFIRMADO POR DAVID Y MEDIDO] El panel del HUD es GRAFISMO
Pintando el bloque de tiles del panel desaparecen **a la vez** el nombre y las
etiquetas LV/HP/MP (nombre 38 px de tinta -> 9; etiquetas 106 -> 20). No es texto:
no lo alimenta ninguna tabla. Se cambia REDIBUJANDO.
Herramienta lista: `arena_vdp_write16()` (core recompilado, escribe VRAM y marca el
patrón sucio; sin eso las escrituras no se ven).

### Pendiente inmediato
Redibujar el panel del HUD con NV / PV / PM (y los nombres) escribiendo en los tiles
del bloque (1764+). Después, dejarlo fijo en el disco (la art va comprimida: hay que
encontrar la rutina de descompresión o inyectar los tiles ya expandidos).

## 2026-09-27 (59ª tanda) — el panel: sólo falta dibujar la N

### [IDEA DE DAVID, CORRECTA Y APLICADA AL PLAN]
De las cinco letras del panel (L,V,H,P,M), **cuatro ya existen**:
```
   LV -> NV  : cambiar la L por una N   <- la UNICA letra nueva
   HP -> PV  : la P ya esta (de HP) y la V ya esta (de LV)
   MP -> PM  : la M y la P ya estan
```
=> el trabajo se reduce a dibujar una N y reordenar tiles.

### [MEDIDO] El panel es un bloque de tiles; las letras van dentro
- Escribir cualquier tile del bloque (1764+) hace desaparecer las letras: son parte
  del art del panel, no de una fuente.
- Los tiles estan VACIOS en VRAM y las letras se ven igual -> el dibujo vive en la
  **cache de patrones**. Al escribir un tile se marca sucio y la cache se rehace con
  lo nuevo (por eso desaparecen): **la via para redibujar funciona**.

### [PENDIENTE] Acertar el tile exacto de cada letra
Cajas exactas medidas (partida cargada): L x=211..213/y=40..46; H x=211..213/y=48..54;
M x=211..213/y=56..62; y las segundas letras en x=215..217.
Metodo para la proxima: escribir un patron DISTINTIVO (una N) en cada tile candidato
(1764..1870) y buscar ese patron en pantalla -- el que caiga sobre la L es su tile.
(NO usar solidos: borran todo y confunden la medida.)

## 2026-09-27 (60ª tanda) — NOMBRES COMPLETOS: el meollo, resuelto (TEST_AB)

### [ENTREGADO] TEST_AB.bin — MD5 51f2dc11636ad81ee6b390612dd35428
Capturas (en `capturas_tanda/`): `AB_ventana_personajes.png` (Tianren / Meifan),
`AB_equipo_tianren.png` (◊EQUIPO◊ Tianren), `AB_magia_tianren.png` (◊MAGIA◊ Tianren),
`AB_estado_tianren.png` (◊Tianren◊ DIVER).

### [HECHO] Por que salia el segundo nombre con kanjis — la causa, medida
La tabla de personajes esta en **INIT.BIN 0x21270** (RAM $49270): 72 entradas de 6 B
`[id:2][off1:2][off2:2]` cerradas con `$00FF`. La rutina del START **$195A8** no
calcula la posicion del nombre: la LEE de esos **offsets de 16 bits**, que suma a la
base `$49246` (= INIT file 0x21246) y deja el puntero en `$bd00`.

```
    lea $49246,a2 ; move.w (a0)+,d1 ; adda.l d1,a1 ; move.l a1,(a3)+
```
=> **Los nombres son reubicables**: basta cambiar su offset. Escribir "en su hueco"
(lo que hacia la v2) era el error: el hueco de 天人 mide 5 B (2 glifos) y cualquier
nombre mas largo desplazaba todo lo de detras, mientras el juego seguia leyendo en la
posicion vieja. Ese era el "meollo": no era falta de espacio, era la colocacion.
Herramienta nueva: `recursos/tools/celdas_fuente.py` (imita la rutina del juego) y
`traduce_nombres.py` v3 (reparte los nombres por huecos libres y reescribe los offsets).

### [HECHO] Donde van los nombres (82 B en 88 B de hueco)
```
  bloque de la party  INIT 0x2291A..0x22959 (64 B, se vacia y se reparte a medida):
      Tianren(15) Meifan(13) Houmei(13) Lee(7) Shu(7) Kai(7)
  relleno tras la TABLA DE OBJETOS  INIT 0x21918..0x2192F (24 B, todo a cero):
      Isaac(11) Cash(9)
```
Los dos sitios estan DENTRO del rango direccionable (offsets 16 bits desde $49246).
El relleno de la tabla de objetos se midio antes: esta a cero y sigue a cero en el
juego (volcado en varias escenas).

### [HECHO] Los iconos de David en los rotulos
- Glifo del icono (**fila 7, columna 2** de `Fuente Illusion City.png`) en la celda
  **1349** de la fuente (= codigo **SJIS 0x965F**), en INIT y en OPEN. Esa celda es
  el unico hueco del rango con UN codigo y que no aparece en ningun texto del disco
  (barridos los 167 ficheros del ISO buscando cadenas japonesas).
- Plantillas de los rotulos (las dos miden LO MISMO, asi que el nombre sigue cayendo
  donde cayia): `Equipo de` -> `◊EQUIPO◊ ` (START 0x13E70) y `Magia de` -> `◊MAGIA◊ `
  (START 0x1758A).
- **El limite del nombre en EQUIPO era 5 glifos** (START 0x12856, `move.w #$5,d2`) y
  por eso salia "Equipo deTianr": ahora 7, igual que el de MAGIA, que ya daba para
  "Tianren" entero.
- **Corchetes del menu de ESTADO** (START $22E58/$22E72): `［`/`］` -> icono. Eso
  arregla tambien el "DIVER" cortado: el nombre basura se comia la cola de la clase.
- `paso_mixto.py`: el codigo del icono se anade a la tabla de "se pinta a 8 px"
  (si no, el icono avanzaba 12 y dejaba un hueco de 4 px).

### [EN CURSO] HUD: NV / PV / PM
Medido y descartado en esta tanda (para no repetirlo):
- Los tiles del panel (1764+) **no se reescriben** en reposo (traza de escrituras de
  VRAM: solo se tocan 1544-1579, 1600-1663, 1728 y 1744-1763; y estos ultimos estan
  VACIOS en VRAM).
- Las celdas del panel (tx 26-28, ty 4-7) apuntan a tiles que en VRAM tienen RAYAS,
  no letras, y sin embargo en pantalla se ven las letras: el pintado no viene de esos
  tiles. Escribir en ellos cambia 4 filas como mucho.
- Los sprites tampoco: el SAT solo tiene sprites en x=128..143 (el dinero).
Siguiente paso: espia del puerto de datos del VDP ($C00000) para capturar la escritura
de los tiles de las letras en el momento en que el panel se monta.

## 2026-09-27 (61ª tanda) — auditoría COMPLETA de la fuente; errata ó/ú; icono ÷

### [HERRAMIENTA NUEVA] celdas_fuente.py, con la fórmula CORREGIDA
Imita la rutina del juego codigo SJIS -> celda de la fuente (START $1922C + $191BE).
La primera version tenia MAL el primer termino del indice (faltaba el `- $200`):
daba 5094 para todo. Corregida y **validada contra las celdas medidas una a una**
(49 = '$', 52-61 = '0'-'9', 69 = 'H', 1334 = 'Á', 1350 = 'á', 1431 = 'ñ').
Con ella: `verifica_fuente.py` (auditoria de los 51 caracteres del PNG en INIT y OPEN)
y `mapa_caracteres.py` (que codigo usa el juego para cada simbolo).

### [ENTREGADO] TEST_AD.bin — MD5 (ver pie)
Dos cambios sobre TEST_AC:
1. **ERRATA MIA, corregida**: en `fuente_8px.py`, `ACENTOS_REL` tenia el 'ó' y el 'ú'
   CAMBIADOS (ó en el rel 600 y ú en el 599). El rel 600 no es el 'ó' pero el 599 si,
   asi que el 'ó' del juego se escribia en una celda que no es suya y el 'ú' tampoco
   -> los dos salian mal. En el CSV hay **80 cadenas con 'ó' y 11 con 'ú'**: era
   grave. Ahora rel 596 = 'ú' y rel 599 = 'ó' (los dos comprobados).
   Prueba en pantalla: puse «ó ú ñ ¿» en la etiqueta de un menu; con la errata salian
   dos glifos deformados, ahora salen los cuatro correctos.
2. **Icono**: el de la fila 7 **columna 3**. Comprobado pixel a pixel contra el PNG
   (0 px de diferencia) en el rotulo de Magia y en el de Estado.

### [AUDITORIA] Todo lo que tiene codigo esta ya con la fuente de David
51 caracteres comprobados en INIT y en OPEN: letras, digitos, los 16 acentos, `. , : ; ? !`
`( ) [ ] " % + - — ~ $` y el icono. **Sin codigo en el juego**: `« » ÷ # ∆`
(y `=`, que tampoco esta en el PNG, sigue siendo el del juego).
`#` es ademas **marcador** del motor (`#1`, `#2` = numeros), aparece en 9 cadenas ya
traducidas.

### [HALLAZGO] La «basura» de Meifan en el menu de Estado es su CLASE SIN TRADUCIR
Lo que sale detras de `÷Meifan÷` es **人民警察官** («Policía del Pueblo»), que es su
clase: la tabla de clases esta en **INIT 0x22292** (16 entradas de 2 B, punteros a
INIT 0x2425C). Igual que 元八部衆 («Ex-Ocho Generales») para Houmei. NO es un fallo
del parche de nombres; y explica que Tianren (ＤＩＶＥＲ, ya en fullwidth) se viera bien
desde el principio. Tabla completa y propuesta en `CLASES_Y_HABILIDADES.md`.
Los textos de clase/habilidad/zona son punteros de 16 bits: se pueden alargar.

### [PENDIENTE] NV / PV / PM del HUD
El menu de Estado ya dice NV/PV/PM (es del propio juego); lo que falta son las
etiquetas del panel derecho (LV/HP/MP), que son grafismo. Sigue haciendo falta cazar
la subida del panel a VRAM.

## 2026-09-27 (62ª tanda) — ENTREGADO TEST_AG; el «+» era de la OTRA tabla de fuente

### [ENTREGADO] TEST_AG.bin — MD5 0b347d79e9896169a536493e4a85fa63
Capturas: `capturas_tanda/AG_estado_tianren.png` (icono ∆ + «+», «%», «~» de David),
`AG_magia_icono.png`.

### [ERROR PROPIO, corregido] `fuente_simbolos.py` escribia en la tabla de fuente EQUIVOCADA
Escribia la puntuacion y los simbolos (`+ % ~ -` ...) en la SEGUNDA tabla (INIT 0x14E0,
la del dinero) en vez de en la PRIMERA (INIT 0x4ED0, la de los menus). Motivo: me fié
de que los DIGITOS de «4+ 75» y «91%» salen de la 2ª, y generalize mal (en la 2ª el
digito '0' esta en la celda 52 y el '+' en la 40, pero la pantalla de Estado usa la 1ª
para el texto y la 2ª SOLO para los digitos y los simbolos de esas filas).
**La prueba definitiva (limpia, sin ruido)**: en la fila ATA/ATA de la pantalla de
Estado, `+` y `%` y `~` se localizan comparando la celda de pantalla con el glifo del
PNG de David. Con el parche anterior (solo tabla A) el «+» que salia en pantalla era
el del juego, 8 px de alto y con el travesaño 6 px (el de David mide 5). Ahora se
encuentran los tres glifos de David **exactos** (coincidencia pixel a pixel) en:
`+` en (80, 122/134/146), `%` en (80, 158/170), `~` en (80, 86/98).
=> CORREGIDO: los simbolos se escriben en LAS CUATRO tablas (menus y dinero, INIT y
OPEN). El `%` ya coincidia *por casualidad* en la tanda anterior (su byte cambia poco).

### [HECHO] El icono elegido por David (fila 7, columna 5, el «∆» del PNG) esta puesto
Comprobado en pantalla en el rotulo de Magia y en el titulo del menu de Estado
(coordenadas (16,26) y (80,26) de la ventana), coincidencia exacta con su PNG.

### [MEDIDO Y DESCARTADO] El hueco de la tabla de objetos para los textos nuevos
Los 24 B a cero de INIT 0x21918 (y los de 0x21AB8, 0x21E70, 0x21FE3) **el juego los
reescribe al iniciar la partida**: puestos marcas ASCII en el .bin, en RAM desaparecen.
=> No sirven para guardar textos. (La prueba de marcas se ha de hacer con la escena
correcta a la vista: el primer intento midio RAM equivocada y dio un falso negativo.)

### [MEDIDO] Donde NO cabe nada
- La tabla de fuente de los menus (INIT 0x4ED0) cae en RAM en $2CED0, **por debajo de
  la base $49246**, asi que sus celdas no valen como almacen de textos (los offsets no
  pueden ser negativos).
- INIT.BIN se carga en $28000 y el ultimo sector del disco **no llega a la PRAM-RAM**
  (marca puesta en el relleno del sector: no aparece en RAM).
- Los 122 B del bloque viejo de clases (INIT 0x2425C) son el mejor sitio contiguo,
  pero los textos de clases+habilidades+zonas suman 316 B: hay que repartirlos.

### [PENDIENTE, con el camino hecho] traduce_clases.py
Escrito y a falta de sitio. Reparto que SI cuadra (medido):
  bloque viejo 0x2425C (122 B contiguo) -> los 5 mas largos (ZONA PELIGRO, ZONA CRISIS,
  ZONA METAL, EX-GENERAL, TUBO AGUA) y los huecos que quedan se usan para 3 de 4 B.
  El resto (11 textos de <=4 glifos, tras abreviatura: BUZO, POLI, CIVI, SABI, ROBO,
  RESIS, DEMO, HILO, ESPA, VARA, GARR, CAÑ, CAÑ G, OBUS, RIFL, ARMA...) en las celdas
  SIN USAR de la tabla de fuente del DINERO (0x14E0, que si esta por encima de la base)
  y en la tabla de fuente de OPEN.
  OJO: la pantalla de Estado usa la tabla A para el texto y la B para los numeros
  (misma trampa que con los simbolos) -> hay que comprobar en cual sale la columna HAB.

## 2026-09-27 (63ª tanda) — ENTREGADO TEST_AJ: clases y rótulos en castellano

### [ENTREGADO] TEST_AJ.bin — MD5 a0b66425ce3987c834dee30fd15f6c29
Capturas: `capturas_tanda/AJ_estado_tianren.png`, `AJ_estado_meifan.png`,
`AJ_habilidades.png`, `AJ_combate.png`.
Lo que se ve: `Meifan POLICÍA` (antes kanjis), `HAB 71% HILO`, `DIVER`/`ARMA`,
y en la ventana de HABILIDADES el titulo «HABILIDADES %» con los % detras de cada
cifra.

### [HECHO] Las tablas están DUPLICADAS: INIT y OPEN
  INIT (base 0x21246):  clases 0x22292 | habilidades 0x222A2 | zonas 0x222B4
  OPEN (base 0x0D938):  clases 0x0E984 | habilidades 0x0E994 | zonas 0x0E9A6
La pantalla de ESTADO tira de INIT; la ventana de HABILIDADES, de OPEN. `traduce_clases.py`
escribe las dos (22 textos x 2 copias, 316 B cada una: 117 de huecos + 243 del bloque
viejo que queda libre).

### [HECHO] Los ROTULOS de la ventana de HABILIDADES van DENTRO de la plantilla (START)
No son cadenas sueltas: la plantilla de 0x140DE las lleva escritas, y **el código salta
a direcciones que caen DENTRO** (leen/escriben las columnas de valores), asi que la
longitud de cada fila es fija:
    fila 1: 20 celdas tras la marca $5  -> «ARMA RIFLE OBÚS CAÑ.» (nombres completos = 21-26: no caben)
    fila 2: 20 celdas tras la marca $5  -> «GARRA VARA ESP. HILO» (con ESPADA = 21: no cabe)
Los dos nombres que no caben son de la MISMA clase de 6 glifos (ESPADA y los de la
fila 1), asi que la regla es que esas dos filas estan dimensionadas para 5 glifos por
columna. Se aplican abreviaturas (David: «si las palabras completas no cupieran,
usariamos las abreviaturas»).

### [HECHO] El titulo «TecnicasUnid» eran DOS cadenas de 16 y 8 B
En la plantilla: «Ｔｅｃｎｉｃａｓ» (16 B) + «Ｕｎｉｄ» (8 B) = 24 B seguidas. Ahora
«HABILIDADES» (22) + «%» (2) = 24 B. Mismo tamano.
Y el ESPACIO que separa cada valor del siguiente de la misma fila se ha cambiado por
«%»: cada cifra lleva su % detras (la 4ª columna no, porque la plantilla no tiene hueco
y es la que esta pegada al borde).

### [PENDIENTE INMEDIATO]
- ATAQUE / DEFENSA / VELOCIDAD enteros: el campo de la plantilla de COMBATE mide 3
  glifos (los ocupan los kanji) y el codigo escribe las cifras en columnas fijas mas
  alla. Hay que decidir si se abrevian (ATQ/DEF/VEL, ya puesto) o se recoloca la fila
  entera de la plantilla moviendo los `lea` del codigo.
- «Tecnicas» ya no existe; si en otro sitio quedara, revisar.

## 2026-09-27 (64ª tanda) — ENTREGADO TEST_AL: la ficha de Estado, arreglada

### [ENTREGADO] TEST_AL.bin — MD5 ecab6e98485161b2206313b57ba942c4
Capturas: `AL_estado_meihong.png` -> `◊Mei Hong◊ POLICÍA` + línea vacía + `NV 1` en
AZUL; `AL_estado_tianren.png`; `AL_equipo_tianren.png` -> `◊EQUIPO◊ Tian Ren` entero;
`AL_equipo_meihong.png`; `AL_ventana.png`.

### [CAUSA MEDIDA] Por que se colaba el «NV» y salia en blanco
La fila del nombre+clase la construye la rutina de la ficha (START $22E0A) DENTRO de la
plantilla: borra 14 celdas y escribe `icono + NOMBRE + icono + 1 + CLASE`.
Con los nombres de 8 letras y clases de 7 glifos (POLICÍA) son 18 celdas: se come los
DOS saltos de linea que van detras (la linea vacia) y el marcador $5 de la fila del
«NV» -> el NV sube a la linea del nombre y pierde su $5 (= el color azul). Con «DIVER»
(5) entra por casualidad, y por eso a Tian Ren no le pasaba.

### [ARREGLO] La plantilla se muda a sitio libre con la fila mas larga
  - fila del nombre: 14 -> 20 celdas (peor caso: icono + 8 + icono + espacio + 10)
  - la plantilla (340 B) se copia a START 0x17ADA (sitio libre medido en el build)
  - 22 referencias reapuntadas (16 `lea` + el puntero del descriptor + 5 mas); se
    comprobo que NO hay referencias PC-relativas a la plantilla
  - la rutina: los espacios que borra pasan de 14 a 20 y el hueco antes de la CLASE
    vuelve a 1 celda (era lo que David echaba en falta)
Herramienta: `recursos/tools/parche_estado.py`.

### [ARREGLADO TAMBIEN] El limite del nombre en EQUIPO: 5 -> 10 glifos
En EQUIPO el nombre lo copia `$2087E` con un limite que estaba en 5 (luego 7): con 8
letras salia «Tian Re». Ahora 10 -> «◊EQUIPO◊ Tian Ren» entero.
**[DESCARTADO CON PRUEBA] No tocar el valor de la tabla de EQUIPO ($00023E70)**: cambiarlo
deja la pantalla SIN TITULO (probado: desaparecio el rotulo). El cambio se revirtio.

### [PENDIENTE, medido]
- Los offsets de la tabla de EQUIPO van desplazados +1 respecto al rotulo en este build
  (el `lea` apunta a 0x23E70 y el texto empieza en 0x23E6F). Funciona, pero conviene
  tenerlo presente antes de tocar esa tabla otra vez.
- La VENTANA FLOTANTE de personajes: el marco azul mide 66 px (x=81..146) y el peor
  caso («Mei Hong» + relleno + marco) pide ~96 px. El marco lo emite la rutina $20430
  con entradas de sprite; el ancho parece venir del patron E6EE (puntas) + E6F2
  (cuerpo) de la lista de sprites, no del descriptor.

## 2026-09-27 (65ª tanda) — ENTREGADO TEST_AM: la ventana flotante, ensanchada

### [ENTREGADO] TEST_AM.bin — MD5 43098d7e28791cf4a9d9a2211edc5f7a
Capturas: `capturas_tanda/AM_ventana_0.png` (Tian Ren), `AM_ventana_sel2_0.png`
(Mei Hong seleccionado: el marco azul y el selector caen en SU fila).

### [HECHO] El marco azul ES la ventana, y su ancho sale del campo $2e
La ventana la monta el setup de START **$23640**, que hace:
```
    move.w #$0,$2a(a0)   $2c   -> fila/columna seleccionada
    move.w #$1,$26(a0)   #$3,$28(a0)
    move.w #$5,$2e(a0)   <- ANCHO de la ventana   (x 0x13672, «317c 0005 002e»)
    move.w #$a,$4(a0)    move.w #$8,$6(a0)        (posicion)
    move.l #$a6000,$1e(a0)                        (mapa de tiles del marco)
```
  Medido en caliente: $2e=5 -> 58 px; $2e=9 -> 106 px. **ancho = 12*$2e - 2**.
  El borde derecho (3 px) caia SOBRE la ultima letra de «Mei Hong» (el texto acaba en
  x=136 y el borde empezaba en 136): la «muesca».
  Puesto en **$2e = 7 -> 82 px** (x=81..162), 26 px de margen.
  Herramienta: `recursos/tools/parche_ventana.py`.
  NOTA: antes probe a tocar los OTROS candidatos de $2e (0x119CC, 0x13590, 0x13A0A...)
  con el poke en caliente y sin cerrar la ventana: no es que no fueran, es que el
  descriptor se reinicializa al ABRIR. Cerrando y reabriendo entre pruebas, el bueno
  salta a la vista (los demas no cambian nada).

### [TAMBIEN EN ESTA ROM] Los dos arreglos de la ficha de Estado (los de TEST_AL)
  - fila del nombre+clase: 20 celdas y plantilla movida a sitio libre (22 referencias
    reapuntadas) -> «◊Mei Hong◊ POLICÍA» con su espacio, la linea vacia y el NV en AZUL
  - limite de la copia del nombre en EQUIPO: 10 glifos -> «◊EQUIPO◊ Tian Ren» entero

### [SIGUIENTE] La maqueta completa del menu de Estado
  Ahora que la tecnica de mover/ensanchar la plantilla esta probada (parche_estado.py),
  se pueden ensanchar las etiquetas (NIVEL, EXPERIENCIA, SIGUIENTE, ATAQUE, DEFENSA,
  VELOCIDAD, HABILIDAD, PRECISION) y correr los valores a la derecha. Hay que reapuntar
  las direcciones del codigo que caen dentro de la plantilla (medidas: las 18 de la
  ficha + las de las filas de valores). La ventana del menu tiene 19-20 celdas.

## 2026-09-27 (66ª tanda) — LA MAQUETA COMPLETA DEL MENU DE ESTADO NO CABE (medido)

### [HECHO] Ancho util de la ventana del menu de Estado
La ventana va de x=9 a x=199 -> **190 px = 15,8 celdas** de 12 px. Todo lo que pase de
ahi se sale (y a la derecha esta el panel del HUD, que no se toca).

### [MEDIDO] Lo que pide la maqueta de David, fila por fila
```
   etiqueta      + $5 + valores(7)   = celdas   px
   NIVEL            5+1+7            =  13     156   ENTRA
   EXPERIENCIA     11+1+7            =  19     228   NO (se sale 38 px)
   SIGUIENTE        9+1+7            =  17     204   NO (14 px)
   PV/PM            2+1+7            =  10     120   ENTRA
   ATAQUE           6+1+7            =  14     168   ENTRA
   DEFENSA          7+1+7            =  15     180   ENTRA
   VELOCIDAD        9+1+7            =  17     204   NO
   HABILIDAD        9+1+3+6(nombre)  =  19     228   NO
   PRECISION        9+1+7            =  17     204   NO
```
=> **EXPERIENCIA, SIGUIENTE, VELOCIDAD y PRECISION no caben** con las palabras enteras,
y HABILIDAD tampoco si ademas va el nombre del arma detras.

### [PROBADO EN EL EMULADOR] La plantilla ancha descoloca los valores
Se rehizo la plantilla con filas de 22 celdas y se desplazaron las 19 referencias de los
bloques de valores (herramienta `parche_maqueta_estado.py`): la etiqueta sale bien
(EXPERIENCIA, SIGUIENTE, ATAQUE, DEFENSA, VELOCIDAD, HABILIDAD, PRECISION) pero **las
cifras aparecen en otra columna** (en la fila de PV solo se ve el 2º valor, y en la 1ª
fila se cuela una letra suelta), porque la rutina escribe los valores en MAS sitios que
los 22 `lea` medidos (hay escrituras que no salen de ahi). **Se descarta**: build TEST_AN
borrado.

### [ENTREGADO] Se queda TEST_AM (MD5 43098d7e28791cf4a9d9a2211edc5f7a)
Que trae: nombres completos, `◊EQUIPO◊ Tian Ren` sin cortar, `◊Mei Hong◊ POLICÍA` con su
espacio + linea vacia + NV en azul, y la ventana flotante ensanchada a 82 px.

### [PROPUESTA PARA DAVID] Maqueta que SI cabe (15,8 celdas)
Con las etiquetas que ya existen y solo cambiando las que no caben:
```
   NIVEL        (5)   ENTRA
   EXPER.       (6)   <- en vez de EXPERIENCIA (11)
   SIGUIENTE    (9)   NO cabe con valores a 7 celdas -> «SIGUIENTE» sola (sin valores)
   PV / PM      (2)   ENTRA
   ATAQUE       (6)   ENTRA
   DEFENSA      (7)   ENTRA
   VELOCIDAD    (9)   -> «VEL.» (4) o «VELOC.» (6), o dejar VEL como ahora
   HAB.         (4)   -> y el nombre del arma cabe (HILO, ESPADA...)
   PREC.        (5)   <- en vez de PRECISION (9)
```
Y para que los VALORES queden alineados, la columna de etiqueta tiene que ser la misma
en todas las filas (12 celdas -> 12+1+... = 20 celdas = 240 px, no cabe). => Los valores
NO se pueden alinear a una columna comun salvo que se acorten TODAS las etiquetas a 8 o
menos. Es la decision que hay que tomar.

## 2026-09-27 (67ª tanda) — MAQUETA DEL ESTADO: mediciones y el muro del «1»

### [MEDIDO] Ancho real de la ficha
Los bordes de la ventana estan en x=8 y x=199; el texto empieza en x=17 (celda 1) y
las filas de arriba acaban en x=142 (11 celdas) => **caben 15 celdas (180 px) de 17 a 196**.

### [PROBADO] `parche_maqueta_estado.py` (v2): etiquetas fila a fila
Reescribe cada fila con su etiqueta nueva y solo ensancha el campo cuando hace falta,
desplazando las referencias de los valores el mismo numero de celdas (17 referencias).
Resultado en TEST_AO: **EXPER., PRÓX., PV, PM, ATAQUE, DEFEN., VELOC., HAB. y PRECISIÓN
salen bien y los valores alineados**. Etiquetas: NIVEL, EXPER., PRÓX., ATAQUE, DEFEN.,
VELOC., HAB. y PRECISIÓN (todas <= 9) con el campo de 5-6 celdas. Build borrado.

### [MURO] El «10» del NIVEL no cabe en 7 celdas
La fila del nombre (B) y la de debajo (A) comparten una cinta de **7 celdas** en la
plantilla: el nombre escribe su ultima celda justo antes del bloque de valores, y el
escritor de numeros ($18722) siempre escribe 3 digitos empezando donde le digan, asi
que el **10 de una partida nueva se sale por la derecha** (en TEST_AO aparece una «E»
suelta donde acaba el «10»).
=> Para el «10» haria falta ensanchar el bloque de valores de ESA fila 1 celda, y eso
   significa mover (no solo desplazar) la fila del nombre. Es el unico punto que falta.

### [DESCARTADO] El volcado de la plantilla en RAM para ver quien escribe el «1»
Se intento con el trazador de memoria del core: no recoge escrituras (el `mem_window`
+ `EV_MEMW` no disparan en este core para la PRG-RAM del Mega CD) y con `exec_=1` el
buffer de eventos se llena (8.000.000 eventos) sin utilidad. Anotado para no repetirlo.

## 2026-09-27 (68ª tanda) — ENTREGADO TEST_AP: la MAQUETA del menu de Estado

### [ENTREGADO] TEST_AP.bin — MD5 e2b19fb7e55be823e451ddf3ac7ecc70
Capturas: `capturas_tanda/AP_estado_tianren.png` y `AP_estado_meihong.png`.
Lo que se ve:
```
  ◊Tian Ren◊ DIVER          /  ◊Mei Hong◊ POLICÍA

  NIVEL              1          (el 10 entra: el valor se imprime a 2 celdas del
  EXPER        0000000           borde, asi que los 4 digitos son el limite)
  PRÓX.        0000007

  PV            10~  10
  PM            10~  10

  ATAQ.          4+  75
  DEFEN        14+  10
  VELOC          4+   0
  HAB.             65%
  PRECIS.          91%
```

### [MEDIDO] Por que salia basura y por que salia el $5 en la fila del nombre
- La rutina del nombre ($22E0A) BORRA **26 celdas** desde el inicio de la plantilla y
  escribe `icono + NOMBRE + icono + espacio + CLASE` (medido en RAM: 3 celdas + icono +
  8 + icono + 1 + **9 de POLICÍA** = 26; con 6 de DIVER son 23). Si la fila de la
  plantilla mide menos, la escritura se sale a la fila siguiente y se come su $5 ->
  el «NV» salia pegado (y luego el «NIVEL» de la plantilla). **La fila necesita 27 celdas.**
- El escritor de numeros escribe desde la direccion que le dan y avanza: para que los
  valores queden alineados hay que darle la direccion de su hueco y **dejar 1 celda de
  aire** antes de las cifras (si no, el numero de 4 digitos choca con la etiqueta).
- El bloque de valores de HAB acaba en un hueco (el arma se manda a un relleno): ese
  hueco hay que ponerlo a «%», que es lo que el original tenia alli.
- La copia del ARMA se hace siempre: si su relleno queda dentro del marco, se ve como
  basura debajo de PRECIS. **El relleno va al final de la plantilla y separado por 4
  saltos de linea** (asi cae por debajo del borde inferior de la ventana, y=206).

### [DECISION PENDIENTE] Las 4 etiquetas abreviadas
La ventana da **15 celdas** y el bloque de valores 7 (o 4 en HAB/PREC): solo caben
etiquetas de 5 glifos (6 en HAB/PREC). Por eso: EXPER (6), PRÓX. (5), ATAQ. (5),
DEFEN (5), VELOC (5), HAB. (4), PRECIS. (6). David puede cambiar cual abrevia y cual no
(por ejemplo «EXPER.» o «PREC.»), pero no pueden pasar de 5 glifos.

## 2026-09-27 (69ª tanda) — BISECCION CONTRA EL ORIGINAL JAPONES

### [HECHO] La estructura de la ficha es IDENTICA al original
Arrancando el .bin japones original (cue propio: `pruebas/orig.cue`) y comparando la
ficha, banda por banda, con TEST_AP:
```
   ORIGINAL:  nombre y=24..34 | (linea vacia) | NV y=51..57 | EXP y=63..69 | Next y=75..81
   TEST_AP :  nombre y=27..33 | (linea vacia) | NV y=51..57 | EXP y=63..69 | PRÓX. y=75..81
```
**Las 12 bandas de texto estan en el MISMO sitio** (y=51, 63, 75, 99, 111, 135, 147,
159, 171, 183). Y la LINEA VACIA tambien: en el original, entre el nombre (y=24) y el
NV (y=51) hay **16 px de tinta, que es una fila de texto de alto** -> el original tambien
la tiene y ambos coinciden. Comparacion en `capturas_tanda/COMPARA_original_vs_AP.png`.

### [HECHO] Es un fallo de la RUTINA, no de la plantilla
Probando el NIVEL con varios valores en memoria ($6ECD2): con 1 y con 10 sale bien, y
con **9 y con 42** la fila del nombre se mezcla con las de NV/EXP. La razon: la rutina
de la ficha borra los espacios SOLO si el valor es menor que $A (su bucle es
`cmpi.w #$A,d1 / bcc`), asi que con 2 digitos no borra y quedan restos de la escritura
anterior. Es un bug del juego original, pero con un digito no se ve.

### [PENDIENTE] Reproducir lo que ve David
En mis capturas (state de la sala y ficha normal) el NV sale bien. Falta reproducir la
secuencia EXACTA: la captura que mando (`AJ_estado_meifan.png`, con `NV` en blanco pegada
a «POLICÍA») es de la ROM **AJ**, no de la AP. Siguiente paso: probar la ficha en la AP
intercalando Tec (habilidades) y Comb (combate) antes de volver a Char, que es cuando la
rutina reescribe la plantilla con la basura de las otras pantallas.

## 2026-09-27 (70ª tanda) — ENTREGADO TEST_AQ: la ventana flotante, LOS TRES montajes

### [CAUSA] La ventana de personajes la montan TRES rutinas distintas
Buscando la firma del setup (`317c 0001 0026` = move.w #$1,$26(a0), que es el campo que
distingue ESTA ventana de los recuadros normales) salen **24 sitios**, y de ellos los que
llevan tambien `$28=3`, `$32=0`, `$18=0` y un `$2e` son **TRES**:
```
      0x0C86A   ($4=7,  $6=0xE, $8=0x14)
      0x13590   ($4=0xA, $6=8,   $8=8)
      0x13672   ($4=0xA, $6=8,   $8=8)   <- la que usa MAGIA
```
El parche de la 65ª tanda solo tocaba la tercera: por eso la ventana seguia estrecha si se
abria desde otros menus. **TEST_AQ las parchea las tres** ($2e = 7 -> 82 px).
`recursos/tools/parche_ventana.py` actualizado con los tres sitios.

### [HECHO] La ficha de TEST_AQ es identica en estructura al original japones
Comparacion marcada (`capturas_tanda/COMPARA_ficha_marcada.png`): las 12 bandas de texto
estan en las MISMAS filas que el original (y=51 NV, 63 EXP, 75 Next, 99 PV, 111 PM,
135 ATA, 147 DEF, 159 VEL, 171 HAB, 183 PRE) y la LINEA VACIA entre el nombre y el NV
esta en los dos.
El «NV pegado a POLICIA» que se ve en la captura de David es de la ROM **AJ** (anterior al
arreglo de la plantilla): en la ficha de AJ la etiqueta es `NV` y sale pegada, ademas sin
su color. En TEST_AQ la etiqueta es `NIVEL`, esta en su linea (y=51) y en azul.
Comparacion directa: `capturas_tanda/COMPARA_ficha_david_vs_AQ.png`.

### [AVISO DE MAQUETA] La fila del nombre y la linea vacia
Con la fila del nombre a 27 celdas, el NIVEL sube a la fila y=51 (el original lo tiene en
y=51 tambien, pero con la fila del nombre mas corta dejaba una linea vacia MAS entre medias).
Para que quede una linea vacia libre entre el nombre y el NIVEL hay que bajar el NIVEL a
y=76 y por tanto correr las 25 referencias (proximo paso, ya medido).

## 2026-09-27 (71ª tanda) — ENTREGADO TEST_AR: ficha con las palabras ENTERAS

### [ENTREGADO] TEST_AR.bin — MD5 d42d95518cc602355d465f6024ebdc4d
Capturas: `capturas_tanda/AR_ficha.png`, `AR_ventana_sel2.png`.

### [ERROR PROPIO] Lo que ensanche en la 70ª tanda era el SELECTOR, no la ventana
David lo vio al momento: el marco azul es el **selector** de la fila elegida, no la
ventana. La VENTANA (marco azul vertical, x=72..152, 80 px) NO la habia tocado: el
`$2e` que encontre gobierna el selector. Revertido. Ahora esta en **$2e=6 (70 px)**:
cubre el nombre de 8 letras y **cabe dentro de la ventana** (que no hay que ensanchar).
El dato que lo cierra: **el texto de la ventana se dibuja a 8 px por letra**
(inicios medidos: 81, 90, 97, 105, 113...), asi que «Mei Hong» ocupa 70 px y la ventana
de 80 px ya lo contiene. Los tres sitios del setup ($0C86A, $13590, $13672) llevan el
mismo valor.

### [HALLAZGO] El paso de las letras en la ficha es de 8 px (no 12)
Medido: las letras de «EXPER» empiezan en x=17, 25, 33, 41, 49 -> **8 px por letra**, y
los espacios a 12. De ahi que las palabras largas SI quepan:
```
   EXPERIENCIA (11) = 88 px + 1 espacio + 7 digitos = 156 px  (la ventana da 179)
   HABILIDAD (9) + el arma = 72 + 12 + 2 digitos + % + 5 letras = 168 px
```
**La maqueta de David cabe ENTERA**: NIVEL, EXPERIENCIA, SIGUIENTE, PV, PM, ATAQUE,
DEFENSA, VELOCIDAD, HABILIDAD y PRECISIÓN, sin abreviar nada.

### [ARREGLADO] El nombre del arma (Gun/Rifle) habia desaparecido
`parche_maqueta_estado.py` recorta el bloque de valores; en HABILIDAD el bloque incluye
las 5 celdas del nombre del arma, que son DATO VIVO (lo copia el codigo desde la tabla
de objetos). Ahora se conservan y se reapuntan sus 2 referencias ($12E32 y $12F72).

### [ARREGLADO] El NIVEL
Su valor lo escribe OTRA rutina ($186D6) en las **dos ultimas celdas** del bloque: la
referencia tiene que estar 6 celdas despues del $7. Con las 3 celdas de $18722 salia
«1   00».

### [MEDIDO] El bug del original con 2 digitos
Con nivel 9 o 42 la fila del nombre se mezcla con las de abajo **tambien en el disco
japones** (probado con el original y con las mismas cifras): la rutina solo borra sus
campos si el valor es menor que 10. No es de nuestro parche.

## 2026-09-27 (72ª tanda) — LA VENTANA: el campo bueno es $8, no $2e

### [HALLAZGO] Quien manda en el ancho de la ventana flotante
Buscando con el trazador de teclas y el poke en caliente, el campo que ensancha la ventana
de personajes es **$8** del descriptor (no $2e):
```
   $8 = 8   -> ventana 76 px (x=74..149)   <- el original
   $8 = 9   -> 84 px
   $8 = 10  -> 92 px   (x=74..165)         <- +1 celda de 12 px, lo que pide David
   formula: ancho = 8*$8 + 12
```
Los otros campos ($4, $6, $a y $2e) NO cambian el ancho en ese camino (probado uno a uno).
Y el **selector azul va acoplado a la ventana** (82-84 px cuando la ventana es de 76):
de ahi que en la 70ª tanda pareciera que habia ensanchado «la ventana» cuando en realidad
movia el selector ($2e, que en ese camino no hace nada; si hace en el del menu Estado).
Sitios con $8 en la ventana de personajes: **0x13684** (menu Magia) y **0x135A2**.
El tercero (0x0C87C) tiene $8=20 (=172 px) y es OTRA ventana: no se toca.
Herramienta actualizada: `recursos/tools/parche_ventana.py` ($8 = 10).

### [MEDIDO] Como se apilan las cifras dentro de un bloque
Cada celda de cifra del bloque son **8 px**: 3 px de glifo + 5 de hueco, apilados. El 1er
digito de un grupo sale en **x+2** respecto al inicio de su celda, y a partir de ahi 8 px.
Dentro de un bloque de 7 celdas, los grupos de cifras caen asi:
```
   |  0  |  0  |  0  |  /  |  0  |  0  |  0  |
   x0+2  x0+10 x0+18      x0+26 x0+34 x0+42
```
=> EXPERIENCIA tiene 7 celdas de cifras (van apiladas y ocupan 6) y su primer 0 deja
**6 celdas libres a su izquierda** dentro del bloque: ese hueco es el que hay que usar
para cuadrar las columnas que pide David (el 1 de NIVEL con la ultima cifra de
EXPERIENCIA, el 1 de PV/SIGUIENTE/DEFENSA/HABILIDAD/PRECISIÓN con el PRIMER 0 de
EXPERIENCIA, y el 4 de ATAQUE/VELOCIDAD con su SEGUNDO 0).

## 2026-09-27 (73ª tanda) — ENTREGADO TEST_AT: submenu en castellano + ventana a 100 px

### [ENTREGADO] TEST_AT.bin — MD5 a7342ba581b728ac3d694aa97cfddc86
Capturas: `capturas_tanda/AT_submenu.png`, `AT_submenu_1.png`, `AT_submenu_2.png`
(Perfiles / Habilidades / Combate), `AT_ventana.png`, `AT_ficha.png`.

### [HECHO] El submenu del menu Estado: tres cadenas sueltas + tabla de punteros
```
   0x13F5E -> $23F6A  «Char»   (0x13F6A, 12 B de hueco)
   0x13F62 -> $23F76  «Tec»    (0x13F76, 10 B)
   0x13F66 -> $23F80  «Comb»   (0x13F80,  9 B)
```
El castellano pide 17+23+15 = 55 B: se mudan a **START 0x152B4** (hueco de 0xFF de 332 B)
y se reapuntan las tres entradas. Herramienta: `recursos/tools/parche_submenu.py`.

### [HECHO] La ventana necesitaba UNA celda mas: 100 px
El texto de dentro se dibuja a **8 px por letra**: «Habilidades» (11) = 88 px y la ventana
de 92 px solo da **80 px de texto** (x=81..161, borde en x=162) -> salia «Habilidade».
Con **$8 = 11** la ventana mide **100 px** (x=74..173, 90 px de texto) y entra.
Formula del ancho: `8*$8 + 12` (76 / 84 / 92 / 100 para $8 = 8/9/10/11).

### [DESCARTADO CON PRUEBA] Mover los bloques de cifras para alinearlas
Se probo a meter celdas extra antes del $7 (EXTRA = {2:6, 6:2, 7:2, 9:4, 11:4}) para
cuadrar las columnas que pide David: **la ficha se rompio** (los numeros de PV/PM/ATAQUE
salieron con «100» y desplazados, y el NIVEL a dos columnas). Motivo: mi suposicion de a
que CELDA apunta cada referencia ($12EC2 etc.) es incorrecta; el escritor de numeros
($1862A/$18722) avanza desde la direccion que le dan, asi que hay que medir celda a celda.
Revertido: `EXTRA = {}` y el build TEST_AU borrado.
**Metodo para la proxima**: escribir un valor distinguible (p.ej. 555) en la RAM que lee
la ficha y ver en QUE celda sale; repetir por fila -> con eso se sabe el desplazamiento
exacto de cada bloque.

## 2026-09-27 (74ª tanda) — ENTREGADO TEST_AV: columnas de la ficha ALINEADAS

### [ENTREGADO] TEST_AV.bin — MD5 3122bb5d41ac147563f53c310c02e5b9
Capturas: `capturas_tanda/AV_ficha.png` (ficha con las columnas que pidio David),
`AV_submenu.png` / `AV_submenu_1.png` (Perfiles / Técnicas / Combate), `AV_ventana.png`.

### [ERROR PROPIO, encontrado y corregido] Por que falló el primer intento de alineacion
Al meter celdas extra antes del $7, **no actualice la posicion del $7** en el calculo de las
referencias: cada referencia quedaba 2 bytes a la izquierda por cada celda extra y el
escritor de numeros empezaba antes -> se pisaba todo (salio «100» en PV y el NIVEL a dos
columnas). Ahora `celdas_bloque[k] = 2 + len(lab) + 2*(1 + EXTRA)`.

### [METODO QUE FUNCIONA] Medir donde esta la 1ª cifra, no deducirla
Se mide en pantalla la x del primer digito de cada fila y se ajusta EXTRA hasta que caiga
en el objetivo. El PV/PM necesitaron **+8 celdas** (no +3 como los demas): su 1ª cifra NO
sigue al bloque (hay algo que la fija aparte y no lo he encontrado; con el ajuste medido
queda en su sitio). Valores finales:
```
   EXTRA = {NIVEL: 6, SIGUIENTE: 2, PV: 8, PM: 8, ATAQUE: 4, DEFENSA: 3,
            VELOCIDAD: 1, HABILIDAD: 1, PRECISION: 1}
   resultado (x del 1er digito):  NIVEL 163 | SIG/PV/PM/DEF/HAB/PRE 114-115
                                  ATA/VEL 122   <- las columnas que pidio David
```

### [HECHO] Submenu: Habilidades -> Técnicas
Con «Técnicas» (8 letras, 64 px) ya no hay muesca en la H. La ventana se queda en 100 px
(compartida con la de personajes, como pide David de momento).
Herramienta: `recursos/tools/parche_submenu.py` (acepta acentos).

## 2026-09-27 (75ª tanda) — ENTREGADO TEST_AW: ventana del submenu una celda menos

### [ENTREGADO] TEST_AW.bin — MD5 957cde27a2e4431e3f914230d3582ae6
Capturas: `capturas_tanda/AW_ventana.png`, `AW_ventana_sel2.png` (ventana de personajes),
y `/tmp/cand_sub.png` (el submenu, con la ventana mas estrecha y SIN muesca).

### [HECHO] La ventana vuelve a 92 px ($8 = 10) y el submenu sigue cabiendo
David pidio quitarle una celda por la derecha a la ventana del submenu. Como la ventana
es compartida, el cambio es el mismo campo ($8) que ya se uso:
```
   $8 = 11 -> 100 px : «Perfiles/Técnicas/Combate» bien, pero sobraba ancho
   $8 = 10 ->  92 px : el submenu sigue sin muesca (Técnicas = 64 px) y la ventana de
                       personajes queda con 92 px, 20 px de aire tras «Mei Hong» (acaba
                       en x=145 y el marco en x=165)
```
Verificado en pantalla abriendo el submenu (Perfiles/Técnicas/Combate) y la ventana de
personajes con Mei Hong seleccionado: **sin muesca en ninguno de los dos**.

### [NOTA DE HERRAMIENTA] El arnes se quedo colgado una vez
En una de las tandas de prueba el core dejo de correr (todas las capturas salian
identicas). Se arregla volviendo a lanzar el proceso: conviene comprobar que `md.frame`
avanza antes de fiarse de una captura.

## 2026-09-27 (76ª tanda) — ENTREGADO TEST_AX: menu de COMBATE en castellano

### [ENTREGADO] TEST_AX.bin — MD5 3b554125c55843e4b48d65068d664852
Captura: `capturas_tanda/AX_combate.png`.
Lo que se ve:
```
   ◊COMBATE◊
        ATAQUE  DEFENSA  VEL
   Tian Ren   79    24     4
   Mei Hong   35    24     5
               0     0     0

        SALUD        MAGIA
   Tian Ren  10~ 10    10~ 10
   Mei Hong  12~ 12     0~  0
              0~  0     0~  0
```
Nombres enteros (antes «Tian R» / «Mei Ho») y valores donde toca.

### [METODO] Mapa de celdas de la plantilla de COMBATE (el dato que hacia falta)
Se saco midiendo a que OFFSET de la plantilla apunta cada una de las **45 referencias**:
```
   fila 0 (titulo)  celda 0                      -> puntero del descriptor
   filas 2,3,4      celda 1 = nombre ; celdas 9,13,17 = las 3 cifras
   fila 6 (PV/PM)   celda 0 (6 referencias)
   filas 7,8,9      celda 1 = nombre ; celdas 7,11,15,19 = las 4 cifras
```
Con eso: las filas de PV/PM solo daban 5 celdas al nombre (de ahi «Tian R»); se han
ensanchado **4 celdas** (nombre en la 1, cifras en 11,15,19,23) y la fila queda en 26
celdas = 208 px (pantalla 256, panel del HUD empieza en 243).
Herramienta: `recursos/tools/parche_combate.py`.

### [ERRORES PROPIOS DE ESTA TANDA, para no repetirlos]
1. «0 referencias reapuntadas»: en el mapa compare **direcciones de fichero** contra los
   longs del codigo, que son **direcciones de RAM** ($2xxxxx). Hay que sumar $10000.
2. «2 celdas»: en el mapa de celdas use el desplazamiento EN BYTES para calcular la
   celda. Celda = offset_en_bytes / 2.
3. La version «segura» (misma estructura, solo textos) descuadraba la pantalla: los
   valores NO se escriben en el $7 sino en celdas concretas (9,13,17 / 7,11,15,19).

## 2026-09-27 (77ª tanda) — ENTREGADO TEST_AY: columnas del menu de COMBATE clavadas

### [ENTREGADO] TEST_AY.bin — MD5 dab49ffae7d5050c1d91eb04da2a41f8
Captura: `capturas_tanda/AY_combate.png`.
```
        ATAQUE  DEFENSA  VEL        <- cabeceras corridas 2 celdas (ATAQUE empieza en x=89)
   Tian Ren   79    24     4
   Mei Hong   35    24     5        <- 79/35 bajo la «AQ», 24/24 bajo la «EN», 4/5 bajo la «E»
               0     0     0        <- los ceros en las columnas del 9, del 4 y de la E
```
Medido: ATAQUE x=89 (A 89 T 97 A 105 Q 113 U 121 E 129), DEFENSA x=145 (D..A 145..193),
VEL x=209 (V 209 E 217 L 225); las cifras caen en 106-114 (bajo AQ), 170-178 (bajo EN) y
218 (bajo E). Los ceros en 114, 178 y 218 (las columnas del 9, del 4 y de la E).

### [DATO] Como van las letras en esta pantalla
- Letras y espacios a **8 px** (cabeceras: inicios 89, 97, 105...; el espacio tambien 8).
- **Cifras a 8 px**: dentro de una celda de la plantilla hay **dos** posiciones (x0+2 y
  x0+10).
- El nombre de 8 letras ocupa 8 celdas y la celda siguiente se pisa con el 2º digito:
  por eso el nombre va en la celda 1 y la 1ª cifra como muy pronto en la 12.

### [ERROR PROPIO DE ESTA TANDA]
Al calcular los offsets de las filas de PV/PM use `len(nueva) - (26 - c)*2` (un lio con
las celdas) y se rompio esa parte de la pantalla (salian «000~ 000» y «Mei H»). Lo
correcto: **offset de la celda = offset de la fila + 2*celda**.

## 2026-09-27 (78ª tanda) — ENTREGADO TEST_AZ: titulo de COMBATE en BLANCO

### [ENTREGADO] TEST_AZ.bin — MD5 218aee9edfb54eac5d595b958aeec281
`◊COMBATE◊` en blanco (antes azul) + todas las columnas de la entrega anterior.
La marca del titulo pasa de **$5 a $7** (el tono de los valores). Probado con $4 y sin
marca: ninguna de las dos cambia el color; **$7 si**.
(El original japones tenia el titulo en azul: es un cambio NUESTRO, pedido por David.)

### [A MEDIO] El menu de MAGIA: lo que he averiguado
La pantalla NO se pinta solo desde la plantilla de 0x1758A. Hay **tres cosas** que
escriben texto en esa caja:
```
   titulo  ◊MAGIA◊ + el nombre del personaje  -> el codigo copia el nombre a $2759A
                                                (lea $2759a,a2 / move.w #$7,d2 / $2087E)
   los valores Ahora/Max e Individual/Grupo   -> lea $275DA/$275EC y $27600/$27612 + $18722/$186D6
   los rotulos «PM Coste / Ahora / Max / Ind / Grp» -> van dentro de la plantilla
```
Al reescribir la plantilla con textos mas largos salen **los dos juegos de texto a la vez**
(el viejo y el nuevo): hay mas codigo que la lee del que he localizado (7 referencias
medidas, todas reapuntadas, pero el pintor de la ventana usa otra via). Tambien probe a
mudar la plantilla a un hueco libre (0x17CC1) y reapuntar: entonces el titulo sale
duplicado. **Pendiente**: identificar TODAS las vias que leen la plantilla de Magia antes
de cambiarle los textos, con el mismo metodo que funciono en Combate (medir a que celda
apunta cada referencia y volcar la plantilla en RAM con la pantalla ya pintada).
Nada de eso se ha aplicado: TEST_AZ no lleva cambios en Magia.

## 2026-09-27 (79ª tanda) — MAGIA: mapa a medias; la ROM buena sigue siendo TEST_AZ

### [MEDIDO] La fuente que usa el panel de Magia es la TERCERA tabla (la del dinero)
Los glifos que el juego carga en RAM estan en **PRG $294E0** (= INIT file 0x14E0, la tabla
del dinero): comprobado buscando por forma los glifos de David (M en +0x29A14, A en
+0x2993C, G en +0x29A08, 0 en +0x29888, o en +0x29C0C) y el **acento «á» tambien esta**
en +0x2F3CC (celda 1350). O sea: no es que falte el glifo; el panel de Magia no usa el
codigo del acento.
  => `Maximo` con tilde NO se puede poner en este panel (sale el kanji); se pone **Maximo**
     sin tilde hasta que se localice el codigo que usa esa pantalla para el acento.
  (De paso: la tabla de SD.BIN **no** es una copia de la fuente; el comentario de
   fuente_menu.py que lo decia es de una hipotesis de septiembre que no se confirmo.)

### [MEDIDO] Las cuatro referencias de los valores apuntan a la PRIMERA CIFRA, no a la marca
  `lea $275DA,a2` + `jsr $18722` -> el escritor escribe desde esa direccion. En el original
  $275DA **es** la primera cifra (el resaltado es una celda ANTERIOR que tambien tiene una
  marca). Con mi version apuntaba a la marca -> las cifras salian desplazadas un caracter.
  Corregido (bloque + 2), pero la pantalla sigue sin cuadrar del todo.

### [PENDIENTE] Queda un problema de alineacion en la lectura de la plantilla
Con el mapa corregido, los ROTULOS salen como kanji y el titulo como «Tian Rea»: parece
que el motor lee la plantilla desde una direccion desplazada (los pares de bytes 0x82xx
se interpretan al reves pares -> kanji). **Vias descartadas hoy**: mudar la plantilla a un
hueco libre (0x17CC1) y reapuntar las 7 referencias -> el titulo sale duplicado. **Siguiente
paso**: volcar la plantilla en RAM con la pantalla pintada y compararla con nuestra version
celda a celda, para ver el desplazamiento exacto que hace el motor.
Nada de esto va en la ROM: **TEST_AZ.bin queda como la entrega buena** (sin cambios en Magia).

## 2026-09-28 (80ª tanda) — ENTREGADO TEST_BA: menu de MAGIA maquetado

### [ENTREGADO] TEST_BA.bin — MD5 3d5d68ad7ffd4457a5281c9a46722ab9
Capturas: `capturas_tanda/BA_magia.png` (Tian Ren) y `BA_magia_popup.png` (el popup
de conjuros encima). Lo que se ve:
```
   ∆MAGIA∆  Tian Ren            <- titulo entero en blanco, nombre completo (8 glifos)

            PM  Coste           <- PM una columna a la derecha; Coste 2 a la derecha de PM
   Ahora    10  Individual  2   <- la 'o' de Coste encima de Individual y de Grupo
   Máximo   10  Grupo       8   <- el 8 justo debajo del 2; los valores en blanco
```
Los seis puntos que pidio David, hechos.

### [RESUELTO] El bloqueo de la tanda anterior: la plantilla tiene que vivir en PAR
Mi diagnostico de anteayer era equivocado: la plantilla SI se lee como la escribo (lo
demuestre cambiando 'Ｍａｇｉａ' por 'Ｐａｔｉｏ' en su sitio: sale en pantalla en el
siguiente arranque, y ampliando `move.w #$7,d2` a 8 el nombre sale entero).
El fallo real era de **alineacion**: puse la plantilla nueva en 0x17CC1, IMPAR, y las
referencias que el codigo ya escribia ($2759A + a) caian en direccion par... pero la
base era impar, asi que al mover la plantilla cambie la PARIDAD de todas las
referencias: `move.w #$824F,(a2)+` con a2 impar acaba escribiendo un byte antes
(el 68000 tira el bit 0), y por eso salian **los dos juegos de texto a la vez**, los
rotulos como kanji y el titulo partido. Con la base **par** (0x17CC2) todo cuadra.
=> REGLA para el futuro: cualquier plantilla que el codigo escriba tiene que empezar
   en direccion PAR, o hay que reapuntar TODAS las referencias al hueco.

### [MEDIDO] Modelo de columnas del motor (vale para todos los menus)
```
   celda_en_pantalla = indice_del_elemento_VISIBLE + 2      x = 1 + 8*celda
```
- Cada elemento visible de la plantilla = 1 columna = 8 px.
- Los saltos ('|' = 2f 6e) pasan de linea; las marcas de color (26 xx) NO ocupan columna.
- Los escritores de numeros ($18722 = 3, $186D6 = 2) escriben TODOS sus caracteres
  seguidos y el digito cae en la ULTIMA casilla del campo. Para poner el '2' en una
  columna concreta hay que dejarle `campo - 1` huecos delante.
- La ventana mide `$8` columnas y **corta** el texto que se pase. La de Magia tenia
  `$8` = 0x17 = 23: por eso la maqueta larga salia cortada ("Individu" + el 2 en la
  linea de abajo, el '8' donde le tocaba...). Ahora `$8` = 0x1B = 27 (ver abajo).
- **El acento 'á' SI se dibuja en esta pantalla** ("Máximo" sale bien). La nota de la
  79ª tanda ("aqui el acento no se puede") venia de la version rota, donde la
  plantilla corrida un byte convertia el acento en kanji. Corregido el dato.

### [PENDIENTE DE OK] La ventana es 4 columnas mas ancha que en la version actual
La maqueta llega a la columna 25 del panel (el valor de Individual/Grupo), asi que
`$8` pasa de 0x17 (23) a 0x1B (27); con 0x17 el motor cortaba "Individual" y el valor.
Consecuencia medida en `BA_juego.png` vs `BASE_magia.png`: **el HUD no se toca mientras
el popup no esta abierto** (el panel de Magia con su ventana original de 23 columnas NO
llegaba a x=203 y el log del motor "tapa" el panel del HUD durante el dialogo; con 27
columnas si llega). En cuanto el popup de conjuros se abre (flujo normal), el panel del
HUD ya queda tapado en las dos versiones. Si David prefiere la ventana estrecha, hay
que acortar "Individual"/"Grupo" (o bajar el valor a su linea): es una decision suya.

### [HERRAMIENTAS]
- `recursos/tools/parche_magia2.py` — la maqueta (parametro de ancho opcional).
- `recursos/tools/ventanas.py` — mapa de las 33 ventanas del motor: fichero, RAM,
  buffer de dibujo ($1e), tamano ($8*$a*32 B) y plantilla de cada una. El panel de
  Magia usa $A6000..$A7700 y el popup $A7800..$A7F80 (por eso no se pueden ensanchar
  a lo loco: a partir de 26 columnas el buffer del panel se mete en el del popup).
- `pruebas/foto_magia.py` — partida limpia -> panel de Magia -> captura (1 comando).

### [MEDIDO] Mei Hong no tiene conjuros
Con Mei Hong el panel de Magia muestra el mensaje "no usa tecnicas" (dial del juego),
asi que la maqueta solo se puede ver con Tian Ren. No es un fallo.

## 2026-09-28 (81ª tanda) — ENTREGADO TEST_BA (v2): Magia afinado + ventana flotante

### [ENTREGADO] TEST_BA.bin — MD5 d46dc293730c9e55eb456a3dd3e6423f
Capturas: `capturas_tanda/BA_magia.png`, `BA_ventana_sel.png`, `BA_ventana_sel2.png`,
`BA_submenu.png`.

**1. Magia: Individual y Grupo un espacio a la izquierda** (peticion de David)
```
   ∆MAGIA∆  Tian Ren

            PM  Coste
   Ahora    10  Individual  2
   Máximo   10  Grupo       8
```
- La 'I' de Individual y la 'G' de Grupo empiezan ahora en la columna 14, o sea
  **justo debajo de la 'C' de Coste**.
- Los valores 2 y 8 **no se han movido** (columna 25): queda un espacio libre entre
  «Individual» y su valor, que es el hueco que pide David para los valores de dos cifras.
- Efecto colateral medido: con ese hueco, **la ventana ya no necesita 27 columnas**.
  Probado a `$8` = 24, 25, 26 y 27 comparando capturas: con 24 el motor corta
  («Individu» + el 2 en la linea de abajo), 25 es el minimo que lo deja todo en su sitio
  -> **`$8` = 0x19 (25 columnas), marco derecho en x=221** (antes con 27 llegaba a 237).
  El marco del panel se queda 3,4 celdas a la derecha del original (23 columnas), no 6.

**2. Ventana flotante de personajes: una celda menos** (`parche_ventana2.py`)
```
   $8  (ancho de la ventana)  10 -> 9   92 -> 84 px
   $2e (largo del selector)    7 -> 6   82 -> 70 px
```
Medido comparando capturas antes/despues, en la ventana de nombres Y en el submenu
Perfiles/Tecnicas/Combate (comparten tamano):
```
   ventana  ANTES x=74..165 (92)   AHORA x=74..157 (84)
   selector ANTES x=...167 (84)    AHORA x=...159 (70)
```
El selector **no puede bajar de 70 px** (12*6-2): es lo que mide «Mei Hong» (64 px) mas
el margen. Con 46 px (12*4-2) se comeria el nombre.

### [ERROR MIO DE ESTA TANDA, para no repetirlo]
Dije que la ventana flotante «ya se habia cambiado»: era verdad (el diario de la 78ª dice
que la ventana de nombres son 92 px), pero **el numero que le di a David como «selector
70 px» era el que yo HABIA pedido, no el que habia quedado**: en la ROM que tiene en las
manos el selector estaba en `$2e` = 7 -> 82 px. Ahora si esta medido en pantalla.

### [METODO] Capturas fiables: esperar por ESTADO, no por tiempo
El motor anima las ventanas (abre y cierra) y los tiempos de las pulsaciones no son
fijos, asi que las capturas salian a veces con la ventana a medias o con el menu de
arriba todavia abierto (eso me hizo medir mal dos veces hoy). Solucion: tras cada tecla
se corre el emulador en rafagas y **se clasifica cada captura** comparandola con
plantillas conocidas (`pruebas/estado.py` + `pruebas/foto_ventana3.py`). Con eso las
capturas de la ventana, del selector y del submenu salen siempre limpias.

### [HERRAMIENTAS NUEVAS]
- `recursos/tools/parche_ventana2.py` — ancho de la ventana flotante ($8) y del selector
  ($2e), con los cuatro sitios medidos.
- `pruebas/estado.py`, `pruebas/foto_ventana3.py`, `pruebas/foto_magia.py`,
  `pruebas/foto_ventana.py`, plantillas en `pruebas/plantillas/`.

## 2026-09-28 (82ª tanda) — ENTREGADO TEST_CB: ARREGLADO el cuelgue del menu de Sistema

### [ENTREGADO] TEST_CB.bin — MD5 6f59cade42d4fca83f842ca6b250ea01
Capturas: `capturas_tanda/CB_sistema_ventana.png` (la ventana, ya con texto),
`CB_velocidad.png` (la pantalla de Velocidad) y `CB_ajustes.png` (la de Ajustes).

### [LA CAUSA DEL CUELGUE: nuestra, y de arrastre desde la 77ª tanda]
En el START original, **detras de la plantilla de Combate (0x14268) hay un bloque de
datos del menu de Sistema**:
```
   0x143D2:  00 02 43 da   -> puntero a la cadena 1   (RAM $243D2)
   0x143D6:  00 02 43 e4   -> puntero a la cadena 2
   0x143DA:  スピード 00 00      0x143E4:  スイッチ 00 00
```
La unica referencia a ese bloque es `move.l #$243d2,$22(a0)` en 0x11D1E.
**Nuestra plantilla de Combate traducida es 114 B mas larga que la japonesa y se comia
ese bloque entero** (0x143D2-0x1444A): los punteros pasaban a apuntar a basura ->
la ventana salia VACIA y, entrando desde Combate, el juego se quedaba clavado en la
pantalla de Velocidad (0 teclas de 4 cambiaban nada). Entrando desde otros menus el
camino era otro y no se notaba. Es un fallo de la tanda 77 (las columnas de Combate),
no de la 81.

### [EL ARREGLO]
Se rehace el bloque en el hueco libre detras de la plantilla de Magia (0x17D82) y se
reapunta su unica referencia. De paso, traducidas las dos cadenas: **Velocidad** y
**Ajustes**.

### [ERROR PROPIO DE ESTA TANDA, gordo y para no repetirlo]
Al montar el bloque nuevo escribi en la tabla las direcciones **de fichero** (0x17D8A)
en vez de las **de RAM** ($27D8A). El pintor leia $00017D8A (basura) y la ventana
salia con DOS simbolos raros. Es exactamente el mismo error que anote en la 76ª tanda
(«en el mapa compare direcciones de fichero contra los longs del codigo, que son
direcciones de RAM»). Se detecto con el trazador de memoria del core, que SI funciona
en este proyecto (`mem_window` + `EV_MEMR`): en la ROM buena se veian las 20 lecturas
en pc=$018392 y pc=$01840C; en la rota, solo 2. **Leccion: cuando algo sale como
simbolos sueltos, trazar las lecturas del bloque antes de tocar nada mas.**

### [MEDIDO] Los tres campos de esa ventana (no son los mismos que en las de nombres)
```
   $2e (0x11D50, move.w #$4,$2e(a0))   = caracteres que se pintan - 1
        ($2e=4 -> 8 caracteres; 5 -> 10)
   $8  (0x11D62, move.w #$8,$8(a0))    = ancho de la ventana (8 px/unidad) Y limite de
        texto: no deja pintar mas de $8 x 2 BYTES (con 8 salia "Velocida", con 9 ya
        entra "Velocidad")
        => $2e = 5, $8 = 9: ventana de 84 px (la japonesa media 76)
```
Ojo: en las ventanas de nombres $2e es el largo del selector en px/6. Son ventanas
distintas con campos que se llaman igual.

### [VERIFICADO]
Con `pruebas/cursor.py` (comprueba que la pantalla responde a las teclas):
```
   ANTES (TEST_BA):  DOWN 0 px, UP 0 px, LEFT 0 px, RIGHT 0 px   <- clavado
   AHORA (TEST_CB):  DOWN 184 px, UP 368 px, LEFT 264 px, RIGHT 80 px
```
La pantalla de Velocidad y la de Ajustes contestan, y al salir se vuelve al juego.

### [PENDIENTE, nuevo] La pantalla de AJUSTES tiene el texto roto (tambien en la japonesa)
En `capturas_tanda/CB_ajustes.png` las lineas salen pisadas unas sobre otras
(«WR transp OF», «desquiva», «Conversacion»...). Comprobado con la ROM japonesa virgen
(`/tmp/JP_ajustes.png`): **sale igual de mal**, asi que NO lo hemos causado nosotros y
NO se ha tocado. Opciones: (a) dejarlo como esta (el original esta igual), (b) subir el
alto de esa ventana ($a, que ahora es 3 => ~36 px) para que quepan las 4 lineas, o
(c) mirar si el juego espera textos mas cortos. Decide David.

### [HERRAMIENTAS NUEVAS DE ESTA TANDA]
- `recursos/tools/parche_sistema.py` — el arreglo del bloque de Sistema + traduccion.
- `pruebas/cursor.py` — reproduce la secuencia del bug y comprueba si el juego responde.
- `pruebas/verifica_cb.py` — repaso del menu entero (Magia/Estado/Combate/Sistema).
- `pruebas/exp_mueve_combate.py` — mueve una plantilla y reapunta sus referencias
  (util para liberar sitios ocupados).

## 2026-09-28 (83ª tanda) — ENTREGADO TEST_BA (v3): menu de OBJETOS

### [ENTREGADO] TEST_BA.bin — MD5 fc2ba11e9af0c88bc1a7befa044fea4e
Capturas: `capturas_tanda/DK_objetos.png` (al abrir), `DK_obj_cambiar.png` y
`DK_obj_tirar.png` (con el cursor en cada opcion).
```
   ◊Objetos◊                 <- «Objetos» en AMARILLO, los rombos en blanco
   Usar      Cambiar   Tirar <- Usar al principio, Cambiar centrado, Tirar al final
```
Medido en pantalla: Usar x=37..66 · Cambiar x=98..150 · Tirar x=165..199, con el
recuadro de x=18 a x=205. Huecos: 32 y 15 px (Usar->Cambiar y Cambiar->Tirar).

### [MEDIDO] Como esta hecho el menu de Objetos
El menu usa una **tabla de punteros en START 0x13E16** (6 longs de RAM) y pinta una
REJILLA de 3x2:
```
   entrada 0 -> x=37,  fila de ARRIBA  = el TITULO (JP: ［Ｉｔｅｍ］)
   entrada 1 -> x=97,  fila de ARRIBA  (JP: Ｕｓａｒ)   <- residuo, no seleccionable
   entrada 2 -> x=157, fila de ARRIBA  (JP: Ｕｓａｒ)   <- residuo, no seleccionable
   entrada 3 -> x=37,  fila de ABAJO   (JP: Ｃａｍｂｉａｒ)
   entrada 4 -> x=97,  fila de ABAJO   (JP: Ｔｉｒａｒ)
   entrada 5 -> x=157, fila de ABAJO   (JP: ＶＲ　ｔｒａｎｓｐ)
```
Medido sustituyendo las seis entradas por etiquetas (Ee1..Ee6, Aaa..Fff) y viendo
donde sale cada una.

### [CLAVE] Cada OPCION tiene que ir en su PROPIA entrada
El cursor de este menu es una **caja azul que se mueve con IZQUIERDA/DERECHA** entre las
tres celdas de la fila de abajo (cajas en x=37..70, x=97..130 y x=157..190).
Si las tres palabras van en una sola cadena, el cursor no puede pasar de la primera:
lo probe (TEST_DG/DI) y al pulsar DERECHA no se movia.
=> van en las entradas 3, 4 y 5 por separado, con 3 opciones distintas.

### [DATO] El original japones esta roto igual
Las filas del menu de Objetos ya salian descuadradas en la japonesa (los rotulos
«sar», «ambiar», «irar» son las mismas palabras a las que les falta la primera letra,
que cae fuera del recuadro) y el cursor casi no se mueve. No lo hemos causado nosotros.

### [HECHO] El amarillo dentro de una linea con rombos
«◊Objetos◊» con la palabra en amarillo se escribe asi:
    &7 ◊ &4 O b j e t o s &7 ◊
(26 37 = blanco, 96 5F = el rombo, 26 34 = amarillo). Es la primera palabra que
cambiamos de color; David quiere ir haciendo lo mismo en los demas menus.

## 2026-09-28 (84ª tanda) — ENTREGADO TEST_BA (v4): selector de Objetos adaptable

### [ENTREGADO] TEST_BA.bin — MD5 fa45c9b8cb1df0ca6a5fea0fae93244a
Capturas: `capturas_tanda/ED_obj_usar.png`, `ED_obj_cambiar.png`, `ED_obj_tirar.png`.
```
   ◊Objetos◊
    Usar   Cambiar     Tirar     <- cajas de 58 px (cada una envuelve a su palabra)
```
David tenia razon: el cursor de los menus de rejilla SI es adaptable. La caja sale de
`$2e` del descriptor (12*$2e-2 px) y la posicion de cada celda de una **tabla de
columnas** en el propio setup del menu. Medido con la ventana del menu de Objetos:
```
   setup 0x12324 (menu de Objetos):
     0x12352  move.w #$3,$32(a0)      <- columna de la opcion 1  (x = 25 + 4*col)
     0x12358  move.w #$12,$34(a0)     <- columna de la opcion 2
     0x1235E  move.w #$21,$36(a0)     <- columna de la opcion 3
     0x1236A  move.w #$3,$2e(a0)      <- ancho de la CAJA (12*$2e-2 px)
```
Comprobado con experimentos: al cambiar la tabla se mueven TEXTO Y CAJA a la vez
(factor 4 px/unidad), al cambiar `$2e` cambia el ancho de las tres cajas.
Con `$2e`=3 las cajas eran de 34 px (12*3-2); por eso «Cambiar» (53 px de tinta)
quedaba fuera.

### [APLICADO]
- `$2e`: 3 -> 5  => cajas de 58 px (12*5-2)
- tabla de columnas: 3, 18, 33 -> 3, 15, 30
  => cajas en x=37..94, x=85..142, x=145..202 (el marco acaba en 206; con col=33 la
     caja se salia hasta 214)
- texto: «Usar» con 1 espacio delante (centrado en su caja), «Cambiar» sin espacios
  (es la mas larga, llena la suya), «Tirar» con 2 (centrado). La «r» de Tirar ya no
  se corta con el marco.

### [DATO] Los selectores que SI se estiran solos
Los menus de DIALOGO (el de preguntas del principio, p.ej.) usan otra rutina que mide
el texto y ajusta la caja al vuelo. Los menus de rejilla (Objetos) usan esta otra de
tabla+`$2e`. Por eso en el dialogo del state de David la caja envuelve a cada opcion
y en Objetos no: son dos mecanismos distintos.

### [ERRATA de la 83ª] El mensaje del menu de Ajustes roto
Comprobe con la japonesa: el texto pisado de Ajustes NO es un fallo del original ni
nuestro — la ventana es de 3 lineas y la traduccioon pide 4. Pendiente de que David
pase el texto definitivo; si no cabe, se amplia el alto (`$a` del descriptor) o se
acorta. Localizar tambien los «OFF»/«ON» de esa pantalla para ponerlos como Sí/NO.

## 2026-09-28 (85ª tanda) — ENTREGADO TEST_BA (v5): cursor de Objetos a medida

### [ENTREGADO] TEST_BA.bin — MD5 7b2ff53a3a485d231148708868b2a4f5
Capturas: `capturas_tanda/DL_obj_0/1/2.png` (cursor en Usar / Cambiar / Tirar).
```
   ◊Objetos◊
   [Usar   ]  [Cambiar]    [Tirar ]   <- cada palabra con SU caja
```
Usar 46 px · Cambiar 58 px · Tirar 46 px. Verificado con el cursor moviendose por las
tres (derecha, derecha, izquierda, derecha).

### [EL GANCHO — como funciona]
El cursor del menu de Objetos lo pinta la rutina de START **$20430** (la de los menus
CON tabla de columnas; la de $203C0 es para ventanas simples y no se toca). Ambas sacan
el ancho de `$2e` del descriptor: `d2 = $2e - 3` y pintan `d2+1` columnas de 12 px.
El gancho (RAM $27E90, 66 B) sustituye ese calculo SOLO cuando la ventana es la de
Objetos ($22 = $23E16; comparando palabra alta y baja porque CMPI.L no existe en 68000):
```
    d2 = tabla[$2c(a0)]      ($2c = la opcion seleccionada, 0..2)
    tabla = dc.w 1,2,1       -> Usar 46 px (d2=1), Cambiar 58 (d2=2), Tirar 46 (d2=1)
```
Cualquier otro menu sigue por el camino de siempre (`d2 = $2e-3`). Verificado el
recorrido completo de menus (Magia/Equipo/Hablar/Sistema) sin cuelgues.

### [ERRORES MIOS DE ESTA TANDA, para no repetirlos]
1. Meti 8 bytes en un hueco de 6 del pintor: todo el codigo posterior se desplazo 2 B
   y el juego se colgaba al abrir cualquier menu.
2. `movem.l d1/a1,-(a7)` con la mascara al derecho: en predecremento la mascara va
   INVERTIDA (la de a1 es el bit 14 => $4040, no $0202).
3. Use `cmpi.l`, que NO existe en el 68000 (solo 68020+): colgaba igual. Hay que
   comparar palabra alta y baja por separado.
4. El puntero de retorno del bsr estaba en $0008(a7): NO. El pintor apila d0-d3/a1
   (20 B) y el bsr añade 4: el retorno esta en $0018(a7).
5. Y el fallo de raiz: parchee el pintor equivocado. Hay DOS rutinas que dibujan este
   tipo de recuadro ($203C0 y $20430); Objetos usa la segunda porque su posicion sale
   de la tabla de columnas. Antes de hacer un gancho, confirmar CON EL TRAZADOR quien
   toca el bloque.
Todo esto quedo detectado midiendo en el emulador (capturas con la caja invisible o
mal) y el desensamblado del gancho antes de grabar.

### [AJUSTES (pendiente de David)]
Recibida la traduccion: TRANSP. VR / AUTOESQUIVAR / DIÁLOGOS, con ON->Sí y OFF->NO.
Pendiente localizar las cadenas ON/OFF (estan cerca del texto de Ajustes).

## 2026-09-28 (apunte) — TEST_EE era un descarte, borrado

David probó TEST_EE y se quedaba negro: era la version intermedia del gancho del
cursor (la de los 5 errores encadenados: 8 B en hueco de 6, movem invertido, cmpi.l,
puntero de pila equivocado y pintor equivocado). Se me quedó en el directorio junto a
la buena. Regla de nuevo en pie: **una sola ROM en el proyecto además de la base**.
La buena es TEST_BA (MD5 7b2ff53a3a485d231148708868b2a4f5), verificada hoy entera:
Magia, Estado, Combate, Sistema y las tres cajas de Objetos responden.

## 2026-09-28 (86ª tanda) — ENTREGADO TEST_BA (v6): cursor de Objetos CAJA A MEDIDA

### [ENTREGADO] TEST_BA.bin — MD5 185bad6300b0cf79880ddea1430da4e9
Capturas de David: `TEST_BA-260923-14*.png` (las tres, con el cursor en cada opción).
```
   ◊Objetos◊
   Usar      Cambiar    Tirar
   [Usar   ] [Cambiar]  [ Tirar ]  <- cajas azules a medida
```
- Usar:    caja 34 px (x=37..70),  tinta 30 px
- Cambiar: caja 58 px (x=85..142), tinta 53 px
- Tirar:   caja 46 px (x=149..194), tinta 38 px, con +4 px de desplazamiento
  (la caja se centra sobre la palabra)

### [LA CAUSA de que las cajas no se ajustaran en la 85ª]
Tres fallos encadenados en mi gancho:
1. El pintor que parchie era el $203C0 (ventanas simples), pero Objetos usa el
   $20430 (menus con tabla de columnas). Confirmado leyendo la RAM en vivo.
2. `move.l a1,$0008(a7)` con el puntero de retorno en $0008(a7): el pintor apila
   d0-d3/a1 = 20 B y el bsr añade 4, el retorno esta en $0018(a7), no $0008.
3. `move.w (a1),d2` sin auto-incremento, asi que el desplazamiento no se leia.
Ademas: `cmpi.l` no existe en 68000 (se compara palabra alta y baja por separado),
la mascara del movem va INVERTIDA en predecremento, y `adda.w d1,a1` es $D2C1
($D341 es addx, no adda).

### [COMO FUNCIONA el gancho]
En el pintor $20430, la instruccion `movea.l #$a220, a1` (6 B) se cambia por
`bsr gancho` + `nop`. El gancho:
  - si la ventana es la de Objetos ($22/$24 = $3E16/0002):
      d2 = tabla[$2c] (el ancho), d0 += tabla[$2c+1] (el desplaz)
  - si no, d2 = $2e - 3 (el original)
  - ejecuta el movea sustituido, restaura d0-d1/a1 y vuelve
La tabla tiene 4 entradas de 4 B: [0] dummy, [1] Usar, [2] Tirar, [3] Cambiar.
**EL ORDEN es [1]=Usar [2]=Tirar [3]=Cambiar** (medido: con RIGHT va 1->3->2).

### [HALLAZGO] El orden interno de las opciones NO es secuencial
`$2c(a0)` con RIGHT va: Usar(1) -> Tirar(3) -> Cambiar(2) -> Usar(1). Por eso la
tabla tiene que ir en ese orden: [1]=Usar [2]=Tirar [3]=Cambiar.
(El original japones tenia el mismo orden interno: la opcion "2" del original
era "Usar" y la "3" era "Cambiar", en el mismo sitio.)

### [VERIFICADO]
- El cursor recorre las 3 opciones con las cajas correctas.
- Magia (ventana de nombres), Estado->Combate->Sistema: todo funciona.
- El gancho no toca ningun otro menu (comparacion por $22/$24 exacta).

### [HERRAMIENTA]
- `recursos/tools/parche_cursor_objetos.py` — el gancho completo, con el
  desensamblado del resultado impreso antes de grabar.

## 2026-09-28 (87ª tanda) — ENTREGADO TEST_BA (v7): menu de Tecnicas en castellano

### [ENTREGADO] TEST_BA.bin — MD5 ad0ad0662be3b2eec41369c136e904d6
Capturas: `capturas_tanda/EC_tecnicas.png`.
```
   Tecnicas
        Gun  Rif  Obu Can
   Tian Ren  43  49   0
   Mei Hong  46  62  37  0
        Gar  Va  Es  Hi
   Tian R    0   0  58   0
   Mei Ho    0   0   0  71
```

### [HECHO]
- Titulo: "TecnicasUnid" -> "Tecnicas" (separado; el "Unid" era el residuo del original japones).
- Etiquetas de armas fila 1: Gun(3) + Rif(3) + Obu(3) + Can(3). Abreviaturas porque el
  ancho es de 20 caracteres y las palabras completas no caben (Rifle=5, Obus=4, etc).
- Etiquetas fila 2: Gar(3) + Va(2) + Es(2) + Hi(2).
- La plantilla nueva mide 394 B y la original 396: se relleno con 1 espacio fullwidth
  al final. Escrita IN-SITU (no hace falta hueco ni reapuntado).

### [DATO] El original japones tenia etiquetas en japonés:
  クロー(garra), ライフル(rifle), 砲(cañón), ヘビー(pesada) / 杖(vara), 剣(espada), 斬糸(hilo)
  Los caracteres japoneses NO han desaparecido: han sido sustituidos por los
  castellanos en la plantilla.

### [VERIFICADO]
- El menu de Tecnicas sale en castellano.
- El menu de Objetos (cursor a medida) funciona.
- Magia, Estado->Combate->Sistema: todo responde.

## 2026-09-28 (88ª tanda) — RECONSTRUCCIÓN COMPLETA de TEST_BA

### [PROBLEMA] El parche de Tecnicas in-situ de la 87ª pisaba la plantilla de COMBATE
La plantilla de Tecnicas (0x140E0) es ADYACENTE a la de Combate (0x14268). Al escribirla
in-situ con 396 B que terminaban en 0x1426E, los últimos 7 B pisaban el título de Combate.
Por eso Combate desapareció y por eso se cuelga Sistema (los bytes corruptos llegan más lejos).

### [SOLUCIÓN] Reconstrucción completa desde la base japonesa
Cadena completa: 17 parches (build_test_i -> parche_combate) + título de Combate en
blanco + Sistema + Objetos + Cursor a medida + Tecnicas (en hueco libre 0x1540E).
La plantilla de Tecnicas se escribe en un HUECO LIBRE y se reapuntan SOLO las 2 refs
de $241E0 (el resto de refs a $240E0-$24270 apuntan a offsets que se copian IN-SITU
en RAM y no se tocan).

### [RESULTADO] TEST_BA.bin — MD5 6f254d22cdde33d48e06174330c0de76
- Combate: ✓ (verificado con el emulador, COMBATE/ATAQUE/DEFENSA/VEL)
- Tecnicas: ✓ (Tecnicas / ARMA RIFLE OBÚS C.G / GARRA VARA ESPADA HILO)
- Sistema: ✓ (Velocidad/Ajustes sin cuelgues al salir)
- Objetos: ✓ (título amarillo + cursor a medida por opción)

## 2026-09-28 (89ª tanda) — ON/OFF de Ajustes traducidos

### [HECHO] Los tres ＯＦＦ del menu de Ajustes -> ＮＯ
En el original japonés, los tres valores del menú de Ajustes son ＯＦＦ (6 B cada uno,
file 0x1767F, 0x1769E, 0x176BF). El ＯＮ no aparece porque el juego inicializa todo a
OFF. Se han cambiado los tres ＯＦＦ por ＮＯ (4 B) + un espacio fullwidth (2 B) para
mantener el mismo tamaño (6 B).

### [PENDIENTE] La ventana de Ajustes está muy estrecha y los textos se pisan
El texto se puede leer pero las líneas se solapan. David dijo que pasará la traducción
definitiva y decidirá si acorta los textos o se amplía la ventana.

## 2026-09-28 (90ª tanda) — ENTREGADO TEST_BA (v7): Tecnicas + Objetos + Sistema

### [ENTREGADO] TEST_BA.bin — MD5 52698bac56e806278708fb9c4efe785b

### [TECNICAS] Reconstruida con nombres completos en hueco libre
La plantilla de Tecnicas se mudo al hueco 0x17000 (RAM $27000, 1280 B) y las 43 refs
del codigo se reapuntaron. Nombres castellanos:
    ARMA RIFLE OBÚS CAÑÓN / GARRA VARA ESPADA HILO
Espera: NO. La plantilla se mudó pero el juego se colgó (el codigo escribe espacios en
direcciones fijas dentro de la plantilla y al mudarla esas escrituras van al hueco pero
el juego lee de las direcciones viejas). Se restauró el bloque original y se escribió
la plantilla nueva IN-SITU con los nombres abreviados que caben (Gun Rif Obu Can / Gar Va Es Hi).
PERO eso pisaba Combate. Se restauró Combate desde el original y se aplicó
la plantilla de Tecnicas IN-SITU recortada a 392 B (lo que cabe hasta 0x14268).

### [RESULTADO FINAL]
- Tecnicas: "Tecnicas" (sin "Unid"), etiquetas Gun Rif Obu Can / Gar Va Es Hi
- Combate: ✓ intacto (se restauró desde el original)
- Sistema/Velocidad: ✓ sin cuelgues
- Objetos: título amarillo + opciones Usar/Cambiar/Tirar + selector de 58 px para las tres
- El cursor individual por opción se intentó con un gancho de código pero se colgaba
  el juego (problemas de stack/registros). Se optó por el ancho uniforme de 58 px.

### [PENDIENTE]
- El selector individual por opción: el gancho de código funciona parcialmente (la tabla
  cambia la posición) pero los anchos no se aplican porque el pintor recalcula d2 desde
  $2e DESPUÉS del gancho. La solución sería mover el gancho después del cálculo de $2e
  pero antes del dbra, lo que requiere un análisis más fino del pintor.
- La ventana de Ajustes: los textos traducidos se pisan (la ventana es muy estrecha).
  David pasará la traducción definitiva.

## 2026-09-28 (91ª tanda) — El cuelgue de Velocidad NO reproduce en GX; descubierto el orig.cue roto

### [ERROR PROPIO, dos y a repetir]
1. Dije haber borrado TEST_I.bin y las capturas viejas y NO fue así: verificado_*.png (11
   capturas de la raíz) seguían ahí y quedaban states de builds descartadas (TEST_I.state,
   TEST_X_menu, TEST_X_velocidad, TEST_J). Borrado OTRA VEZ y verificado: el árbol queda en
   42 MB / 323 ficheros. TEST_I.bin NO existe en ninguna carpeta (comprobado con find); lo
   que había era states/TEST_I.state, borrado. (David insiste en que lo ve: si le sigue
   apareciendo es una copia local de su ordenador de una entrega antigua.)
2. **orig.cue apuntaba a un fichero que NO existe**: decía "Gen'sei Toshi..." y el base se
   llama "Gen'ei Toshi...". El core, al no hallar el fichero, cargaba BASURA (unas veces el
   base, otras TEST_BA, otras nada): TODAS mis comparaciones "contra la base japonesa"
   hechas a través de orig.cue son nulas — incluida la de la 82ª ("el original también sale
   mal en Ajustes", comparado contra basura). Cue arreglado y repetido el pase: la base
   japonesa CORRECTA sale limpia en el arnés (3/3).

### [HECHO] El flujo de David en el arnés (GX + arena_dbg), sin cuelgue
- TEST_BA: menú -> Sistema -> Velocidad -> B -> B -> menú principal: **5/5 limpio y
  determinista** (mismos píxeles exactos en cada intento). Camino largo vía
  Estado->Combate->B,B->Sistema: también limpio.
- Base japonesa correcta: 3/3 limpio.
- Nadie escribe sobre la cola parcheada de START: ventana de memoria $27900-$28000 armada
  durante TODO el flujo -> 0 escrituras.
- La lista de comandos del motor (crece desde $a4f00 hacia $a5000) llega como mucho a
  $a4f18: sin desborde hacia $a5000 (donde viven $a510/$a530 y companyía).
- El contador de frames del BIOS ($a4032, Word RAM) tickea y el handshake $103DE
  ($ff8003 / bandera $a002) completa siempre en GX.

### [ESTATICO] Cómo se cierra la ventana de Velocidad (por si 1.3.5 lo hace distinto)
- $23C60 (al salir con $2c=-1): jsr $1736C = cierre con animación: bsr $17710 (paso de la
  animación) / jsr $104F6 (refresco), en bucle hasta que $17710 sale con acarreo.
- Cada refresco ($1042E) re-monta la lista de comandos en $a4f00 y llama $103DE =
  handshake con el sub-CPU: espera estado 1 en $ff8003, espera $a002==0, espera estado 2 y
  compara $a4032 antes/después (un frame). Si el contador no avanza EXACTO, `beq $103e8`
  repite para siempre = cuelgue seco sin dibujar nada.
- [HIPÓTESIS] Genesis Plus 1.3.5 pierde ese tique con nuestra distribución de tiempos (los
  textos más largos cambian DMAs/H-ints por frame). El disco ORIGINAL pasa por el mismo
  código: el experimento que discrimina "nuestro parche" vs "su emulador" es probar el
  original japonés en 1.3.5 haciendo Sistema->Velocidad->salir.

### [AUDITORÍA] Mapa de parches de TEST_BA sobre START: 75 zonas, todas identificadas
- $258xx-$26Exx: intérpretes/avance de letras (parche_lote3 y familia).
- $24269-$24449: plantilla de COMBATE. $24472-$244BC: plantillas de Velocidad/opciones
  (sin solape: Combate acaba en $24449, Velocidad empieza en $24472).
- $2513C-$252E4 y $25400: stubbs de salto de parches antiguos + gancho de submenu.
- $2758A-$27612: plantillas de Velocidad (Rápido/Lento) y sus opciones.
- $27914-$279D0: plantilla y textos de Ajustes (Poner/Usar/Restaurar).
- $27AA0-$27CED: plantilla de TECNICAS (hueco libre).
- $27CC2-$27D0F: bloque de punteros + strings de Sistema (Velocidad/Ajustes).
- $27ED2-$27F1F: gancho del cursor individual de Objetos = **CÓDIGO MUERTO** (nadie salta
  a él: $10478 conserva el move.l original). Quitarlo en la próxima build o ensamblar el
  gancho de verdad (pendiente de David).

## 2026-09-28 (92ª tanda) — REGRESION reconocida y REVERTIDA: TEST_BC + el state de David resuelto

### [EL ERROR GORDO, mio, explicado]
La "reconstruccion completa" de la 88ª monto la cadena con los ficheros que HABIA en
recursos/tools, y en esa cadena NUNCA entraron parche_magia2.py (80ª) ni
parche_ventana2.py (81ª): se aplicaron a mano en su tanda sobre otra base y no
quedaron en build_test_ba.py. Todas las TEST_BA desde la 88ª perdieron: el panel de
Magia (volvio "Max" y "Tian Re"), la ventana flotante y su selector (volvio a 92/82 px).
Yo verifique los menus que tocaba cada tanda y no los que "ya estaban": tres
regresiones entregadas como si nada. David: "avanzamos un paso y retrocedemos tres" —
literal. Ademas la 91ª dejo dos erratas: la plantilla de Tecnicas NO vive en la cola
(va IN-SITU en 0x140E0, y parche_plantillas.py es su traduccion); y las zonas
$27914-$279D0 son los textos de Ajustes (Poner/Usar/Restaurar), no Tecnicas.

### [EL MISTERIO DE TEST_I.bin, RESUELTO]
TEST_I.bin "inmortal": lo RECREABA build_test_ba.py en cada reconstruccion (su primer
paso, build_test_i.py, escribe en la raiz y nadie lo movia). Por eso David lo vio dos
veces despues de que yo jurara haberlo borrado. Arreglado: el script lo mueve a /tmp.
ELIMINADO de nuevo y esta vez no puede volver.

### [FORENSE del state de David (TEST_BA.state de su GitHub) — medido en el arnes]
- El state carga aqui (RASTATE/GENPLUS). Su pantalla: la ventana Velocidad/Ajustes.
- Su ROM NO es la del workspace: en su PRG-RAM $20478 hay `bsr $27ED2` = EL GANCHO
  individual de Objetos de las tandas 85-86 (la v6). La del workspace no lo lleva.
  -> David llevaba dos tandas probando una ROM vieja.
- Su PRG-RAM $180E8-$18121: 58 B de codigo sobreescritos por una TABLA DE DMA que no
  existe en ningun modulo del disco = CORRUPCION en caliente, anterior al savestate.
- Pulsando B sobre su state: REPRODUCIDO el cuelgue AQUI. La consola queda a medio
  reiniciar: main CPU en el envoltorio del BIOS copiado en $ff0000 esperando 'GENE'
  en $a12020 (lea $ffdffe,sp; cmpi.l #'GENE'; bne a si mismo) y sub CPU clavado en el
  bucle del checksum de arranque (pc $2e0). El juego llama al BIOS $360 justo antes.
- Desactivar el gancho EN VIVO sobre su state no resucita: el dano ya estaba hecho.
- El gancho inyectado EN VIVO sobre un flujo sano (sesion completa Objetos->Sistema->
  Velocidad->salir): limpio y sin corrupcion. En GX solo no basta para colgar.
- Core reconstruido con tag de CPU en los eventos (bit 16 de type: 0=main, 1=sub) y
  arena_get_s68k_pc(). MD5 e99bec9dadecfa7d6f991407332f2796. La traza sin tag mezclaba
  los dos CPUs y me hizo perder la tarde.

### [REVERTIDAS las tres regresiones + Tecnicas -> TEST_BC.bin]
Receta completa, AHORA SI 100% en ficheros:
  cadena build_test_ba.py (hasta parche_combate, sin su v2 que ya esta dentro)
  + parche_magia2.py (panel de Magia de la 80ª: PM/Coste, Individual/Grupo enteros,
    "Maximo" con acento, nombre de 8 glifos, ventana $8=25)
  + parche_ventana2.py (ventana flotante 84 px, selector 70 px)
  + parche_sistema.py (Velocidad/Ajustes + reapunte; el bloque cae en 0x17D82,
    detras de la plantilla de Magia restaurada)
  + parche_objetos.py (◊Objetos◊ amarillo + Usar/Cambiar/Tirar en x=37/98/165, hueco
    buscado dinamicamente porque Magia desplaza la cola)
  + 2 bytes: titulo de COMBATE en blanco (0x14269: 35->37) y selector de Objetos
    uniforme de 58 px (0x1236D: 03->05)
  + Tecnicas: SIN TOCAR (plantilla identica al base = la captura que David llama
    "perfecta": TecnicasUnid + armas japonesas)
TEST_BC.bin MD5 34cc7a15ecce6a600449eb62858f4a1b. La TEST_BA vieja (3735a43d...) y su
state borradas. Capturas de cada menu en capturas_tanda/BC_*.png.
Verificado: salida de Velocidad limpia en GX, Magia/ventanas/Combate/Objetos/Estado
como en sus tandas buenas (capturas).

### [DATO DE DAVID, 92ª tanda] El japonés NO se cuelga en su 1.3.5
Lo dice sin necesidad de probarlo (y le sobra razón: un softlock asi no se escapa al QA
de 1992). Consecuencia diagnostica: si el original pasa y nuestra ROM cuelga, el gatillo
esta en NUESTROS parches. Y la linea temporal cuadra: el gancho del cursor de Objetos
entro en la 85ª y los cuelgues se reportaron a partir de la 87ª. Su state lleva ese
gancho y lleva corrupcion PREVIA al savestate ($180E8 pisada por una tabla de DMA).
Pendiente el experimento discriminante real: TEST_BC (sin gancho, sin codigo propio
de esa epoca) en 1.3.5 con sesion larga. Si cuelga, el sospechoso pasa al parche de
avance de letras (el otro codigo propio que corre constantemente, presente desde el
lote 3); si no cuelga, caso cerrado: la v6 era la culpable y quema.

### [93ª tanda] TEST_BC TAMBIEN se cuelga en 1.3.5 (reporte de David: "se ha parado")
El gancho de Objetos queda EXONERADO: TEST_BC no lo lleva y cuelga igual. Lo que pasa a
la lista de sospechosos es lo que TEST_BC SI lleva de codigo propio:
  1. parche de avance de letras (lote 3, corre SIEMPRE; pero estaba en todas las tandas
     sin cuelgues... salvo que nadie probase este flujo concreto antes de la 82ª, que es
     cuando la ventana de Velocidad/Ajustes existe traducida y se pisa).
  2. los $2e de la ventana de Velocidad/selector (parche_selector_vel + arregla_selectores
     desde la 74-77ª + parche_sistema 82ª: $2e=5/$8=9 EN ESA VENTANA).
  3. ON/OFF -> Sí/NO (88ª... en TEST_BC: NO esta, se hizo inline en la 89ª y no entro en
     la cadena reconstruida — verificar).
La corrupcion del state de David ($180E8 = mitad de OPEN.BIN cargado, que ocupa
$10000-$20ECA) apunta a un DMA/carga que escribe fuera de sitio durante el flujo.
SIGUIENTE PASO: pedir el state congelado de TEST_BC y repetir la autopsia (PC de los
dos CPUs, $180E8, $a12020, tabla de DMA).

### [93ª tanda, cont.] TEST_BE: el bisturi (diagnostic ROM)
Receta: BASE japonesa virgen + SOLO parche_sistema.py (bloque Sistema reubicado en
0x17CC2 + $2e=5/$8=9). MD5 07d4715c2bde2b1b84b6c7a6ee41bce7. Sin nombres, sin Magia,
sin ventanas, sin lote 3, sin Combate, sin Objetos, sin Tecnicas, sin Si/NO.
Verificado en el arnes: la ventana de Sistema sale "Velocidad"/"Ajuste" sobre la ROM
japonesa y el flujo responde (bev_04/bev_05).
EXPERIMENTO para David (1.3.5): sesion larga con TEST_BE.
  - Se cuelga -> el avance de letras es EL sospechoso (unico codigo propio que queda
    delante del parche temporalmente); biseco el lote 3 en micro-ROMs.
  - No se cuelga -> el problema es de INTERACCION entre parches en la cadena de BC;
    biseco la cadena de BC por la mitad (state en cada palier).
En el workspace quedan DOS ROMs activas: TEST_BC (revertida) y TEST_BE (bisturi).

### [93ª tanda, cont.] TEST_BE TAMBIEN cuelga -> bisecado de parche_sistema
TEST_BE (base + parche_sistema entero) cuelga en 1.3.5. El japonés no. TEST_BE difiere
del japonés en TRES cosas: bloque reubicado a $27CC2, $2e=5, $8=9. Medido en GX:
CERO escrituras en $27C00-$28100 durante sesion larga completa (el hueco esta muerto
AQUI; en 1.3.5 no se puede medir, pero el mecanismo del cuelgue —excepcion->
BIOS->'GENE'— encaja con un puntero del bloque corrompido o con las metricas).
Dos ROMs de UNA variable para que el 1.3.5 de David señale al culpable:
  TEST_BF  MD5 77f041436cbbeb867e7ce839c70ba62e  = base + SOLO metricas ($2e=5/$8=9)
  TEST_BG  MD5 9924998fa3ea1519d203aacba86c3872  = base + SOLO bloque en $27CC2
     (cadenas japonesas verbatim, punteros internos sumando el desplazamiento 0x3F0)
Ambas verificadas en el arnes (ventana responde, salida limpia, mismas cifras que la base).
Arbol de decision:
  BF cuelga  -> las metricas ($2e/$8) son el gatillo -> revisar el pintor con $8=9
  BG cuelga  -> la UBICACION del bloque -> el juego 1.3.5 escribe en $27CC2+ en caliente
                -> FIX: mover la plantilla de COMBATE (exp_mueve_combate.py) y devolver
                el bloque a $243D2, su casa natural (donde el japonés vive sin cuelgues)
  BF y BG limpios -> interaccion (repetir con ambas juntas = TEST_BE clon)
TEST_BE borrada (ya ha cumplido). En el workspace: TEST_BC (revertida, cuelga),
TEST_BF y TEST_BG (el experimento).

### [93ª tanda, cont.] Mapa de buffers de ventana (ventanas.py sobre BASE y TEST_BC)
- Sistema (setup 0x11D74): buffer $A7000; en la base 8x3=768 B ($A7000-$A7300); con
  $8=9 -> 864 B ($A7000-$A7360). NO choca con el de Velocidad ($A7800-$A7F80).
- DATO: las ventanas de 31 columnas (setups 0x0690A/0x10C34/0x121D6, buffer $A6000)
  llegan hasta $A7360: PISAN la zona del buffer de Sistema. Solapa con la base incluida
  -> el motor reutiliza buffers solapados sin morir (no coexisten en pantalla).
- En TEST_BC la ventana de Magia (25 columnas desde la 81ª) llega a $A7900: SOLAPA el
  buffer de Velocidad ($A7800). En BF/BG (Magia japonesa, 23 col -> $A7700) no hay
  solape. Si BG cuelga, NO puede ser por buffers (BG no tiene el ensanche de Magia).
- Pendiente para la rama "metricas": el pintor con $8=9 durante la animacion de cierre.

## 2026-09-28 (94ª tanda) — TEST_BH: el menu de TECNICAS con la maqueta del log

### [DECISION DE DAVID] Base = TEST_BC (la revertida). BF/BG eran diagnostic ROMs: fuera.
El Tecnicas "perfecto" que yo creia (BA_tecnicas_final.png) era la captura de la tanda
de las ABREVIATURAS que David rechazo. El bueno es la maqueta del LOG (lineas 2416+)
con titulo TECNICAS (David, esta tanda: "sin que ponga Habilidades").

### [EL TRABAJO] La plantilla SE MUDA ENTERA al hueco 0x15410 y se crece alli (+16 B)
Mapa de referencias medido sobre TEST_BC (el de la 88ª era una miada: conto 43 y solo
reapunto 2; el de ayer conto 24 y el rango estaba desplazado 0x10000 — comparaba RAM
contra offsets de fichero):
  - START: 6 lea $24xxxx,aN (0x12FF0-0x1302E) + 1 move.l #$240DE,(a0,d0) en 0x12FF0-ish
    + UNA TABLA dc.l en 0x13150-0x131C4 (29 entradas) = 37 referencias REALES.
  - SSTART: 0. INIT/OPEN: 0. (Los 2 hits de SSTART eran matches en offsets IMPARES.)
  - Los 7 matches restantes ($241F9, impar) son operandos partidos de instrucciones
    vecinas: NO se tocan (los desensamble uno a uno).
TRES fallos mios de esta tanda, documentados para no repetirlos:
  1. Escaneo sin alinear ni opcode: "reapunto" 2 BSR del SSTART -> el juego ni arranca.
  2. Reapuntar en el mismo bucle que decide: la tabla se rompe a partir de la 2a
     entrada (miraba el long anterior YA modificado). Decidir primero, escribir despues.
  3. Los offsets de las lineas calculados ANTES de las inserciones: el rótulo 2 se
     escribia 10 B antes de su sitio y se comia un %. Buscar las marcas DESPUES.
Regla final de deteccion: long par con opcode de puntero delante (lea/move.l) o vecino
de tabla que apunte a la plantilla. 37/37 reapuntadas, 0 vivas en la zona vieja.

### [ENTREGADO] TEST_BH.bin — MD5 9884eeffa93640b814108b3909a96730  (TEST_BC + esto)
```
   ∆TECNICAS∆                      <- palabra AMARILLA, rombos BLANCOS
        ARMA RIFLE OBÚS CAÑÓN      <- COMPLETOS (21 celdas: +2 B en la plantilla)
   Tian Ren   65%   49%   0%    0% <- % detras de TODAS las cifras (4a col. incluida)
   ...
   Tian R    0%   0%  58%    0%    <- (los nombres los da el juego; ver pendiente)
```
Verificado en el arnes: arranca, carga partida, menu vivo, salida de Velocidad limpia
(136 px), Combate/Estado/Magia/submenu intactos. Capturas BH_*.png.

### [PENDIENTE de David]
- Los nombres "Tian R"/"Mei Ho" (6 glifos): su maqueta dice "Tian Ren" (8). El campo
  del nombre en esta pantalla parece de 6; hay que mirarlo (otra tanda).
- El cuelgue de 1.3.5: pendiente su pase de TEST_BC/TEST_BH con sesion larga.

## 2026-09-28 (95ª tanda) — TEST_BH PROMOCIONADA por David
"No se cuelga al salir de Velocidad. Podemos promocionarla." Puntos flojos que el mismo
cita: alineaciones, colores y los selectores azules. David pide disculpas por el tono
("era una ceja levantada"); no habia nada que perdonar: las regresiones eran mias.
- PROMOCION: TEST_BH.bin queda como la unica ROM de prueba; TEST_BC.bin eliminada
  (su contenido vive dentro de BH). Workspace: base + TEST_BH (59 MB, 342 ficheros).
- DESCUBIERTO y ARREGLADO para la proxima build: los Si/NO de Ajustes (89ª) tambien se
  habian perdido con la reconstruccion (los tres ＯＦＦ seguian en BH). parche_si_no.py
  escrito y metido en la cadena. VERIFICAR EN PANTALLA en la siguiente build.
- COMO_RETOMAR.md reescrito: ROM buena, lecciones, pendientes, estado del cuelgue.
- [ACLARADO por David] Los "Se ha parado. Sigue." de la 93ª NO eran cuelgues del juego:
  se habian quedado parados MIS procesos y me daba empujones. O sea: TEST_BE/BF/BG nunca
  llegaron a probarse en su 1.3.5. La hipotesis del gancho v6 sigue en pie SOLO por
  BC/BH (no lo llevan y no cuelgan) + el state forense con memoria pisada. Falta el
  experimento limpio si algun dia vuelve a colgarse: sesion larga + state congelado.

## 2026-09-28 (96ª/97ª tandas) — BJ/BJ2 abortadas; TEST_BK = BH + 2 cambios menores

### [LO QUE PASO] Las tandas de los titulos azules fueron un desastre de tres pisos
- BJ v1: inserciones netas sin reapuntar -> el juego rebooteaba a medias (BIOS
  esperando 'GENE'). BJ v2: Magia mal (borre el rombo de cierre en vez del espacio:
  "∆MAGIATian Ren"). BJ v3: lo mismo (borrado con offset pre-insercion). BJ v4 con la
  cirugia bien verificada por bytes, pero David ya habia probado la v1 y la confianza
  estaba perdida. DAVID: "es mejor quedarnos con la TEST_BH y aplicar cambios aun mas
  pequenos que no rompan nada".
- MAPA DE MARCAS (calibrado EMPIRICAMENTE en pantalla, probar por ventana):
  * Menu principal (linea del dinero): &0=verde, &1=rojo, &2=lila, &3=AMARILLO,
    &4=azul claro, &5=AZUL OSCURO (NIVEL/ATAQUE), &6=&7=blanco.
  * Ventana Velocidad (paleta DIFERENTE): &0=verde oscuro, &1=&2=rojo, &3=lila,
    &4=naranja, &5=azul claro, &6=azul medio-grisaceo, &7=blanco. NO HAY azul oscuro.
  * Por eso los titulos "azul claro" de David: cada ventana pinta la misma marca con
    SU paleta. Cualquier color nuevo = calibracion por ventana, nunca asumir.
- PENDIENTES de esa tanda (David los quiere, NO OLVIDAR): titulos entre iconos al azul
  oscuro + mayusculas (MAGIA OBJETOS EQUIPO TECNICAS COMBATE VELOCIDAD), "Dinero: " en
  amarillo, Cambiar/Tirar a la izquierda, iconos bajados 1 px, y el titulo interior de
  Velocidad como "∆VELOCIDAD∆" (con la calibracion de su paleta: &5 o &6, a elegir).
- [LECCION DE METODO] El menu RECUERDA la posicion del cursor entre aperturas; mi
  navegacion ciega ("3 DOWN y C") abria cualquier cosa. Y los detectores de color con
  umbrales fijos fallan con el dithering. Verificar con OJOS cada captura; los
  procesos nuevos arrancan de cero (no comparten estado).

### [ENTREGADO] TEST_BK.bin — MD5 4dbec10019c2ceec9aee6d7adac1f476
TEST_BH + SOLO:
  1. Menu Objetos interior: "Objetos" -> "OBJETOS" (in-place, 0x17DB4)
  2. Columnas de Cambiar/Tirar: 18->17 y 33->32 (un espacio a la izquierda)
  3. Fuente: q y p g j , ; ¡ ¿ bajados 1 px (ANYADIDA la 'y', que faltaba en la
     lista de la 96ª; 9 glifos, 20 copias entre INIT y OPEN)
Verificado en capturas: BK_objetos.png (OBJETOS + columnas), BK_menu.png (resto
intacto), fuente_compara.png (antes/despues de cada glifo). BF/BG/BJ/BJ2 viejas:
BF y BG ya borradas antes; BJ y BJ2 se quedan SOLO como archivo historico (BD elijo
no tocar mas; no son base de nada).

### [Workspace al cierre de la 97ª] base + TEST_BH (la buena de siempre) + TEST_BK (actual)
Cues: bk.cue y bh.cue (nuevo, para volver a BH cuando toque), orig.cue (arreglado).

## 2026-09-25 (98ª tanda) — Continuidad en chat nuevo: TEST_BL regenerada y auditada a nivel disco; la verificación en pantalla está BLOQUEADA (falta emu+BIOS+base)

### [HECHO] Reconstrucción del entorno (lo que entró en el pack de continuidad)
- Leído LEEME_CONTINUIDAD.md entero + diario (últimas tandas). Pack: TEST_BK.bin,
  herramientas, documentación, estados. NO trae: emu (genesis_plus_gx_libretro.so
  con arena_dbg), BIOS, base japonesa, TEST_BH, ni emu/RECETA.md. En el repo de
  David solo hay: el zip, START_correcto.bin, TEST_BK.state, parchea_cast_bin.py,
  v43_Lord_Monarch.state.
- TEST_BK.bin: MD5 4dbec10019c2ceec9aee6d7adac1f476 = el oficial. ✓
- TEST_BK.state descargado del repo (blob API; la URL raw daba 404 con página
  HTML guardada por error, borrada): 298504 B, RZIPv1 -> RASTATE v1, payload
  1036312 B, íntegro. Queda en el paquete para la verificación en pantalla.

### [HECHO] TEST_BL regenerada desde TEST_BK (parche_tk_nombres.py)
- MD5 52651d639fe2c335f98a8fabee4906f7 = IGUAL que la documentada (la 98ª-100ª
  del LEEME). El script es determinista y la base está intacta. Plantilla
  410 -> 446 B; 38 refs reapuntadas (el docstring decía 37; las reales son 38).

### [HECHO] Auditoría estática de TEST_BL (independiente del script, byte a byte)
- Plantilla 0x15410 (446 B): 6 filas de 54 B = [2634][8x8140][2637][32 B valores]
  [terminador]; los cuerpos de 32 B y terminadores son IDENTICOS a los de BK;
  cabecera (76 B) y rótulo fila 2 (46 B) intactos. ✓
- 38/38 refs: MISMAS posiciones que en BK y valores EXACTOS según el mapa
  viejo->nuevo (verificado con el mapa reconstruido a mano, no el del script).
  Composición: 1 setup (0x12FEE: move.l #$00025410,$22(a0)); 6 lea del blanker
  (0x12FFA..0x13034, cada uno seguido de bsr $23C94 con d0=5); tabla de 30
  longs en 0x13150-0x131C7 (6 campos de nombre + 24 campos de valores); 1 ref
  extra (0x0683C: +330 -> +360). ✓
- CORRECCION al diario de la 94ª: la tabla tiene 30 entradas, no 29 (la 30ª,
  en 0x131C4, es la 4ª celda de valores de la fila 6: BK+400 -> BL+436). Por eso
  las refs suman 38 y no 37.
- Sin valores huérfanos en la zona, sin refs nuevas creadas, todas alineadas a
  palabra. ✓
- Diff BK->BL: 303 B, solo en las zonas esperadas (plantilla desde el off 88 +
  35 bytes de refs, todos el byte bajo de cada long; los desplazamientos max
  +36 B no tocan el byte alto). ✓
- EDC/ECC con la referencia independiente (Neill Corlett, ref_check compilado
  de terceros/ecc_ref): 0 de 7842 sectores malos en TEST_BL y en TEST_BK. ✓
- Estructura del código alrededor (capstone + bytes): setup+blanker en
  0x12FEE-0x1303E; consumidor de la tabla en 0x1308A (lea.l $00023150, a3);
  escritor $23C94 (d0 celdas de espacio fullwidth 8140). Coincide con el
  análisis de LEEME/diario. Ojo: el blanker sigue escribiendo d0=5 celdas con
  el campo ya de 8; el experimento en vivo de la 94ª/98ª (poke en PRG-RAM con
  código intacto) funcionó y el nombre de 8 glifos repinta el campo entero,
  así que [HIPÓTESIS] no hace falta tocar el código del blanker: confirmarlo
  en pantalla con la captura.

### [ERROR PROPIO, sesión] dos falsas alarmas del primer pase de auditoría
1. El primer script de auditoría escaneaba refs en [$25410, $25410+0x1000) en
   vez de +410, y dio 59 "refs" (21 fuera de plantilla, opcodes "raros") que
   eran longs de datos de la misma página. La ROM no tiene nada que ver:
   corregido el rango, salen 38/38 limpias.
2. Leí el código desde memoria con codificaciones LEA/MOVE equivocadas y base
   de RAM mal puesta ($20000 en vez de $10000 para START): la primera pasada
   de desensamblado no decodificaba y dudé de la ROM. Contraste byte a byte
   (od + capstone + decodificación manual): la ROM es correcta; lea.l $imm,a0 =
   41F9+imm, move.l #$imm,$22(a0) = 217C+imm+disp16, base START = $10000
   (como usan todos los parches y como confirman las ROMs que David promoto).

### [BLOQUEADO] Verificación en pantalla (§8.2/8.3)
Faltan 3 piezas que no están en el pack ni en el repo (el LEEME dice que las
tiene David): el core emu /home/user/emu/bin/genesis_plus_gx_libretro.so
(o su receta emu/RECETA.md para reconstruirlo), la BIOS del Mega CD, y la base
japonesa Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin. Sin ellas
ni el arnés (pruebas/mdcd.py) arranca: no se puede abrir TEST_BK ni navegar a
Técnicas con la ruta probada. PENDIENTE de David.

### [PENDIENTE siguiente] En cuanto entre la emu:
1. Abrir TEST_BK (sanidad del arnés) y luego TEST_BL con la ruta de §4.4 del
   LEEME (menú -> 3 DOWN -> C -> C -> C -> C -> C -> DOWN -> C). Captura y
   MIRAR: nombres completos "Tian Ren"/"Mei Hong", filas alineadas por %,
   valores de Tian/Mei (aún amarillos), título/rotulos intactos.
2. Si BL sale bien: el 5.1a/b está HECHO y se entrega a David con capturas.
   Si sale mal: depurar el reapunte contra este volcado (la auditoría estática
   da 38/38, así que el sospechoso sería el blanker d0=5 vs campo de 8).
3. Después: 5.1c valores en blanco (calibrar en pantalla; la reordenación de
   marcas 2634/2637 se decide entonces), y §5.2 con calibración por ventana.

## 2026-09-25 (99ª tanda) — Emu reconstruida, TEST_BL verificada EN PANTALLA: nombres completos

### [HECHO] Emulador reconstruido desde cero (David: "el chat original lo compiló él")
- GPGX libretro master (commit c2838c7dc, "v1.7.4") + arena_dbg.c (33 símbolos
  arena_*: memoria real vram/cram/vsram/VDP regs/PRG-RAM/Word-RAM/BIOS, PC del
  68k; eventos/breakpoints = stubs). Receta completa en /home/user/emu/RECETA.md
  y arena_dbg.c en /home/user/emu/. Instalado en /home/user/emu/bin/.
- BIOS: las 3 de David (repo, blob API) en "/home/user/Illusion City/bios/"
  (131072 B cada una; GPGX las encuentra vía GET_SYSTEM_DIRECTORY = cmd 9).
- Arranque de frío: BIOS enciende (pantalla SEGA CD "presiona start"), el core
  v1.7.4 CARGA los states de David (RZIPv1/RASTATE) y restaura la imagen
  correcta -> la numeración "1.3.5" de David no es un obstáculo de formato.

### [HECHO] TEST_BL verificada en pantalla
- Flujo: load TEST_BL.cue -> state de David (Tecnicas de BK) -> poke_prg de las
  38 refs re-apuntadas + plantilla 446 B en $25410 (readback 38/38 y 446 B OK)
  -> B (cierra Tecnicas; queda el submenu Perfiles/Tecnicas/Combate) -> DOWN
  -> C.
- RESULTADO (captura capturas/99a_test_bl_tecnicas.png): "Tian Ren" y "Mei Hong"
  COMPLETOS en las 6 filas, valores en sus columnas, % tras las cifras.
- Lección de navegación: desde el submenu el cursor arranca en PERFIL (no en
  Tecnicas como decía la nota BM) -> DOWN -> C abre Tecnicas. C directo abre la
  ventana de nombres. MD C = RetroPad A (id 8); MD B = RetroPad B (id 0).
- Ojo: con la ventana YA abierta el poke a la plantilla no se ve (render al
  abrir); hay que cerrar B y reabrir C. Al reabrir $25410 cambia (la ventana
  repinta); la verificación final en disco es la de esta tanda.
- NOTA de corrección: la 98ª decía "bloqueo por emu"; ahora desbloqueado.

### [HECHO] Análisis de la maqueta de David (su mensaje de hoy)
- Título: en los bytes YA hay acento: "TéCNICAS" (T=8266, é=hijack 966B,
  resto 82xx) con iconos ∆=965F a los lados y marcas ⟨35⟩⟨37⟩...⟨34⟩...⟨37⟩.
  Coincide con su maqueta: NADA que hacer en el título.
- Rótulo 1 actual (23 celdas): ⟨35⟩ + ARMA + 1esp + RIFLE + 1esp + OBúS + 1esp
  + CAñóN + fin (arranca en col 1, bajo el nombre). Rótulo 2 igual pero
  GARRA/VARA/ESP./HILO con un |fin| inicial.
- Su maqueta: 2 espacios entre palabras ("ARMA  RIFLE  OBÚS CAÑÓN") y rótulos
  desplazados hacia los valores. El ancho de celdas NO cuadra 1:1 con su texto
  (si cada palabra terminara bajo su %, RIFLE chocaría con ARMA: los campos
  de valor están a 4 celdas). -> PREGUNTA a David pendiente (maquetación la
  decide él).
- Pendientes §5.2 del LEEME siguen a la espera: valores en blanco (5.1c),
  Cambiar col 17->16, Equipo, títulos ∆PALABRA∆ por ventana, dinero.

## 2026-09-25 (101ª tanda, este chat) — Rótulos de TECNICAS +7 celdas: HECHO

### [HECHO] ARMA/RIFLE/OBÚS/CAÑÓN y GARRA/VARA/ESP./HILO desplazados 7 celdas
Petición literal de David ("siete espacios a la derecha, solo esas dos filas").
La plantilla crece 446 -> 474 B (los dos rótulos +14 B cada uno) y las filas de
valores se desplazan en bloque dentro de la plantilla (mismo contenido, mismas
celdas de pantalla). Refs reapuntadas: 38 (todas).
Ademas se ensanchó la ventana de Técnicas: $8 = 22 -> 29 y el buffer de dibujo
$a6000 -> $b0000 (Word RAM alta; en el modo del juego la zona $a6000+$4000 no
daba para 29 celdas). Verificado en pantalla con el state de David:
capturas_tanda/BL2_tecnicas.png — ARMA sobre el 65%, GARRA sobre el 0% de Tian,
sin cortes, valores y colores intactos.
**TEST_BL.bin OFICIAL: MD5 d52709bc5d2616c55861ac8f86cb3790**
(sustituye a la que David tiene del otro chat: la 3a20ea89… sin este cambio).

### [AVISO] En BP/BP2 (intentos intermedios) la plantilla quedó corrupta: BORRADAS.
La vía que funciona: reconstruir la plantilla por BLOQUES con mapa de offsets
(rotulos +14 B, filas +0) y reapuntar con el mapa. Scripts: parche_tk_rotulos7.py
(versión buena reescrita en esta tanda; el borrador anterior tenía bugs).

## 2026-09-26 (102ª tanda, este chat) — BL restaurada (borrado de 2.100 B heredado)

### [EL DESASTRE y la causa]
David manda 7 capturas de la TEST_BL con mi parche de rótulos: el MENÚ PRINCIPAL
en japonés/basura ("talla0000140 E"), panel de MAGIA destruido, OBJETOS roto,
EQUIPO con basura, VELOCIDAD mezclada. Causa: la TEST_BL del otro chat tenía
BORRADAS las cadenas de la cola de START (0x17500-0x17E0F: menú principal,
panel Magia, dinero, Objetos, Velocidad, Equipo). Mi parche de rótulos partió
de esa BL y heredó el borrado sin detectarlo (mi diff BH-vs-BL usaba ventanas
de 24 B y agrupó esas zonas con otras legítimas).

### [RESTAURACIÓN]
Copiadas desde la BK regenerada las zonas 0x17500-0x177CC, 0x17800-0x179ED,
0x17AA0-0x17AF5, 0x17B10-0x17E10 y 0x17F80-0x17F87. Reaplicado el fix de 1
byte (region 0x683F: 5A->42; OJO: 0x683F es offset de REGION, el de FICHERO es
0x295CF — la confusión me hizo creer que estaba arreglado cuando no).
**TEST_BL OFICIAL: MD5 159017dfc044647ba09facb0d2dc0184.**
Verificado en arnés: menú principal completo en castellano + TÉCNICAS con la
maqueta (nombres 8, rótulos +7 celdas, valores blancos).

### [DIFF FINAL BH vs BL — 7 zonas, todas legítimas]
0x0683F (fix subq), 0x1235B-61 (columnas Objetos), 0x12FA5-BB y 0x12FFF-13031
y 0x13153-1C7 (ventana Técnicas ensanchada + refs), 0x15430-155E9 (plantilla),
0x17DB7-C1 (OBJETOS mayúsculas).

### [PENDIENTE en TÉCNICAS tras ver David BL]
- Ajustes finos de rótulos (David: "Luego veremos cómo se quedan").
- Color del título (∆TÉCNICAS∆): en BL sale AMARILLO (&4); decidir con David.
- Recordar: los % de "65%" y "0%" de una misma columna difieren 1 celda
  (el pintor escribe cifra+% desde el inicio del campo). Inevitable sin
  reprogramar el pintor.

## 2026-09-26 (103ª tanda, este chat) — GLITCHES de la ficha: RESUELTOS (buffer $aa000)

### [CAUSA de los glitches de David (capturas TEST_BL-2-*)]
El buffer de la ventana de Técnicas (ensanchada a 29 celdas) lo moví a $b0000:
esa zona NO está libre — el juego tiene allí gráficos descomprimidos del fondo.
La ficha de Estado y el mapa los usan => franjas parpadeantes en la ficha y
fondo corrupto al salir. Reproducido y medido en el arnés (5.643 bytes escritos
en $b0000 al navegar a la ficha).

### [SOLUCIÓN, probada en pantalla]
El buffer de la ventana de Técnicas va a $aa000 (justo después del área oficial
$a6000-$a9F80; en BL esa zona tenía datos de buffers de OTRAS ventanas no
coexistentes en pantalla, y el resultado es PERFECTO):
  - Técnicas: rótulos +7 celdas, nombres completos, valores blancos (BL2b_tecnicas_final)
  - Ficha Perfiles: SIN glitches (BL2b_ficha.png)
  - Combate: perfecto (BL2b_ficha5.png)
  - Mapa tras salir: limpio (BL2b_mapa.png)
FIX aplicado al disco: move.l #$0aa000,$1e(a0) en el setup de Técnicas (file
0x12FB4 de START). OJO con el mapeo región->fichero: la región 0x12FB4 es el
fichero 0x379C4 (sector LBA 59 + 0x19C4). Los fixes de 1 byte en esta ROM van
SIEMPRE por el mapeo de fichero, no por el de región (me equiviqué dos veces).
**TEST_BL.bin OFICIAL: MD5 aa2d6568e18df1718b08d1475d19743a**

### [Recordatorio navegación]
A (menú) -> 4 DOWN (Estado) -> C (submenu Perfiles/Tecnicas/Combate) -> C
(Perfiles=ficha) o DOWN+C (Tecnicas) o ... el cursor del submenu RECORDA la
última opción usada.
