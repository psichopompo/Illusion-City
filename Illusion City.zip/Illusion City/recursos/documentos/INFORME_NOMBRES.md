# Nombres propios: dónde están, cómo se miden y qué cabe

Medido el 27/09 sobre el build de trabajo. Todo lo de este informe está comprobado en
el fichero (offsets) y en el emulador (la tabla está viva en memoria), no deducido.

## 1. La tabla de nombres de la party

Está en **OPEN.BIN**, a partir de **0xF00B**. Formato: cada nombre es
`[texto sjis] 00` seguido del siguiente (la tabla se cierra con `00 80` antes del
primer nombre; el `80` es el terminador de la cadena anterior).

```
  offset   nombre        texto   hueco real   glifos que caben
  0xF00C   天人            4 B      5 B            2
  0xF011   美紅            4 B      5 B            2
  0xF016   ホウメイ          8 B      9 B            4
  0xF01F   シュウ老師         10 B     11 B            5
  0xF02A   アイザック         10 B     11 B            5
  0xF035   カッシュ           8 B      9 B            4
  0xF03E   薬師カイ           8 B      9 B            4
  0xF047   リー             4 B      5 B            2
  0xF04C   謎の男達           8 B      9 B            4
  0xF055   ガード・ロボ        12 B     13 B            6
  0xF062   ハイタオ兵          10 B     11 B            5
  0xF06D   レヴァ             6 B      7 B            3
```

**La misma tabla está en memoria en el build, en la PRG-RAM en `$4A919`** (medido con
el menú abierto: ahí aparece `...80 93 56 90 6c 00 94 fc 8d 67 00 83 7a...`). El HUD
del panel derecho y los menús leen de aquí.

Además, **los nombres aparecen como texto normal en los diálogos** de 60 ficheros de
guion (A*, B*, C*, E*, F*, H*, I*, J*, INIT.BIN, GENEI_OP.DAT...). Esos van por la vía
del reconstructor (lote 2 ya tradujo el prólogo de INIT).

## 2. Cabida del canon (5f) en la tabla

Cada glifo castellano ocupa 2 B (fullwidth). Medido contra el hueco real:

| Original | Canon | Glifos | Necesita | Hueco | ¿Cabe? |
|---|---|---|---|---|---|
| 天人 | Tianren | 7 | 14 B | 5 B | **NO** |
| 美紅 | Meifan | 6 | 12 B | 5 B | **NO** |
| ホウメイ | Houmei | 6 | 12 B | 9 B | **NO** |
| シュウ老師 | Maestro Shu | 11 | 22 B | 11 B | **NO** |
| アイザック | Isaac | 5 | 10 B | 11 B | sí |
| カッシュ | Cash | 4 | 8 B | 9 B | sí |
| 薬師カイ | Kai | 3 | 6 B | 9 B | sí |
| リー | Lee | 3 | 6 B | 5 B | **NO** (por 1 B) |

Osea: **los cuatro nombres principales no caben** donde están hoy. La tabla está
dimensionada para nombres japoneses de 2 glifos, y el canon pide 6-7.

## 3. Salidas (elegir una)

1. **Reubicar la tabla**: moverla a un hueco libre de OPEN.BIN y cambiar el puntero.
   Con el reconstructor ya se hizo crecer OPEN.BIN (+400 B, reubicado en la vía del
   lote 2), así que la vía de crecimiento existe. Los nombres cabrían enteros.
2. **Acortar los nombres** al hueco (2-5 glifos): Tian/Tie, Mei, Hou, Shu, Lee...
   Es lo que hace el propio juego en el HUD (usa 天人, 美紅: 2 glifos).
3. **Mixto**: nombres completos en diálogos (donde el espacio es del reconstructor) y
   forma corta en la tabla del HUD/menús. **El informe ya recomienda esto** en 5f:
   «solo nombre propio (Lee, Fei, Vaara, Dai, Ark, Meshmer, Yama); títulos completos
   reservados a diálogos».

## 4. Lo que hace falta para aplicar la tabla

- Decidir la forma corta de cada nombre (o reubicar).
- El codificador castellano (`codificador_castellano.py`) rechaza lo que no tiene
  glifo; los nombres llevan `ñ` y acento (`Airén`) → están en los 16 slots
  secuestrados, así que deben caber.
- Escribir la tabla con un script que **respete el hueco** (relleno de ceros) y
  verificar en pantalla (HUD + menús), cargando estado y con ROM, como las veces
  anteriores (un savestate lleva la tabla vieja dentro).

## 5. Pendiente de esta tanda

- No he aplicado ningún nombre todavía: primero la decisión de arriba (los huecos no
  dan para el canon tal cual).
- La prueba de que el HUD lee de esta tabla quedó a medias: inyectándola en la PRG-RAM
  no se ve el cambio porque el juego tiene más de una copia (la del estado y la del
  disco); hay que hacerlo con ROM parcheada + estado limpio, como se hizo con los
  menús.
