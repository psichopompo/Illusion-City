# Clases y habilidades del menú de Estado

Medido el 22/09. Las tres columnas de texto que salen en el menú de Estado (y en las
tiendas) son **tres tablas de punteros** dentro de INIT.BIN, con los textos juntos en
el mismo bloque (INIT 0x2425C). Como son punteros de 16 bits, **se puede escribir más
largo** siempre que quepa en el hueco libre de al lado (hay 16 B a cero justo después).

## Clase (la que sale detrás del nombre)

La tabla está en **INIT 0x22292** (16 entradas).

| # | Original | Significado | Propuesta | Letras | ¿cabe? |
|---|---|---|---|---|---|
| 0 | ＤＩＶＥＲ | Buzo | **BUZO** | 4 | sí |
| 1 | 人民警察官 | Policía del Pueblo | **POLICIA** | 7 | sí |
| 2 | 民間人 | Civil | **CIVIL** | 5 | sí |
| 3 | 仙導士 | Guía espiritual | **GUIDO**?  | 5 | sí |
| 4 | ロボット | Robot | **ROBOT** | 5 | sí |
| 5 | Ｒｅｓｉｓｔ | Resistencia | **RESIST.** | 8 | sí |
| 6 | 謎の魔人 | Demonio misterioso | **MISTICO** | 7 | sí |
| 7 | 元八部衆 | Ex-Ocho Generales | **EX-GENERAL** | 10 | sí |
| 8 | 斬糸 | Hilo cortante | **HILO** | 4 | sí |
| 9 | 剣 | Espada | **ESPADA** | 6 | sí |
| 10 | 杖 | Bastón | **BASTON** | 6 | sí |
| 11 | クロー | Garras | **GARRAS** | 6 | sí |
| 12 | ヘビーＧ | Cañón pesado | **CAÑON P.** | 8 | sí |
| 13 | 砲 | Cañón | **CAÑON** | 5 | sí |
| 14 | ライフル | Rifle | **RIFLE** | 5 | sí |
| 15 | Ｇｕｎ | Arma | **ARMA** | 4 | sí |

(El original 8-15 son las "habilidades" que salen en ATA/HAB; ver abajo.)

## Habilidad de arma (la que sale en la fila HAB)

Tabla en **INIT 0x222A2**, comparte textos con las clases 8-15.

Las longitudes actuales japonesas son de 2 a 4 glifos → el hueco es corto. Con el
bloque de textos (INIT 0x2425C) y sus 16 B libres al final se pueden alargar, pero
hay que mover el puntero de cada una.

## Zona de combate

Tabla en **INIT 0x222B4** (6 entradas):

| # | Original | Propuesta |
|---|---|---|
| 0 | ショップ | TIENDA |
| 1 | クライシス・エリア | ZONA CRISIS |
| 2 | インドア・コンバット | INTERIOR |
| 3 | ハザード・エリア | ZONA PELIGRO |
| 4 | ＭＥＴＡＬエリア | ZONA METAL |
| 5 | ＷＡＴＥＲパイプ | TUBO AGUA |

## Lo que necesito de ti

1. La palabra de la **clase** de cada personaje (la columna de arriba).
2. Si quieres cambiar alguna de las **habilidades** (Gun, Rifle, Cañón...).
3. El `―` de "斬糸" (clase 8) y demás nombres de arma: son los que salen con el arma
   equipada.
