# El panel del HUD (LV / HP / MP): lo que está MEDIDO y lo que falta

Fecha: 27/09. Todo lo de aquí son medidas en el emulador, no deducciones.

## Lo que se ve
- Panel derecho: 3 bloques (uno por personaje). Cada bloque tiene el NOMBRE, una
  barra PV/PM y las etiquetas **LV / HP / MP** con sus números.
- Nombre: x=209..227, y=25..31 (primera fila). El recuadro mide 49 px (x=203..251)
  => caben 4 glifos de 8 px.

## Lo que he DESCARTADO (con prueba, no por descarte lógico)
1. **No son texto de las tablas de fuente**: escribir un bloque sólido en las celdas
   de L, V, H, P y M de las DOS tablas de fuente ($29ED0 menús y $294E0 dinero) no
   cambia ni un píxel de las etiquetas (sí cambia la línea del dinero, 400 px).
2. **No son tiles de la nametable**: leyendo la entrada de la nametable de la celda
   donde están (26,5) en las CINCO bases posibles ($C000, $C800, $D000, $E000, $F000)
   y con las dos anchuras de plano (32 y 64 tiles), machacar el tile que apuntan NO
   cambia las etiquetas.
3. **No son sprites**: apagar los 80 sprites (poner y=0 en todo el SAT $DA00) no
   cambia NADA en pantalla (0 px).
4. **No existe ningún tile en VRAM con la forma de la «L»**: barrida la VRAM entera
   (2048 tiles) buscando el patrón de la L medido en pantalla -> 0 candidatos.

## Por qué los cambios no se ven (esto es la clave)
Medido en reposo (sin pulsar nada), el juego escribe en VRAM **2400-3000 palabras cada
4-6 frames**:
```
   $C000-$C7FF: 432 escrituras    (nametable A)
   $C800-$CFFF: 1027 escrituras   (nametable W)
   $D800-$DFFF: 974 escrituras    (lista de sprites)
```
Es decir: **el panel se reconstruye ENTERO cada frame** desde datos de la RAM del
sub-procesador. Cualquier poke en VRAM/CRAM se revierte antes del siguiente frame
visible. También se reescribe la CRAM (cambiar un color de paleta -> 0 px de cambio).

## Lo que falta para poder cambiarlas
Trazar las **lecturas** del sub-procesador (s68k) para encontrar de qué dirección de
la RAM saca el panel cada frame. El banco de pruebas actual engancha el PC del sub-CPU
(RECETA.md: `s68kcpu_hook.c`) pero **no sus accesos a memoria**: el gancho de memoria
(`HOOK_M68K_R/W`) solo cubre el 68000 principal, y el juego corre en el sub-CPU.

Plan: añadir el gancho de memoria al s68k (recompilar el core, ~30 s con la receta),
capturar la dirección de origen de las escrituras a $C000-$CFFF, y parchear esa fuente
en el INIT/el fichero que corresponda.

## Lo que NO hay que tocar
El logo de Illusion City de abajo a la derecha: David no lo quiere traducir.

## ACTUALIZACIÓN (misma tanda) — la escritura en VRAM ya funciona

### [HALLAZGO] El fallo de todos los pokes anteriores: la caché de patrones
El core guarda la VRAM en `vram[]` **más** una caché de patrones decodificados
(`bg_pattern_cache` + `bg_name_dirty[]` en `core/vdp_ctrl.c`). Escribiendo sólo en
`vram[]` **la pantalla no cambia** (probado: pintar 1600-2047 de rojo -> **0 píxeles
rojos en pantalla**). Hay que marcar sucio el patrón con `MARK_BG_DIRTY(addr)`.

**Arreglado**: se ha añadido `arena_vdp_write16(addr, value)` al core, recompilado y
verificado: escribir un bloque en el tile 1893 ahora **sí** se ve en pantalla.

```
   core/vdp_ctrl.c   + void arena_vdp_write16(...)   (escribe vram[] y marca dirty)
   libretro/link.T   -> global: retro_*; arena_*;
   .so nuevo: /home/user/emu/bin/*.so  MD5 bf6d2a9f45d6f2ad373989274a1ce649
```

### [MEDIDO] Los tiles de las etiquetas y su mapa en pantalla
```
   fila LV  -> tiles 1893 (x=208..215) y 1894 (x=216..223)   y=40..47
   fila HP  -> tiles 1911 (x=208..215) y 1912 (x=216..223)   y=48..55
   fila MP  -> tiles 1877 (x=208..215) y 1877 (x=216..223)   y=56..63
   (el panel de cada personaje repite el patrón cada 48 px)
   La columna x=208..215 y la x=216..223 son dos celdas de 8 px.
```
Prueba de control: copiar el tile 1894 (V) sobre el 1893 **no** cambia el dibujo ->
los tiles de las letras **se reescriben cada frame** (el resto del panel no).

### Siguiente paso (concreto)
Los tiles se regeneran cada frame, así que hay que encontrar la FUENTE. Como el juego
usa el AUTOINCREMENTO del puerto de datos ($C00004/$C00000) para las subidas **in situ**,
la vía barata es espiar el puerto de datos del VDP: leer $C00000 con el bit de modo a 1
antes de que el hilo del emulador consuma el dato -> dirección de destino de cada
escritura en tiempo real. Con eso se ve de un tirón qué rutina sube el panel.
(Alternativa: gancho de memoria del sub-CPU; hoy el core sólo engancha su PC y éste
sale como $FFFFxxxx en la BIOS, no del código del juego.)

## ACTUALIZACIÓN 2 — el instrumental ya funciona; el tile exacto sigue sin aparecer

### [HECHO] La escritura en VRAM y en la nametable ya se ve
Con `arena_vdp_write16()` (core recompilado, MD5 `bf6d2a9f45d6f2ad373989274a1ce649`):
- Escribir en un tile -> se ve.
- **Cambiar la entrada de la nametable -> se ve** (probado: poner tile 0 en (26,5) y
  (27,5) cambia y=80..87; poner una «Z» dibujada por mí en (26,5) la dibuja en pantalla).
=> El instrumental está listo; el problema es sólo localizar el dato.

### [MEDIDO] Desfases que me habían engañado (importante para el que siga)
```
   fila MP en pantalla = y=80..87   (no 56..63: eso era de la captura del state)
   la celda (26,5) del plano A ($C000) dibuja y=80..87
   => el plano empieza en y=32 y el panel tiene ~7 filas de alto, no 28
   => celda (26,ty) -> y = 32 + 8*ty
   Las filas LV/HP/MP de UN personaje: y=48, 64, 80  ->  ty=2, 4, 6
```
Y en esa columna, la nametable apunta a: ty=2 -> 1893, ty=3 -> 1911, ty=4 -> 1877,
ty=5 -> 2020 (ninguno de ellos es el glifo de una letra).

### [DESCARTADO CON PRUEBA]
- Los glifos de las letras NO están en la PRG-RAM, ni en la Word RAM, ni en la Word
  RAM 2M (buscados por sus formas en 1 byte/fila y por el patrón del tile).
- La VRAM de tiles es **estática** (0 tiles cambian entre dos volcados seguidos en
  reposo) => no se regenera cada frame; lo que se reescribe cada frame es la
  **nametable y el SAT** (medido: 2400-3000 escrituras).
- Apagar los 80 sprites del SAT no cambia nada de la pantalla: los sprites no están
  activos en esta escena (mi lectura del SAT dice x=48..212, y=96, que no cuadra con
  nada visible -> probablemente esa zona del SAT es basura o el formato no es el que
  estoy leyendo).

### Siguiente paso recomendado
1. Confirmar el formato real del SAT leyendo el registro de modo y el tamaño de sprite.
2. Si los glifos no aparecen, ir al revés: buscar en la nametable **qué celdas**
   dibujan exactamente y=48..55/x=208..223 (barrer tx 0..40 con ty fijo usando el
   desfase ya medido) y mirar el tile que apuntan -> ese es el de la letra.
Con el desfase corregido (y = 32 + 8*ty) ese barrido es de 40 pruebas, no de 2000.

## ACTUALIZACIÓN 3 — EL PANEL ESTÁ LOCALIZADO (bloque de tiles 1764+)

### [HALLAZGO] El panel entero es un BLOQUE DE TILES contiguos, y las letras van dentro
Todas las celdas de la columna de las etiquetas apuntan al tile **1764** y pintarlo
borra las letras (66 px de 100 de la tinta). Es decir: el panel (con sus letras
LV/HP/MP dibujadas dentro) es un bloque de tiles que empieza en **1764**.

Vuelco del bloque (los tiles con contenido):
```
   tile 1783: diagonal (##### / #### / ###)      -> parte de una letra
   tile 1785: diagonal (##### / #### / ###)      -> parte de una letra
   tile 1786: forma con filas llenas y un circulo -> parte de la V/barra
   tile 1787: forma con filas llenas y curvas     -> parte de la barra PV/PM
   (1780-1790 es la zona donde están las letras de las 3 filas)
```
Reparto de una captura anterior (x=208..231, tres celdas de 16 px):
```
   ancho: 24-32 px  ->  el bloque ocupa ~3 celdas
   alto:  3 filas (LV, HP, MP) + barras
```

### Lo que falta para poder cambiarlas
1. Identificar **qué tile es cada letra** (L, V, H, P, M) dentro del bloque 1764+.
   Con la herramienta actual es directo: sustituir cada tile del bloque por un patrón
   conocido (p. ej. filas alternas) y ver qué trozo de las letras cambia -- la misma
   bisección que ya funcionó, pero restringida a 1764..1830 (66 tiles).
2. Una vez identificados, redibujar L,V,H,P -> N,V,P,M (o lo que se decida) dentro del
   bloque, con `arena_vdp_write16()` si es un cambio en vivo, o en el fichero de art si
   se encuentra en el disco (el bloque no aparece en claro en el .bin: puede venir de
   un fichero comprimido, quizá de GENEI_OP.DAT).

### Dejado apuntado para no repetir
- `arena_vdp_write16()` funciona para tiles y para nametable (probado en pantalla).
- El desfase de la nametable: celda (tx,ty) del plano A -> y = 32 + 8*ty.
- La VRAM de tiles NO se regenera cada frame (0 tiles cambian en dos volcados).
- Los glifos de las letras NO están como datos sueltos en PRG-RAM/Word RAM.

## ACTUALIZACIÓN 4 — sólo hace falta dibujar la N (idea de David, correcta)

### [HECHO] De las cinco letras, cuatro ya existen en el panel
```
   LV -> NV : solo hay que cambiar la L por una N
   HP -> PV : la P ya esta en HP y la V en LV  -> reordenar
   MP -> PM : la M y la P ya estan             -> intercambiar
```
=> **solo hay que dibujar UNA letra nueva (la N)** y reordenar tiles. Eso reduce el
trabajo de "redibujar el panel" a mover/copiar tiles.

### [MEDIDO] El panel es un BLOQUE de tiles y las letras van dentro
- Todas las celdas de la columna de las etiquetas apuntan a un bloque que empieza en
  el tile 1764; escribir en cualquier tile del bloque hace desaparecer las letras
  (probado: la tinta de las 6 cajas baja a ~20%).
- Los tiles del bloque estan **VACIOS en la VRAM** (0x00) y las letras se siguen
  viendo -> el dibujo sobrevive en la **cache de patrones** del emulador/juego.
- Consecuencia practica: si se escribe un patron nuevo en el tile correcto y se marca
  sucio, la cache se rehace **con el patron nuevo** (asi desaparecen las letras al
  escribir un solido). Es decir: **la via para redibujar funciona**, lo que falta es
  acertar el tile exacto de cada letra.

### Cajas exactas de las letras en la partida cargada (para las pruebas)
```
   L  x=211..213 y=40..46     V  x=215..217 y=40..46
   H  x=211..213 y=48..54     P  x=215..217 y=48..54
   M  x=211..213 y=56..62     P  x=215..217 y=56..62
```
(La mayoria de los tiles 1813-1860 afectan a las seis cajas -> el bloque cubre toda la
columna; hay que ir tile a tile escribiendo un patron marcado y MIRANDO la pantalla.)

### Truco para la proxima pasada
En vez de escribir solidos (que borran todo y confunden), escribir un patron
**distintivo y pequeno** (p. ej. un solo pixel o una N) en un tile candidato y buscar
ese patron en pantalla: el que aparezca sobre la L es su tile.

## 22/09 — por qué las letras no salen de los tiles del panel (medido, con la traza)

**[HECHO] El juego sube las letras a unos tiles de trabajo (1744-1763), no a los que
apunta la nametable del panel.** Medido en dos pasos:
1. Las celdas del panel (tx 26-28, ty 4-7) apuntan a tiles 1877/1893/1894/1895/1911/1912
   que en VRAM contienen **rayas**, no letras. Pintarlos cambia como mucho 4 filas de
   letras (porque la fuente se sube *encima* de esos tiles).
2. Con la pantalla de Estado a la vista (el panel muestra los mismos NV/PV/PM que se
   pintan una sola vez), reescribir las celdas 36-52 de la **fuente de menús en RAM
   ($294E0)** con `poke_prg` ANTES de abrir el menú cambia justo los caracteres que
   faltaban: la celda 40 es el `+` de ATA, la 50 el `%` de PRE y la 14 el `~` de PV/PM.
   Los tiles 0-46 de VRAM ($294E0 - $28000 = $14E0) están **vacíos**, y los números
   aparecen en menos de 4 frames al abrir el menú: el juego copia la fuente a VRAM.

**[HECHO] Traza de escrituras de VRAM en reposo** (4 frames): solo 1544-1579, 1600-1663,
1728 y 1744-1763; y **1744-1763 están a CERO en VRAM** con el panel a la vista. El
panel completo no se reescribe cada frame.

**Siguiente paso (concreto)**: los tiles donde caen las letras del panel son los que
la nametable apunta *detrás* de la fuente (1877/1893/1894/1895/1911/1912). Escribir en
esos tiles un patrón propio es la vía para redibujar NV/PV/PM (la N es la única letra
nueva; V, P y M ya existen en el panel).
