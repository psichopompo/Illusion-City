# Nombres que salen en el HUD: lista completa y medida

La tabla de nombres del juego está en **INIT.BIN 0x22919** y tiene **30 entradas**.
Éstos son TODOS los nombres que pueden aparecer en el HUD (y en la ventana de
personajes). El recuadro del HUD tiene **40 px útiles** (de x=209 a x=249).

Convención: **celda de 5 px = 4 de dibujo + 1 de hueco**. Caben **8 letras** (40 px).
Entre paréntesis, lo que ocupa el nombre: por ejemplo (7) = 7 letras = 35 px.

| # | Original | Nombre propuesto | Letras | px a 5 px/letra | ¿cabe? |
|---|---|---|---|---|---|
| 0 | 天人 | **Tianren** | 7 | 35 | sí |
| 1 | 美紅 | **Meifan** | 6 | 30 | sí |
| 2 | ホウメイ | **Houmei** | 6 | 30 | sí |
| 3 | Ｓｈｕ | **Shu** | 3 | 15 | sí |
| 4 | Ｉｓａａｃ | **Isaac** | 5 | 25 | sí |
| 5 | Ｃａｓｈ | **Cash** | 4 | 20 | sí |
| 6 | Ｋａｉ | **Kai** | 3 | 15 | sí |
| 7 | リー | **Lee** | 3 | 15 | sí |
| 8 | 謎の男達 | *Enigma* (8) | 8 | 40 | justo |
| 9 | ガード・ロボ | *Guardián* (8) | 8 | 40 | justo |
| 10 | ハイタオ兵 | *Haitao* (6) | 6 | 30 | sí |
| 11 | レヴァ | **Reva** | 4 | 20 | sí |
| 12 | Ｚｕ　Ｖａ | **Zu Va** | 5 | 25 | sí |
| 13 | Ｋｉ　Ｔｕａ | **Ki Tua** | 6 | 30 | sí |
| 14 | ハーメルン | **Hameln** | 6 | 30 | sí |
| 15 | ニニュートア | **Ninyutoa** | 8 | 40 | justo |
| 16 | Ｖａｍｕ | **Vamu** | 4 | 20 | sí |
| 17 | ヴァザ | **Vaza** | 4 | 20 | sí |
| 18 | フェイ | **Fei** | 3 | 15 | sí |
| 19 | リュウケイ | **Liu-Kei** | 7 | 35 | sí |
| 20 | ソリッド | **Solid** | 5 | 25 | sí |
| 21 | コロニー | **Colony** | 6 | 30 | sí |
| 22 | Ｃａｚａｄｏｒ | **Cazador** | 7 | 35 | sí |
| 23 | ハンマー | **Hammer** | 6 | 30 | sí |
| 24 | ウィップ | **Whip** | 4 | 20 | sí |
| 25 | ヴァーラ | **Vaara** | 5 | 25 | sí |
| 26 | 黒ヒョウ | *Pantera* (7) | 7 | 35 | sí |
| 27 | デュラン | **Durand** | 6 | 30 | sí |
| 28 | 密告者（インフォマー） | *Informe* (7) | 7 | 35 | sí |
| 29 | 殺人者（マーダー） | **Asesino** | 7 | 35 | sí |

## Letras que hacen falta

Con estos nombres, las letras que se usan son:

```
  MAYÚSCULAS: A B C D E F G H I K L M N P R S T U V W X Y Z  (24)
  minúsculas: a b c d e f g h i k l m n o p q r s t u v w x y z  (25)
```

Prácticamente el alfabeto entero, así que **dibuja A-Z y a-z completos** y te olvidas
de excepciones.

## Notas para el dibujo (medidas reales del HUD)

- **Caben 8 letras** en el recuadro (40 px). El más largo de la lista es de 8 letras.
- **Tianren** (el más largo de los jugables) son 7 letras = 35 px → **5 px de sobra**.
- Si usas **celda de 4 px** (3 de dibujo + 1 de hueco) caben **10 letras** y sobra sitio
  en todos. Es la medida que usa el propio panel del juego para LV/HP/MP.
- Sobre la **M**: en el panel del juego la M de "MP" ocupa 4 px de ancho, así que sí se
  puede hacer en 4. Si te resulta imposible, dibújala de 5 px y la usamos sólo en los
  nombres cortos (Meifan, Vamu, Hameln, Meshmer…), que tienen sitio de sobra.
- **5 px de paso = 4 de dibujo + 1 vacío a la derecha**. El hueco va DENTRO del paso,
  no es una columna aparte.

## Los tres jugables confirmados

```
  Tianren   7 letras   35 px
  Meifan    6 letras   30 px
  Isaac     5 letras   25 px
```
