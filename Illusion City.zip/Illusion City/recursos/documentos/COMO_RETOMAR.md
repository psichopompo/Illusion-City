# COMO RETOMAR (actualizado al cierre de la 94ª tanda, 28/09)

## LA ROM BUENA: TEST_BH.bin — MD5 9884eeffa93640b814108b3909a96730
Promocionada por David: el menu de Tecnicas con su maqueta (title ∆TECNICAS∆ amarillo,
rotulos completos, % detras de todas las cifras) y NO se cuelga al salir de Velocidad
en su Genesis Plus 1.3.5. Es la unica ROM de prueba del workspace.
La reconstruccion completa sale de: build_test_ba.py (la cadena entera, AHORA SI
con TODO dentro: parche_plantillas + parche_magia2 + parche_ventana2 + parche_sistema +
parche_objetos + parche_si_no + los 2 bytes sueltos del titulo de Combate y el selector
de Objetos). ATENCION: los "2 bytes sueltos" y el paso de Tecnicas (parche_tecnicas_bc.py)
siguen FUERA de la cadena automatica; mirar el diario 94ª antes de reconstruir.

## LECCIONES DE ORO (pagadas caras, NO repetir)
1. Todo parche va en FICHERO y en la CADENA el mismo dia. Los "inline" se pierden con
   la proxima reconstruccion (así se perdieron Magia 80ª, ventanas 81ª, Si/NO 89ª...).
2. Verificar tras cada build TODOS los menus, no solo el de la tanda (comparar capturas).
3. TEST_I.bin "inmortal": lo recreaba build_test_ba.py; ya arreglado (se mueve a /tmp).
4. orig.cue tenia un nombre de fichero equivocado: las comparaciones con "el original"
   hechas por cue eran basura. Verificar SIEMPRE que el cue carga la ROM esperada.
5. Mudar plantillas: mapear TODAS las referencias (lea/move.l con opcode delante +
   tablas dc.l con vecinos; nada de escaneos sin alinear) y decidir antes de escribir.
6. "Se ha parado" de David = ¿el juego o mi proceso? Aclararlo antes de diagnosticar.

## PENDIENTE (por orden de entrada probable)
- Selectores azules de Objetos: 3 tamanos individuales (Usar/Cambiar/Tirar). El pintor
  lee $2e del descriptor; el gancho de la v6 esta PROHIBIDO (sospechoso del cuelgue
  historico). Falta el punto exacto donde d2 se consume para el ancho.
- Nombres completos "Tian Ren"/"Mei Hong" en la pantalla de Tecnicas (hoy salen de 6:
  "Tian R"). Medir el campo del nombre en la plantilla nueva (hueco 0x15410).
- Ajustes: textos pisados (ventana de 3 lineas para 4 textos); falta el texto final
  de David y decidir si se sube el alto ($a) o se acorta. Los Si/NO entran en la
  proxima build (parche_si_no.py ya en la cadena, VERIFICARLO en pantalla).
- Alineaciones y colores que David anote menu a menu.
- Costes de Magia/Tecnicas desalineados (pendiente antiguo).

## EL CUELGUE (casi cerrado)
El state forense de David (ROM v6 con gancho) tenia memoria pisada ANTES del savestate
y la maquina a medio reiniciar (BIOS esperando 'GENE'). TEST_BC y TEST_BH (sin gancho)
NO cuelgan en su 1.3.5. [HIPOTESIS] el gancho v6 era el culpable. Los "Se ha
parado" de la 93ª eran empujones a mis procesos parados (aclarado por David), NO
cuelgues del juego: TEST_BE/BF/BG nunca llegaron a probarse alli.
