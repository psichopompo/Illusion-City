# Proyecto de traducción: Gen'ei Toshi / Illusion City (Mega CD) → Castellano

## 1. Estructura del disco

| Track | Tipo | Tamaño | Contenido |
|-------|------|--------|-----------|
| 01 | MODE1/2352 (datos) | 18.444.384 B (8.987 sectores) | Todo el juego: código 68000 + datos + textos |
| 02–10 | AUDIO (CDDA) | — | Bandas sonoras, sin datos |

**Toda la localización vive en el Track 01.** Header Sega: `GM T-51014 -01` (Microcabin, 1993).
El volcado `track01.iso` (sectores de 2048 B, offset = 16 en cada sector crudo de 2352 B) es el archivo de trabajo.

## 2. Encoding y formato de texto

- Los textos están en **Shift-JIS plano, terminados en `00`** — sin compresión ni cifrado.
- Marcadores de control incrustados:
  - `$1`, `$2`, `$3` → nombres de personajes/enemigos/objetos.
  - `#1` → valores numéricos (daño, niveles, cantidades).
  - `Nu` al inicio de mensajes de sistema → opcode de control, NO es texto (artefacto de `4E75` = `rts` de 68000 adyacente).
- Textos duplicados en dos copias (~0x5BF00 y ~0xABB00): el juego mantiene dos sets paralelos (posiblemente uno por modo de vídeo o por zona del guion). Habrá que parchear ambas copias o descubrir cuál se usa realmente.

## 3. Bloques localizados (offsets sobre `track01.iso`)

| Rango | Contenido |
|-------|-----------|
| `0x52D8` | Mensajes de prueba/licencia (ISO dev) |
| `0x1AD04` | Mensajes de objetos ("$1を手に入れた。") |
| `0x23EC8` | "敵と遭遇した", subida de nivel |
| `0x2805C-0x285E4` | Estados de batalla (veneno, sueño, parálisis, etc.) |
| `0x2F6BA` | Menús ("ステータス", "個人データ") |
| `0x59020` | Diálogos cortos |
| `0x5BF3D-0x5E137` | **Nombres de enemigos, ataques enemigos, objetos, tiendas, localizaciones, conjuros** — el bloque más compacto y rico |
| `0x1AF830` | Diálogos con la party (美紅, etc.) |
| `0x1D0769`+ | NPCs y guion principal |
| `0x3DFCEC`+ | Más guion de NPC |
| `0x1AF830`-`0x3FF6D0` aprox. | Guion repartido por toda la zona media/alta |

## 4. Herramientas creadas

- `tools/sjis_scan.py` — escáner Shift-JIS genérico sobre binario crudo.
- `tools/sjis_filter.py` — filtro de ruido (ratio japonés / longitud mínima).
- `track01.iso` — sector data crudo extraído.
- `sjis_clean.txt` — lista depurada de 3457 bloques con offsets.

## 5. Investigación de la fuente (en curso)

### Negativo
- Escaneo 4bpp por nibbles bajos: solo capturó gráficos comprimidos, no fuentes.
- Escaneo 1bpp (popcount 1-6, runs largos): blobs de exactamente 1215 B repetidos en muchos offsets (0x1F7CC5, 0x2107D5, 0x230A55...). Estructura interna rara (bytes tipo 0x51/0x58/0x91/0x99), no encaja con glifos planos. **Hipótesis: contenedor comprimido o datos de otra naturaleza.**
- Regiones de alta entropía (>7.2 bits/byte, hasta 28 KB): ruido comprimido, no tiles legibles a 1/2/4 bpp.
- Render multi-formato (1/2/4 bpp × 8x8/8x16/16x16) de todos los candidatos: sin éxito visual.

### Conclusión provisional
La fuente no está en el disco en formato plano. Dos hipótesis vivas:
1. **Fuente comprimida** → requiere localizar la rutina de descompresión en el 68000.
2. **Kanji ROM del Mega CD** → el texto en Shift-JIS plano del disco es coherente con que el juego mande códigos JIS directamente a la Kanji ROM integrada en el ASIC de Sega CD. Esto explicaría la ausencia total de tiles de fuente en el disco.

### Siguiente paso
- Desensamblar el código alrededor de 0xCD447 (único patrón que parece instrucción real 68000 tocando 0xFF0004) para confirmar/descartar la Kanji ROM.
- Si usa Kanji ROM: los caracteres castellanos **no existen** en esa ROM; habría que forzar que el texto pequeño se dibuje desde VRAM con nuestra propia fuente, o inyectar los glifos como tiles propios en un banco libre.

## 5b. Dumper de textos (COMPLETADO)

`tools/dumper_textos.py` recorre los 167 archivos ISO9660 del Track 01 y extrae las
cadenas SJIS terminadas en `00` validadas con estas reglas (afinadas empíricamente):

- Exige contenido japonés (kana/kanji) y tolera pocos caracteres desconocidos.
- **Sin caracteres de control** (< 0x20, salvo `$` `#` del motor).
- **Kana halfwidth** (SJIS 0xA1-0xDF) solo permitido como opcodes `｡ﾇﾊﾋﾌﾍﾎﾏﾐﾑ`
  en las dos primeras posiciones — el binario que se decodifica como SJIS los
  esparce por todas partes.
- **Sin ASCII imprimible** fuera de los marcadores `$1/#1` y `/n`.
- Repeticiones de un mismo caracter (`(.)\1{5,}`) rechazadas (tiles de gráficos).

Resultado en `textos_dumper.csv` (**2.933 cadenas**, 2.377 de confianza alta,
~69.000 caracteres japoneses, 89 archivos):

| Columna | Contenido |
|---|---|
| `id` | Identificador estable (1..N) |
| `archivo` / `offset_archivo` / `offset_iso` | Localización exacta para el reinsertador |
| `japones` | Texto original (con marcadores `$1 $2 $3 #1` y `/n`) |
| `marcadores` | Lista de marcadores presentes |
| `confianza` | `alta` (lleva hiragana común) / `media` (nombres/etiquetas kanji puros) |
| `traduccion_castellano` | **A rellenar** |

Los archivos con más texto: `INIT.BIN` (363), `OPEN.BIN` (302), `A10.BIN` (126),
`C20.BIN` (121), `B20.BIN` (97), `A02.BIN` (94), `A3B.BIN` (87), `H21.BIN` (84),
`START.BIN` (83, textos de batalla: `$1は毒が回ってきた`, `$2に#1のダメージ`...).

Opcodes de línea detectados al inicio de cadena: `ﾇ` (limpia/diálogo nuevo),
`ﾈ`, `ﾊ-ﾑ`, `｡` (posiblemente color/voz). Se conservan en el CSV — el
reinsertador deberá reproducirlos tal cual. `/n` = salto de línea manual.

## 5c. Codificador castellano (COMPLETADO)

`tools/codificador_castellano.py` convierte texto castellano a los bytes que
espera el motor. Reglas de codificación:

| Entrada | Salida SJIS |
|---|---|
| `A-Z a-z 0-9` | fullwidth `Ａ-Ｚ ａ-ｚ ０-９` (0x824F+/0x8260+/0x8281+, presentes en GFONT) |
| `¿¡ÑñáéíóúüÁÉÍÓÚÜ` | códigos de los 16 slots secuestrados (`tabla_castellano.txt`) |
| espacio | `81 40` (fullwidth) |
| `...` | `…` (81 63) |
| `, . : ; ! ? ( ) " % / + = ' * < > -` | equivalente japonés `、。：；！？（）”％／＋＝’＊＜＞－` — **solo si el glifo existe en la fuente** (verificado contra los códigos presentes en los textos originales) |
| `$1 $2 $3 #1 /n` | ASCII literal, sin convertir (marcadores del motor) |
| `ﾇ ﾈ ﾊ-ﾑ ｡` | byte halfwidth 0xA1-0xDF (opcodes de línea) |
| 「 」 その他 japoneses | tal cual si existen en la fuente |
| cualquier otro | `EncodeError` con lista de caracteres sin glifo |

Incluye `decode_engine()` (bytes motor → texto legible) para verificación, y
`--selftest` con 6 pruebas roundtrip (PASS). Uso:

    python3 tools/codificador_castellano.py '¡$2 te ha quitado #1 PV!'

La verificación de símbolos existentes se hace contra los códigos del bloque
0x8140-0x824E realmente usados en `textos_dumper.csv`: si un símbolo no aparece
en el texto original del juego, el glifo puede no existir en GFONT y se rechaza.

## 5d. Reinsertador y primer lote (COMPLETADO)

`tools/reinsertador.py` aplica la columna `traduccion_castellano` del CSV sobre
la imagen:

- **Estrategia in-situ**: cadena nueva + `00` + relleno de ceros hasta el tamaño
  original (el motor ya tolera runs de `00` entre comandos: `...8176 00 00 00 c7...`).
  La longitud total del archivo no cambia → offsets intactos, compatible incluso
  con los bloques en tabla secuencial de START.BIN.
- Verificación automática por `decode_engine()` de cada cadena escrita.
- Regenera `track01_castellano.iso` y el `.bin [CAST]` completo (solo reescribe
  los sectores que difieren del original) tras parchear GFONT (LBA 679).
- `informe_reinsercion.txt`: detalle EXACTO/RELLENO(n) por cadena.

**Primer lote traducido (83 cadenas)**: `tools/lote1.py` — batalla (EXP/Premio,
veneno, parálisis, daño, huida), menús (Item/Ficha/Sist), tiendas (Falta oro,
Gracias, Lleno, menús ［Armas］［Venta］...), nombres propios (Isaac, Kash, Kai,
Shu) y localizaciones (Kowlo, Saikun, Bahía, Fosa, Biolab...).

Pendiente de resolver en lotes grandes: ~~frases largas de guion donde el
castellano no cabe~~ → RESUELTO con el reconstructor (ver 5e).

## 5e. Reconstructor con reubicación (COMPLETADO)

`tools/reconstruir.py` + `tools/reconstruir_iso.py` permiten **traducciones de
cualquier longitud** en los 61 archivos de guion con formato `c6`.

### Modelo del formato (crackeado y verificado)
- El texto viaja inline en un flujo de comandos; `c6 <id> 00 <texto> 00` es un
  bloque con etiqueta y `c5 <id> 00` son referencias a esas etiquetas.
- **El ID es una posición relativa a una BASE constante por archivo**:
  `id + BASE = offset del target` (la mayoría de las veces el `c6` siguiente,
  a veces un salto a mitad de texto). `find_segment()` deduce BASE por mediana.
- Varios archivos tienen MÁS DE UN segmento de texto separados por comandos
  (descubierto en A3E/B50); `E` cubre hasta la última cadena del archivo.

### Garantías (tests integrados, 61/61 archivos)
1. **Test sin cambios**: reconstruir sin traducciones produce el archivo
   byte-idéntico.
2. **Test de crecimiento**: con traducciones de prueba, cada target de ID
   conserva EXACTAMENTE sus bytes en el archivo nuevo (tolerando solo los
   bytes-ID remapeados y las propias cadenas traducidas).
3. Las cadenas que encogen se **rellenan con ceros hasta su tamaño original**
   (los runs de `00` ya son naturales en el flujo) → el segmento SOLO crece.

### Reubicación en el disco
- Los archivos crecidos se mueven a la zona libre final (a partir de LBA 7700;
  el disco termina en LBA 7691, quedan 151 LBAs ≈ 300 KB).
- Los IDs son relativos a la BASE interna del archivo → mover el archivo
  entero no rompe nada.
- `reconstruir_iso.py` parchea los directory records ISO9660 (extent y size,
  LE+BE) in-situ: los registros no cambian de tamaño.
- El .bin [CAST] se regenera reescribiendo solo los sectores modificados
  (146 sectores en la prueba con A00 reubicado).

### Estado de la traducción
- **Lote 1** (83): batalla/menús/tiendas cortas de START/INIT (in-situ v1).
- **Lote 2** (`tools/lote2.py`, 343): INIT.BIN completo por vía rebuild — diálogo del
  prólogo (60), nombres de enemigos, acciones de batalla, objetos, armas/armaduras,
  conjuros completos y tiendas — más los menús de tienda de OPEN.BIN.
  INIT creció +16 KB (reubicado a LBA 7700) y OPEN +400 B (LBA 7781).
- Verificación end-to-end: el archivo embarcado es byte-idéntico al
  `rebuild(original, traducciones_CSV)` y el test de targets da 0 fallos.
- **Pendiente**: la BD de OPEN.BIN fuera de su segmento c6 (nombres/objetos del
  sistema de la intro) — sin tabla de punteros hallada aún; viven en tablas
  secuenciales → solo in-situ. INIT tiene las MISMAS cadenas ya traducidas
  dentro de su segmento, así que en la práctica el juego usa las de INIT.

### Pipeline final
```
textos_dumper.csv (traducción) → tools/reconstruir_iso.py
  → rebuild c6 (reubicación + fixup IDs) → in-situ v1 (resto de archivos)
  → GFONT_CAST.BIN → track01_castellano.iso → .bin [CAST]
```

## 5f. Canon de nombres propios (COMPLETADO)

Nombres oficiales según la wiki japonesa, aplicados con `tools/lote_nombres.py`
(reescrituras EXACT por id + sustituciones regex sobre el CSV, con
sincronización de lote1.py/lote2.py; verificación: 0 restos de formas viejas).

| Original | Canon castellano |
|---|---|
| 天人（ティエンレン） | Tianren |
| 美紅（メイファン） | **Meifan** (antes "Meihong") |
| シュウ老師 | Maestro Shu |
| ホウメイ | **Houmei** (antes "Homei") |
| カッシュ | **Cash** |
| アイザック | Isaac |
| ドク | **Doc** (antes "Dok") |
| アイレン | **Airén** |
| シャオメイ | **Xiao Mei** (antes "Xiaomei") |
| 薬師カイ | Kai |
| 魔天王 | Rey Maten (el culto 魔天教 = "Secta Maten") |
| 南天リー | **Lee del Cielo Sur** (diálogos: "Lee") |
| 西天フェイ | Fei del Cielo Oeste |
| 樹羅帝ヴァーラ | **Vaara**, Emperador de Jurá (区 樹羅 = "Jurá") |
| 東天ダイ | Dai del Cielo Este |
| 雷帝アーク | **Emperador Ark** (antes "Señor del Rayo") |
| 妖鋼妃 | **Consorte del Acero** (antes "Dama del Acero") |
| 北天メシュメル | Meshmer del Cielo Norte (diálogos: "Meshmer") |
| 月琴明王ヤマ | Yama (en diálogos; título largo solo en presentaciones) |
| リュウケイ / デュラン / ライデン | **Liu-Kei / Durand / Raiden** |
| クロガネ / スメラギ | Kurogane / Sumeragi |

Criterio de recorte (HUD/batalla): solo nombre propio (Lee, Fei, Vaara, Dai,
Ark, Meshmer, Yama); títulos completos reservados a diálogos.

NOTA de cabida: los slots de nombre puro tienen huecos de 9-17 B; nombres de
5-6 glifos fullwidth como "Vaara"/"Durand" NO caben in-situ (2210, 2212...
ya constan en no_cabe). Se aplicarán en cuanto exista la vía de crecimiento
segura para INIT.BIN (hoy bloqueada: sus tablas de offsets fijos se rompieron
con rebuild; ver informe_reconstruccion.txt).

## 5g. Menús, fuente fina y HUD (18-09-2026)

Se corrigió la fuente fina de los menús: el código secuestrado `0x9660` (que
cp932 decodifica como 冒, pero que el juego debe mostrar como `á`) se parchea
directamente en las tres copias de la celda 226 de la fuente (incluida
`GFONT.BIN`). El reemplazo anterior solo alcanzaba las copias gruesas; por eso
David veía 膨 en `Rápido`.

También se regeneraron las plantillas de `START.BIN`: Z22 conserva la cabecera
azul, resalta Rápido/Lento en amarillo y deja Mensajes, Moverse y Combate en
blanco; Z5 usa `[Magia] Tianren`; la ventana de objetivo usa `Efecto`, `Ind` y
`Grupo`; y el HUD usa Tianren, Meifan, Isaac y PV/PM en los huecos disponibles.
Las plantillas mantienen sus tamaños originales (Z5 136 B, Z22 130 B), sin
activar el rebuild peligroso. Z22 conserva la geometría original: Rápido en
4-9, Lento en 11-15, dígitos en 8-15 y las etiquetas inferiores desde 1.
Verificación final: 147 cadenas in-situ, 329 aún sin cabida, 48 bitmaps gruesos
sustituidos, 3 copias de la fuente fina sustituidas y 0 errores.

## 6. Emulador

Instalado **Genesis Plus 1.3.5** vía Homebrew (`/Applications/Genesis Plus.app`). 
Ojo: es la versión standalone clásica (1999-2004), no Genesis Plus GX. Para Mega CD basta.
Falta: generar BIOS o emulador de Mega CD correcto para arrancar la imagen `.cue` (no probado todavía).

## 7. Próximos pasos (en orden)

1. ~~Dumper estructurado~~ ✅ (`textos_dumper.csv`)
2. ~~Fuente castellana~~ ✅ (16 glifos en GFONT via secuestro de slots kanji)
3. **Traducir el CSV**: empezar por `confianza=alta` de los archivos de guion (A*, B*, C*...). LIMITACION ACTUAL: solo 147/476 cadenas caben in-situ (no_cabe=329); para el resto hace falta una vía de crecimiento segura por archivo (el rebuild global rompio INIT por sus tablas de offsets fijos).
3b. ~~Canon de nombres propios~~ ✅ (`tools/lote_nombres.py`, Meifan/Houmei/Cash/Airén/Vaara/Lee/Raiden/Liu-Kei/Durand/Doc...).
4. ~~Codificador castellano→SJIS~~ ✅ (`tools/codificador_castellano.py`, selftest PASS).
5. ~~Reinsertador in-situ~~ ✅ (`tools/reinsertador.py`) + ~~reconstructor con reubicación~~ ✅ (`tools/reconstruir.py`, 61/61 tests).
6. ~~Parchear Track 01~~ ✅ pipeline completo `reconstruir_iso.py` verificado end-to-end.
7. **Ojo**: B50/E3X y otros pocos archivos usan OTRO formato de bloques (sin c6) → quedan por crackear para cobertura total; hoy van por la vía in-situ v1.

## 7. Referencias de las capturas

- Diálogo de Tianren con retrato → guion de conversación (~0x1D0769 en adelante).
- Batalla con status panel → textos de batalla (0x2805C+).
- Diálogo con viejo → guion con comillas japonesas `「`.
- Batalla floral → textos de batalla, ataques enemigos (0x5C252+).
