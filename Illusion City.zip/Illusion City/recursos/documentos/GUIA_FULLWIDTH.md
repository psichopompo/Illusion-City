# Guía para agente paralelo — Dónde están las traducciones (fullwidth SJIS)

**Resumen ejecutivo:** El pack minimal SÍ contiene las traducciones en español, pero NO en ASCII. Todo el texto del juego está en **fullwidth Shift-JIS (SJIS)**, no ASCII. Buscar `Magia` en ASCII falla siempre. Hay que buscar en fullwidth y reconstruir el ISO con `reconstruir_iso.py`.

## 1. Encoding: fullwidth, no ASCII

- **Motor del juego:** solo entiende SJIS 2 bytes para texto visible. Si escribes ASCII 1 byte (`4D 61 67 69 61` = "Magia"), el motor lo empareja como SJIS y salen kanjis basura (bug v1).
- **Fullwidth mapping (ver `tools/codificador_castellano.py`):**
  - `A-Z` = `0x8260` + (ord-0x41): `A=8260, B=8261, ... Z=8279`
  - `a-z` = `0x8281` + (ord-0x61): `a=8281, b=8282, ... z=829A`
  - `0-9` = `0x824F` + digit: `0=824F, 1=8250, ... 9=8258`
  - espacio = `0x8140` (ideographic space), **NO 0x20**
  - `:` = `0x8146`, `.` = `0x8144`, `,` = `0x8143`, etc. (ver `PUNCT` dict)
  - `ñ/á/é/í/ó/ú/ü/Á/É/Í/Ó/Ú/Ñ/¿/¡` = **HIJACK** codes: `á=0x9660, é=0x966B, í=0x967B, ó=0x9682, ú=0x96AF, ñ=0x96B3, etc.` (16 slots en INIT.BIN 0x4ED0 + OPEN.BIN 0xA710, celdas 12x12 18B). Ver `cod.HIJACK`.

- **Ejemplos hex (cod.encode_spanish):**
  ```
  Magia     = 82 6C 82 81 82 86 82 89 82 81
  Objetos   = 82 6E 82 82 82 8A 82 85 82 94 82 8F 82 93
  Sistema   = 82 72 82 89 82 93 82 94 82 85 82 8D 82 81
  Equipo    = 82 64 82 91 82 95 82 89 82 90 82 8F
  Hablar    = 82 67 82 81 82 82 82 8C 82 81 82 92
  Ficha     = 82 65 82 89 82 83 82 88 82 81
  Velocidad = 82 75 82 85 82 8C 82 8F 82 83 82 89 82 84 82 81 82 84
  Rápido    = 82 72 96 60 82 90 82 89 82 84 82 8F  (á = 96 60 HIJACK)
  Tianren   = 82 73 82 89 82 81 82 8E 82 92 82 85 82 8E
  ```

- **Cómo buscar:**
  ```python
  import tools.codificador_castellano as cod
  b = cod.encode_spanish("Objetos")
  data = open("analisis/START_CAST.BIN","rb").read()
  print(data.find(b))  # -> 95538 (0x1752A) en free area
  ```
  Buscar ASCII `b"Magia"` = 0 hits. Buscar FW = hits.

## 2. Dónde viven las traducciones

### a) `textos_dumper.csv` (147 ok in-situ)
- CSV con 476 filas: `archivo, offset_archivo, offset_absoluto, japones, traduccion_castellano`
- Ejemplo:
  ```
  2920,START.BIN,0x00EEF8,術,raw:Magia
  2939,START.BIN,0x13D30,アイテム,raw:Objetos
  2943,START.BIN,0x13D56,システム,raw:Sistema
  ```
- `raw:` = etiqueta corta 1 celda lógica (ASCII 1 byte) usada en batalla (Atacar/Defender/Huir/Magia/Objetos) — estas SÍ son ASCII porque el motor de batalla las trata distinto.
- Resto: fullwidth 2B, se parchea in-situ si cabe (`len(new)+1 <= slot`), si no, se reubica a zona libre.

### b) `analisis/START_CAST.BIN` (98184B, traducido)
- **NO es el original.** Es `extraidos/START.BIN` + parches de `tools/parchear_start.py`:
  - Zona libre `0x17500-0x17D00` (cola de 0xFF) contiene strings largas:
    - `0x13D30 Objetos`, `0x13D3A Equipo`, `0x13D42 Hablar`, `0x13D4A Ficha`, `0x13D56 Sistema` → todas reubicadas a `0x17500+` porque no caben in-situ (ej. アイテム 8B vs Objetos 14B).
    - Redirects: tabla de punteros u32 BE `RAM_BASE + old_off` (RAM_BASE=0x10000) apuntando a `RAM_BASE + free_ptr`. Ej. `0x13D12` = tabla 6 u32: `$23D2A, $2773E, $2774D, $2775A, $23D4A, $27767`. Los `$27xxx` son free area.
  - Plantillas Z5/Z22/EFG/IT/SY con `Magia de`, `Equipo de`, `Velocidad`, `Rápido/Lento`, `Efecto/Ind/Grp`, `Tianren/Meifan/Isaac`, `NV/PV/PM`, etc.
  - Ver offsets en `DIARIO.md` sección "Notas técnicas — layout FINAL v4".

- **Por qué el otro agente vio "1-byte diff":** el minimal zip original contenía `START_CAST.BIN` original (o v3.12 con $32=2) sin traducir, no el regenerado. Ahora regenerado con `parchear_start.py` → traducido.

### c) `analisis/SSTART_CAST.BIN` (32644B)
- Boot file, contiene setup del menú (struct $A4200: `$04=7, $08=17, $0A=3, $1E=$A6000`). Originalmente sin traducir, pero necesario para pipeline.

### d) `analisis/INIT.BIN` + `OPEN.BIN` font patches
- Fuente menú 12x12 18B cells en `INIT.BIN+0x4ED0` y `OPEN.BIN+0xA710`, 78 celdas pintadas con glifos de David (Lord Monarch 8x8 centrado en 12x12): 62 fullwidth + 16 HIJACK acentos. Parcheado por `tools/fuente_menu.py` dentro de `reconstruir_iso.py`.

## 3. Pipeline de construcción ISO

**NO buscar en `track01.iso` (16MB, 2048B/sector) original — es japonés puro.**

Pipeline correcto (`tools/reconstruir_iso.py`):
1. Input: `recursos/track01.iso` (16MB, 2048B/sector, original) + `iso_map.json` (LBA de archivos)
2. Aplica `textos_dumper.csv` in-situ (ok=147, no_cabe=329, errores=0) → 167 archivos parcheados en RAM
3. Reemplaza `START.BIN` LBA59 con `analisis/START_CAST.BIN` (traducido)
4. Reemplaza `SSTART.BIN` LBA43 con `analisis/SSTART_CAST.BIN`
5. Aplica font patches INIT/OPEN (78 celdas) + GFONT 62 celdas
6. Output:
   - `/tmp/track01_castellano.iso` (16MB, 2048B/sector, para emulador que acepta ISO)
   - `Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin` (18MB, 2352B/sector raw, para .cue)
   - Mapeo raw: `raw_offset = (LBA + off//2048)*2352 + 16 + off%2048`

**Para ver traducciones:**
```bash
cd recursos
python3 tools/parchear_start.py  # regenera START_CAST.BIN traducido desde extraidos/START.BIN + CSV
python3 tools/reconstruir_iso.py
# luego buscar en [CAST].bin:
python3 -c "import tools.codificador_castellano as cod; data=open('Gen'\''ei Toshi...[CAST].bin','rb').read(); print(data.find(cod.encode_spanish('Objetos')))"
# debe dar ~248306
```

## 4. Qué debe contener el minimal v2 para GitHub

- `recursos/textos_dumper.csv` (¡faltaba en v1!)
- `recursos/analisis/START_CAST.BIN` (traducido, regenerado)
- `recursos/analisis/SSTART_CAST.BIN`
- `recursos/analisis/INIT.BIN` (opcional, para referencia font)
- `recursos/tools/reconstruir_iso.py`
- `recursos/tools/codificador_castellano.py`
- `recursos/tools/parchear_start.py`
- `recursos/tools/fuente_menu.py`
- `recursos/iso_map.json`
- `recursos/track01.iso` (original, 16MB) — o indicar que se extrae del .bin original via `iso_extract.py`
- `DIARIO.md`, `NORMAS.md`, `GUIA_FULLWIDTH.md` (este archivo)
- Capturas de referencia (051810.png etc)

## 5. Errores comunes del agente paralelo

1. **Buscar ASCII:** `grep -a Magia track01.iso` → 0 hits. Usar fullwidth.
2. **Buscar en ISO original:** `track01.iso` es japonés. Buscar en `[CAST].bin` después de reconstruir.
3. **Confundir raw vs iso:** `track01.iso` 2048B/sector vs `[CAST].bin` 2352B/sector. Offsets distintos.
4. **No aplicar redirects:** `0x13D30` original contiene `アイテム` (8B), no `Objetos`. `Objetos` está en `0x17500+` y la tabla `0x13D12` apunta allí. Hay que seguir punteros BE32.
5. **Ignorar HIJACK:** `Rápido` contiene `96 60` (á), no `82 81`. Buscar con `encode_spanish` que resuelve HIJACK.

## 6. Estado actual v3.2 baseline limpio

- `START_CAST.BIN`: $04=7 @0x119D2, $08=10 @0x119DE, $2E=5 @0x119CC, $32=3 @0x119C0 (originales)
- Menú: X=0 (no -1), Grp blanco 1 dígito OK, Equipo de Tianren OK, Velocidad/Rápido OK, Magia/Objetos/Equipo/Hablar/Ficha/Sistema en fullwidth.
- Pendiente: caja menú wrap (s de Objetos pierde 1px en x136, a de Sistema pierde 1px, O muesca 59,60 por wrap). Necesita ampliar paintable box 1-2px, texto debe quedar en X=59 v3.2. Candidatos: SD.BIN LBA251, INIT.BIN LBA107, CHR1.BIN bitmap table @0x1D28 → $AB000/$AE000/$B0000, VDP window $91/$92, blit fns 0x1244C/0x12508/0x125C4/0x12680 + bsr $1273E.

---
*Generado 2026-09-19 — para agente paralelo GitHub psichopompo/Illusion-City*
