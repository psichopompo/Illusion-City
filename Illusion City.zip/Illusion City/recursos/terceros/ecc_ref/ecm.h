////////////////////////////////////////////////////////////////////////////////
//
// #define TITLE "ecm - Encoder/decoder for Error Code Modeler format"
// #define COPYR "Copyright (C) 2002-2011 Neill Corlett"
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
////////////////////////////////////////////////////////////////////////////////
#pragma once

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "Enum.h"

/* expuestas para la verificacion externa (firmas reales de ecm.cpp) */
int8_t ecc_checksector(const uint8_t *address, const uint8_t *data, const uint8_t *ecc);
void   ecc_writesector(const uint8_t *address, const uint8_t *data, uint8_t *ecc);

void eccedc_init(void);
SectorType detect_sector(const uint8_t* sector, size_t size_available, TrackMode *trackMode);
bool reconstruct_sector(
	uint8_t* sector, // must point to a full 2352-byte sector
	SectorType type
);
