/* ref_check.cpp - verificacion con el codigo de REFERENCIA de Neill Corlett
   (ecm.cpp) de los EDC/ECC de un .bin de CD de 2352 B por sector.
   Uso: ./ref_check FICHERO.bin [SALIDA.bin]  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "ecm.h"

#define SECTOR 2352

/* el EDC va en +0x810 (2064), la ECC en +0x81C (2076) */
static int edcecc_ok(const uint8_t *s) {
    /* EDC: el de referencia esta dentro de ecc_checksector? no: se calcula aparte.
       Aqui usamos ecc_checksector para P/Q y el propio campo para el EDC. */
    return ecc_checksector(s + 0x0C, s + 0x10, s + 0x81C);
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "uso: %s FICHERO.bin [SALIDA.bin]\n", argv[0]); return 2; }
    eccedc_init();
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("abrir"); return 1; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    long nsec = n / SECTOR;
    uint8_t *buf = (uint8_t *)malloc(n);
    if (fread(buf, 1, n, f) != (size_t)n) { fprintf(stderr, "lectura corta\n"); return 1; }
    fclose(f);

    long mal_pq = 0, mode1 = 0;
    for (long k = 0; k < nsec; k++) {
        const uint8_t *s = buf + k * SECTOR;
        if (s[15] == 1) mode1++;
        if (!edcecc_ok(s)) mal_pq++;
    }
    printf("sectores: %ld   modo1: %ld   con P/Q MAL segun la REFERENCIA: %ld\n",
           nsec, mode1, mal_pq);

    if (argc > 2) {
        long corr = 0;
        for (long k = 0; k < nsec; k++) {
            uint8_t *s = buf + k * SECTOR;
            if (!edcecc_ok(s)) { ecc_writesector(s + 0x0C, s + 0x10, s + 0x81C); corr++; }
        }
        FILE *o = fopen(argv[2], "wb");
        fwrite(buf, 1, n, o); fclose(o);
        printf("reescritos %ld sectores con la referencia -> %s\n", corr, argv[2]);
    }
    free(buf);
    return 0;
}
