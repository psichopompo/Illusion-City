# Referencia para validar EDC/ECC (terceros, GPL)

Son los ficheros de **Neill Corlett** (`ecm.cpp` / `ecm.h` / `Enum.h`), del
proyecto [EccEdc](https://github.com/saramibreak/EccEdc), que a su vez deriva de
`ecm.c` de cmdpack (GPLv3). **No son nuestros** y no forman parte del pipeline:
están aquí solo para poder **validar** el EDC/ECC de un `.bin` con una
implementación independiente de la nuestra (`tools/edcecc.py`).

Verificado: para los 7842 sectores del `[CAST].bin`, `tools/edcecc.py` calcula
**byte a byte** el mismo EDC y la misma paridad P/Q que esta referencia, y el
chequeo de la referencia da **0 sectores malos**.

## Compilar
`enum.h` viene con `#include "../Enum.h"`; se ha cambiado a `"Enum.h"` y se le
han añadido los `#include <stdint.h> <stddef.h> <stdbool.h>`, y en `ecm.h` las
declaraciones de `ecc_checksector`/`ecc_writesector` (con la firma real:
`(address, data, ecc)`).

```bash
gcc -O2 -o ref_check ref_check.cpp ecm.cpp -lstdc++
./ref_check FICHERO.bin              # verifica P/Q de todos los sectores
./ref_check FICHERO.bin SALIDA.bin   # reescribe el EDC/ECC que esté mal
```

`ref_check.cpp` es nuestro: un main mínimo que llama a la referencia.

## Detalle importante que nos costó un error
En **Mode 1** la paridad se calcula **con la cabecera (4 B) tal cual**:
`ecc_writesector(sector + 0xC, sector + 0x10, sector + 0x81C)`. El "con la
cabecera a cero" (`zeroaddress`) es solo para **Mode 2 Form 1**. Tenerlo al
revés produce una paridad que parece correcta (nadie la comprueba en emulador)
pero que en hardware real no cuadra.
