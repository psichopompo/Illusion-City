import sys
from PIL import Image
def medir(png):
    im=Image.open(png).convert('RGB'); px=im.load()
    def negro(x,y):
        r,g,b=px[x,y]; return r<25 and g<25 and b<25
    def blanco(x,y):
        r,g,b=px[x,y]; return r>200 and g>200 and b>200
    # columnas con una tirada larga de negro = interior de la caja
    cols=[]
    for x in range(256):
        run=0; mejor=0
        for y in range(100,160):
            run = run+1 if negro(x,y) else 0
            mejor=max(mejor,run)
        if mejor>=24: cols.append(x)
    # filas del marco (lineas horizontales): filas con muchos pixeles no negros seguidos
    filas=[]
    for y in range(95,170):
        n=sum(1 for x in range(0,256) if not negro(x,y))
        if n>140: filas.append(y)
    tcols=[x for x in range(256) if any(blanco(x,y) for y in range(103,155))]
    return (min(cols),max(cols)) if cols else None, (min(tcols),max(tcols)) if tcols else None, (min(filas),max(filas)) if filas else None
if __name__=='__main__':
    for f in sys.argv[1:]:
        c,t,fi = medir(f)
        if not c: print('%-16s sin caja' % f); continue
        x0,x1=c
        if t:
            print('%-16s caja x=%d..%d (ancho %d, centro %.1f) | texto x=%d..%d | izq %d der %d | filas marco %s'
                  % (f,x0,x1,x1-x0+1,(x0+x1)/2,t[0],t[1],t[0]-x0,x1-t[1],fi))
        else:
            print('%-16s caja x=%d..%d (centro %.1f) | sin texto | filas %s' % (f,x0,x1,(x0+x1)/2,fi))
