import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
G=f.glifos_david()
david=np.unpackbits(np.frombuffer(f.a_celda12(G['$'],0),dtype=np.uint8))[:144]
def prueba(addr, bitoff):
    md = mdcd.MD('dt.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/tmp/dolar_test.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    prg=bytearray(md.prg8(0,0x80000))
    base=addr*8+bitoff
    for i in range(144):
        b=base+i; byte,bi=b//8, 7-(b%8)
        if david[i]: prg[byte] |= (1<<bi)
        else:        prg[byte] &= ~(1<<bi)
    md.poke_prg(0, bytes(prg))
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png('bb.png')
    a=np.array(Image.open('bb.png').convert('RGB'))
    pat=(a[135:147,198:210,0]>190)
    # mido: ¿hay tinta en la columna 0 (izquierda) y cual es el ancho?
    cols=[c for c in range(12) if pat[:,c].any()]
    return ''.join('#' if pat[r,c] else '.' for r in range(12) for c in range(12)), (min(cols),max(cols)) if cols else None
for bit in range(8):
    p,cols = prueba(0x29889, bit)
    print('bit +%d -> columnas con tinta: %s' % (bit, cols))
    if bit in (0,1,2,3):
        for r in range(12): print('   ', p[r*12:(r+1)*12])
