import sys; sys.path.insert(0,'.')
exec(open('t_busqueda.py').read().split("base = dolar([])")[0])
base = dolar([])
print('base:', base)
for k in range(-2515,-2470):
    r=dolar([k])
    if r!=base: print('  rel %5d -> %s  <-- CELDA DEL $' % (k,r))
