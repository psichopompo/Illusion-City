"""flujo_limpio.py - PARTIDA LIMPIA sin states contaminados (idea de David).

El savestate guarda la PRG-RAM entera, y con ella los datos que trajo el disco
(tabla de nombres, textos, rutinas). Por eso "cargar un state" NO sirve para
comprobar cosas que vienen del disco.

METODO (medido y funcionando):
  1. state de la sala de guardado (TEST_L.state) -> pantalla [セーブ]
  2. C  -> guarda en el slot 1
  3. retro_reset() -> arranque desde BIOS, todo se relee del CD
  4. titulo -> START hasta que responda -> CARGAR PARTIDA (opcion 1) -> C (slot 1)
  5. dentro del juego SIN ningun state: lo que se ve viene del disco

Uso:
    python3 flujo_limpio.py guardar <cue> <prefijo>
    python3 flujo_limpio.py cargar  <cue> <prefijo>
    python3 flujo_limpio.py nueva   <cue> <prefijo>   (PARTIDA NUEVA, sin save)
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def guarda(md, pref):
    md.load_rzip(SALA); md.run(40)
    pulsa(md, 'C', 8, 60)          # abre [セーブ]
    md.save_png(pref + '_save.png')
    pulsa(md, 'C', 8, 90)          # guarda en el slot 1
    md.run(90)
    print('  guardado en el slot 1')


def arranca(md):
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa(md, 'START', 8, 60)
    md.run(250)


def carga(md, pref):
    arranca(md)
    md.save_png(pref + '_titulo.png')
    pulsa(md, 'C', 8, 60)          # CARGAR PARTIDA -> [ロード]
    md.save_png(pref + '_load.png')
    pulsa(md, 'C', 8, 60)          # slot 1
    md.run(700)
    md.save_png(pref + '_juego.png')
    print('  partida cargada del CD (sin states)')


def nueva(md, pref):
    arranca(md)
    md.save_png(pref + '_titulo.png')
    pulsa(md, 'DOWN', 6, 40)       # PARTIDA NUEVA
    pulsa(md, 'C', 8, 60)
    md.run(300)
    for _ in range(14):
        pulsa(md, 'C', 6, 30)
        pulsa(md, 'START', 6, 20)
    md.run(200)
    md.save_png(pref + '_nueva.png')
    print('  partida nueva')


if __name__ == '__main__':
    modo, cue, pref = sys.argv[1], sys.argv[2], sys.argv[3]
    md = mdcd.MD(cue)
    if modo == 'guardar':
        guarda(md, pref)
    elif modo == 'cargar':
        carga(md, pref)
    else:
        nueva(md, pref)
