import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
prg = md.prg8(0, 0x80000)
print('los 18 B del glifo del $ en memoria ($299C4):')
print('  ', prg[0x299C4:0x299D6].hex(' '))
print()
print('¿de donde salen? busco esa secuencia en los ficheros del juego...')
spec3=importlib.util.spec_from_file_location('p','/home/user/Illusion City/recursos/tools/parche_lote3.py')
m=importlib.util.module_from_spec(spec3); spec3.loader.exec_module(m)
raw=open("/home/user/Illusion City/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin",'rb').read()
pat=prg[0x299C4:0x299D6]
for nom,lba,sz in (('INIT.BIN',107,149400),('OPEN.BIN',285,69258),('SD.BIN',251,69194),
                   ('CHR.BIN',180,94310),('CHR1.BIN',227,47984),('GFONT.BIN',679,7920)):
    d=m.region(raw,lba,sz)
    i=d.find(pat)
    if i>=0: print('  %-12s -> offset 0x%X' % (nom,i))
    else: print('  %-12s -> no' % nom)
