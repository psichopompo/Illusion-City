import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def prueba(encoger_siempre, nom):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    if encoger_siempre:
        C2 = (bytes.fromhex('2f01')+bytes.fromhex('2f0b')+
              bytes.fromhex('4eb9')+(0x18B18).to_bytes(4,'big')+
              bytes.fromhex('53680014')+
              bytes.fromhex('265f')+bytes.fromhex('221f')+
              bytes.fromhex('30280008')+
              bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big'))
    else:
        C2,_ = pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)
    md.poke_prg(pm.CAP2_RAM, C2)
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.press(IDS['A']); md.run(20); md.release(); md.run(70)
    f='sw_%s.png'%nom; md.save_png(f)
    im=Image.open(f).convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(45,245) if any(claro(x,y) for y in range(135,150))]
    runs=[]
    for x in t:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    print('  %-22s x=%d..%d  pasos=%s' % (nom, min(t), max(t), [runs[i+1][0]-runs[i][0] for i in range(min(5,len(runs)-1))]))
print('=== ¿encoge el dinero si encojo SIEMPRE? ===')
prueba(False, 'con deteccion actual')
prueba(True,  'encogiendo siempre')
