"""flujo_juego.py - flujo limpio y comprobacion DENTRO de la partida.

  guarda (state de la sala) -> reset -> titulo -> CARGAR PARTIDA -> slot 1 (C)
  -> dentro del juego: abre el menu y mira el HUD (nombres) y los menus.

Uso: python3 flujo_juego.py <cue> <prefijo>
"""
import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)

def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

# 1) guardar
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60)
pulsa('C', 8, 90)
md.run(90)
# 2) reset + titulo
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
md.save_png(pref + '_titulo.png')
# 3) CARGAR PARTIDA (opcion 1) + slot 1
pulsa('C', 8, 60)          # entra en [ロード]
md.save_png(pref + '_load.png')
pulsa('C', 8, 120)         # carga el slot 1
md.run(400)
md.save_png(pref + '_juego.png')
print('  dentro del juego')
# 4) menu + nombre
pulsa('A', 18, 60)
md.save_png(pref + '_menu.png')
pulsa('C', 8, 70)          # Magia (fila 0) -> deberia mostrar el nombre del personaje
md.save_png(pref + '_magia.png')
print('  capturas hechas')
