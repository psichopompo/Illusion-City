import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image, ImageChops
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
G=f.glifos_david()
def corre(addr=None, data=None, salida='x.png'):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if addr is not None: md.poke_prg(addr, data)
    md.press(IDS['A']); md.run(20); md.release(); md.run(60)
    md.save_png(salida)
    return salida
a=corre(None,None,'ref_nueva.png')
b=corre(0x29852, f.a_celda12(G['$'],0), 'con_david.png')
d=ImageChops.difference(Image.open(a).convert('L'), Image.open(b).convert('L'))
print('pixeles distintos:', sum(1 for p in d.get_flattened_data() if p>60))
print('zona que cambia:', d.getbbox())
# y el dinero de la version con David
im=Image.open('con_david.png').convert('RGB')
im.crop((40,128,240,160)).resize((200*4,32*4), Image.NEAREST).save('/home/user/zoom_ok.png')
