"""tpl_mapa.py - despieza la plantilla de MAGIA elemento a elemento, con su columna.

Regla MEDIDA (comparando la plantilla con la pantalla)
    columna_en_pantalla = 2 + indice_de_elemento_visible_de_la_linea
    x = 1 + 8*columna        (el primer elemento visible de cada linea cae en x=17)
    el salto '|' (2f 6e) pasa a la linea siguiente; las marcas 26 xx NO ocupan columna.

Uso: python3 tpl_mapa.py [fichero.bin] [offset_plantilla_hex]
"""
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    'm', os.path.join(AQUI, '..', 'recursos', 'tools', 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
sspec = importlib.util.spec_from_file_location(
    'lp', os.path.join(AQUI, '..', 'recursos', 'tools', 'lee_plantilla.py'))
lp = importlib.util.module_from_spec(sspec)
sspec.loader.exec_module(lp)

BIN = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(AQUI), "Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin")
TPL = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x1758A

raw = open(BIN, 'rb').read()
st = m.region(raw, 59, 98184)
tpl = st[TPL:TPL + 0x100]

linea, col, i = 0, 0, 0
print('  off   RAM       linea col  x     elemento')
while i < len(tpl):
    b = tpl[i:i + 2]
    if b == b'\x00\x00':
        print('  0x%03X  $%06X  %d  --   ---   FIN' % (i, TPL + i + 0x10000, linea))
        break
    if b == b'\x2f\x6e':
        print('  0x%03X  $%06X  %d  --   ---   | salto (col->0)' % (i, TPL + i + 0x10000, linea))
        linea += 1
        col = 0
        i += 2
        continue
    if b[0] == 0x26:
        print('  0x%03X  $%06X  %d  --   ---   marca $%s' % (i, TPL + i + 0x10000, linea, chr(b[1])))
        i += 2
        continue
    txt = lp.dec(b)
    print('  0x%03X  $%06X  %d  %2d   %3d   %r' % (i, TPL + i + 0x10000, linea, col, 1 + 8 * (col + 2), txt))
    col += 1
    i += 2
print()
for ram, nom in ((0x2759A, 'NOMBRE'), (0x275DA, 'valor Ahora'), (0x275EC, 'valor Individual'),
                 (0x27600, 'valor Maximo'), (0x27612, 'valor Grupo')):
    print('  %-16s $%06X = plantilla + 0x%02X' % (nom, ram, ram - (TPL + 0x10000)))
