import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
md.mem_window(0x29400, 0x29C00)
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(45)
md.trace(0)
reads=[e for e in md.events() if e.kind==10]
print('lecturas en la zona de la fuente ($29400-$29C00): %d' % len(reads))
# agrupo por frame: el dibujado del dinero ocurre en unos pocos frames
frames={}
for e in reads: frames.setdefault(e.frame,[]).append(e)
print('frames con lecturas:', sorted(frames)[:8])
f=max(frames) if frames else None
if f is not None:
    seq=[]
    for e in frames[f]:
        if not seq or seq[-1][0]!=e.a: seq.append([e.a,1])
        else: seq[-1][1]+=1
    print('secuencia de direcciones del ultimo frame (dir, repeticiones):')
    for a,n in seq[-24:]: print('   $%05X x%d' % (a,n))
