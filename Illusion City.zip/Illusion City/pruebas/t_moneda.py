import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def fw(s):
    out=bytearray()
    for ch in s:
        if 'A'<=ch<='Z': out+=bytes([0x82,0x60+ord(ch)-65])
        elif 'a'<=ch<='z': out+=bytes([0x82,0x81+ord(ch)-97])
        elif '0'<=ch<='9': out+=bytes([0x82,0x4F+ord(ch)-48])
        elif ch==' ': out+=bytes([0x81,0x40])
        elif ch==':': out+=bytes([0x81,0x46])
        elif ch=='$': out+=bytes([0x81,0x90])
    return bytes(out)
def prueba(cadena, nom):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, fw('Dinero:')+b'\x00\x00')
    md.poke_prg(0x27AD0, fw(cadena)+b'\x00\x00')
    for off in (0x10B18, 0x10BAE, 0x10CE8, 0x10DBA):
        md.poke_prg(0x10000+off, bytes.fromhex('43f9')+(0x00027AD0).to_bytes(4,'big'))
    md.press(IDS['A']); md.run(20); md.release(); md.run(65)
    f='mon_%s.png'%nom; md.save_png(f)
    im=Image.open(f).convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,250) if any(claro(x,y) for y in range(133,152))]
    print('  %-12s x=%d..%d  (%d px)' % (nom, min(t), max(t), max(t)-min(t)+1))
print('=== ¿importa el espacio inicial de la cadena de la moneda? ===')
prueba(' HK$','con espacio')
prueba('HK$','sin espacio')
