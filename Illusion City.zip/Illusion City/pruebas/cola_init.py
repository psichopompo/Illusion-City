"""cola_init.py - ¿el juego carga el ULTIMO SECTOR ENTERO de INIT.BIN?

INIT.BIN mide 149400 B y se carga en $28000: acaba en $4C797. El sector del disco
(LBA 179) tiene 2048 B de datos, de los que 1944 son del fichero y 104 son relleno.
Si el cargador lee sectores enteros, esos 104 B estan en la PRG-RAM en
$4C798..$4C7FF y son ESPACIO LIBRE de verdad (no los usa ningun otro dato).

Uso: python3 cola_init.py [cue]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'aa.cue'
SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)
prg = md.prg8(0, 0x80000)
print('  PRG-RAM $4C780..$4C820 (en el juego):')
for o in range(0x4C780, 0x4C820, 16):
    print('    $%05X  %s' % (o, prg[o:o+16].hex(' ')))
print()
print('  $4C798..$4C7FF deberia ser el relleno del sector si se carga entero.')
# menu abierto, a ver si cambia
pulsa(md, 'A', 18, 60)
pulsa(md, 'C', 8, 70)
prg2 = md.prg8(0, 0x80000)
print('  con el menu abierto:')
for o in range(0x4C780, 0x4C820, 16):
    print('    $%05X  %s' % (o, prg2[o:o+16].hex(' ')))
