"""bateria_bc.py - repaso visual completo de TEST_BC (cada menu, captura propia).
Uso: python3 bateria_bc.py <cue> <prefijo>
"""
import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)

def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

def foto(n):
    p = '%s_%s.png' % (pref, n)
    md.save_png(p)
    print('  ' + p)

# flujo limpio: save + reset + cargar del CD
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C',8,60); pulsa('C',8,90); md.run(90)
md.lib.retro_reset(); md.run(800)
for _ in range(6): pulsa('START',8,60)
md.run(250)
pulsa('C',8,60); pulsa('C',8,60); md.run(700)
# normalizar: cerrar lo que haya abierto
for _ in range(3):
    md.save_png('/tmp/_n0.png'); pulsa('B',8,60); md.run(200)
    md.save_png('/tmp/_n1.png')
    a = np.array(Image.open('/tmp/_n0.png').convert('RGB'))
    b = np.array(Image.open('/tmp/_n1.png').convert('RGB'))
    if int((np.abs(a.astype(int)-b.astype(int)).sum(axis=2)>0).sum()) < 200: break
pulsa('A',20,90); md.run(250)
foto('01_menu')

# Magia (fila 0)
pulsa('C',10,160); md.run(280)
foto('02_magia')
pulsa('B',10,130); md.run(250)

# Objetos (fila 1)
pulsa('DOWN',8,60); md.run(110)
pulsa('C',10,160); md.run(280)
foto('03_objetos')
pulsa('RIGHT',10,110); md.run(150)
foto('04_objetos_der')
pulsa('RIGHT',10,110); md.run(150)
foto('05_objetos_der2')
pulsa('B',10,130); md.run(250)

# Estado (fila 4) + submenu (Perfiles/Tecnicas/Combate)
for _ in range(3): pulsa('DOWN',8,60); md.run(110)
pulsa('C',10,160); md.run(280)
foto('06_estado')
pulsa('C',10,160); md.run(250)
foto('07_submenu')
# Tecnicas (2a entrada del submenu)
pulsa('DOWN',8,70); md.run(110)
pulsa('C',10,220); md.run(350)
foto('08_tecnicas')
pulsa('B',10,130); md.run(250)
pulsa('B',10,130); md.run(250)
# Combate (3a entrada del submenu)
pulsa('C',10,160); md.run(250)
pulsa('DOWN',8,70); md.run(110)
pulsa('DOWN',8,70); md.run(110)
pulsa('C',10,220); md.run(350)
foto('09_combate')
pulsa('B',10,130); md.run(250)
pulsa('B',10,130); md.run(250)

# Sistema (fila 5): ventana + Velocidad + Ajustes + SALIDA
for _ in range(5): pulsa('DOWN',8,60); md.run(110)
pulsa('C',10,160); md.run(250)
foto('10_sistema')
pulsa('C',10,200); md.run(300)
foto('11_velocidad')
pulsa('B',10,130); md.run(250)
pulsa('DOWN',8,70); md.run(110)
pulsa('C',10,220); md.run(350)
foto('12_ajustes')
pulsa('B',10,130); md.run(250)
# salida al menu principal (el flujo del cuelgue)
pulsa('B',10,130); md.run(250)
a0 = None; vivos = 0
for k in range(10):
    md.save_png('/tmp/_q.png')
    a = np.array(Image.open('/tmp/_q.png').convert('RGB'))
    if a0 is not None:
        if int((np.abs(a.astype(int)-a0.astype(int)).sum(axis=2)>0).sum()) > 0: vivos += 1
    a0 = a
    md.run(20)
print('  tras salir al menu principal: %d/10 ventanas de muestreo vivas' % vivos)
foto('13_menu_tras_salir')
pulsa('DOWN',10,130); md.run(200)
foto('14_menu_responde')
print('OK bateria')
