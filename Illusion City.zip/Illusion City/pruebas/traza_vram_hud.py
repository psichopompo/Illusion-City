"""traza_vram_hud.py - QUE escribe el juego en la VRAM del panel del HUD cada frame.

El panel del HUD (marco, rayas, letras NV/PV/PM y los numeros) no sale de ninguna
tabla de texto: es grafismo. Aqui se graba TODO lo que el juego escribe en la VRAM
(fiestas incluidas) durante unos frames con el panel a la vista, para ver:
  - que direcciones de VRAM toca (que tiles),
  - desde que rutina (PC),
  - con que valores.

Uso: python3 traza_vram_hud.py [cue] [frames]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'ab.cue'
NFRAMES = int(sys.argv[2]) if len(sys.argv) > 2 else 4
SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)
md.save_png('/tmp/traza_base.png')

md.reset_events()
md.config(exec_=0, flow=0, vram=1, cram=1, vdpreg=0, mem=0)
md.trace(True)
md.run(NFRAMES)
md.trace(False)
evs = md.events()
print('  %d eventos en %d frames' % (len(evs), NFRAMES))
porpc = {}
porrango = {}
for e in evs:
    if e.kind == mdcd.EV_VRAMW:
        t = (e.a // 32) % 2048
        porpc.setdefault(e.pc, []).append((t, e.a, e.v, e.width, e.frame))
        porrango.setdefault(t, []).append((e.pc, e.v, e.width, e.frame))
print('  --- tiles escritos (agrupados de 8 en 8) ---')
claves = sorted(porrango)
grupos = []
for t in claves:
    if grupos and t - grupos[-1][-1] <= 1:
        grupos[-1].append(t)
    else:
        grupos.append([t])
for g in grupos:
    n = sum(len(porrango[t]) for t in g)
    print('    tiles %4d..%4d  (%d escrituras)  PCs: %s'
          % (g[0], g[-1], n, sorted({hex(pc) for t in g for pc, _, _, _ in porrango[t]})[:4]))
print('  --- escrituras por PC (las 12 con mas) ---')
for pc, lst in sorted(porpc.items(), key=lambda kv: -len(kv[1]))[:12]:
    tiles = sorted({t for t, _, _, _, _ in lst})
    print('    PC %06X  %5d escrituras  tiles %s%s'
          % (pc, len(lst), tiles[:14], '...' if len(tiles) > 14 else ''))
