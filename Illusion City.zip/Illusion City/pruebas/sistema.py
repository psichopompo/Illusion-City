"""sistema.py - navega al menu SISTEMA y saca capturas, con clasificacion de estado.

Uso: python3 sistema.py <cue> <prefijo> [combate]
   combate = 1 -> antes de Sistema pasa por Estado -> Combate (la secuencia del bug)
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

cue, pref = sys.argv[1], sys.argv[2]
por_combate = len(sys.argv) > 3 and sys.argv[3] == 'combate'
md = mdcd.MD(cue)


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(n):
    p = '%s_%s.png' % (pref, n)
    md.save_png(p)
    return p


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado (frame %d)' % md.frame)
foto('juego')

pulsa('A', 20, 90)
md.run(300)
foto('menu')

if por_combate:
    for _ in range(4):                    # Estado
        pulsa('DOWN', 8, 60); md.run(100)
    pulsa('C', 10, 150); md.run(300)
    foto('submenu')
    for _ in range(2):                    # Combate
        pulsa('DOWN', 8, 60); md.run(100)
    pulsa('C', 10, 200); md.run(400)
    foto('combate')
    print('  combate visto (frame %d)' % md.frame)
    pulsa('B', 10, 90); md.run(200)      # vuelve al submenu
    foto('vuelta_submenu')
    pulsa('B', 10, 90); md.run(200)      # vuelve al menu principal
    foto('vuelta_menu')
    for _ in range(4):                    # de Estado a Sistema
        pulsa('DOWN', 8, 60); md.run(100)
    pulsa('C', 10, 150); md.run(400)
    foto('sistema')
    print('  sistema visto (frame %d)' % md.frame)
else:
    for _ in range(5):                    # Sistema
        pulsa('DOWN', 8, 60); md.run(100)
    pulsa('C', 10, 150); md.run(400)
    foto('sistema')
    print('  sistema visto (frame %d)' % md.frame)

# ¿sigue vivo el juego? corremos 300 frames mas y volvemos a capturar
antes = md.frame
md.run(300)
foto('despues')
print('  +300 frames: %d -> %d' % (antes, md.frame))
