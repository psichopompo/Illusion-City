"""verifica_tabla.py - flujo LIMPIO (guardar -> reset -> CARGAR) y mide el HUD.

Uso: python3 verifica_tabla.py <cue> <prefijo>
"""
import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)

def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)          # guardar
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)                      # CARGAR -> slot 1
md.run(700)
md.save_png(pref + '_juego.png')
print('  en el juego (partida del CD)')
