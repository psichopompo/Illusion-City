"""ver_N.py - escribe un patron (N) en un tile y guarda captura del panel.

Uso: python3 ver_N.py <cue> <tile> [salida.png]
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1]
T = int(sys.argv[2])
SAL = sys.argv[3] if len(sys.argv) > 3 else '/tmp/ver_N.png'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

# N: dos verticales y la diagonal, en 8 px de ancho
N = [0b11000011, 0b11100011, 0b11110011, 0b11011011,
     0b11001111, 0b11000111, 0b11000011, 0b00000000]
# construir los 32 B del tile (4 bytes por fila, 2 px por byte)
d = bytearray()
for b in N:
    d += bytes([b, b, b, b])
print('  patron a escribir: %s' % d[:16].hex(' '))
for i in range(16):
    md.lib.arena_vdp_write16(T * 32 + 2 * i, (d[2 * i] << 8) | d[2 * i + 1])
md.run(3)
md.save_png(SAL)
print('  captura: %s (tile %d)' % (SAL, T))
