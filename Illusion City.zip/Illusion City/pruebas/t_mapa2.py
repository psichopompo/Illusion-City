import sys; sys.path.insert(0,'.')
exec(open('t_hallar.py').read().split("# lugar del $")[0])
import numpy as np
from PIL import Image
def cambia(f1,f2):
    a=np.array(Image.open(f1).convert('L')).astype(int)
    b=np.array(Image.open(f2).convert('L')).astype(int)
    d=np.abs(a-b)>60
    ys,xs=np.nonzero(d)
    return (xs.min(),xs.max (),ys.min(),ys.max()) if len(xs) else None
prueba(None,'m_ref.png')
print('celda -> zona de pantalla que cambia:')
for celda in (33,34,45,55,69,70,71,72,73,74):
    prueba(celda,'m_%d.png'%celda)
    print('  celda %2d -> %s' % (celda, cambia('m_ref.png','m_%d.png'%celda)))
