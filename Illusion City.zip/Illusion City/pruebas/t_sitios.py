import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from collections import Counter
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.config(exec_=1)
md.exec_filter(1, 0x20000, 0x22000)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(45)
md.trace(0)
evs=[e for e in md.events() if e.kind==1 and e.width==0x5A]
c=Counter(e.pc for e in evs)
print('los 4 sitios que cargan la cadena de la moneda (lea $21882):')
for sitio in (0x20B18, 0x20BAE, 0x20CE8, 0x20DBA):
    print('   $%05X -> %d veces' % (sitio, c.get(sitio,0)))
print()
print('las rutinas de dinero mas ejecutadas:')
for a,n in c.most_common(12): print('   $%05X x%d' % (a,n))
