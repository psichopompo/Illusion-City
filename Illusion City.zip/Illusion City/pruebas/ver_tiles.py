"""ver_tiles.py - imprime tiles de VRAM como ASCII para identificarlos a ojo.

Uso: python3 ver_tiles.py <cue> <desde> <hasta> [ancho_celda]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1]
DESDE, HASTA = int(sys.argv[2]), int(sys.argv[3])
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

for t in range(DESDE, HASTA):
    a = t * 32
    d = bytes(md.vram8(a + i) for i in range(32))
    lineas = []
    for y in range(8):
        fila = []
        for bx in range(4):
            b = d[y * 4 + bx]
            fila += [(b >> 4) & 0xF, b & 0xF]
        lineas.append(''.join('#' if v >= 0x8 else ('.' if v <= 2 else 'o') for v in fila))
    print('tile %4d  %s | %s' % (t, lineas[0], lineas[4]))
