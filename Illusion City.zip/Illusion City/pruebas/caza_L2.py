"""caza_L2.py - que tile dibuja la L del panel (probando solo la caja de la L).

Cajas medidas en la pantalla de partida cargada:
    L: x=211..213  y=40..46        V: x=215..217
    H: x=211..213  y=48..54        P: x=215..217
    M: x=211..213  y=56..62        P2: x=215..217
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

CAJAS = {'L': (210, 214, 39, 47), 'V': (214, 218, 39, 47),
         'H': (210, 214, 47, 55), 'P': (214, 218, 47, 55),
         'M': (210, 214, 55, 63), 'P2': (214, 218, 55, 63)}


def tinta():
    md.save_png('/tmp/cl1.png')
    a = np.array(Image.open('/tmp/cl1.png').convert('RGB')).astype(int)
    m = (np.abs(a - np.array([239, 170, 0])).sum(axis=2) < 130)
    return {k: int(m[y0:y1, x0:x1].sum()) for k, (x0, x1, y0, y1) in CAJAS.items()}


base = tinta()
print('  tinta base:', base)
print('  tiles que quitan tinta SOLO de la L (candidatos a ser la L):')
for t in range(1700, 1861):
    orig = bytes(md.vram8(t * 32 + i) for i in range(32))
    for i in range(16):
        md.lib.arena_vdp_write16(t * 32 + 2 * i, 0x0CCC)
    md.run(1)
    ahora = tinta()
    for i in range(16):
        md.lib.arena_vdp_write16(t * 32 + 2 * i, (orig[2 * i] << 8) | orig[2 * i + 1])
    dif = {k: base[k] - ahora[k] for k in base}
    afect = [k for k, v in dif.items() if v > 1]
    if afect:
        print('   tile %4d -> %s  (perdidas %s)' % (t, afect, {k: dif[k] for k in afect}))
