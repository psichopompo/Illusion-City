import sys; sys.path.insert(0,'.')
import mdcd
from collections import Counter
md = mdcd.MD('dt.cue')
md.mem_window(0x0, 0x9FFFF)
md.config(mem=1)
md.trace(1)
md.run(60)
md.trace(0)
evs=md.events()
print('SIN state: %d eventos %s' % (len(evs), dict(Counter(e.kind for e in evs))))
if len(evs)==0:
    print('  -> el hook no graba nada: el problema esta en el core/arnes, no en el state')
else:
    print('  -> funciona; el problema aparece al cargar el state')
