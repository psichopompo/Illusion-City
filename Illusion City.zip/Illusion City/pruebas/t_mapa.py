import sys; sys.path.insert(0,'.')
exec(open('t_hallar.py').read().split("# lugar del $")[0])
import numpy as np
from PIL import Image, ImageChops
ref = Image.open(prueba(None,'m_ref.png')).convert('L')
print('para cada celda, la zona de pantalla que cambia al tocarla:')
for celda in (33,34,45,55,69,70,71,72,73,74):
    a=Image.open(prueba(celda,'m_%d.png'%celda)).convert('L')
    d=ImageChops.difference(ref,a)
    bbox=d.getbbox()
    print('  celda %2d -> bbox %s' % (celda, bbox))
