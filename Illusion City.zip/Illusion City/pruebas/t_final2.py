import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
g8=f.glifos_david()['$']
def bytes24(ox,oy):
    out=bytearray()
    for r in range(12):
        row=0; rr=r-oy
        if 0<=rr<8:
            for c in range(8):
                col=ox+c
                if g8[rr][c] and col<16: row |= (0x8000>>col)
        out += row.to_bytes(2,'big')
    return bytes(out)
def prueba(addr,ox,oy,guardar=None):
    md = mdcd.MD('dt.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/tmp/dolar_test.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    md.poke_prg(addr, bytes24(ox,oy))
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    f2=guardar or 'f2.png'; md.save_png(f2)
    a=np.array(Image.open(f2).convert('RGB'))
    return (a[133:152,190:230,0]>190)
for ox in (2,1,3,0):
    pat=prueba(0x29892,ox,2)
    print('off_x=%d -> tinta en la zona: %d' % (ox, pat.sum()))
pat=prueba(0x29892,2,2,'/home/user/Illusion City/verificado_dolar_ok.png')
a=np.array(Image.open('/home/user/Illusion City/verificado_dolar_ok.png').convert('RGB'))
print()
print('el $ dibujado (x=194..214, y=133..152):')
for r in range(19):
    print('   ', ''.join('#' if a[133+r,194+c,0]>190 else '.' for c in range(20)))
