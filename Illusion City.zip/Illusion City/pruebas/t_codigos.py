import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
# CAP2 "espia": guarda d0 en $A9F00 y hace el glifo, sin encoger
ESPIA = (bytes.fromhex('2f01')+bytes.fromhex('2f0b')+
         bytes.fromhex('33c0')+(0x000A9F00).to_bytes(4,'big')+   # move.w d0,$A9F00
         bytes.fromhex('4eb9')+(0x18B18).to_bytes(4,'big')+
         bytes.fromhex('265f221f')+
         bytes.fromhex('30280008')+
         bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big'))
md.poke_prg(pm.CAP2_RAM, ESPIA)
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
# el espia solo guarda el ULTIMO; mejor: guardo todos con un contador
ESPIA2 = (bytes.fromhex('2f01')+bytes.fromhex('2f0b')+bytes.fromhex('2f02')+bytes.fromhex('2f03')+
          bytes.fromhex('3639')+(0x000A9F02).to_bytes(4,'big')+   # move.w $A9F02,d3
          bytes.fromhex('41f9')+(0x000A9F40).to_bytes(4,'big')+   # lea $A9F40,a0
          bytes.fromhex('3580')+(0x0000).to_bytes(2,'big') if False else b'')
