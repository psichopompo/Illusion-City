import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def captura(con_parche, salida):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    if con_parche:
        md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
        md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
        md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
        md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.press(IDS['A']); md.run(20); md.release(); md.run(70)
    md.save_png(salida)
    return md
captura(False, 'lado_SIN.png')
captura(True,  'lado_CON.png')
for f,nom in (('lado_SIN.png','SIN parche'),('lado_CON.png','CON parche')):
    im=Image.open(f).convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,245) if any(claro(x,y) for y in range(133,152))]
    print('%-12s dinero: x=%d..%d  (%d px)' % (nom, min(t), max(t), max(t)-min(t)+1))
