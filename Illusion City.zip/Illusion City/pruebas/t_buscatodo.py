import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AD0, bytes.fromhex('8190')+b'\x00')
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA):
    md.poke_prg(0x10000+off, bytes.fromhex('43f9')+(0x00027AD0).to_bytes(4,'big'))
md.press(IDS['A']); md.run(20); md.release(); md.run(55)
md.save_png('todo.png')
a=np.array(Image.open('todo.png').convert('RGB'))
pat=(a[135:147,198:210,0]>190).astype(np.uint8).reshape(144)
# busco el patron en TODA la PRG-RAM y en la tabla (con alineaciones 0 y 1 byte)
prg=md.prg8(0,0x80000)
bits=np.unpackbits(np.frombuffer(prg,dtype=np.uint8))
hits=[]
for off in range(0, len(bits)-144):
    if np.array_equal(bits[off:off+144], pat): hits.append(off)
print('coincidencias en la PRG-RAM (byte, bit):', [(h//8, h%8) for h in hits[:20]])
# tambien con el patron desplazado (el glifo puede estar en otra fila de la celda)
for dy in (-1,1):
    pat2=(a[135+dy:147+dy,198:210,0]>190).astype(np.uint8).reshape(144)
    h2=[o for o in range(0,len(bits)-144) if np.array_equal(bits[o:o+144], pat2)]
    if h2: print('  con desplazamiento vertical %+d: %s' % (dy,[(o//8,o%8) for o in h2[:8]]))
