import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from collections import Counter
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.mem_window(0x29800, 0x29900)          # la zona donde vive el $ medido
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(40)
md.trace(0)
reads=[e for e in md.events() if e.kind==10]
print('lecturas en $29800-$29900: %d' % len(reads))
print('(pc del que lee, direccion leida)')
for e in reads[:20]: print('   pc=$%06X  lee $%05X' % (e.pc, e.a))
print()
c=Counter(e.pc for e in reads)
print('PC que leen esa zona:', c.most_common(6))
