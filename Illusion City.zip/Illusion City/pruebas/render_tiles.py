"""render_tiles.py - dibuja un rango de tiles de VRAM como imagen para poder mirarlos.

Uso: python3 render_tiles.py <cue> <desde> <hasta> <salida.png> [zoom]
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE, DESDE, HASTA, SAL = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
ZOOM = int(sys.argv[5]) if len(sys.argv) > 5 else 6
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


# arranque limpio + cargar partida (asi el panel esta en pantalla)
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

n = HASTA - DESDE
cols = 16
filas = (n + cols - 1) // cols
img = Image.new('RGB', (cols * 8, filas * 8), (0, 0, 0))
px = img.load()
for k, t in enumerate(range(DESDE, HASTA)):
    a = t * 32
    d = bytes(md.vram8(a + i) for i in range(32))
    for y in range(8):
        for bx in range(4):
            b = d[y * 4 + bx]
            for j, nib in enumerate(((b >> 4) & 0xF, b & 0xF)):
                col = 8 * (k % cols) + bx * 2 + j
                row = 8 * (k // cols) + y
                if nib >= 0x8:
                    px[col, row] = (255, 255, 255)
                elif nib == 0x6:
                    px[col, row] = (0, 0, 80)
                elif nib == 0x7:
                    px[col, row] = (0, 80, 0)
                elif nib == 0x4:
                    px[col, row] = (80, 80, 0)
img = img.resize((img.size[0] * ZOOM, img.size[1] * ZOOM), Image.NEAREST)
img.save(SAL)
print('  %s  (%d tiles desde %d, %dx%d)' % (SAL, n, DESDE, cols, filas))
print('  orden: izq->der, arriba->abajo, 16 por fila')
