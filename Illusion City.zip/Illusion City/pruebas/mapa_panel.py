"""mapa_panel.py - mapea celda de nametable -> fila de pantalla -> tile.

Para cada ty de la columna de las etiquetas (tx=26 y 27), vacia la celda y mide en
que fila de pantalla se nota. Asi se sabe que tile dibuja cada fila (y por tanto
donde estan las letras L, V, H, P, M).

Uso: python3 mapa_panel.py <cue>
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

md.save_png('/tmp/mp0.png')
a0 = np.array(Image.open('/tmp/mp0.png').convert('RGB')).astype(int)
amar = (np.abs(a0 - np.array([239, 170, 0])).sum(axis=2) < 130)
print('  filas con tinta amarilla (etiquetas) en x=200..236:')
filas = []
for y in range(20, 110):
    if amar[y, 200:236].sum() > 1:
        if filas and y <= filas[-1][1] + 1:
            filas[-1][1] = y
        else:
            filas.append([y, y])
print('   ', filas)

r = md.vdp_regs()
print('  regs: 2=%d 3=%d 4=%d 6=%d 7=%d 16=%d' % (r[2], r[3], r[4], r[6], r[7], r[16]))
bases = [(0xC000, 'A'), (0xC800, 'A+800'), (0xD000, 'W'), (0xE000, 'B'), (0xF000, 'F')]
print('  celdas tx=26,27 en ty=0..12 -> tile y fila de pantalla que borra:')
for base, nom in bases:
    for ty in range(0, 13):
        for tx in (26, 27):
            o = base + 2 * (ty * 64 + tx)
            v = md.vram16(o)
            md.lib.arena_vdp_write16(o, 0x0000)
            md.run(1)
            md.save_png('/tmp/mp1.png')
            a1 = np.array(Image.open('/tmp/mp1.png').convert('RGB')).astype(int)
            d = np.abs(a0 - a1).sum(axis=2)
            ys, xs = np.nonzero(d[20:110, 200:240])
            md.lib.arena_vdp_write16(o, v)
            if len(ys):
                print('   base $%X (%s) celda(%d,%2d) tile %4d -> y=%d..%d (x=%d..%d)'
                      % (base, nom, tx, ty, v & 0x7FF, 20 + ys.min(), 20 + ys.max(),
                         200 + xs.min(), 200 + xs.max()))
