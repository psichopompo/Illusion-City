"""caza_tiles_hud.py - ¿que tile del bloque del panel del HUD dibuja cada letra?

METODO (con arena_vdp_write16, que ya se ve en pantalla)
  Con el juego cargado (flujo limpio) y el panel del HUD a la vista, se escribe un
  BLOQUE SOLIDO blanco en UN tile del bloque (1764+) y se guarda una captura; luego
  se restaura el contenido original del tile. El bloque blanco de 8x8 aparece en la
  posicion exacta que ocupa ese tile, asi que se puede mapear tile -> (x,y).

Uso: python3 caza_tiles_hud.py [cue] [prefijo] [tile_ini] [tile_fin]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'ab.cue'
PREF = sys.argv[2] if len(sys.argv) > 2 else '/tmp/hud'
T0 = int(sys.argv[3]) if len(sys.argv) > 3 else 1764
T1 = int(sys.argv[4]) if len(sys.argv) > 4 else 1875
SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.restype = None
md.lib.arena_vdp_write16.argtypes = [__import__('ctypes').c_int,
                                     __import__('ctypes').c_int]


def lee_tile(t):
    return [md.vram16((t * 32 + i) % 0x10000) for i in range(0, 32, 2)]


def escribe_tile(t, vals):
    for i, v in enumerate(vals):
        md.lib.arena_vdp_write16((t * 32 + 2 * i) % 0x10000, v)


# --- partida limpia ---
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)
md.save_png(PREF + '_base.png')
base = np.array(Image.open(PREF + '_base.png').convert('RGB')).astype(int)
print('  base: %s' % (base.shape,))

import json
res = {}
for t in range(T0, T1):
    orig = lee_tile(t)
    escribe_tile(t, [0xFFFF] * 16)
    md.run(3)
    md.save_png(PREF + '_t%d.png' % t)
    escribe_tile(t, orig)
    md.run(2)
    a = np.array(Image.open(PREF + '_t%d.png' % t).convert('RGB')).astype(int)
    d = np.abs(a - base).sum(axis=2)
    ys, xs = np.nonzero(d > 200)
    if len(ys) == 0:
        res[t] = None
    else:
        res[t] = (int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max()), int(len(ys)))
print('  --- tile -> zona que cambia (x0..x1, y0..y1) ---')
for t in range(T0, T1):
    if res[t]:
        print('    tile %4d  x=%3d..%3d  y=%3d..%3d  (%d px)' % (t, *res[t]))
    else:
        print('    tile %4d  sin cambio' % t)
json.dump({str(k): v for k, v in res.items()}, open(PREF + '_mapa.json', 'w'))
