"""sonda_salida_vel.py - reproduce el flujo de David: menu -> Sistema -> Velocidad
-> salir al menu principal, sobre TEST_BA, midiendo TODO el camino.

En cada etapa guarda captura (/tmp) y volca:
  - hash del final de START en PRG-RAM ($27800-$28000, donde viven los parches)
  - $a002 (bandera del handshake), $a4032 (contador de frames), WRAM $FF8003
  - el PC del main CPU
Ademas comprueba si el juego responde (DOWN/UP cambian la pantalla) tras salir.

Uso: python3 sonda_salida_vel.py <cue> <prefijo> [tocar]
  tocar = cambiar la velocidad con RIGHT antes de salir
"""
import sys, hashlib
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
TOCAR = len(sys.argv) > 3 and sys.argv[3] == 'tocar'
SALA = '/home/user/Illusion City/states/TEST_L.state'
md = mdcd.MD(cue)


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(n):
    p = '%s_%s.png' % (pref, n)
    md.save_png(p)
    return p


def estado(et):
    prg = md.prg8(0x27800, 0x800)
    h = hashlib.md5(prg).hexdigest()[:8]
    a002 = md.prg8(0xa002, 2)                      # PRG-RAM
    a4032 = md.deswap(md.word_ram()[0x24032:0x24034])   # Word RAM ($a4032-$80000)
    hs = md.w8(0xff8003)
    print('  %-22s f=%-6d pc=%06x  a002=%02x%02x a4032=%02x%02x ff8003=%02x  colaSTART=%s'
          % (et, md.frame, md.pc(), a002[0], a002[1], a4032[0], a4032[1], hs, h))
    return h


def pix(a): return np.array(Image.open(a).convert('RGB'))


def dif(p1, p2):
    a, b = pix(p1), pix(p2)
    return int((np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).sum())


# ---- 1. guardar en BRAM y recargar desde el CD (flujo limpio) ----
md.load_rzip(SALA); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60); md.run(700)
foto('00_juego')
print('  partida cargada del CD (frame %d)' % md.frame)

# ---- 2. abrir el menu ----
pulsa('A', 20, 90); md.run(250)
p_menu = foto('01_menu')
h0 = estado('menu abierto')

# ---- 3. Sistema ----
for _ in range(5):
    pulsa('DOWN', 8, 60); md.run(110)
pulsa('C', 10, 160); md.run(250)
p_sist = foto('02_sistema')
h1 = estado('ventana Sistema')

# ---- 4. Velocidad ----
pulsa('C', 10, 200); md.run(300)
p_vel = foto('03_velocidad')
h2 = estado('ventana Velocidad')

if TOCAR:
    pulsa('RIGHT', 10, 130); md.run(200)
    p_toc = foto('04_velocidad_tocada')
    print('  RIGHT cambia %d px' % dif(p_vel, p_toc))
    h3 = estado('velocidad cambiada')
else:
    h3 = h2

# ---- 5. salir: B (vuelta a Sistema), B (menu principal) ----
pulsa('B', 10, 130); md.run(250)
p_v1 = foto('05_tras_B1')
h4 = estado('tras 1er B')
pulsa('B', 10, 130); md.run(250)
p_v2 = foto('06_tras_B2')
h5 = estado('tras 2o B (menu ppal)')

# ---- 6. ¿responde el menu principal? ----
p_r0 = foto('07_resp0')
pulsa('DOWN', 10, 130); md.run(200)
p_r1 = foto('08_resp_down')
pulsa('UP', 10, 130); md.run(200)
p_r2 = foto('09_resp_up')
print('  respuesta tras salir:  DOWN %d px | UP %d px' % (dif(p_r0, p_r1), dif(p_r1, p_r2)))
h6 = estado('menu tras pruebas')

# ---- 7. cerrar el menu del todo ----
pulsa('B', 10, 130); md.run(300)
p_fin = foto('10_menu_cerrado')
h7 = estado('menu cerrado')

hashes = [h0, h1, h2, h3, h4, h5, h6, h7]
print('  hash cola START:', ' '.join(h[:4] for h in hashes))
print('  ¿la cola cambio durante el flujo?: %s'
      % ('NO' if len(set(hashes)) == 1 else 'SI  <-- MIRAR'))
