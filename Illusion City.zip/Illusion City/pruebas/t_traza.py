import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from collections import Counter
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.config(exec_=1)
md.exec_filter(1, 0x10000, 0x30000)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(40)
md.trace(0)
evs=[e for e in md.events() if e.kind==1 and e.width==0x5A]
c=Counter(e.pc for e in evs)
print('ejecuciones en la zona del codigo del juego:')
for a,n in c.most_common(10): print('   $%06X x%d' % (a,n))
for dir_,nom in ((pm.CAP1_RAM,'CAP1'),(pm.CAP2_RAM,'CAP2'),(0x18A80,'punto de llamada 2'),
                 (0x1840E,'punto de llamada 1'),(0x18B18,'pintor de glifos')):
    print('  %-22s $%05X -> %d veces' % (nom,dir_,c.get(dir_,0)))
