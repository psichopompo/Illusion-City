FILE "../Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
