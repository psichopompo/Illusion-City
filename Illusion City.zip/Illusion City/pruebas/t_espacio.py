import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def prueba(cadena, nom):
    md = mdcd.MD('n2.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('n2.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    ini=pm.m.region(raw,107,149400); md.poke_prg(0x28000+0x14E0, ini[0x14E0:0x14E0+2000])
    md.poke_prg(0x27AD0, bytes.fromhex(cadena)+b'\x00')
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    f='sp_%s.png'%nom; md.save_png(f)
    a=np.array(Image.open(f).convert('RGB'))
    fila=(a[134:148,45:240,0]>190).any(axis=0)
    xs=[i+45 for i,v in enumerate(fila) if v]
    runs=[]
    for x in xs:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    return [r[0] for r in runs], (max(xs) if xs else 0)
print('sin espacio (HK$):        ', prueba('8290826B8267' if False else '8267826B8290','a'))
print('con espacio 0x8140:      ', prueba('8267826B8290'.replace('8267','8140'+'8267'),'b'))
print('con espacio 0x20:        ', prueba('8140','c'))
print('candidatos de espacio:')
for cod in ('8140','0020','8141','8142','8143','8144','8145'):
    ini,fin=prueba(cod+'8267826B8290', cod)
    print('  espacio $%s -> x=%d..%d' % (cod, ini[0] if ini else 0, fin))
