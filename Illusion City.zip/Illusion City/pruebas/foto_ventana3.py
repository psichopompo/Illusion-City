"""foto_ventana3.py - capturas del menu con ESPERA POR ESTADO (no por tiempo).

Tras cada pulsacion se corre el emulador en rafagas y se clasifica cada captura
comparandola con plantillas conocidas (menu / ventana de nombres / submenu), asi
que no importa que la animacion tarde mas o menos.

Uso: python3 foto_ventana3.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import estado
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)
PLANT = estado.prepara()


def pulsa(b, hold=10, des=60):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def espera(quiero, limite=40, paso=25, guarda=None):
    """corre hasta que la pantalla sea la del estado 'quiero'."""
    for k in range(limite):
        md.run(paso)
        p = '/tmp/_e.png'
        md.save_png(p)
        quien, dist = estado.clasifica(p, PLANT)
        if quien == quiero:
            if guarda:
                md.save_png(guarda)
            return k, dist, quien
    return None, dist, quien


# ---- flujo limpio ----
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 70)
pulsa('C', 10, 100)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 70)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado')

pulsa('A', 20, 80)
k, d, quien = espera('menu', guarda=pref + '_menu.png')
print('  menu: %s (k=%s)' % (quien, k))

pulsa('C', 10, 120)
k, d, quien = espera('ventana', guarda=pref + '_ventana.png')
print('  ventana de nombres: %s (k=%s)' % (quien, k))

pulsa('DOWN', 8, 80)
md.run(60)
md.save_png(pref + '_ventana_sel.png')
pulsa('DOWN', 8, 80)
md.run(60)
md.save_png(pref + '_ventana_sel2.png')

pulsa('B', 10, 80)
espera('menu')
for _ in range(4):
    pulsa('DOWN', 8, 60)
    md.run(120)
pulsa('C', 10, 150)
k, d, quien = espera('submenu', guarda=pref + '_submenu.png')
print('  submenu Estado: %s (k=%s)' % (quien, k))
pulsa('DOWN', 8, 80)
md.run(60)
md.save_png(pref + '_submenu_2.png')
print('  frame %d' % md.frame)
