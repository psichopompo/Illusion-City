"""mina_nombres.py - de donde saca el juego los nombres (tabla de caracteres + base).

La rutina de START $195A8 hace:
    lea $49246.l,a2        ; BASE de los textos
    movea.l $a600.l,a0     ; tabla de personajes: entradas de 6 B [id:2][off1:2][off2:2]
    ... busca d0 == id ... termina con id $00FF
    a1 = BASE + off1  ->  move.l a1,(a3)+   ($bd00)
    a1 = BASE + off2  ->  move.l a1,(a3)+   ($bd04)   (si off2 == 0, $bd04 = 0)

Aqui se arranca desde el CD (sin state), se carga la partida del slot 1 y se abre la
ventana de personajes, para volcar:
  - el puntero de la tabla ($a600), sus entradas (id/off1/off2)
  - la BASE y las cadenas que apunta cada off
  - el entorno de la BASE en RAM, para emparejarlo con el fichero del disco

Uso: python3 mina_nombres.py [cue] [prefijo]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'aa.cue'
PREF = sys.argv[2] if len(sys.argv) > 2 else '/tmp/mina'
SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def arranca(md):
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa(md, 'START', 8, 60)
    md.run(250)


md = mdcd.MD(CUE)
# 1) guardar en el slot 1 desde el state de la sala de guardado
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60)
pulsa(md, 'C', 8, 90)
md.run(90)
# 2) reset y cargar del CD
arranca(md)
pulsa(md, 'C', 8, 60)          # CARGAR PARTIDA
pulsa(md, 'C', 8, 60)          # slot 1
md.run(700)
md.save_png(PREF + '_juego.png')

prg = md.prg8(0, 0x80000)


def w32(a):
    return int.from_bytes(prg[a:a + 4], 'big')


def txt(a, n=48):
    if not (0x10000 <= a < 0x80000):
        return '{%06X}' % a
    """cadena del juego a partir de 'a' (direccion 68k dentro de la PRG-RAM)"""
    d = prg[a:a + n]
    out, i = [], 0
    while i < n:
        if d[i] == 0:
            break
        if d[i] < 0x80:
            out.append('{%02X}' % d[i]); i += 1; continue
        try:
            out.append(d[i:i + 2].decode('shift_jis'))
        except Exception:
            out.append('?')
        i += 2
    return ''.join(out)


print('  --- antes de abrir el menu ---')
print('   $a600 = $%06X   $bd00 = $%06X' % (w32(0xA600), w32(0xBD00)))

pulsa(md, 'A', 18, 60)         # menu principal
md.save_png(PREF + '_menu.png')
pulsa(md, 'C', 8, 70)          # primera opcion (Magia) -> ventana de personajes
md.run(60)
md.save_png(PREF + '_ventana.png')

print('  --- con la ventana de personajes abierta ---')
tab = w32(0xA600)
print('   $a600 (tabla) = $%06X   $bd00 = $%06X  «%s»   $bd04 = $%06X «%s»'
      % (tab, w32(0xBD00), txt(w32(0xBD00)), w32(0xBD04), txt(w32(0xBD04))))

if 0x1000 < tab < 0x80000:
    print('   tabla de personajes:')
    for k in range(40):
        e = prg[tab + 6 * k: tab + 6 * k + 6]
        i1 = int.from_bytes(e[0:2], 'big'); o1 = int.from_bytes(e[2:4], 'big')
        o2 = int.from_bytes(e[4:6], 'big')
        if i1 == 0x00FF:
            print('    %2d: id=$%04X  FIN' % (k, i1)); break
        s1 = txt(0x49246 + o1) if o1 else ''
        s2 = txt(0x49246 + o2) if o2 else ''
        print('    %2d: id=%4d  off1=$%04X -> «%s»   off2=$%04X -> «%s»'
              % (k, i1, o1, s1, o2, s2))

print('   --- entorno de la BASE ($49246) en RAM: 96 bytes ---')
for o in range(0x49240, 0x492A0, 16):
    f = prg[o:o + 16]
    print('     %05X  %s  %s' % (o, ' '.join('%02X' % b for b in f),
                                 ''.join(chr(b) if 32 <= b < 127 else '.' for b in f)))
open(PREF + '_ram_base.bin', 'wb').write(prg[0x49246:0x49246 + 0x400])
print('   volcado de la base guardado en %s_ram_base.bin' % PREF)
