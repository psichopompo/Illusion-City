"""Nombres de boton del MEGA DRIVE (no de RetroPad).
   Mapeo medido en libretro.c (osd_input_update_internal_bitmasks):
     MD A = RetroPad Y ; MD B = RetroPad B ; MD C = RetroPad A
     MD X = RetroPad L ; MD Y = RetroPad X ; MD Z = RetroPad R
   En el arnes, los ids de RetroPad son: B=0 Y=1 START=3 A=8 X=9 Z=10 C=11
"""
IDS = {'A': 1, 'B': 0, 'C': 8, 'X': 10, 'Y': 9, 'Z': 11, 'START': 3,
       'UP': 4, 'DOWN': 5, 'LEFT': 6, 'RIGHT': 7}
