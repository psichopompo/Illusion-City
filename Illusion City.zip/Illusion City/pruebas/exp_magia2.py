"""exp_magia2.py - MAGIA: mover la plantilla a un hueco libre y reapuntarla.

La plantilla del panel de Magia vive en START 0x1758A (RAM $2758A). El motor la
recorre asi:
    - cada caracter visible avanza UNA columna (=8 px en pantalla)
    - el salto '|' (2f 6e) pasa a la linea siguiente (baja 3 celdas = 18 px)
    - las marcas $4/$5/$7 (26 xx) NO se dibujan: cambian el color
    - el 00 00 termina la plantilla
El codigo escribe los VALORES y el NOMBRE en direcciones que caen DENTRO de la
plantilla (7 referencias medidas), asi que al moverla hay que reapuntarlas todas.

Uso:
    python3 exp_magia2.py <entrada.bin> <salida.bin>            (solo mover)
    python3 exp_magia2.py <entrada.bin> <salida.bin> plana      (maqueta de David)
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    'm', os.path.join(AQUI, '..', 'recursos', 'tools', 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
TPL, SZ_TPL = 0x1758A, 0x90        # 0x1758A .. 0x1761A (el 00 00 final incluido)
LIBRE = 0x17CC1                    # hueco de 703 B
REF_TPL, REF_VALS = 0x2758A, [0x275DA, 0x275EC, 0x27600, 0x27612]

ESP = b'\x81\x40'
SALTO = b'\x2f\x6e'
NOMBRE_BYTES = 16                  # 8 glifos de 2 B


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        elif ch == ' ':
            out += ESP
        else:
            raise SystemExit('sin glifo: %r' % ch)
    return bytes(out)


def trocea(tpl):
    """devuelve [(offset, bytes)] de cada elemento visible y de las marcas."""
    out, i = [], 0
    while i < len(tpl):
        b = tpl[i:i + 2]
        if b == b'\x00\x00':
            out.append((i, 'FIN')); break
        if b == SALTO:
            out.append((i, '|')); i += 2; continue
        if b[0] == 0x26:
            out.append((i, 'marca$%s' % chr(b[1]))); i += 2; continue
        out.append((i, '2B')); i += 2
    return out


def aplica(entrada, salida, plana=False):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    vieja = bytes(st[TPL:TPL + SZ_TPL])
    fin = vieja.find(b'\x00\x00')
    print('  plantilla vieja: %d B (00 00 en +0x%X)' % (len(vieja), fin))
    assert st[TPL:TPL + 2] == b'\x96\x5f', 'no reconozco el titulo'
    assert st[LIBRE:LIBRE + 64] == b'\xff' * 64, 'el hueco no esta libre'

    if not plana:
        nueva = vieja
    else:
        nueva = monta()
    assert st[LIBRE:LIBRE+len(nueva)] == b'\xff'*len(nueva), 'no cabe en el hueco'
    st[LIBRE:LIBRE + len(nueva)] = nueva

    # offsets de los elementos que el codigo escribe
    offs = {}
    lineas = despieza(vieja, nueva)
    for k in ('nombre', 'val_ahora', 'val_ind', 'val_max', 'val_grp'):
        offs[k] = lineas[k]
    print('  offsets nuevos: %s' % {k: hex(v) for k, v in offs.items()})

    refs = {REF_TPL: LIBRE + 0x10000, 0x2759A: LIBRE + offs['nombre'] + 0x10000}
    for clave, ref in zip(('val_ahora', 'val_ind', 'val_max', 'val_grp'), REF_VALS):
        refs[ref] = LIBRE + offs[clave] + 0x10000
    n = 0
    for o in range(0, len(st) - 4, 2):
        v = int.from_bytes(st[o:o + 4], 'big')
        if v in refs:
            st[o:o + 4] = refs[v].to_bytes(4, 'big')
            n += 1
    print('  %d referencias reapuntadas' % n)
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


def despieza(vieja, nueva):
    """offset en la plantilla NUEVA de: nombre, val_ahora, val_ind, val_max, val_grp."""
    # los tres primeros son los mismos que en la vieja (el texto no cambia de sitio)
    def busca_viejo():
        o = {}
        o['nombre'] = 0x1759A - TPL
        o['val_ahora'] = 0x275DA - 0x2758A
        o['val_ind'] = 0x275EC - 0x2758A
        o['val_max'] = 0x27600 - 0x2758A
        o['val_grp'] = 0x27612 - 0x2758A
        return o
    o = busca_viejo()
    vistos = {}
    for k, v in o.items():
        print('    %-10s offset viejo +0x%02X  %r' %
              (k, v, nueva[v:v + 20].decode('shift_jis', 'replace')))
    return o


def monta():
    """maqueta pedida por David (paso de 8 px = 1 caracter = 2 B)."""
    L = []
    # --- linea 0: titulo + nombre (8 glifos) ---
    L.append(fw(' ') if False else b'')
    l0 = bytearray()
    l0 += b'\x26\x37'                     # blanco
    l0 += b'\x96\x5f' + fw('MAGIA') + b'\x96\x5f' + ESP
    l0 += ESP * 8                         # hueco del nombre (8 glifos)
    l0 += SALTO
    L.append(bytes(l0))
    L.append(SALTO)                       # linea 1: vacia
    # --- linea 2: PM + 2 esp + Coste ---
    l2 = bytearray()
    l2 += b'\x26\x37' + ESP * 7 + fw('PM')     # 7 espacios + marca = PM en la col. 8
    l2 += ESP * 2 + fw('Coste')
    l2 += SALTO
    L.append(bytes(l2))
    # --- linea 3: Ahora + valor(3) + Individual + valor(2) ---
    l3 = bytearray()
    l3 += b'\x26\x37' + fw('Ahora') + ESP + b'\x26\x37' + ESP * 3
    l3 += ESP * 4 + fw('Individual') + ESP + b'\x26\x37' + ESP * 2
    l3 += SALTO
    L.append(bytes(l3))
    # --- linea 4: Maximo + valor(3) + Grupo + valor(2) ---
    l4 = bytearray()
    l4 += b'\x26\x37' + ESP * 6 + fw('Maximo') + ESP + b'\x26\x37' + ESP * 3
    l4 += ESP * 4 + fw('Grupo') + ESP + b'\x26\x37' + ESP * 2
    l4 += b'\x00\x00'
    L.append(bytes(l4))
    tpl = b''.join(L)
    print('  plantilla nueva: %d B' % len(tpl))
    return tpl


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2], len(sys.argv) > 3 and sys.argv[3] == 'plana')
