import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
fp=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(fp)
G=fp.glifos_david()
def corre(addr=None,data=None,salida='v.png'):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if addr is not None: md.poke_prg(addr,data)
    md.press(IDS['A']); md.run(20); md.release(); md.run(60)
    md.save_png(salida); return salida
def dolar(f):
    a=np.array(Image.open(f).convert('RGB'))
    return (a[135:147,205:217,0]>190)
corre(None,None,'v_ref.png')
z=dolar('v_ref.png'); print('ANTES:'); 
for r in range(12): print('   ', ''.join('#' if z[r,c] else '.' for c in range(12)))
corre(0x299C4, fp.a_celda12(G['$'],0), 'v_dav.png')
z2=dolar('v_dav.png'); print('DESPUES ($299C4 = glifo de David):')
for r in range(12): print('   ', ''.join('#' if z2[r,c] else '.' for c in range(12)))
