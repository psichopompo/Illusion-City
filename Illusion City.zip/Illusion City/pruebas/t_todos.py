import sys; sys.path.insert(0,'.')
exec(open('t_fuente.py').read().split("md.mem_window(0x29400, 0x29C00)")[0])
md.mem_window(0x28000, 0x2A000)
md.config(mem=1); md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(45)
md.trace(0)
reads=[e for e in md.events() if e.kind==10]
print('lecturas: %d' % len(reads))
seq=[e.a for e in reads]
bloques=[]; ini=seq[0]; prev=seq[0]
for a in seq[1:]:
    if a==prev+1: prev=a
    else: bloques.append((ini,prev)); ini=a; prev=a
bloques.append((ini,prev))
print('bloques >= 12 B (los glifos):')
for a,b in bloques:
    if b-a+1>=12: print('   $%05X..$%05X (%d B)' % (a,b,b-a+1))
print()
print('los 6 ULTIMOS bloques:')
for a,b in bloques[-6:]: print('   $%05X..$%05X (%d B)' % (a,b,b-a+1))
