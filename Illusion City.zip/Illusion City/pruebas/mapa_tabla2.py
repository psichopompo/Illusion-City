"""mapa_tabla2.py - MAPA DE CELDAS DE FUENTE (metodo del bloque solido).

Escribe un bloque solido (18 B = 12x12) en la celda k de la tabla de fuente VIVA
(PRG-RAM), repinta la pantalla y mira que columnas cambian: eso dice que celda
dibuja cada cosa. No toca ningun fichero.

Direcciones medidas (26/09):
    tabla de MENUS (ASCII: celda = codigo-3)   $28000 + 0x4ED0 = $29ED0
    bloque fullwidth de la tabla de menus      $29ED0 + 18*(-772) = $29888
    tabla del DINERO (INIT 0x14E0)             $28000 + 0x14E0 = $294E0
OJO: las tablas se SOLAPAN (la tabla 2 con el bloque fullwidth), asi que hay que
mirar la pantalla para saber a que tabla pertenece cada celda.

Uso: python3 mapa_tabla2.py <cue> <build.bin> <base_hex> <desde> <hasta> [y0 y1 x0 x1]
Ej.: python3 mapa_tabla2.py o.cue TEST_O.bin 0x29ED0 -780 -700
"""
import sys, importlib.util; sys.path.insert(0, '.')
import mdcd
import numpy as np
from PIL import Image
from md_btn import IDS

spec = importlib.util.spec_from_file_location('m', '/home/user/Illusion City/recursos/tools/parche_lote3.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
CELDA = 18


def pulsa(md, b, hold=3, des=26):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def banda(md, y0, y1, x0, x1):
    md.save_png('/tmp/_mapa.png')
    a = np.array(Image.open('/tmp/_mapa.png').convert('RGB')).astype(int)
    return a[y0:y1, x0:x1]


def main():
    cue, build = sys.argv[1], sys.argv[2]
    base = int(sys.argv[3], 0)
    k0 = int(sys.argv[4]); k1 = int(sys.argv[5])
    y0, y1, x0, x1 = (int(v) for v in sys.argv[6:10]) if len(sys.argv) > 9 else (134, 150, 20, 230)
    md = mdcd.MD(cue)
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state')
    md.run(20)
    md.poke_prg(0x10000, m.region(open(build, 'rb').read(), 59, 98184))
    pulsa(md, 'A', 18, 55)
    base_img = banda(md, y0, y1, x0, x1)
    print('barrido de la base $%X, celdas %d..%d  (ventana y=%d..%d x=%d..%d)'
          % (base, k0, k1, y0, y1, x0, x1))
    for k in range(k0, k1):
        dir_ = base + CELDA * k
        orig = md.prg8(dir_, CELDA)
        md.poke_prg(dir_, bytes([0xFF] * CELDA))
        pulsa(md, 'A', 10, 30); pulsa(md, 'A', 18, 55)
        now = banda(md, y0, y1, x0, x1)
        md.poke_prg(dir_, orig)
        d = np.abs(now - base_img).sum(axis=2).sum(axis=0)
        cols = [i + x0 for i, v in enumerate(d) if v > 40]
        if cols:
            print('   celda %5d ($%X) -> x=%d..%d' % (k, dir_, min(cols), max(cols)))


if __name__ == '__main__':
    main()
