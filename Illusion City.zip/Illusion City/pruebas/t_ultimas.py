import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
# ventana AMPLIA: toda la zona donde puede estar la fuente
md.mem_window(0x20000, 0x2C000)
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(50)
md.trace(0)
reads=[e for e in md.events() if e.kind==10]
print('lecturas totales en 0x20000-0x2C000: %d' % len(reads))
# las ultimas lecturas de cada pasada = los ultimos glifos (el $)
porframe={}
for e in reads: porframe.setdefault(e.frame,[]).append(e)
frames=sorted(porframe)
print('frames con lecturas:', frames[:12])
if frames:
    ult = porframe[frames[-1]]
    print('ultimas lecturas del ultimo frame (%d):' % len(ult))
    vistos=[]
    for e in ult[-20:]:
        if e.a not in vistos: vistos.append(e.a)
    print('  direcciones distintas (ultimas):', ['$%05X'%a for a in vistos])
