"""foto_ventana2.py - capturas FIABLES de la ventana de nombres y del submenu.

El motor anima las ventanas (abre/cierra) y los tiempos de las pulsaciones no son
fijos, asi que tras cada tecla se hace una RAFAGA de capturas y se elige la ultima
que tenga la firma buscada:
  - ventana de nombres: marco naranja horizontal en y=57 con tramo largo
  - submenu:            el popup de tres lineas (tramo negro de >=200 px en y=100)

Uso: python3 foto_ventana2.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)
FRAME = (238, 170, 0)


def pulsa(b, hold=10, des=60):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(nombre):
    p = '%s_%s.png' % (pref, nombre)
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def firma_ventana(a):
    """marco naranja horizontal largo en la zona alta."""
    fila = (a[57, 40:230] == FRAME).all(axis=1)
    return fila.sum() > 60


def firma_popup(a):
    """el popup del submenu/efecto: franja negra larga a media altura."""
    mejor = 0
    for y in (100, 103, 106, 140, 150):
        fila = (a[y, 40:230] == (0, 0, 0)).all(axis=1)
        n = max((len(s) for s in ''.join('1' if v else '0' for v in fila).split('0')), default=0)
        mejor = max(mejor, n)
    return mejor > 90


def rafaga(nombre, prueba, intentos=10, paso=20):
    for k in range(intentos):
        md.run(paso)
        a = foto('%s_%02d' % (nombre, k))
        if prueba(a):
            foto(nombre)
            return True, k
    foto(nombre + '_fallo')
    return False, intentos


# ---- flujo limpio (guardar en slot 1 -> reset -> cargar partida) ----
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 70)
pulsa('C', 10, 100)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 70)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
foto('juego')

pulsa('A', 20, 80)
md.run(300)
foto('menu')
ok, k = rafaga('ventana', firma_ventana)
print('  ventana de nombres: %s (intento %d)' % ('OK' if ok else 'NO', k))
if ok:
    pulsa('DOWN', 8, 80)
    rafaga('ventana_sel', firma_ventana, intentos=4, paso=8)
    pulsa('DOWN', 8, 80)
    rafaga('ventana_sel2', firma_ventana, intentos=4, paso=8)
    pulsa('B', 10, 90)
    md.run(200)

for _ in range(4):
    pulsa('DOWN', 8, 60)
    md.run(120)
pulsa('C', 10, 150)
ok, k = rafaga('submenu', firma_popup)
print('  submenu Estado:     %s (intento %d)' % ('OK' if ok else 'NO', k))
if ok:
    pulsa('DOWN', 8, 80)
    rafaga('submenu_2', firma_popup, intentos=4, paso=8)
print('  frame %d' % md.frame)
