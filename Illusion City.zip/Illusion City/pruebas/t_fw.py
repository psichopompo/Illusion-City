import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
SOLIDO = bytes.fromhex('ff'*18)
def glifos(marcar, cadena):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AD0, cadena+b'\x00')
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA):
        md.poke_prg(0x10000+off, bytes.fromhex('43f9')+(0x00027AD0).to_bytes(4,'big'))
    if marcar is not None: md.poke_prg(TABLA + marcar*CELL, SOLIDO)
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png('cf.png')
    im=Image.open('cf.png').convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,250) if any(claro(x,y) for y in range(133,152))]
    runs=[]
    for x in t:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    return [(a,b-a+1) for a,b in runs]
# con la cadena "HK$" (sin espacio) y la formula fullwidth:
#   rel = -772 - (0x824F - codigo)
casos = [(0x8190,'$'),(0x8267,'H'),(0x826B,'K'),(0x8146,':'),(0x8140,'espacio')]
base = glifos(None, bytes.fromhex('48244b'))
print('base con "HK$":', base[-4:])
print()
for cod,nom in casos:
    rel = -772 - (0x824F - cod)
    r = glifos(rel, bytes.fromhex('48244b'))
    cambia = [i for i in range(min(len(r),len(base))) if r[i]!=base[i]]
    print('  %-8s codigo $%04X -> rel %5d : cambian %s' % (nom, cod, rel, cambia if cambia else 'NINGUNO'))

