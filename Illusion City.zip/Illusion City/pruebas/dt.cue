FILE "/tmp/dolar_test.bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
