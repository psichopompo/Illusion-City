import sys; sys.path.insert(0,'.')
import mdcd
from collections import Counter
md = mdcd.MD('n.cue')          # <- cue VALIDO
md.mem_window(0x29400, 0x29C00)
md.config(mem=1)
md.trace(1)
md.run(60)
md.trace(0)
evs=md.events()
print('con cue valido: %d eventos %s' % (len(evs), dict(Counter(e.kind for e in evs))))
