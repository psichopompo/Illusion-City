"""ram_magia.py - volcado de la RAM con el panel de MAGIA abierto.

Compara los glifos que el juego tiene EN RAM (la tabla $294E0, que es la del dinero
y la que usa el pintor $191BE) con los del fichero INIT del disco, y volca el
buffer de dibujo $A6000 del panel.

Uso: python3 ram_magia.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60)
pulsa('C', 8, 90)
md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60)
pulsa('C', 8, 120)
md.run(500)
pulsa('A', 18, 60)
pulsa('C', 8, 120)
md.run(150)
md.save_png(pref + '_magia.png')

prg = md.prg_ram()


def rd(ram, n):
    return md.deswap(prg[ram:ram + n])


open('/tmp/ram_glifos.bin', 'wb').write(rd(0x2F300, 0x200))
for celda, nombre in ((1349, 'icono ◊'), (1350, 'á'), (1334, 'Á'), (1431, 'ñ'), (49, '$')):
    off = 0x14E0 + celda * 18
    print('  celda %4d %-9s  RAM $%05X' % (celda, nombre, 0x294E0 + celda * 18))
buf = rd(0xA6000, 0x800)
open('/tmp/buf_magia.bin', 'wb').write(buf)
print('  glifos $2F300-$2F500 -> /tmp/ram_glifos.bin')
print('  buffer $A6000-$A6800 -> /tmp/buf_magia.bin')
print('  captura %s_magia.png (frame %d)' % (pref, md.frame))
