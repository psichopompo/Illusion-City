import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
from collections import Counter
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
for nombre, kw in (('solo mem', dict(mem=1)), ('solo flow', dict(flow=1)), ('mem+flow', dict(mem=1, flow=1))):
    md.mem_window(0x20000, 0x2C000)
    md.reset_events()
    md.config(**kw)
    md.trace(1)
    md.press(IDS['A']); md.run(15); md.release(); md.run(25)
    md.trace(0)
    evs=md.events()
    print('%-10s -> %d eventos, tipos %s' % (nombre, len(evs), dict(Counter(e.kind for e in evs))))
    md.trace(0)
