"""mapa_panel2.py - mapa celda<->pantalla del panel del HUD y tile que dibuja cada letra.

METODO (limpio, sin adivinar)
  1. Con el juego cargado y el panel a la vista, se lee la NAMETABLE del plano A/B
     (registros 2/4 del VDP) y se saca, para cada celda de la columna del panel, el
     tile que tiene puesto.
  2. Para saber DONDE cae cada celda en pantalla, se cambia su tile por uno LIBRE
     (el 2030) que se pinta con un bloque solido blanco, y se busca ese bloque en la
     captura. Asi se mapea celda -> (x,y) y de paso se confirma que celda es cual.
  3. Se restaura la celda.

Uso: python3 mapa_panel2.py [cue]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import ctypes
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'ab.cue'
SALA = '/home/user/Illusion City/states/TEST_L.state'
TILE_LIBRE = 2030


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.restype = None
md.lib.arena_vdp_write16.argtypes = [ctypes.c_int, ctypes.c_int]


def w16(a, v):
    md.lib.arena_vdp_write16(a, v)


def r16(a):
    return md.vram16(a)


md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)
md.save_png('/tmp/mp_base.png')

regs = md.vdp_regs()
baseA = (regs[2] & 0x38) << 10
baseB = (regs[4] & 0x07) << 13
tam = regs[16] & 3
cols = 64 if (tam & 1) else 32
print('  plano A en 0x%05X  plano B en 0x%05X  ancho %d columnas' % (baseA, baseB, cols))

# --- 1) que tile hay en cada celda de la zona del panel ---
print('  --- celdas de la zona del panel (tx 24..31, ty 2..9) ---')
celdas = {}
for ty in range(2, 10):
    fila = []
    for tx in range(24, 32):
        dir_ = baseA + 2 * (ty * cols + tx)
        v = r16(dir_)
        fila.append(v & 0x7FF)
        celdas[(tx, ty)] = (v, dir_)
    print('    ty=%d  tiles: %s' % (ty, ' '.join('%4d' % t for t in fila)))

# --- 2) marcar cada celda con el tile libre y ver donde sale ---
marca = [0xFFFF] * 16          # bloque blanco
for i, v in enumerate(marca):
    w16(TILE_LIBRE * 32 + 2 * i, v)


def pos_marca(png):
    a = np.array(Image.open(png).convert('RGB')).astype(int)
    for y in range(0, a.shape[0] - 7):
        for x in range(0, a.shape[1] - 7):
            blk = a[y:y + 8, x:x + 8]
            if blk.min() > 200:
                return (x, y)
    return None


print('  --- posicion en pantalla de cada celda ---')
res = {}
for (tx, ty), (v, dir_) in sorted(celdas.items()):
    w16(dir_, (v & 0xF800) | TILE_LIBRE)
    md.run(3)
    md.save_png('/tmp/mp_c.png')
    p = pos_marca('/tmp/mp_c.png')
    w16(dir_, v)
    md.run(2)
    if p:
        res[(tx, ty)] = p
        print('    celda (%2d,%d) tile %4d (prio %d pal %d) -> pantalla x=%3d y=%3d'
              % (tx, ty, v & 0x7FF, (v >> 15) & 1, (v >> 13) & 7, p[0], p[1]))
    else:
        print('    celda (%2d,%d) tile %4d  -> sin marca visible' % (tx, ty, v & 0x7FF))
