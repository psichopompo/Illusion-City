import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
prg = md.prg8(0,0x80000)
print('PRG $29880..$298B0 (de donde lee el pintor):')
for a in range(0x29880,0x298B0,16):
    print('  $%05X  %s' % (a, prg[a:a+16].hex(' ')))
print()
print('PRG $29840..$29870 (donde yo escribi):')
for a in range(0x29840,0x29870,16):
    print('  $%05X  %s' % (a, prg[a:a+16].hex(' ')))
print()
# el patron del $ en pantalla (medido)
a=np.array(__import__('PIL.Image',fromlist=['Image']).open('dolar_pantalla.png').convert('RGB'))
pat=(a[135:147,198:210,0]>190).astype(np.uint8).reshape(144)
bits=np.unpackbits(np.frombuffer(prg,dtype=np.uint8))
hits=[o for o in range(0,len(bits)-144) if np.array_equal(bits[o:o+144],pat)]
print('el dibujo del $ en pantalla aparece en PRG en:', [(h//8,h%8) for h in hits])
