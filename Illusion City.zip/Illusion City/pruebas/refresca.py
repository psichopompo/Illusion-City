"""refresca.py - mete el START.BIN de un BUILD en la PRG-RAM de un savestate.

POR QUE HACE FALTA (medido el 26/09): el savestate guarda la PRG-RAM entera, y los
TEXTOS de los menus (plantilla de Velocidad, etiqueta del dinero, filas del menu)
viven en la PRG-RAM. Con un savestate se ven los textos del build con el que se
grabo, no los del build nuevo. Las FUENTES (INIT) si se recargan del CD al abrir el
menu. Asi que para probar textos nuevos hay que escribir el START.BIN del build
encima de la PRG-RAM: eso es lo que hace el juego al arrancar de cero.

Uso: python3 refresca.py <cue> <build.bin> <state> [captura.png]
     si no se pasa state, usa states/TEST_I.state
"""
import sys; sys.path.insert(0, '.')
import mdcd, importlib.util
from md_btn import IDS

spec = importlib.util.spec_from_file_location('m', '/home/user/Illusion City/recursos/tools/parche_lote3.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
LBA_START, SZ_START = 59, 98184


def pulsa(md, b, hold=3, des=26):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def fila(md):
    x = md.deswap(md.word_ram_2m()); o = 0xA422C - 0x80000
    return int.from_bytes(x[o:o + 2], 'big')


def u32(md, a):
    x = md.deswap(md.word_ram_2m()); o = a - 0x80000
    return int.from_bytes(x[o:o + 4], 'big')


def refresca(cue, build, state='/home/user/Illusion City/states/TEST_I.state'):
    md = mdcd.MD(cue)
    md.load_rzip(state)
    md.run(20)
    md.poke_prg(0x10000, m.region(open(build, 'rb').read(), LBA_START, SZ_START))
    return md


if __name__ == '__main__':
    md = refresca(sys.argv[1], sys.argv[2],
                  sys.argv[3] if len(sys.argv) > 3 else '/home/user/Illusion City/states/TEST_I.state')
    pulsa(md, 'A', 18, 60)
    print('  menu abierto: fila=%d  txt=$%X' % (fila(md), u32(md, 0xA4222)))
    if len(sys.argv) > 4:
        md.save_png(sys.argv[4]); print('  captura', sys.argv[4])
