import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('ok.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.mem_window(0x299B0, 0x299D0)
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(25); md.release(); md.run(50)
md.trace(0)
lec=[e for e in md.events() if e.kind==10]
print('lecturas (pc -> direccion):')
for e in lec[:24]: print('   $%06X -> $%05X' % (e.pc, e.a))
print()
print('direcciones distintas leidas:', sorted(set('$%05X'%e.a for e in lec)))
