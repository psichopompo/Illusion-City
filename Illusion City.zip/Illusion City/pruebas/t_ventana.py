import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
from collections import Counter
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
for lo,hi in ((0x29800,0x29900), (0x29400,0x29C00), (0x28000,0x2A000), (0x20000,0x2C000)):
    md.mem_window(lo,hi)
    md.reset_events()
    md.config(mem=1)
    md.trace(1)
    md.press(IDS['A']); md.run(15); md.release(); md.run(25)
    md.trace(0)
    evs=md.events()
    print('ventana $%05X-$%05X -> %d eventos %s' % (lo,hi,len(evs), dict(Counter(e.kind for e in evs))))
