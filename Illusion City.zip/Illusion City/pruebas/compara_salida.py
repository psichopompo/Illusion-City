"""compara_salida.py - traza el FLUJO de llamadas (jsr/bsr/ret) durante la salida
de Velocidad -> Sistema -> menu principal, en TEST_BA y en la base japonesa,
y saca la primera divergencia entre ambas.

Uso: python3 compara_salida.py
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def navegar_hasta_velocidad(md):
    """flujo limpio: save en BRAM, reset, cargar del CD, menu->Sistema->Velocidad"""
    md.load_rzip(SALA); md.run(40)
    pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa(md, 'START', 8, 60)
    md.run(250)
    pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60); md.run(700)
    pulsa(md, 'A', 20, 90); md.run(250)
    for _ in range(5):
        pulsa(md, 'DOWN', 8, 60); md.run(110)
    pulsa(md, 'C', 10, 160); md.run(250)     # ventana Sistema
    pulsa(md, 'C', 10, 200); md.run(300)     # entrar en la 1a opcion (Velocidad)


def traza_salida(cue):
    md = mdcd.MD(cue)
    navegar_hasta_velocidad(md)
    md.config(flow=1)
    md.trace(True)
    md.reset_events()
    md.mark(1)                                # MARK 1: empezamos
    pulsa(md, 'B', 10, 130); md.run(200)      # salir de Velocidad
    md.mark(2)                                # MARK 2: B para salir de Sistema
    pulsa(md, 'B', 10, 130); md.run(250)      # salir de Sistema -> menu principal
    md.mark(3)                                # MARK 3: hasta aqui
    md.run(200)
    md.trace(False)
    evs = md.events()
    print('  %s: %d eventos de flujo' % (cue, len(evs)))
    seq = []
    for e in evs:
        if e.kind == 11:                       # MARK
            seq.append(('MARK', e.a))
        elif e.kind in (2, 4):                 # CALL/JMP
            seq.append(('CALL', e.a, e.pc))
        elif e.kind == 3:                      # RET
            seq.append(('RET', e.a))
    md.config(flow=0)
    return seq


a = traza_salida('ba.cue')
b = traza_salida('orig.cue')

# normalizar: quitar eventos posteriores al MARK 3 y emparejar
def hasta_mark3(s):
    out = []
    for e in s:
        out.append(e)
        if e[0] == 'MARK' and e[1] == 3:
            break
    return out

a, b = hasta_mark3(a), hasta_mark3(b)
print('  secuencia TEST_BA: %d eventos | BASE: %d eventos' % (len(a), len(b)))
n = 0
for i in range(min(len(a), len(b))):
    if a[i] != b[i]:
        print('  PRIMERA DIVERGENCIA en el evento %d:' % i)
        for j in range(max(0, i - 8), min(len(a), i + 8)):
            print('    BA  %3d %s' % (j, a[j]))
            print('    BASE %3d %s' % (j, b[j]))
        n += 1
        break
if not n:
    print('  SIN DIVERGENCIAS hasta el minimo comun (los flujos son identicos)')
