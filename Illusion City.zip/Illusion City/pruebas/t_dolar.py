import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
SOLIDO = bytes.fromhex('ff'*18)
def marca(k):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(TABLA + k*CELL, SOLIDO)
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png('mkd.png')
    im=Image.open('mkd.png').convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,245) if any(claro(x,y) for y in range(133,152))]
    return t
base = marca(99999) if False else None
md = mdcd.MD('n.cue'); md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.press(IDS['A']); md.run(20); md.release(); md.run(55); md.save_png('mkd_base.png')
im=Image.open('mkd_base.png').convert('RGB'); px=im.load()
claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
t0=[x for x in range(40,245) if any(claro(x,y) for y in range(133,152))]
runs0=[]
for x in t0:
    if runs0 and x<=runs0[-1][1]+2: runs0[-1][1]=x
    else: runs0.append([x,x])
print('glifos de la linea (sin marcar):', [(a,b-a+1) for a,b in runs0])
print()
print('marco celdas candidatas al ASCII "$" (0x24):')
for k in (-2272, -2271, -2270, -2273, -2274):
    t=marca(k)
    runs=[]
    for x in t:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    ch=[(a,b-a+1) for a,b in runs]
    print('  rel %5d: %s %s' % (k, ch, '<-- CAMBIA (es el $)' if ch!= [(a,b-a+1) for a,b in runs0] else ''))
