import sys; sys.path.insert(0,'.')
exec(open('t_diff.py').read().split("a=corre(None,None,'ref_nueva.png')")[0])
import numpy as np
from PIL import Image, ImageChops
ref='ref_nueva.png'
def zona_dolar(f):
    a=np.array(Image.open(f).convert('RGB'))
    return (a[135:147,205:217,0]>190)
print('el $ de referencia:')
z=zona_dolar(ref)
for r in range(12): print('   ', ''.join('#' if z[r,c] else '.' for c in range(12)))
print()
for addr in (0x299C4, 0x299F1, 0x299F4, 0x299FA, 0x299FD, 0x29A00, 0x29852):
    f=corre(addr, f.a_celda12(G['$'],0), 'cand.png')
    z2=zona_dolar('cand.png')
    print('  escrito en $%05X -> el $ %s' % (addr, 'CAMBIA' if not (z2==z).all() else 'igual'))
