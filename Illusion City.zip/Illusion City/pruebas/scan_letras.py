"""scan_letras.py - busca en la VRAM los tiles que forman las letras del panel.

Las letras del panel (LV, HP, MP) son trazos verticales con color brillante. Se busca
por forma: un tile con una barra vertical a la izquierda y un trazo abajo (la L), etc.
Aqui solo se LISTAN los tiles con tinta (para poder mirarlos despues).

Uso: python3 scan_letras.py <cue>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1]
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

print('  tiles con tinta y su firma (color alto 8..F):')
for t in range(0, 2048):
    a = t * 32
    d = bytes(md.vram8(a + i) for i in range(32))
    nib = []
    for b in d:
        nib += [(b >> 4) & 0xF, b & 0xF]
    altos = sum(1 for v in nib if v >= 8)
    if altos < 6:
        continue
    # columna: cuantos pixeles por columna
    cols = []
    for x in range(8):
        cols.append(sum(1 for y in range(8) if nib[y * 8 + x] >= 8))
    # firma: forma de la columna 0..7
    print('   tile %4d altos=%2d cols=%s' % (t, altos, ''.join(str(c) for c in cols)))
