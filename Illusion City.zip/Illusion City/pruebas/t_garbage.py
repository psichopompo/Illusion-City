import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def prueba(ini,fin):
    md = mdcd.MD('dt.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/tmp/dolar_test.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    md.poke_prg(ini, b'\xff'*(fin-ini))
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png('gb.png')
    a=np.array(Image.open('gb.png').convert('RGB'))
    z=(a[133:152,190:230,0]>190).astype(int)
    return z.sum()
base=prueba(0x2A000,0x2A001)   # sin tocar nada
print('tinta en la zona del H$ (sin tocar): %d' % base)
print()
# rangos de 24 bytes (un glifo)
for a in range(0x2987A, 0x298B0, 24):
    n=prueba(a, a+24)
    print('  basura en $%05X..$%05X -> tinta %d %s' % (a,a+24,n,'CAMBIA!' if abs(n-base)>5 else ''))
