"""dump_ram_magia.py - partida limpia -> panel de MAGIA -> volcado COMPLETO de RAM.

Guarda PRG-RAM (512K), Word RAM (2x128K) y la captura para poder buscar despues
donde estan los glifos que el juego usa de verdad.

Uso: python3 dump_ram_magia.py <cue> <fichero_salida>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

cue, salida = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60)
pulsa('C', 8, 90)
md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60)
pulsa('C', 8, 120)
md.run(500)
pulsa('A', 18, 60)
pulsa('C', 8, 120)
md.run(150)
md.save_png('/tmp/dump_magia.png')
open(salida, 'wb').write(md.deswap(md.prg_ram()))
open(salida + '.word', 'wb').write(md.deswap(md.word_ram()))
print('  PRG-RAM -> %s   (captura /tmp/dump_magia.png, frame %d)' % (salida, md.frame))
