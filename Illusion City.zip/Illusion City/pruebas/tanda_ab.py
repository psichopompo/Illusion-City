"""tanda_ab.py - capturas de la tanda AB (nombres completos + iconos).

Flujo limpio (idea de David): state de la sala de guardado -> guardar en el slot 1
-> retro_reset -> CARGAR PARTIDA -> slot 1. Todo lo que se ve viene del disco.

Capturas: menu principal, ventana de personajes (Magia), Equipo y Estado.

Uso: python3 tanda_ab.py <cue> <prefijo>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'ab.cue'
PREF = sys.argv[2] if len(sys.argv) > 2 else '/tmp/ab'
SALA = '/home/user/Illusion City/states/TEST_L.state'


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
print('  guardado en el slot 1')
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)      # CARGAR PARTIDA -> slot 1
md.run(700)
md.save_png(PREF + '_1_juego.png')

pulsa(md, 'A', 18, 60)                            # menu principal
md.save_png(PREF + '_2_menu.png')
pulsa(md, 'C', 8, 70)                             # Magia -> ventana de personajes
md.run(60)
md.save_png(PREF + '_3_ventana.png')
pulsa(md, 'B', 8, 60)                             # cerrar la ventana
md.save_png(PREF + '_4_tras_cerrar.png')
print('  capturas 1-4 hechas')

# --- Equipo: bajar el selector DOS veces (Magia -> Objetos -> Equipo) y abrir ---
for _ in range(2):
    pulsa(md, 'DOWN', 8, 50)
md.save_png(PREF + '_5_selector.png')
pulsa(md, 'C', 8, 80)
md.run(80)
md.save_png(PREF + '_6_equipo.png')
for k in range(3):                                 # recorrer las categorias
    pulsa(md, 'C', 8, 60)
    md.run(40)
    md.save_png(PREF + '_7_equipo_%d.png' % (k + 2))
pulsa(md, 'B', 8, 60)
pulsa(md, 'B', 8, 60)
md.run(60)

# --- Estado: desde Magia hay que bajar CUATRO veces ---
for _ in range(4):
    pulsa(md, 'DOWN', 8, 50)
md.save_png(PREF + '_8_selector2.png')
pulsa(md, 'C', 8, 80)
md.run(80)
md.save_png(PREF + '_9_estado.png')
# segundo personaje
pulsa(md, 'C', 8, 60)
pulsa(md, 'DOWN', 8, 40)
pulsa(md, 'C', 8, 60)
md.run(60)
md.save_png(PREF + '_10_estado2.png')
print('  capturas 5-10 hechas')
