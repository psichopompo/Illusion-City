import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
fp=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(fp)
DAVID = fp.a_celda12(fp.glifos_david()['$'], 0)
TABLA=0x294E0; CELL=18
def prueba(celda, salida):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if celda is not None: md.poke_prg(TABLA+celda*CELL, DAVID)
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png(salida)
    a=np.array(Image.open(salida).convert('RGB'))
    return a
# lugar del $: el ultimo glifo de la linea
a=prueba(None,'h0.png')
fila=(a[134:148,45:240,0]>190).any(axis=0)
xs=[i+45 for i,v in enumerate(fila) if v]
runs=[]
for x in xs:
    if runs and x<=runs[-1][1]+2: runs[-1][1]=x
    else: runs.append([x,x])
print('glifos de la linea (sin tocar la fuente):', [a_ for a_,b_ in runs])
ult = runs[-1][0]-1 if runs else 200
print('posicion del ultimo glifo: x=%d' % ult)
esp = np.unpackbits(np.frombuffer(DAVID,dtype=np.uint8))[:144].reshape(12,12)
for celda in (33,70,71,73,74,34):
    a2=prueba(celda,'h_%d.png'%celda)
    zona=(a2[135:147,ult:ult+12,0]>190)
    igual=(zona==esp).sum()
    print('  celda %2d -> coincidencia con el $ de David: %d/144' % (celda,igual))
