"""quien_lee_nombres.py - busca QUIEN lee los nombres de la ventana de personajes.

Con la ventana abierta (menu Magia) se localizan las cadenas de nombres en la
PRG-RAM y se buscan punteros (4 B) que apunten a ellas. Eso dice si el juego usa
punteros (se puede reubicar y alargar) o posiciones fijas.

Uso: python3 quien_lee_nombres.py <cue>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


# flujo limpio -> partida -> menu -> Magia (abre la ventana de personajes)
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)
pulsa('A', 18, 60)          # menu principal
pulsa('C', 8, 70)           # Magia -> ventana de personajes
md.save_png('/tmp/qn.png')

prg = md.prg8(0, 0x80000)
NOMBRES = ['Ｔｉ', 'Ｍｅ', 'Ｔｉａｎ', 'Ｍｅｉ']
print('  cadenas encontradas en la PRG-RAM:')
hallados = []
for n in NOMBRES:
    pat = n.encode('shift_jis')
    i = prg.find(pat)
    while i >= 0 and len(hallados) < 30:
        hallados.append((n, i))
        i = prg.find(pat, i + 1)
for n, i in hallados:
    print('   %-8s en $%05X' % (n, 0x10000 + i))

print()
print('  punteros (4 B) a esas direcciones:')
for n, i in hallados[:12]:
    dir_ = 0x10000 + i
    for forma in ('absoluta', 'offset INIT'):
        p = dir_.to_bytes(4, 'big') if forma == 'absoluta' else (i).to_bytes(4, 'big')
        j = prg.find(p)
        cuantos = 0
        while j >= 0 and cuantos < 4:
            print('   %s ($%X) <- en $%05X  [%s]' % (n, dir_, 0x10000 + j, forma) if forma == 'absoluta'
                  else '   %s (offset $%X) <- en $%05X  [%s]' % (n, i, 0x10000 + j, forma))
            cuantos += 1
            j = prg.find(p, j + 1)
