import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from collections import Counter
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('ok.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
# ventana SOLO en la celda del $ (y alrededores inmediatos)
md.mem_window(0x299BA, 0x299CB)
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(25); md.release(); md.run(50)
md.trace(0)
evs=list(md.events())
esc=[e for e in evs if e.kind==9]
lec=[e for e in evs if e.kind==10]
print('eventos en la celda del $: %d  (escrituras %d, lecturas %d)' % (len(evs),len(esc),len(lec)))
print()
if esc:
    print('QUIEN ESCRIBE (pc, direccion, valor):')
    for e in esc[:24]: print('   pc=$%06X  $%05X = $%02X' % (e.pc, e.a, e.v))
else:
    print('nadie escribe ahi en ese momento')
print()
if lec:
    print('QUIEN LEE:', [('$%06X'%e.pc) for e in lec[:10]])
