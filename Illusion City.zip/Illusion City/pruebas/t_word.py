import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.press(IDS['A']); md.run(20); md.release(); md.run(55)
md.save_png('w.png')
a=np.array(Image.open('w.png').convert('RGB'))
# el $ tal como se ve (x=205..216)
pat=(a[135:147,205:217,0]>190).astype(np.uint8).reshape(144)
for nom, d in (('PRG', md.prg8(0,0x80000)), ('WORD2M', md.deswap(md.word_ram_2m())), ('WORD', md.deswap(md.word_ram()))):
    bits=np.unpackbits(np.frombuffer(d,dtype=np.uint8))
    hits=[o for o in range(0,len(bits)-144) if np.array_equal(bits[o:o+144],pat)]
    print('%-8s -> %s' % (nom, [(h//8,h%8) for h in hits[:6]]))
