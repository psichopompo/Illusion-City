import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
SOLIDO = bytes.fromhex('ff'*18)
def glifos(marcar):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    if marcar is not None: md.poke_prg(TABLA + marcar*CELL, SOLIDO)
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png('gc.png')
    im=Image.open('gc.png').convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,250) if any(claro(x,y) for y in range(133,152))]
    runs=[]
    for x in t:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    return runs
base = glifos(None)
print('base:', [(a,w) for a,w in [(a,b-a+1) for a,b in base]])
print()
print('si la formula es rel = codigo - 0x921 :')
for cod,nom in ((0x44,'D'),(0x69,'i'),(0x48,'H'),(0x24,'$'),(0x3A,':'),(0x30,'0')):
    rel = cod - 0x921
    r = glifos(rel)
    cambio = [i for i in range(min(len(r),len(base))) if r[i]!=base[i]]
    print('  %-4s codigo $%02X -> rel %5d : glifos que cambian: %s' % (nom, cod, rel, cambio if cambio else 'NINGUNO'))
