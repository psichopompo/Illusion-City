"""estado.py - clasifica una captura comparandola con plantillas conocidas.

Las plantillas son capturas ya guardadas (menu, ventana de nombres, submenu...).
Se comparan los pixeles del recuadro central y gana el mas parecido.
"""
import numpy as np
from PIL import Image

AQUI = '/home/user/Illusion City/pruebas/plantillas/'
ZONA = (60, 40, 175, 140)          # x0, y0, x1, y1

PLANTILLAS = {
    'sin_menu': '/tmp/BA_juego.png',
    'menu': AQUI + 'BA_juego.png',          # se sobreescribe abajo
    'ventana': '/tmp/N_ventana.png',
    'submenu': '/tmp/S2_submenu.png',
}


def carga(p):
    a = np.array(Image.open(p).convert('RGB')).astype(int)
    x0, y0, x1, y1 = ZONA
    return a[y0:y1, x0:x1]


def clasifica(png, plantillas):
    objetivo = carga(png)
    mejor, dist = None, 1e18
    for nombre, plant in plantillas.items():
        d = np.abs(objetivo - plant).sum()
        if d < dist:
            mejor, dist = nombre, d
    return mejor, dist


def prepara():
    p = dict(PLANTILLAS)
    p['menu'] = AQUI + 'BA_menu_ref.png'
    p['ventana'] = AQUI + 'BA_ventana_ref.png'
    p['submenu'] = AQUI + 'BA_submenu_ref.png'
    p['sin_menu'] = AQUI + 'BA_juego_ref.png'
    return {k: carga(v) for k, v in p.items()}
