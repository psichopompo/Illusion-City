"""md.py - instrumented Mega Drive harness (Genesis Plus GX + arena_dbg).

Read-only investigation tool: loads a ROM, runs frames, records a 68k
call/flow trace plus VDP traffic, and snapshots VRAM/CRAM/WRAM/VDP regs.

Nothing here writes to the ROM.
"""
import ctypes, os, struct
from ctypes import CDLL, CFUNCTYPE, POINTER, Structure, byref, cast, c_bool, \
    c_char_p, c_int, c_int16, c_size_t, c_uint, c_void_p, create_string_buffer, string_at
from pathlib import Path

SO = '/home/user/emu/bin/genesis_plus_gx_libretro.so'

# ---- event types (must match arena_dbg.c) ----
EV_EXEC, EV_CALL, EV_RET, EV_JMP = 1, 2, 3, 4
EV_VRAMW, EV_CRAMW, EV_VSRW, EV_VDPREG = 5, 6, 7, 8
EV_MEMW, EV_MEMR, EV_MARK, EV_DMA = 9, 10, 11, 12
EVNAME = {EV_EXEC: 'EXEC', EV_CALL: 'CALL', EV_RET: 'RET', EV_JMP: 'JMP',
          EV_VRAMW: 'VRAMW', EV_CRAMW: 'CRAMW', EV_VSRW: 'VSRAMW',
          EV_VDPREG: 'VDPREG', EV_MEMW: 'MEMW', EV_MEMR: 'MEMR',
          EV_MARK: 'MARK', EV_DMA: 'DMA'}

# libretro joypad button ids
B_B, B_Y, B_SEL, B_START, B_UP, B_DOWN, B_LEFT, B_RIGHT, B_A, B_X, B_Z, B_C = range(12)
BTN = {'B': 0, 'Y': 1, 'SELECT': 2, 'START': 3, 'UP': 4, 'DOWN': 5,
       'LEFT': 6, 'RIGHT': 7, 'A': 8, 'X': 9, 'Z': 10, 'C': 11}


class GameInfo(Structure):
    _fields_ = [('path', c_char_p), ('data', c_void_p),
                ('size', c_size_t), ('meta', c_char_p)]


class Event(Structure):
    _fields_ = [('type', c_uint), ('pc', c_uint), ('a', c_uint),
                ('v', c_uint), ('frame', c_uint), ('depth', c_uint)]

    @property
    def kind(self):
        return self.type & 0xff

    @property
    def width(self):
        return self.type >> 8

    def __repr__(self):
        return (f'<{EVNAME.get(self.kind, self.kind)} f={self.frame} d={self.depth} '
                f'pc={self.pc:06x} a={self.a:06x} v={self.v:04x}>')


ENV = CFUNCTYPE(c_bool, c_uint, c_void_p)
BIOS_DIR = b"/home/user/Illusion City/bios"
VIDEO = CFUNCTYPE(None, c_void_p, c_uint, c_uint, c_size_t)
AUDIO = CFUNCTYPE(None, c_int16, c_int16)
AUDIOB = CFUNCTYPE(c_size_t, POINTER(c_int16), c_size_t)
POLL = CFUNCTYPE(None)
INPUT = CFUNCTYPE(c_int16, c_uint, c_uint, c_uint, c_uint)


class MD:
    def __init__(self, rom, evcap=8_000_000):
        self.lib = CDLL(SO)            # fresh handle per instance is NOT possible
        L = self.lib
        L.retro_set_environment.argtypes = [ENV]
        L.retro_set_video_refresh.argtypes = [VIDEO]
        L.retro_set_audio_sample.argtypes = [AUDIO]
        L.retro_set_audio_sample_batch.argtypes = [AUDIOB]
        L.retro_set_input_poll.argtypes = [POLL]
        L.retro_set_input_state.argtypes = [INPUT]
        L.retro_load_game.argtypes = [POINTER(GameInfo)]
        L.retro_load_game.restype = c_bool
        for n in ('arena_get_vram', 'arena_get_cram', 'arena_get_vsram',
                  'arena_get_work_ram', 'arena_get_vdp_regs', 'arena_get_rom',
                  'arena_events'):
            getattr(L, n).restype = c_void_p

        self.rom_path = Path(rom)
        self.rom = self.rom_path.read_bytes() if self.rom_path.suffix.lower() != '.cue' else b'\0'*16
        self.frame = 0
        self.buttons = set()
        self.pixfmt = 2
        self.last = None

        @ENV
        def env(cmd, data):
            if cmd == 10:
                self.pixfmt = cast(data, POINTER(c_int)).contents.value
                return True
            if cmd in (9, 30, 31):
                cast(data, POINTER(c_char_p)).contents.value = BIOS_DIR
                return True
            if cmd == 16:      # GET_VARIABLE: opciones del core
                return False
            if cmd == 52:      # SET_MESSAGE_EXT
                return True
            if cmd == 17:
                cast(data, POINTER(c_bool)).contents.value = False
                return True
            return False

        @VIDEO
        def video(data, w, h, pitch):
            if data:
                self.last = (string_at(data, pitch * h), w, h, pitch, self.pixfmt)

        @AUDIO
        def audio(l, r):
            pass

        @AUDIOB
        def audiob(d, frames):
            return frames

        @POLL
        def poll():
            pass

        @INPUT
        def inp(port, device, index, id_):
            # GPGX pide la MASCARA de botones (RETRO_DEVICE_ID_JOYPAD_MASK = 256),
            # no boton a boton.  Devolver 0 para la mascara = no llega ninguna
            # pulsacion (por eso el BIOS se quedaba en "press start").
            if port != 0 or device != 1:
                return 0
            if id_ == 256:
                m = 0
                for b in self.buttons:
                    m |= 1 << b
                return m
            return 1 if id_ in self.buttons else 0

        self._cbs = [env, video, audio, audiob, poll, inp]
        L.retro_set_environment(env)
        L.retro_set_video_refresh(video)
        L.retro_set_audio_sample(audio)
        L.retro_set_audio_sample_batch(audiob)
        L.retro_set_input_poll(poll)
        L.retro_set_input_state(inp)
        L.retro_init()
        self._buf = create_string_buffer(self.rom, len(self.rom))
        gi = GameInfo(str(self.rom_path).encode(), cast(self._buf, c_void_p), len(self.rom), None)
        if not L.retro_load_game(byref(gi)):
            raise RuntimeError('retro_load_game failed')
        L.arena_init(evcap)
        self.evcap = evcap


    # ---------- Mega CD memory (anadido 26/09) ----------
    def _cd_mem(self, nombre, size):
        import ctypes
        f = getattr(self.lib, nombre)
        f.restype = c_void_p
        base = f()
        return string_at(base, size)

    def prg_ram(self):
        """512K de PRG-RAM (68k $000000-$07FFFF), bytes intercambiados."""
        return self._cd_mem('arena_get_prg_ram', 0x80000)

    def word_ram(self):
        """2 x 128K de Word RAM (68k $080000-$0BFFFF)."""
        return self._cd_mem('arena_get_word_ram', 0x40000)

    def word_ram_2m(self):
        return self._cd_mem('arena_get_word_ram_2m', 0x40000)

    def boot_rom(self):
        return self._cd_mem('arena_get_boot_rom', 0x20000)

    @staticmethod
    def deswap(b):
        """quita el intercambio de bytes por palabra (LSB_FIRST)."""
        return bytes([b[i ^ 1] for i in range(len(b))])

    def prg8(self, addr, n):
        return self.deswap(self.prg_ram()[addr:addr + n])



    # ---------- escritura en la PRG-RAM del Mega CD (solo emulador) ----------
    def poke_prg(self, addr, data):
        """Escribe bytes en la PRG-RAM (con el intercambio de bytes por palabra)."""
        import ctypes
        f = self.lib.arena_get_prg_ram
        f.restype = c_void_p
        buf = (ctypes.c_ubyte * 0x80000).from_address(f())
        for i, b in enumerate(data):
            buf[(addr + i) ^ 1] = b

    # ---------- savestates de RetroArch (RZIP) ----------
    def load_rzip(self, path):
        """Carga un .state de RetroArch en el core."""
        import zlib
        raw = open(path, 'rb').read()
        if raw[:8] == b'#RZIPv\x01#':
            total = int.from_bytes(raw[12:20], 'little')
            off, out = 20, bytearray()
            while off < len(raw) and len(out) < total:
                clen = int.from_bytes(raw[off:off+4], 'little')
                off += 4
                if clen == 0: break
                out += zlib.decompress(raw[off:off+clen]); off += clen
            raw = bytes(out)
        assert raw[:8] == b'RASTATE\x01', 'no es RASTATE'
        self.lib.retro_serialize_size.restype = c_size_t
        n = self.lib.retro_serialize_size()
        self.lib.retro_unserialize.restype = c_bool
        self.lib.retro_unserialize.argtypes = [c_char_p, c_size_t]
        return bool(self.lib.retro_unserialize(raw[16:16+n], n))


    def save_rzip(self, path):
        """Escribe un .state de RetroArch (RZIP) desde el arnes."""
        import zlib
        blob = self.state()
        ras = b'RASTATE\x01' + b'MEM ' + len(blob).to_bytes(4, 'little') + blob
        CH = 131072
        out = bytearray(b'#RZIPv\x01#')
        out += CH.to_bytes(4, 'little')
        out += len(ras).to_bytes(8, 'little')
        for i in range(0, len(ras), CH):
            c = zlib.compress(ras[i:i + CH], 9)
            out += len(c).to_bytes(4, 'little') + c
        open(path, 'wb').write(bytes(out))
        return len(out)

    # ---------- trace configuration ----------
    def config(self, exec_=0, flow=0, vram=0, cram=0, vdpreg=0, mem=0, wrap=0):
        self.lib.arena_config(exec_, flow, vram, cram, vdpreg, mem, wrap)

    def exec_filter(self, on, lo=0, hi=0xffffffff):
        self.lib.arena_exec_filter(on, lo, hi)

    def mem_window(self, lo, hi):
        self.lib.arena_mem_window(lo, hi)

    def trace(self, on=True):
        self.lib.arena_trace(1 if on else 0)

    def reset_events(self):
        self.lib.arena_reset_events()

    def mark(self, id_):
        self.lib.arena_mark(id_)

    # ---------- breakpoints ----------
    def bp_clear(self):
        self.lib.arena_bp_clear()

    def bp_add(self, addr):
        return self.lib.arena_bp_add(addr)

    def bp_hits(self, i):
        return self.lib.arena_bp_hits(i)

    def bp_stop(self, addr):
        self.lib.arena_bp_stop(addr)

    def bp_fired(self):
        return bool(self.lib.arena_bp_fired())

    def bp_reset_fired(self):
        self.lib.arena_bp_reset_fired()

    # ---------- running ----------
    def press(self, *names):
        self.buttons = {BTN[n] if isinstance(n, str) else n for n in names}

    def release(self):
        self.buttons = set()

    def run(self, n=1, script=None):
        """script: {frame_index_absolute: [button names] or []}"""
        script = script or {}
        for _ in range(n):
            if self.frame in script:
                self.press(*script[self.frame])
            self.lib.arena_set_frame(self.frame)
            self.lib.retro_run()
            self.frame += 1

    def run_until_frame(self, target, script=None):
        self.run(max(0, target - self.frame), script)


    # ---------- runtime ROM poking (EMULATOR MEMORY ONLY) ----------
    # These write into the core's in-RAM copy of the cartridge. The ROM file
    # on disk is NEVER modified. Used to prove causality by neutralising a
    # hook in-flight.
    def poke16(self, addr, value):
        if self.lib.arena_poke16(addr, value) != 0:
            raise ValueError(f'poke16 out of range: {addr:#x}')

    def peek16(self, addr):
        return self.lib.arena_peek16(addr)

    def nop_out(self, addr, nwords):
        """Replace nwords 16-bit words at addr with NOP ($4E71)."""
        for i in range(nwords):
            self.poke16(addr + 2 * i, 0x4E71)


    def poke_wram16(self, addr, value):
        """Write a 16-bit value into work RAM (emulator memory only)."""
        self.lib.arena_poke_wram16(addr, value)

    def peek_wram16(self, addr):
        return self.lib.arena_peek_wram16(addr)


    def poke_vram_tile(self, tile_index, data32):
        """Write 32 bytes of tile data at VRAM tile slot (emulator memory only).

        GPGX keeps vram[] byteswapped on LE hosts: the logical byte at address A
        lives at vram[A^1]. We honour that so the pattern cache stays coherent.
        """
        import ctypes
        base = self.lib.arena_get_vram()
        off = tile_index * 32
        buf = (ctypes.c_ubyte * 0x10000).from_address(base)
        for i, b in enumerate(data32):
            buf[(off + i) ^ 1] = b

    # ---------- state ----------
    def vram(self):
        return string_at(self.lib.arena_get_vram(), 0x10000)

    # NOTE: Genesis Plus GX keeps vram[] byteswapped on little-endian hosts
    # (the logical byte at address A lives at vram[A^1]). Usar vram8/vram16,
    # NO el volcado crudo con v[a] | (v[a+1]<<8): eso da la palabra al reves.
    def vram8(self, addr):
        return self.vram()[(addr & 0xffff) ^ 1]

    def vram16(self, addr):
        v = self.vram()
        o = addr & 0xfffe
        return (v[o + 1] << 8) | v[o]

    def cram(self):
        return string_at(self.lib.arena_get_cram(), 0x80)

    def vsram(self):
        return string_at(self.lib.arena_get_vsram(), 0x80)

    def wram(self):
        return string_at(self.lib.arena_get_work_ram(), 0x10000)

    def vdp_regs(self):
        return string_at(self.lib.arena_get_vdp_regs(), 0x20)

    # NOTE: Genesis Plus GX keeps work_ram byteswapped on little-endian hosts
    # (see core/macros.h READ_BYTE/READ_WORD under LSB_FIRST). All accessors
    # below undo that so they return true 68k-visible values.
    def w8(self, addr):
        """read work RAM byte at 68k address (0xffxxxx) or raw offset"""
        return self.wram()[(addr & 0xffff) ^ 1]

    def w16(self, addr):
        w = self.wram()
        o = addr & 0xfffe
        return (w[o + 1] << 8) | w[o]

    def w32(self, addr):
        return (self.w16(addr) << 16) | self.w16(addr + 2)

    def wblock(self, addr, n):
        """return n bytes of work RAM in true 68k order"""
        w = self.wram()
        return bytes(w[((addr + i) & 0xffff) ^ 1] for i in range(n))

    def pc(self):
        return self.lib.arena_get_pc()

    # ---------- events ----------
    def events(self):
        n = self.lib.arena_event_count()
        if n == 0:
            return []
        raw = string_at(self.lib.arena_events(), n * ctypes.sizeof(Event))
        arr = (Event * n).from_buffer_copy(raw)
        return arr

    def event_count(self):
        return self.lib.arena_event_count()

    # ---------- savestates ----------
    def state(self):
        """Serializa el estado del core (formato libretro)."""
        self.lib.retro_serialize_size.restype = c_size_t
        n = self.lib.retro_serialize_size()
        buf = create_string_buffer(n)
        self.lib.retro_serialize(buf, n)
        return buf.raw

    def load_state(self, blob):
        """Carga un blob de estado. Devuelve True si el core lo acepta."""
        buf = create_string_buffer(blob, len(blob))
        return bool(self.lib.retro_unserialize(buf, len(blob)))

    # ---------- video ----------
    def save_png(self, path):
        from PIL import Image
        if not self.last:
            return
        raw, w, h, pitch, fmt = self.last
        im = Image.new('RGB', (w, h))
        px = im.load()
        for y in range(h):
            row = raw[y * pitch:y * pitch + w * 2]
            for x in range(w):
                v = row[2 * x] | (row[2 * x + 1] << 8)
                if fmt == 2:
                    px[x, y] = (((v >> 11) & 31) * 255 // 31,
                                ((v >> 5) & 63) * 255 // 63,
                                (v & 31) * 255 // 31)
                else:
                    px[x, y] = (((v >> 10) & 31) * 255 // 31,
                                ((v >> 5) & 31) * 255 // 31,
                                (v & 31) * 255 // 31)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        im.save(path)
        return path

    def close(self):
        self.lib.retro_unload_game()
        self.lib.retro_deinit()
        self.lib.arena_free()
