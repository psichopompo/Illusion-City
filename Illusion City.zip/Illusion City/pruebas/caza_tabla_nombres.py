"""caza_tabla_nombres.py - busca la tabla y la base de los nombres de la ventana.

La rutina de la ventana hace:
    lea $49246,a2          (base de los textos)
    movea.l $a600.l,a0     (tabla de personajes)
    ... busca d0 (id) ... a1 = $49246 + offset ... move.l a1,$bd00

Aqui se leen $a600 y $bd00 con la ventana ABIERTA (comprobando antes con captura que
lo esta) y se volcan la tabla y sus destinos para localizarla en el INIT.BIN.

Uso: python3 caza_tabla_nombres.py <cue>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)
pulsa('A', 18, 70)          # menu principal
md.save_png('/tmp/ct1.png')
pulsa('C', 8, 80)           # Magia -> ventana de personajes
md.save_png('/tmp/ct2.png')

# confirmar que la ventana esta abierta (mirando la pantalla)
a = np.array(Image.open('/tmp/ct2.png').convert('RGB')).astype(int)
b = np.array(Image.open('/tmp/ct1.png').convert('RGB')).astype(int)
d = np.abs(a - b).sum(axis=2)
ys, xs = np.nonzero(d > 60)
print('  la pantalla cambio en y=%d..%d x=%d..%d (%d px)'
      % (ys.min(), ys.max(), xs.min(), xs.max(), len(ys)) if len(ys) else '  sin cambios')

prg = md.prg8(0, 0x80000)


def w32(a):
    return int.from_bytes(prg[a - 0x10000:a - 0x10000 + 4], 'big')


def txt(off, n=40):
    d = prg[off:off + n]
    out, i = [], 0
    while i < n:
        if d[i] == 0:
            out.append('|'); break
        if d[i] < 0x80:
            out.append('{%02X}' % d[i]); i += 1; continue
        try:
            out.append(d[i:i + 2].decode('shift_jis'))
        except Exception:
            out.append('?')
        i += 2
    return ''.join(out)


print('  punteros clave (con la ventana abierta):')
for a_ in (0xBD00, 0xBD04, 0xA600, 0xA604, 0xA610):
    v = w32(a_)
    extra = '  -> «%s»' % txt(v - 0x10000) if 0x10000 <= v < 0x80000 else ''
    print('   $%05X = $%06X%s' % (a_, v, extra))
