"""prueba_N.py - escribe una "N" en cada tile candidato y mira cual cambia la L.

Los tiles 1728-1740 dibujan las letras del panel (aunque su contenido en VRAM este
a cero: el grafico sobrevive en la cache de patrones). Si escribimos un patron nuevo
en el tile correcto, la cache se rehace con NUESTRO patron y se ve en pantalla.

Uso: python3 prueba_N.py <cue>
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1]
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def arranca():
    md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
    pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa('START', 8, 60)
    md.run(250)
    pulsa('C', 8, 60); pulsa('C', 8, 60)
    md.run(700)


def escribe_patron(n, filas8):
    """filas8 = 8 bytes, 1 por fila (bit 7 = pixel izquierdo)."""
    d = bytearray()
    for b in filas8:
        d += bytes([b, b, b, b])       # 8 px por fila en 4 bytes (2 px por byte)
    for i in range(16):
        md.lib.arena_vdp_write16(n * 32 + 2 * i, (d[2 * i] << 8) | d[2 * i + 1])


# una "N" mirando a la izquierda (8x8): dos verticales y diagonal
N = [0b10001000, 0b11001000, 0b10101000, 0b10011000,
     0b10001000, 0b10001000, 0b10001000, 0b00000000]


def main():
    arranca()
    md.save_png('/tmp/n0.png')
    a0 = np.array(Image.open('/tmp/n0.png').convert('RGB')).astype(int)
    for t in range(1724, 1745):
        escribe_patron(t, N)
        md.run(2)
        md.save_png('/tmp/n1.png')
        a1 = np.array(Image.open('/tmp/n1.png').convert('RGB')).astype(int)
        d = np.abs(a0 - a1).sum(axis=2)
        ys, xs = np.nonzero(d[30:100, 195:245])
        if len(ys) > 3:
            print('  tile %4d -> cambios en y=%d..%d x=%d..%d (%d px)'
                  % (t, 30 + ys.min(), 30 + ys.max(), 195 + xs.min(), 195 + xs.max(), len(ys)))
        # restaurar
        for i in range(16):
            md.lib.arena_vdp_write16(t * 32 + 2 * i, 0x0000)


if __name__ == '__main__':
    main()
