"""arranque.py - flujo limpio con verificacion por pixeles, UN intento por proceso.

El core a veces no arranca (pantalla negra/congelada, md.frame avanza igual) y el
.so es unico por proceso (dlopen devuelve el MISMO handle con su estado), asi que
los reintentos hay que hacerlos lanzando este script de nuevo.

Uso:
    python3 arranque.py <cue> menu        -> abre el menu y para (exit 0)
    python3 arranque.py <cue> velocidad   -> menu -> Sistema -> Velocidad (exit 0)
    python3 arranque.py <cue> salir       -> ... y sale con B,B al menu principal
Devuelve exit 1 si la etapa no se verifico. Las capturas quedan en /tmp/arr_*.png.
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

SALA = '/home/user/Illusion City/states/TEST_L.state'


def png(md, p):
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def dif(a, b):
    return int((np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).sum())


def vivo(md, frames=40, umbral=40):
    a = png(md, '/tmp/_v0.png')
    md.run(frames)
    b = png(md, '/tmp/_v1.png')
    return dif(a, b) > umbral


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def main(cue, etapa):
    md = mdcd.MD(cue)
    md.load_rzip(SALA); md.run(40)
    pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
    md.lib.retro_reset(); md.run(800)
    for _ in range(6):
        pulsa(md, 'START', 8, 60)
    md.run(250)
    pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60); md.run(700)
    # normalizar: cerrar con B cualquier menu/mapa que haya quedado abierto
    for _ in range(3):
        a = png(md, '/tmp/_norm0.png')
        pulsa(md, 'B', 8, 60); md.run(200)
        b = png(md, '/tmp/_norm1.png')
        if dif(a, b) < 200:            # ya no se cierra nada mas
            break
    a = png(md, '/tmp/arr_juego.png')
    pulsa(md, 'A', 20, 90); md.run(250)
    b = png(md, '/tmp/arr_menu.png')
    if dif(a, b) < 300:
        print('FALLO: el menu no se abrio')
        return 1
    if etapa == 'menu':
        print('OK menu (frame %d)' % md.frame)
        return 0
    for _ in range(5):
        pulsa(md, 'DOWN', 8, 60); md.run(110)
    a = png(md, '/tmp/arr_sist0.png')
    pulsa(md, 'C', 10, 160); md.run(250)
    b = png(md, '/tmp/arr_sist1.png')
    if dif(a, b) < 300:
        print('FALLO: la ventana de Sistema no se abrio')
        return 1
    if etapa == 'sistema':
        print('OK sistema (frame %d)' % md.frame)
        return 0
    a = png(md, '/tmp/arr_vel0.png')
    pulsa(md, 'C', 10, 200); md.run(300)
    b = png(md, '/tmp/arr_vel1.png')
    if dif(a, b) < 300:
        print('FALLO: la pantalla de Velocidad no se abrio')
        return 1
    if etapa == 'velocidad':
        print('OK velocidad (frame %d)' % md.frame)
        return 0
    # etapa 'salir'
    a = png(md, '/tmp/arr_x0.png')
    pulsa(md, 'B', 10, 130); md.run(250)
    b = png(md, '/tmp/arr_x1.png')
    print('B1 (salir Velocidad): %5d px' % dif(a, b))
    a = b
    pulsa(md, 'B', 10, 130); md.run(250)
    b = png(md, '/tmp/arr_x2.png')
    print('B2 (salir Sistema):   %5d px' % dif(a, b))
    a = b
    pulsa(md, 'DOWN', 10, 130); md.run(200)
    b = png(md, '/tmp/arr_x3.png')
    print('DOWN (respuesta):     %5d px' % dif(a, b))
    a = b
    pulsa(md, 'B', 10, 130); md.run(300)
    b = png(md, '/tmp/arr_x4.png')
    print('B3 (cerrar menu):     %5d px' % dif(a, b))
    print('OK salir (frame %d)' % md.frame)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1], sys.argv[2]))
