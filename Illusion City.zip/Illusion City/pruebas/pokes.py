"""pokes.py - escritura en la Word RAM del Mega CD (el arnes solo tenia PRG)."""
import ctypes, mdcd

def _buf(md, nombre, size):
    f = getattr(md.lib, nombre); f.restype = ctypes.c_void_p
    return (ctypes.c_ubyte * size).from_address(f())

def poke_wram(md, addr, data, dos_mb=False):
    """addr = direccion 68k ($80000-$BFFFF)."""
    b = _buf(md, 'arena_get_word_ram_2m' if dos_mb else 'arena_get_word_ram', 0x40000)
    off = (addr - 0x80000)
    for i, v in enumerate(data):
        b[(off + i) ^ 1] = v

def lee_wram(md, addr, n, dos_mb=False):
    b = _buf(md, 'arena_get_word_ram_2m' if dos_mb else 'arena_get_word_ram', 0x40000)
    off = (addr - 0x80000)
    return bytes(b[(off + i) ^ 1] for i in range(n))
