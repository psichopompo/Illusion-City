"""buscar_letras.py - localiza los tiles que dibujan cada letra del panel del HUD.

Metodo: pintar cada tile candidato con un color plano y medir cuanta TINTA de las
letras desaparece (mascara amarilla, en el recuadro de cada fila de letras).

Las letras del panel son LV, HP y MP (una fila cada una). Con esto se sabe que tile
dibuja cada letra, que es lo que hace falta para:
   L -> N  (dibujar la N)
   H -> P  (reusar el tile de la P)
   V -> V  (no se toca)
   M -> P  (reusar)
   P -> M  (reusar)
Uso: python3 buscar_letras.py <cue>
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def arranca():
    md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
    pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa('START', 8, 60)
    md.run(250)
    pulsa('C', 8, 60); pulsa('C', 8, 60)
    md.run(700)


def main():
    arranca()
    md.save_png('/tmp/bl0.png')
    a0 = np.array(Image.open('/tmp/bl0.png').convert('RGB')).astype(int)
    amar = (np.abs(a0 - np.array([239, 170, 0])).sum(axis=2) < 130)
    ys, xs = np.nonzero(amar[30:95, 200:236])
    print('  zona de letras: y=%d..%d x=%d..%d' % (30 + ys.min(), 30 + ys.max(),
                                                  200 + xs.min(), 200 + xs.max()))
    filas = []
    for y in range(30, 95):
        if amar[y, 200:236].sum() > 1:
            if filas and y <= filas[-1][1] + 2:
                filas[-1][1] = y
            else:
                filas.append([y, y])
    print('  filas de letras (y):', filas)
    BOX = {i: (f[0], f[1] + 1) for i, f in enumerate(filas)}

    def tinta():
        md.save_png('/tmp/bl1.png')
        a = np.array(Image.open('/tmp/bl1.png').convert('RGB')).astype(int)
        m = (np.abs(a - np.array([239, 170, 0])).sum(axis=2) < 130)
        return {i: int(m[y0:y1, 203:232].sum()) for i, (y0, y1) in BOX.items()}

    base = tinta()
    print('  tinta base por fila:', base)
    print('  barrido de tiles 1700..1860 (los que pierden tinta son los de las letras):')
    for n in range(1700, 1861):
        orig = bytes(md.vram8(n * 32 + i) for i in range(32))
        for i in range(16):
            md.lib.arena_vdp_write16(n * 32 + 2 * i, 0x0CCC)
        md.run(1)
        ahora = tinta()
        for i in range(16):
            md.lib.arena_vdp_write16(n * 32 + 2 * i, (orig[2 * i] << 8) | orig[2 * i + 1])
        perd = {i: base[i] - ahora[i] for i in base if base[i] - ahora[i] > 2}
        if perd:
            print('   tile %4d -> pierde %s' % (n, perd))


if __name__ == '__main__':
    main()
