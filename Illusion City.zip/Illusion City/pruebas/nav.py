"""nav.py - navegacion FIABLE por los menus: mira donde esta el resaltado.

El resaltado de la fila seleccionada va en amarillo (238,170,0) y el resto en blanco,
asi que antes de pulsar C se comprueba en que fila esta el amarillo y se pulsa DOWN
hasta que este donde queremos.

Uso: python3 nav.py <cue> <prefijo> [combate]
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
por_combate = len(sys.argv) > 3 and sys.argv[3] == 'combate'
md = mdcd.MD(cue)
AMARILLO = (238, 170, 0)


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(n, guarda=True):
    p = '/tmp/_nav.png' if not guarda else '%s_%s.png' % (pref, n)
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def filas_resaltadas(a, x0=60, x1=150, y0=40, y1=190):
    """devuelve las franjas (y0,y1) con texto amarillo."""
    amp = ((a[:, :, 0] == AMARILLO[0]) & (a[:, :, 1] == AMARILLO[1]) &
           (a[:, :, 2] == AMARILLO[2]))
    ys = [y for y in range(y0, y1) if amp[y, x0:x1].sum() > 3]
    franjas = []
    for y in ys:
        if franjas and y - franjas[-1][1] <= 4:
            franjas[-1][1] = y
        else:
            franjas.append([y, y])
    return franjas


def estable(nombre, intentos=12, paso=20):
    """espera a que dos capturas seguidas sean iguales (animacion acabada)."""
    prev = None
    for k in range(intentos):
        a = foto('_tmp', guarda=False)
        if prev is not None and np.array_equal(a, prev):
            return a
        prev = a
        md.run(paso)
    return prev


def elige(fila, filas_menu, nombre):
    """pulsa DOWN hasta que el resaltado caiga en la fila pedida."""
    for intento in range(8):
        a = estable(nombre)
        fr = filas_resaltadas(a)
        actual = None
        for k, (y0, y1) in enumerate(filas_menu):
            if fr and abs(fr[0][0] - y0) < 7:
                actual = k
        if actual == fila:
            return a
        pulsa('DOWN', 8, 60)
    print('    !! no consigo poner el resaltado en la fila %d' % fila)
    return a


FILAS_MENU = [(52, 62), (66, 76), (80, 90), (94, 104), (108, 118), (122, 132)]
NOMBRES = ['Magia', 'Objetos', 'Equipo', 'Hablar', 'Estado', 'Sistema']
FILAS_SUB = [(96, 106), (112, 122), (128, 138)]
SUBN = ['Perfiles', 'Tecnicas', 'Combate']

md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado')

pulsa('A', 20, 90)
a = elige(0, FILAS_MENU, 'menu')
print('  menu abierto, resaltado en %s' % NOMBRES[0])
md.save_png(pref + '_00_menu.png')

if por_combate:
    elige(4, FILAS_MENU, 'estado'); md.save_png(pref + '_01_estado.png')
    pulsa('C', 10, 150)
    a = elige(2, FILAS_SUB, 'submenu'); md.save_png(pref + '_02_combate_sel.png')
    pulsa('C', 10, 200); md.run(300)
    md.save_png(pref + '_03_combate.png'); print('  Combate visto')
    pulsa('B', 10, 110); md.run(200)
    md.save_png(pref + '_04_vuelta1.png')
    pulsa('B', 10, 110); md.run(200)
    md.save_png(pref + '_05_vuelta2.png')
    elige(5, FILAS_MENU, 'sistema'); md.save_png(pref + '_06_sistema_sel.png')
else:
    elige(5, FILAS_MENU, 'sistema'); md.save_png(pref + '_06_sistema_sel.png')

print('  pulsando C en Sistema (frame %d)' % md.frame)
pulsa('C', 10, 150)
md.run(300)
md.save_png(pref + '_07_sistema.png')
f1 = md.frame
md.run(400)
md.save_png(pref + '_08_sistema_b.png')
print('  frame %d -> %d (el juego sigue corriendo)' % (f1, md.frame))
for k in range(4):
    pulsa('DOWN', 8, 60)
    md.run(120)
md.save_png(pref + '_09_sistema_down.png')
pulsa('C', 10, 150); md.run(300)
md.save_png(pref + '_10_sistema_c.png')
print('  final (frame %d)' % md.frame)
