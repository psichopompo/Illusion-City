import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
from PIL import Image
def prueba(cue, nom):
    md = mdcd.MD(cue)
    t=0
    for _ in range(3):
        md.run_until_frame(t+300); t+=300
        md.press(IDS['START']); md.run(20); t+=20; md.release()
    md.run_until_frame(2000)
    md.save_png('c_%s_0.png'%nom)
    # ¿se mueve el cursor con DOWN?
    md.press(IDS['DOWN']); md.run(15); md.release(); md.run(40)
    md.save_png('c_%s_1.png'%nom)
    # arrancar
    md.press(IDS['A']); md.run(40); md.release()
    for k in range(4):
        md.run(600)
        md.save_png('c_%s_%d.png'%(nom,k+2))
    # resumen: cuantos pixeles claros en cada captura
    res=[]
    for k in range(6):
        im=Image.open('c_%s_%d.png'%(nom,k)).convert('L')
        res.append(sum(1 for p in im.get_flattened_data() if p>60))
    return res
for cue,nom in (('l.cue','TEST_L'),('n.cue','TEST_N')):
    print('%-8s claros por captura: %s' % (nom, prueba(cue,nom)))
