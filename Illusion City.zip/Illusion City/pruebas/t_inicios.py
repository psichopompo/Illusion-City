import sys; sys.path.insert(0,'.')
exec(open('t_ver.py').read().split("corre(None,None,'v_ref.png')")[0])
import numpy as np
from PIL import Image
ref = None
disp = fp.a_celda12(G['$'],0)
esperado = np.unpackbits(np.frombuffer(disp,dtype=np.uint8))[:144].reshape(12,12)
for k in range(-8, 9, 2):
    addr = 0x299C4 + k
    corre(addr, disp, 'ini.png')
    z = dolar('ini.png').astype(int)
    # comparo con el glifo de David (alineado a la izquierda en la celda)
    igual = (z == esperado).sum()
    print('  inicio $%05X -> coinciden %d/144 px con el $ de David' % (addr, igual))
