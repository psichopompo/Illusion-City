"""guarda_y_carga.py - flujo LIMPIO: guardar partida y recargarla SIN states.

  1. carga el state de la sala de guardado (TEST_L.state, con el panel SAVE abierto)
  2. pulsa C para guardar -> el juego escribe en la backup RAM
  3. RESET (retro_reset) -> arranque desde BIOS, todo se relee del CD
  4. pantalla de titulo -> CARGAR PARTIDA -> slot 1
  5. ya en el juego: abre el menu y comprueba lo que venga del disco

Uso: python3 guarda_y_carga.py <cue> <prefijo>
"""
import sys, time; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)
md.load_rzip('/home/user/Illusion City/states/TEST_L.state')
md.run(40)
md.save_png(pref + '_1_sala.png')
print('  1) en la sala de guardado')

def pulsa(b, hold=8, des=40):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

pulsa('C')                      # pulsar SAVE
md.run(120)
md.save_png(pref + '_2_guardado.png')
print('  2) partida guardada')

md.lib.retro_reset()            # arranque limpio
print('  3) RESET hecho')
md.run(400)
md.save_png(pref + '_3_tras_reset.png')
# arranque: la BIOS pide START; el juego luego muestra el titulo
for _ in range(6):
    pulsa('START', 8, 60)
md.run(200)
md.save_png(pref + '_4_titulo.png')
print('  4) captura del titulo')
