import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
def corre(rango, salida):
    lo,hi = rango
    C2 = (bytes.fromhex('2f012f0b')+bytes.fromhex('4eb9')+(0x18B18).to_bytes(4,'big')+
          bytes.fromhex('0c40')+lo.to_bytes(2,'big')+bytes.fromhex('6d00')+bytes.fromhex('000a')+
          bytes.fromhex('0c40')+hi.to_bytes(2,'big')+bytes.fromhex('6f00')+bytes.fromhex('0004')+
          bytes.fromhex('6000')+bytes.fromhex('000e')+
          bytes.fromhex('53680014')+
          bytes.fromhex('265f221f')+bytes.fromhex('30280008')+
          bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big')+
          bytes.fromhex('265f221f')+bytes.fromhex('30280008')+
          bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big'))
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(pm.CAP2_RAM, C2)
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png(salida)
    a=np.array(Image.open(salida).convert('RGB'))
    fila=(a[134:148,45:240,0]>190).any(axis=0)
    xs=[i+45 for i,v in enumerate(fila) if v]
    runs=[]
    for x in xs:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    return [a_ for a_,b_ in runs]
print('solo digitos fullwidth 824F-8258:', corre((0x824F,0x8258),'r1.png'))
print('solo ASCII 20-7E             :', corre((0x20,0x7E),'r2.png'))
print('solo letras 8260-8279        :', corre((0x8260,0x8279),'r3.png'))
