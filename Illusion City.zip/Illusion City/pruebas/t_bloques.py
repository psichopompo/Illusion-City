import sys; sys.path.insert(0,'.')
exec(open('t_fuente.py').read().split("print('lecturas en la zona")[0])
# analizo TODAS las lecturas, en orden, y saco los bloques consecutivos de ~24 bytes
seq=[e.a for e in reads]
bloques=[]
ini=seq[0]; prev=seq[0]
for a in seq[1:]:
    if a==prev+1: prev=a
    else:
        bloques.append((ini,prev)); ini=a; prev=a
bloques.append((ini,prev))
print('bloques de lectura consecutiva (inicio, fin, bytes):')
for a,b in bloques:
    if b-a+1 >= 4: print('   $%05X..$%05X  (%d B)' % (a,b,b-a+1))
print()
print('ultimos 12 bloques:')
for a,b in bloques[-12:]: print('   $%05X..$%05X  (%d B)' % (a,b,b-a+1))
