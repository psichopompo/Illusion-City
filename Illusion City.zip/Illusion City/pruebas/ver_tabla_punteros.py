"""ver_tabla_punteros.py - vuelca la tabla de punteros de nombres y sus destinos.

Uso: python3 ver_tabla_punteros.py <cue> [base_hex]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)
pulsa('A', 18, 60)
pulsa('C', 8, 70)          # ventana de personajes abierta

prg = md.prg8(0, 0x80000)


def txt(off, n=24):
    d = prg[off:off + n]
    out, i = [], 0
    while i < n:
        if d[i] == 0:
            out.append('|')
            break
        if d[i] < 0x80:
            out.append('{%02X}' % d[i]); i += 1; continue
        try:
            out.append(d[i:i + 2].decode('shift_jis'))
        except Exception:
            out.append('?')
        i += 2
    return ''.join(out)


print('  === volcado alrededor de $2C402 (tabla de punteros) ===')
for base in range(0x2C3E0, 0x2C500, 0x10):
    seg = prg[base - 0x10000:base - 0x10000 + 0x10]
    print('   %05X  %s' % (base, seg.hex(' ')))
print()
print('  === como punteros (4 B big-endian) ===')
for base in range(0x2C400, 0x2C4A0, 4):
    v = int.from_bytes(prg[base - 0x10000:base - 0x10000 + 4], 'big')
    marca = ''
    if 0x10000 <= v < 0x80000:
        marca = '  -> «%s»' % txt(v - 0x10000)
    print('   %05X: %08X%s' % (base, v, marca))
print()
print('  === las cadenas destino ===')
for d in (0x1CB5E, 0x1CB6E, 0x1BB00, 0x1BB06):
    print('   $%05X: «%s»' % (d, txt(d - 0x10000, 32)))
