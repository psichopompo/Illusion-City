# Banco de pruebas de Illusion City (Mega CD)

## Qué hace falta

```
/home/user/emu/bin/genesis_plus_gx_libretro.so   core instrumentado (6,2 MB)
/home/user/emu/RECETA.md                          receta para reconstruirlo
/home/user/Illusion City/bios/                    BIOS E/J/U (las paso David)
```

## Herramientas

| fichero | para qué |
|---|---|
| `mdcd.py` | arnés libretro: cargar state (`load_rzip`), volcar memoria del Mega CD (`prg8`, `word_ram`, `word_ram_2m`), escribir en la PRG (`poke_prg`), capturas (`save_png`), trazador (`trace`, `config`, `events`) |
| `md_btn.py` | **mapeo de botones** de Mega Drive a RetroPad (medido en el core: MD A = RetroPad Y, MD C = RetroPad A, MD X = L, MD Y = X, MD Z = R) |
| `medir.py` | mide la caja y el texto de una captura |
| `ver_titulo.py` | arranca y captura la pantalla de título |
| `barrido3.py` | barrido de geometría de la caja del título |

## Estados

```
states/TEST_L.state   de David: sala de guardado, con el panel abierto (SAVE)
states/TEST_I.state   de David: cuarto, menu de dialogo
```
**El savestate guarda la memoria del juego**, así que al cargarlo los textos son los
de cuando se grabó. Para ver textos nuevos hay que **empezar partida desde cero**.

## Cómo probar un build

```
python3 - <<'PY'
import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')                                   # n.cue -> ../TEST_N.bin
md.load_rzip('/home/user/Illusion City/states/TEST_L.state')
md.run(20)
md.press(1); md.run(20); md.release(); md.run(60)       # 1 = MD A (abrir menu)
md.save_png('captura.png')
PY
```
