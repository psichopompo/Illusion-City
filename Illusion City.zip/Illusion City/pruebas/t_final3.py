import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
# la tabla del dinero (INIT 0x14E0) tambien al state
ini=pm.m.region(raw,107,149400)
md.poke_prg(0x28000+0x14E0, ini[0x14E0:0x14E0+2000])
md.press(IDS['A']); md.run(20); md.release(); md.run(55)
md.save_png('/home/user/Illusion City/verificado_dinero_final.png')
a=np.array(Image.open('/home/user/Illusion City/verificado_dinero_final.png').convert('RGB'))
fila=(a[134:148,45:240,0]>190).any(axis=0)
xs=[i+45 for i,v in enumerate(fila) if v]
runs=[]
for x in xs:
    if runs and x<=runs[-1][1]+2: runs[-1][1]=x
    else: runs.append([x,x])
print('linea del dinero: x=%d..%d, %d glifos' % (min(xs),max(xs),len(runs)))
print('inicios:', [r[0] for r in runs])
Image.open('/home/user/Illusion City/verificado_dinero_final.png').convert('RGB').crop((40,128,240,160)).resize((200*4,32*4), Image.NEAREST).save('/home/user/zoom_final4.png')
