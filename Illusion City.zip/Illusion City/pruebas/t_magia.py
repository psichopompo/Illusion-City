"""t_magia.py - reproducir el menu de MAGIA con PARTIDA LIMPIA y volcar la plantilla.

Flujo (idea de David, ver LEEME.md):
  state sala de guardado -> C -> C (guarda slot 1) -> reset -> titulo -> CARGAR PARTIDA
  -> C (slot 1) -> dentro del juego -> A (menu) -> C (Magia)
Despues vuelca la PRG-RAM en $2758A y la compara con el fichero START.BIN del disco.

Uso: python3 t_magia.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


# 1) guardar la partida del state en el slot 1
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60)
pulsa('C', 8, 90)
md.run(90)
# 2) reset -> titulo -> CARGAR PARTIDA -> slot 1
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60)          # [ロード]
pulsa('C', 8, 120)         # slot 1
md.run(500)
print('  dentro del juego (frame %d)' % md.frame)
# 3) menu de Magia
pulsa('A', 18, 60)
md.save_png(pref + '_menu.png')
pulsa('C', 8, 90)
md.run(120)
md.save_png(pref + '_magia.png')
print('  capturas hechas (frame %d)' % md.frame)

# 4) volcado de la plantilla en RAM
prg = md.prg_ram()
def rd(ram, n):
    return md.deswap(prg[ram:ram + n])
tpl = rd(0x2758A, 0x120)
open('/tmp/tpl_ram.bin', 'wb').write(tpl)
print('  PRG $2758A volcada (%d B) -> /tmp/tpl_ram.bin' % len(tpl))
