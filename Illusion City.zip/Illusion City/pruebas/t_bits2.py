import sys; sys.path.insert(0,'.')
exec(open('t_bits.py').read().split('for bit in range(8):')[0])
mejor=None
for addr in (0x2988B, 0x2988C):
    for bit in (0,2,4,6):
        p,cols = prueba(addr, bit)
        tinta=sum(1 for ch in p if ch=='#')
        print('$%05X bit +%d -> tinta=%d columnas=%s' % (addr,bit,tinta,cols))
        print('   ', p[0:12]); print('   ', p[12:24]); print('   ', p[24:36])
        print('   ', p[36:48]); print('   ', p[48:60]); print('   ', p[60:72])
