import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
# espia: guarda (cursorX, codigo) por llamada; contador en $A9F3E, datos en $A9F40
ESPIA = (bytes.fromhex('48e7c040')+                                  # movem d0-d1/a1
         bytes.fromhex('43f9')+(0x000A9F40).to_bytes(4,'big')+       # lea $A9F40,a1
         bytes.fromhex('3239')+(0x000A9F3E).to_bytes(4,'big')+       # move.w $A9F3E,d1
         bytes.fromhex('d3c1')+                                      # adda.l d1,a1
         bytes.fromhex('32a8')+b'\x00\x14'+                          # move.w $14(a0),(a1)+
         bytes.fromhex('3280')+                                      # move.w d0,(a1)
         bytes.fromhex('5841')+                                      # addq.w #4,d1
         bytes.fromhex('33c1')+(0x000A9F3E).to_bytes(4,'big')+
         bytes.fromhex('4cdf0203')+                                  # movem (a7)+
         bytes.fromhex('4eb9')+(0x18B18).to_bytes(4,'big')+
         bytes.fromhex('30280008')+bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big'))
print('espia: %d B' % len(ESPIA))
md.poke_prg(pm.CAP2_RAM, ESPIA)
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
md.press(IDS['A']); md.run(20); md.release(); md.run(45)
w2=md.deswap(md.word_ram_2m())
n=int.from_bytes(w2[0x1F3E:0x1F40],'big')//4
print('llamadas espiadas:', n)
vistos={}
for k in range(min(n,4000)):
    x=int.from_bytes(w2[0x1F40+k*4:0x1F42+k*4],'big')
    c=int.from_bytes(w2[0x1F42+k*4:0x1F44+k*4],'big')
    if 40<=x<=240 and x not in vistos: vistos[x]=c
print('cursor X -> codigo del caracter (en la zona del dinero):')
for x in sorted(vistos):
    if 40<=x<=240: print('   X=%3d -> $%04X' % (x,vistos[x]))
