"""exp_magia.py - prueba de MECANISMO del panel de Magia (2 cambios minimos).

  Exp 1: en START 0x1758A (la plantilla del panel) cambiar 'Ｍａｇｉａ' por 'Ｐａｔｉｏ'
         (misma longitud) -> si sale en pantalla, esa es la plantilla que se pinta.
  Exp 2: en START 0x11E08 cambiar el limite de caracteres del nombre de 7 a 8
         -> el titulo deberia mostrar 'Tian Ren' completo.

Uso: python3 exp_magia.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    'm', os.path.join(AQUI, '..', 'recursos', 'tools', 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA_START, SZ_START = 59, 98184


def fw(t):
    out = bytearray()
    for ch in t:
        if 'A' <= ch <= 'Z':
            out += bytes([0x82, 0x60 + ord(ch) - 65])
        elif 'a' <= ch <= 'z':
            out += bytes([0x82, 0x81 + ord(ch) - 97])
        else:
            out += bytes([0x81, 0x40])
    return bytes(out)


def aplica(entrada, salida, exp1=True, exp2=True):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA_START, SZ_START))
    print('  plantilla en disco: %s' % st[0x1758A:0x1758A + 16].hex(' '))
    assert st[0x1758A:0x1758A + 2] == b'\x96\x5f', 'no reconozco el icono del titulo'
    if exp1:
        viejo = st[0x1758C:0x17596]
        nuevo = fw('PATIO')
        st[0x1758C:0x17596] = nuevo
        print('  Exp1: 0x1758C %s -> %s' % (viejo.hex(' '), nuevo.hex(' ')))
    if exp2:
        print('  Exp2: 0x11E08 %s -> 0008' % st[0x11E06:0x11E0A].hex(' '))
        assert st[0x11E06:0x11E0A] == bytes.fromhex('343c0007')
        st[0x11E08:0x11E0A] = (8).to_bytes(2, 'big')
    m.escribe_region(raw, LBA_START, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2],
           exp1=(len(sys.argv) < 4 or '1' in sys.argv[3]),
           exp2=(len(sys.argv) < 4 or '2' in sys.argv[3]))
