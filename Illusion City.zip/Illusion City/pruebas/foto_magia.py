"""foto_magia.py - PARTIDA LIMPIA -> panel de MAGIA -> captura.

Uso: python3 foto_magia.py <cue> <fichero_png>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

cue, png = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60)
pulsa('C', 8, 90)
md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60)
pulsa('C', 8, 120)
md.run(500)
pulsa('A', 18, 60)
for k in range(4):                 # Magia -> Perfiles -> Técnicas -> Combate
    md.press(IDS['C']); md.run(8); md.release(); md.run(45)
md.run(40)
md.save_png(png)
print('  %s  (frame %d)' % (png, md.frame))
