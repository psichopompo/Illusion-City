"""cursor.py - ¿aparece la CAJA AZUL del cursor del menu principal?

  cursor.py <cue> <prefijo> con_combate|sin_combate

Navega a Sistema y comprueba en cada paso si hay caja de seleccion, con capturas.
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref, modo = sys.argv[1], sys.argv[2], sys.argv[3]
md = mdcd.MD(cue)
AZUL = ((98, 170, 238), (32, 101, 172))


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def captura(n=None):
    p = ('%s_%s.png' % (pref, n)) if n else '/tmp/_c.png'
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def hay_caja(a, x0=64, x1=158):
    """busca un PAR de lineas azules separadas entre 6 y 16 px (la caja)."""
    lineas = []
    for y in range(38, 120):
        n = sum(1 for c in a[y, x0:x1] if (c[0], c[1], c[2]) in AZUL)
        if n > 25:
            lineas.append(y)
    grupos = []
    for y in lineas:
        if grupos and y - grupos[-1][-1] <= 2:
            grupos[-1].append(y)
        else:
            grupos.append([y])
    for k in range(len(grupos) - 1):
        if 6 <= grupos[k + 1][0] - grupos[k][-1] <= 16:
            return True
    return False


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
pulsa('A', 20, 90); md.run(250)
a = captura('00_menu')
print('  menu recien abierto: caja=%s' % hay_caja(a))

if modo == 'con_combate':
    for _ in range(4):
        pulsa('DOWN', 8, 60); md.run(110)
    print('  en Estado:            caja=%s' % hay_caja(captura('01_estado')))
    pulsa('C', 10, 160); md.run(250)
    captura('02_submenu')
    pulsa('DOWN', 8, 70); md.run(110)
    pulsa('DOWN', 8, 70); md.run(110)
    captura('03_combate_sel')
    pulsa('C', 10, 220); md.run(350)
    captura('04_combate')
    print('  Combate visto (frame %d)' % md.frame)
    pulsa('B', 10, 130); md.run(250)
    captura('05_vuelta1')
    print('  tras el 1er B:       caja=%s' % hay_caja(captura()))
    pulsa('B', 10, 130); md.run(250)
    a = captura('06_vuelta2')
    print('  tras el 2o B:        caja=%s  <-- aqui ya no hay cursor' % hay_caja(a))
else:
    print('  (sin pasar por Combate)')

for k in range(5):
    pulsa('DOWN', 8, 60)
    md.run(110)
a = captura('07_tras_5down')
print('  tras 5 DOWN:         caja=%s' % hay_caja(a))
pulsa('C', 10, 160)
md.run(250)
a1 = captura('08_tras_c')
pulsa('C', 10, 200)
md.run(300)
a2 = captura('09_tras_c2')
for k, t in enumerate(['DOWN', 'UP', 'LEFT', 'RIGHT'], 1):
    antes = captura()
    pulsa(t, 10, 130); md.run(200)
    d = captura('10_paso%d_%s' % (k, t))
    dif = int((np.abs(antes.astype(int) - d.astype(int)).sum(axis=2) > 0).sum())
    print('  %-5s: cambia en %6d px' % (t, dif))
md.run(500)
captura('11_final')
print('  final (frame %d)' % md.frame)
