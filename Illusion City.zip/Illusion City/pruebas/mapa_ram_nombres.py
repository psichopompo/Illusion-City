"""mapa_ram_nombres.py - que hay en la PRG-RAM por encima de INIT.BIN.

INIT.BIN se carga en $28000 (medido: BASE $49246 = INIT 0x21246) y mide 149400 B,
asi que acaba en $4C798. La BASE de textos es $49246, con offsets de 16 bits: los
nombres pueden estar en CUALQUIER direccion de $49246 a $59245.
Aqui se mira que hay en $4C000..$60000 durante el juego (¿esta libre?) y si cambia
con la escena (menus abiertos, ventana de personajes...).

Uso: python3 mapa_ram_nombres.py [cue]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import hashlib

CUE = sys.argv[1] if len(sys.argv) > 1 else 'aa.cue'
SALA = '/home/user/Illusion City/states/TEST_L.state'
INI, FIN = 0x44000, 0x60000


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def resume(prg, etiqueta):
    print('  --- %s ---' % etiqueta)
    trozo = prg[INI:FIN]
    # runs distintos de cero
    o = 0
    while o < len(trozo):
        if trozo[o] != 0:
            j = o
            while j < len(trozo) and trozo[j] != 0: j += 1
            if j - o >= 16:
                print('    $%05X..$%05X  %5d B no nulos   md5 %s'
                      % (INI + o, INI + j, j - o,
                         hashlib.md5(trozo[o:j]).hexdigest()[:8]))
            o = j
        else:
            o += 1
    print('    md5 de $4C800..$50000: %s' % hashlib.md5(prg[0x4C800:0x50000]).hexdigest()[:12])
    print('    md5 de $50000..$58000: %s' % hashlib.md5(prg[0x50000:0x58000]).hexdigest()[:12])


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)

prg = md.prg8(0, 0x80000)
resume(prg, 'en el juego (partida cargada)')
pulsa(md, 'A', 18, 60)
resume(md.prg8(0, 0x80000), 'menu principal abierto')
pulsa(md, 'C', 8, 70)
md.run(60)
resume(md.prg8(0, 0x80000), 'ventana de personajes abierta')
# volver al juego y hacer un par de cosas
pulsa(md, 'B', 8, 60); pulsa(md, 'B', 8, 60); pulsa(md, 'B', 8, 60)
md.run(200)
resume(md.prg8(0, 0x80000), 'de vuelta al juego')
