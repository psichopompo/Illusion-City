import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
SOLIDO = bytes.fromhex('ff'*18)
def corre(marcar):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    if marcar is not None: md.poke_prg(TABLA + marcar*CELL, SOLIDO)
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png('ddd.png')
    im=Image.open('ddd.png').convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    # miro solo la ZONA DEL FINAL de la linea (x>=185), donde esta el "H$"
    return [x for x in range(185,250) if any(claro(x,y) for y in range(133,152))]
base = corre(None)
print('zona del "H$" sin marcar:', min(base) if base else '-', max(base) if base else '-')
print('buscando la celda del simbolo $ (el ultimo glifo):')
for k in range(-2260,-2200):
    r = corre(k)
    if r != base:
        print('  rel %5d -> zona x=%s   <-- CAMBIA' % (k, (min(r),max(r)) if r else 'VACIA'))
