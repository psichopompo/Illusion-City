import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
# el descriptor del dinero es $A42AE; su cursor esta en $A42AE+$14 = $A42C2
CURSOR = 0xA42AE + 0x14
md.mem_window(CURSOR, CURSOR+2)
md.config(mem=1)
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(40)
md.trace(0)
evs=[e for e in md.events() if e.kind==9]
print('escrituras al cursor del dinero ($%X): %d' % (CURSOR, len(evs)))
for e in evs[:24]:
    print('   pc=$%06X  valor=%d' % (e.pc, e.v))
