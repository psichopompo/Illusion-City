import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
G=f.glifos_david()
david18 = f.a_celda12(G['$'], 0)      # 18 B, 12x12 continuo
def prueba(addr, guardar=None):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    md.poke_prg(addr, david18)
    md.press(IDS['A']); md.run(20); md.release(); md.run(60)
    f2=guardar or 'okk.png'; md.save_png(f2)
    a=np.array(Image.open(f2).convert('RGB'))
    return (a[135:147,202:214,0]>190)
print('escribo el $ de David en $29852 (18 B, 12x12 continuo):')
pat=prueba(0x29852, '/home/user/Illusion City/verificado_dolar.png')
for r in range(12): print('   ', ''.join('#' if pat[r,c] else '.' for c in range(12)))
