"""nav3.py - navegacion GUIADA POR DATOS hasta el menu de VELOCIDAD.

Lo que se lee de la Word RAM (medido en el codigo del juego):
  $A422C  = fila seleccionada del menu principal (descriptor $A4200): 0=Magia .. 5=Sistema
  $A4222  = puntero al texto del descriptor $A4200 ($27914 = menu de Velocidad)
  $A4266  = fila seleccionada del menu de 2 filas (descriptor $A423A): 0=スピード 1=スイツチ
  $A4232  = puntero al texto del descriptor $A423A

Uso: python3 nav3.py <cue> <captura.png>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

FILA_PPAL = 0xA422C
TXT_PPAL = 0xA4222
FILA_2 = 0xA4266
TXT_2 = 0xA4232
TPL_VEL = 0x27914


def u32(w2, addr):
    o = addr - 0x80000
    return int.from_bytes(w2[o:o + 4], 'big')


def u16(w2, addr):
    o = addr - 0x80000
    return int.from_bytes(w2[o:o + 2], 'big')


def pulsa(md, b, antes=12, despues=25):
    md.press(IDS[b]); md.run(antes); md.release(); md.run(despues)


def estado(md):
    w2 = md.deswap(md.word_ram_2m())
    return u16(w2, FILA_PPAL), u32(w2, TXT_PPAL), u16(w2, FILA_2), u32(w2, TXT_2)


def main():
    cue = sys.argv[1] if len(sys.argv) > 1 else 'n.cue'
    salida = sys.argv[2] if len(sys.argv) > 2 else 'vel.png'
    md = mdcd.MD(cue)
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state')
    md.run(20)
    print('   antes de abrir: fila=%s txt=$%X' % (estado(md)[0], estado(md)[1]))
    pulsa(md, 'A', 18, 55)
    print('   menu abierto:   fila=%d txt=$%X' % (estado(md)[0], estado(md)[1]))
    # bajar hasta Sistema (fila 5)
    for k in range(12):
        f = estado(md)[0]
        if f == 5:
            break
        pulsa(md, 'DOWN')
        print('   DOWN -> fila=%d' % estado(md)[0])
    md.save_png('nav3_sel.png')
    pulsa(md, 'A', 15, 55)
    f, t, f2, t2 = estado(md)
    print('   tras A: fila_ppal=%d txt_ppal=$%X | fila_2=%d txt_2=$%X' % (f, t, f2, t2))
    md.save_png('nav3_2filas.png')
    # en el menu de 2 filas: bajar a la fila 0 (スピード) y entrar
    for k in range(6):
        if estado(md)[2] == 0:
            break
        pulsa(md, 'UP')
    print('   fila_2 =', estado(md)[2])
    pulsa(md, 'A', 15, 55)
    f, t, f2, t2 = estado(md)
    print('   tras A: txt_ppal=$%X (velocidad = $%X)' % (t, TPL_VEL))
    md.save_png(salida)
    print('   escrito', salida)


if __name__ == '__main__':
    main()
