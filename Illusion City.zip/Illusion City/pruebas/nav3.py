"""nav3.py - navegacion fiable (la fila seleccionada va dentro de una CAJA azul).

Detector: se buscan las lineas azules largas (x=64..158) de la mitad superior de la
pantalla; la fila seleccionada es la que tiene su texto ENTRE dos de esas lineas
(la caja). Las filas del menu principal estan a y = 46 58 70 82 94 106 (texto).

Escenario: reproduce la secuencia EXACTA del bug que reporto David:
   menu -> Estado -> Combate -> B -> B -> Sistema -> C (ventana) -> C (Velocidad)

Uso: python3 nav3.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)
AZUL = ((98, 170, 238), (32, 101, 172))
BLANCO = (238, 238, 238)
CENTROS = [46, 58, 70, 82, 94, 106]
NOMBRES = ['Magia', 'Objetos', 'Equipo', 'Hablar', 'Estado', 'Sistema']


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def captura(n=None):
    p = ('%s_%s.png' % (pref, n)) if n else '/tmp/_n3.png'
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def cajas(a, x0=64, x1=158, ymin=38, ymax=118):
    """devuelve [(y0,y1)] de las cajas azules del menu principal."""
    runs = []
    for y in range(ymin, ymax):
        n = sum(1 for c in a[y, x0:x1] if (c[0], c[1], c[2]) in AZUL)
        if n > 25:
            if runs and y - runs[-1][-1] <= 2:
                runs[-1].append(y)
            else:
                runs.append([y])
    parejas = []
    for k in range(len(runs) - 1):
        if 6 <= runs[k + 1][0] - runs[k][-1] <= 16:
            parejas.append((runs[k][-1], runs[k + 1][0]))
    return parejas


def fila_seleccionada(a):
    for y0, y1 in cajas(a):
        centro = (y0 + y1) // 2
        for k, cy in enumerate(CENTROS):
            if abs(centro - cy) < 6:
                return k
    return None


def pon(fila, intentos=9):
    for k in range(intentos):
        a = captura()
        s = fila_seleccionada(a)
        if s == fila:
            return a
        pulsa('DOWN', 8, 60)
    print('     !! no llego a la fila %d (%s), estoy en %s'
          % (fila, NOMBRES[fila], s))
    return a


def cambia(antes, despues):
    return int((np.abs(antes.astype(int) - despues.astype(int)).sum(axis=2) > 0).sum())


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado')

pulsa('A', 20, 90); md.run(250)
a = pon(0)
print('  menu abierto (fila %s)' % NOMBRES[fila_seleccionada(a)])
captura('00_menu')

# --- Estado -> Combate ---
pon(4); captura('01_estado_sel')
pulsa('C', 10, 160); md.run(250)
captura('02_submenu')
pulsa('DOWN', 8, 70); md.run(120)
pulsa('DOWN', 8, 70); md.run(120)
captura('03_combate_sel')
pulsa('C', 10, 220); md.run(350)
captura('04_combate')
print('  Combate visto (frame %d)' % md.frame)
pulsa('B', 10, 130); md.run(250)
pulsa('B', 10, 130); md.run(250)
captura('05_vuelta')

# --- Sistema ---
a = pon(5)
captura('06_sistema_sel')
print('  Sistema seleccionado (frame %d)' % md.frame)
antes = captura()
pulsa('C', 10, 160)
md.run(250)
v1 = captura('07_ventana')
print('  1er C: la pantalla cambia en %d px' % cambia(antes, v1))
antes = captura()
pulsa('C', 10, 160)
md.run(250)
v2 = captura('08_velocidad')
print('  2o C: la pantalla cambia en %d px' % cambia(antes, v2))
for k, t in enumerate(['DOWN', 'DOWN', 'LEFT', 'RIGHT', 'B'], 1):
    antes = captura()
    pulsa(t, 10, 130)
    md.run(200)
    d = captura('09_paso%d_%s' % (k, t))
    print('  %-5s: la pantalla cambia en %d px' % (t, cambia(antes, d)))
md.run(400)
captura('10_final')
print('  final (frame %d)' % md.frame)
