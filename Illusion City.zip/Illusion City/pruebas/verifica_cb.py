"""verifica_cb.py - repaso completo del menu con la ROM de la tanda.

  menu -> Magia (ventana) -> vuelta -> Estado -> submenu -> Combate -> vuelta
       -> Sistema -> ventana (Velocidad/Ajustes) -> pantalla de Velocidad

Comprueba ademas que el juego RESPONDE en cada pantalla (que no hay cuelgues).

Uso: python3 verifica_cb.py <cue> <prefijo>
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)
AZUL = ((98, 170, 238), (32, 101, 172))


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(n=None):
    p = ('%s_%s.png' % (pref, n)) if n else '/tmp/_v.png'
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def dif(a, b):
    return int((np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).sum())


def responde(nombre):
    """pulsa DOWN y comprueba que la pantalla cambia."""
    a = foto()
    pulsa('DOWN', 8, 70); md.run(200)
    b = foto()
    d = dif(a, b)
    pulsa('UP', 8, 70); md.run(200)
    print('    %-22s responde: %s (%d px)' % (nombre, 'SI' if d > 20 else 'NO', d))
    return d > 20


def abrir(nombre, fila, esc=0):
    for _ in range(fila):
        pulsa('DOWN', 8, 60); md.run(120)
    pulsa('C', 10, 160); md.run(280)
    foto(nombre)
    print('  %s' % nombre)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado')

pulsa('A', 20, 90); md.run(250)
foto('00_menu')
responde('menu')

# 1. Magia + ventana de nombres
pulsa('C', 10, 150); md.run(300)
foto('01_magia_nombres')
responde('ventana de nombres')
pulsa('B', 10, 90); md.run(200)

# 2. Estado -> submenu -> Combate
for _ in range(4):
    pulsa('DOWN', 8, 60); md.run(120)
pulsa('C', 10, 160); md.run(300)
foto('02_submenu')
pulsa('DOWN', 8, 70); md.run(120)
pulsa('DOWN', 8, 70); md.run(120)
pulsa('C', 10, 220); md.run(400)
foto('03_combate')
responde('combate')
pulsa('B', 10, 130); md.run(250)
pulsa('B', 10, 130); md.run(250)

# 3. Sistema (el que se colgaba)
for _ in range(5):
    pulsa('DOWN', 8, 60); md.run(120)
pulsa('C', 10, 160); md.run(300)
foto('04_sistema_ventana')
a = foto()
pulsa('DOWN', 8, 70); md.run(200)
print('    la ventana de Sistema responde: %s' % ('SI' if dif(a, foto()) > 20 else 'NO'))
pulsa('C', 10, 160); md.run(300)
foto('05_velocidad')
responde('pantalla Velocidad')
pulsa('B', 10, 120); md.run(250)
pulsa('B', 10, 120); md.run(250)
foto('06_vuelta_menu')
print('  final (frame %d)' % md.frame)
