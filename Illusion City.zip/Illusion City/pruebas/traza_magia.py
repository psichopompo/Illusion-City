"""traza_magia.py - QUIEN lee la plantilla de MAGIA (lecturas de RAM en la ventana).

Se abre el menu de MAGIA con el flujo de siempre y se graba quien LEE la zona
$27580-$27680 (donde vive la plantilla de Magia en RAM) y la del descriptor
($a4200-$a4240). Cada evento MEMR trae pc / direccion / valor, asi que se ve la
rutina exacta que pinta el panel.

Uso: python3 traza_magia.py [cue] [frames_a_trazar]
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'az.cue'
NFRAMES = int(sys.argv[2]) if len(sys.argv) > 2 else 6
SALA = '/home/user/Illusion City/states/TEST_L.state'
LO, HI = 0x27500, 0x27700


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'A', 18, 60)
md.save_png('/tmp/tr_menu.png')
md.reset_events()
md.config(exec_=0, flow=0, vram=0, cram=0, vdpreg=0, mem=1, wrap=0)
md.mem_window(LO, HI)
md.trace(True)
pulsa(md, 'C', 8, 90)          # Magia
md.run(120)
md.trace(False)
md.save_png('/tmp/tr_magia.png')
evs = md.events()
print('  %d eventos' % len(evs))
vistos = {}
for e in evs:
    if e.kind in (mdcd.EV_MEMR, mdcd.EV_MEMW):
        vistos.setdefault((e.pc, e.kind), []).append(e)
print('  PC que tocan $%05X-$%05X:' % (LO, HI))
for (pc, kind), lst in sorted(vistos.items()):
    dirs = sorted({e.a for e in lst})
    print('   pc=$%06X %s  %4d veces  dirs %s' %
          (pc, mdcd.EVNAME[kind], len(lst),
           ' '.join('$%05X' % a for a in dirs[:12]) + (' ...' if len(dirs) > 12 else '')))
