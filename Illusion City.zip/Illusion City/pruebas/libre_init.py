"""libre_init.py - ¿que hay en la PRG-RAM despues del final de INIT.BIN?

INIT.BIN (149400 B) se carga en $28000 -> ocupa hasta $4C797. Los offsets de los
nombres son de 16 bits desde $49246, asi que llegan hasta $59245. Aqui se mira
$4C798..$59245 en varias escenas para ver si el juego escribe ahi o esta libre.

Uso: python3 libre_init.py [cue]
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'aa.cue'
SALA = '/home/user/Illusion City/states/TEST_L.state'
INI, FIN = 0x4C798, 0x59246


def pulsa(md, b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def resume(prg, etiqueta):
    trozo = prg[INI:FIN]
    nz = sum(1 for b in trozo if b)
    # primer byte no nulo
    prim = next((INI + i for i, b in enumerate(trozo) if b), None)
    ult = next((INI + len(trozo) - 1 - i for i, b in enumerate(reversed(trozo)) if b), None)
    print('    %-34s no nulos: %6d de %d   (primero %s, ultimo %s)'
          % (etiqueta, nz, len(trozo), hex(prim) if prim else '-', hex(ult) if ult else '-'))


md = mdcd.MD(CUE)
md.load_rzip(SALA); md.run(40)
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa(md, 'START', 8, 60)
md.run(250)
resume(md.prg8(0, 0x80000), 'pantalla de titulo')
pulsa(md, 'C', 8, 60); pulsa(md, 'C', 8, 60)
md.run(700)
resume(md.prg8(0, 0x80000), 'partida cargada (sala)')
pulsa(md, 'A', 18, 60)
resume(md.prg8(0, 0x80000), 'menu principal')
pulsa(md, 'C', 8, 70)
md.run(60)
resume(md.prg8(0, 0x80000), 'ventana de personajes (Magia)')
pulsa(md, 'B', 8, 50)
pulsa(md, 'B', 8, 50)
pulsa(md, 'B', 8, 50)
for k in range(12):          # hablar / avanzar dialogos
    pulsa(md, 'C', 6, 40)
md.run(200)
resume(md.prg8(0, 0x80000), 'tras 12 pulsaciones de C (dialogo)')
for k in range(6):           # andar
    pulsa(md, 'RIGHT', 12, 20)
    pulsa(md, 'DOWN', 12, 20)
md.run(200)
resume(md.prg8(0, 0x80000), 'tras andar por la sala')
pulsa(md, 'A', 18, 60)
resume(md.prg8(0, 0x80000), 'menu otra vez')
