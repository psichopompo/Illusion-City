import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
# 1) capturo el dinero con la moneda = solo "$"
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AD0, bytes.fromhex('8190')+b'\x00')
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA):
    md.poke_prg(0x10000+off, bytes.fromhex('43f9')+(0x00027AD0).to_bytes(4,'big'))
md.press(IDS['A']); md.run(20); md.release(); md.run(55)
md.save_png('dolar_pantalla.png')
a = np.array(Image.open('dolar_pantalla.png').convert('RGB'))
# el glifo del $ esta en x=198..209, y=135..146
pat = (a[135:147, 198:210, 0] > 190).astype(int)
print('el $ en pantalla (%dx%d):' % pat.shape)
for r in range(12): print('   ', ''.join('#' if pat[r,c] else '.' for c in range(12)))
print()
# 2) busco esa celda en la tabla
prg = md.prg8(0, 0x80000)
encontradas=[]
for rel in range(-2600, -1900):
    off = TABLA + rel*CELL
    if off+18 > len(prg): continue
    d = prg[off:off+18]
    g = np.unpackbits(np.frombuffer(d, dtype=np.uint8))[:144].reshape(12,12)
    if np.array_equal(g, pat):
        encontradas.append(rel)
print('celdas de la tabla IDENTICAS al $ de pantalla:', encontradas)
