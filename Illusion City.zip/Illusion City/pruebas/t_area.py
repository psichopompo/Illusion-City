import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA=0x294E0; CELL=18; SOL=bytes.fromhex('ff'*18)
def zonas(celda):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if celda is not None: md.poke_prg(TABLA+celda*CELL, SOL)
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png('za.png')
    a=np.array(Image.open('za.png').convert('RGB'))
    # H ~ x185-196 ; K ~ x196-205 ; $ ~ x205-218
    f=lambda x0,x1: (a[134:148,x0:x1,0]>190).sum()
    return f(183,195), f(195,205), f(205,219)
b=zonas(None)
print('base (H,K,$) =', b)
for c in range(60,80):
    z=zonas(c)
    camb=[i for i in range(3) if abs(z[i]-b[i])>20]
    if camb: print('  celda %2d -> (H,K,$)=%s  cambia: %s' % (c,z,['H','K','$'][camb[0]]))
