"""nav2.py - navegacion fiable por los menus (detector corregido).

En este juego la fila seleccionada NO cambia el color del texto: va envuelta en una
CAJA azul (lineas horizontales de (98,170,238)). Deteccion:
   - filas de texto = franjas con pixeles blancos en la columna del texto
   - fila seleccionada = la que tiene una linea azul larga justo encima
   - en los menus de LISTA (p.ej. la lista de conjuros) el seleccionado va en blanco
     y el resto en azul claro.

Uso: python3 nav2.py <cue> <prefijo> <escenario>
   escenario = plana | combate
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref, esc = sys.argv[1], sys.argv[2], sys.argv[3]
md = mdcd.MD(cue)
BLANCO = (238, 238, 238)
AZUL = ((98, 170, 238), (32, 101, 172))


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


def foto(n, ruta=None):
    p = ruta or ('%s_%s.png' % (pref, n))
    md.save_png(p)
    return np.array(Image.open(p).convert('RGB'))


def estable(nombre, intentos=10, paso=20):
    prev = None
    for k in range(intentos):
        a = foto(nombre + '_e', '/tmp/_nav2.png')
        if prev is not None and np.array_equal(a, prev):
            return a
        prev = a
        md.run(paso)
    return prev


def filas(a, x0, x1, y0, y1, minimo=4):
    fr = []
    for y in range(y0, y1):
        n = ((a[y, :, 0] == BLANCO[0]) & (a[y, :, 1] == BLANCO[1]) &
             (a[y, :, 2] == BLANCO[2]))[x0:x1].sum()
        if n > minimo:
            if fr and y - fr[-1][1] <= 3:
                fr[-1][1] = y
            else:
                fr.append([y, y])
    return [(f[0], f[1]) for f in fr]


def linea_azul(a, y, x0=62, x1=158, minimo=40):
    fila = a[y, x0:x1]
    return sum(1 for c in fila
               if (c[0], c[1], c[2]) in AZUL) > minimo


def seleccionada(a, fr, x0=62, x1=158):
    """indice de la fila de texto que tiene una linea azul justo encima."""
    for k, (y0, y1) in enumerate(fr):
        for dy in range(2, 6):
            if linea_azul(a, y0 - dy, x0, x1):
                return k
    return None


def pon(fila, x0=62, x1=158, y0=40, y1=140, nombre='menu', intentos=8):
    for k in range(intentos):
        a = estable(nombre)
        fr = filas(a, x0, x1, y0, y1)
        s = seleccionada(a, fr, x0, x1)
        if s == fila:
            return a, fr
        pulsa('DOWN', 8, 60)
    print('     !! no llego a la fila %d (estoy en %s)' % (fila, s))
    return a, fr


# ---------------- flujo limpio ----------------
md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
print('  juego cargado')

pulsa('A', 20, 90)
a, fr = pon(0, nombre='menu', y1=150)
print('  menu abierto, filas en %s' % fr[:6])
foto('00_menu')

if esc == 'combate':
    pon(4, nombre='estado', y1=150)
    foto('01_estado_sel')
    pulsa('C', 10, 160); md.run(200)
    a, fr2 = pon(2, x0=70, x1=170, y0=85, y1=145, nombre='submenu')
    print('  submenu filas %s' % fr2[:3])
    foto('02_submenu_combate')
    pulsa('C', 10, 200); md.run(300)
    foto('03_combate')
    print('  Combate visto (frame %d)' % md.frame)
    pulsa('B', 10, 120); md.run(250)
    foto('04_vuelta1')
    pulsa('B', 10, 120); md.run(250)
    foto('05_vuelta2')
    a, fr = pon(5, nombre='sistema', y1=150)
    foto('06_sistema_sel')
else:
    pon(5, nombre='sistema', y1=150)
    foto('06_sistema_sel')

print('  --- C en Sistema (frame %d)' % md.frame)
pulsa('C', 10, 160)
md.run(250)
foto('07_sistema_ventana')
print('  ventana de Sistema (frame %d)' % md.frame)
pulsa('C', 10, 160)
md.run(250)
foto('08_sistema_opcion')
print('  tras el 2o C (frame %d)' % md.frame)
for k in range(3):
    pulsa('DOWN', 8, 70)
    md.run(150)
md.save_png('%s_09_sistema_down.png' % pref)
pulsa('C', 10, 160); md.run(250)
md.save_png('%s_10_sistema_final.png' % pref)
f1 = md.frame
md.run(400)
md.save_png('%s_11_despues.png' % pref)
print('  frame %d -> %d (sigue vivo)' % (f1, md.frame))
