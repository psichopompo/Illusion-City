import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
TABLA = 0x2D7D0 + 0x4ED0; CELL=18
SOLIDO = bytes.fromhex('ff'*18)
def dolar(celdas):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AD0, bytes.fromhex('8190')+b'\x00')     # moneda = solo $
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA):
        md.poke_prg(0x10000+off, bytes.fromhex('43f9')+(0x00027AD0).to_bytes(4,'big'))
    for k in celdas: md.poke_prg(TABLA + k*CELL, SOLIDO)
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png('bs.png')
    im=Image.open('bs.png').convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    t=[x for x in range(40,250) if any(claro(x,y) for y in range(133,152))]
    runs=[]
    for x in t:
        if runs and x<=runs[-1][1]+2: runs[-1][1]=x
        else: runs.append([x,x])
    return (runs[-1][0], runs[-1][1]-runs[-1][0]+1) if runs else None
base = dolar([])
print('el $ sin marcar:', base)
print()
lo, hi = -3000, -1800
while hi-lo > 40:
    mid=(lo+hi)//2
    rango=list(range(lo,mid))
    r=dolar(rango)
    print('  rango %d..%d -> %s %s' % (lo,mid,r,'(AFECTA)' if r!=base else ''))
    if r!=base: hi=mid
    else: lo=mid
print()
print('la celda del $ esta entre', lo, 'y', hi)
for k in range(lo,hi):
    r=dolar([k])
    if r!=base: print('   rel %d -> %s  <-- ES LA DEL $' % (k,r))
