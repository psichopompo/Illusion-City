import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from collections import Counter
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('dt.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
for a,d in ((pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0]),):
    md.poke_prg(a,d)
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.mem_window(0x20000, 0x2C000)
md.config(mem=1)
md.reset_events()
md.trace(1)
md.press(IDS['A']); md.run(20); md.release(); md.run(50)
md.trace(0)
n = md.event_count()
evs = md.events()
print('eventos registrados: %d (capacidad %d)' % (n, md.evcap))
print('por tipo:', dict(Counter(e.kind for e in evs)))
reads=[e for e in evs if e.kind==10]
print('lecturas: %d' % len(reads))
from collections import Counter as C
if reads:
    print('  direcciones mas leidas:', [('$%05X'%a, n) for a,n in C(e.a for e in reads).most_common(8)])
print()
print('¿llega a ejecutarse el ultimo glifo? pongo una sonda:')
