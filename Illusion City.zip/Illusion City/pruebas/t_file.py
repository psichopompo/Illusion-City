import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
prg = md.prg8(0, 0x80000)
pat = prg[0x299BA:0x299CC]
print('glifo del $ en memoria ($299BA):', pat.hex(' '))
spec3=importlib.util.spec_from_file_location('p','/home/user/Illusion City/recursos/tools/parche_lote3.py')
m=importlib.util.module_from_spec(spec3); spec3.loader.exec_module(m)
raw=open("/home/user/Illusion City/Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin",'rb').read()
for nom,lba,sz in (('INIT.BIN',107,149400),('OPEN.BIN',285,69258),('SD.BIN',251,69194),
                   ('CHR.BIN',180,94310),('CHR1.BIN',227,47984),('GFONT.BIN',679,7920),
                   ('GHEAD.BIN',677,3184)):
    d=m.region(raw,lba,sz)
    i=d.find(pat)
    print('  %-12s -> %s' % (nom, ('offset 0x%X' % i) if i>=0 else 'no'))
# ¿y la fuente completa? busco el inicio de la fuente ($294E0) en los ficheros:
print()
print('buscando el inicio de la fuente ($294E0) en los ficheros...')
ini = prg[0x294E0:0x294E0+32]
for nom,lba,sz in (('INIT.BIN',107,149400),('OPEN.BIN',285,69258),('SD.BIN',251,69194),
                   ('CHR.BIN',180,94310),('CHR1.BIN',227,47984)):
    d=m.region(raw,lba,sz)
    i=d.find(ini)
    print('  %-12s -> %s' % (nom, ('offset 0x%X' % i) if i>=0 else 'no'))
