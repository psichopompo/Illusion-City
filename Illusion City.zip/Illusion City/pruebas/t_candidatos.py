import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
G=f.glifos_david()
david=np.unpackbits(np.frombuffer(f.a_celda12(G['$'],0),dtype=np.uint8))[:144]
def prueba(addr, alineado, nom):
    md = mdcd.MD('dt.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/tmp/dolar_test.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    prg=bytearray(md.prg8(0,0x80000))
    base=addr*8+(6 if alineado else 0)
    for i in range(144):
        b=base+i; byte,bi=b//8, 7-(b%8)
        if david[i]: prg[byte] |= (1<<bi)
        else:        prg[byte] &= ~(1<<bi)
    md.poke_prg(0, bytes(prg))
    md.press(IDS['A']); md.run(20); md.release(); md.run(60)
    f2='cand.png'; md.save_png(f2)
    a=np.array(Image.open(f2).convert('RGB'))
    pat=(a[135:147,198:210,0]>190)
    return ''.join('#' if pat[r,c] else '.' for r in range(12) for c in range(12))
ref = prueba(0x29850, True, 'ref')     # el sitio que ya probe (no cambia)
print('referencia (donde ya probe, sin efecto):')
for r in range(12): print('   ', ref[r*12:(r+1)*12])
print()
for addr in (0x2988A, 0x2988B, 0x2988C, 0x29894, 0x29889):
    p=prueba(addr, False, hex(addr))
    print('  escrito en $%05X (byte) -> %s' % (addr, 'CAMBIA!' if p!=ref else 'igual'))
