#!/usr/bin/env python3
"""exp_mueve_combate.py - mueve SOLO la plantilla de Combate, sin tocar el bloque
de datos del menu de Sistema (que es lo que rompia la ventana de Velocidad).

Con esto se comprueba si con el bloque intacto la ventana de Sistema vuelve a
funcionar con sus cadenas de siempre.

Uso: python3 exp_mueve_combate.py <entrada.bin> <salida.bin>
"""
import hashlib
import importlib.util
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('m', os.path.join(AQUI, '..', 'recursos', 'tools', 'parche_lote3.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

LBA, SZ = 59, 98184
TPL = 0x14268
FIN_MAX = 0x14300          # hasta aqui buscamos el final de la plantilla
RAM_TPL = 0x24268


def aplica(entrada, salida):
    raw = bytearray(open(entrada, 'rb').read())
    st = bytearray(m.region(raw, LBA, SZ))
    fin = st.find(b'\x00\x00', TPL)
    print('  plantilla de Combate: 0x%05X..0x%05X (%d B)  RAM $%06X'
          % (TPL, fin + 1, fin + 2 - TPL, RAM_TPL))
    # hueco libre detras de las plantillas que ya se movieron (Magia y Sistema)
    libre = 0x17CC2
    while libre < len(st) and st[libre] != 0xFF:
        libre += 1
    if libre % 2:
        libre += 1
    largo = fin + 2 - TPL
    print('  hueco libre desde 0x%05X' % libre)
    assert st[libre:libre + largo] == b'\xff' * largo, 'no cabe'
    st[libre:libre + largo] = st[TPL:fin + 2]
    # reapuntar TODAS las referencias a la plantilla (RAM $24268 y sus offsets)
    n = 0
    for k in range(0, largo, 2):
        viejo = (RAM_TPL + k).to_bytes(4, 'big')
        nuevo = (libre + 0x10000 + k).to_bytes(4, 'big')
        for o in range(0, len(st) - 4, 2):
            if st[o:o + 4] == viejo:
                st[o:o + 4] = nuevo
                n += 1
    print('  %d referencias reapuntadas' % n)
    m.escribe_region(raw, LBA, bytes(st))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open(salida, 'wb').write(bytes(raw))
    print('  MD5 %s' % hashlib.md5(bytes(raw)).hexdigest())


if __name__ == '__main__':
    aplica(sys.argv[1], sys.argv[2])
