"""mapa_bloque.py - situa cada tile del bloque del panel en pantalla.

Escribe UN PIXEL (el de arriba a la izquierda) del tile y busca donde aparece en la
pantalla. Asi se sabe que zona de pantalla cubre cada tile y, por tanto, cual cubre
la L de "LV".
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

md.save_png('/tmp/mb0.png')
a0 = np.array(Image.open('/tmp/mb0.png').convert('RGB')).astype(int)

print('  tile -> posicion del pixel de arriba-izquierda en pantalla:')
for t in range(1760, 1870, 1):
    # fila 0 = primer word; el pixel 0 es el nibble ALTO del byte 0
    md.lib.arena_vdp_write16(t * 32, 0x0C00)
    md.run(1)
    md.save_png('/tmp/mb1.png')
    a1 = np.array(Image.open('/tmp/mb1.png').convert('RGB')).astype(int)
    d = np.abs(a0 - a1).sum(axis=2)
    ys, xs = np.nonzero(d > 200)
    md.lib.arena_vdp_write16(t * 32, 0x0000)
    if len(ys):
        print('   tile %4d -> (x=%d, y=%d)' % (t, xs.min(), ys.min()))
