import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
G=f.glifos_david()
g8=G['$']
def bytes_glyph16(offs_x=2, offs_y=2):
    """glifo 8x8 en 12 filas x 16 bits (2 bytes por fila), MSB primero."""
    out=bytearray()
    for r in range(12):
        row=0
        rr=r-offs_y
        if 0<=rr<8:
            for c in range(8):
                col=offs_x+c
                if g8[rr][c] and 0<=col<16:
                    row |= (0x8000 >> col)
        out += row.to_bytes(2,'big')
    return bytes(out)
def prueba(addr, ox, oy, guardar=None):
    md = mdcd.MD('dt.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/tmp/dolar_test.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    md.poke_prg(addr, bytes_glyph16(ox,oy))
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    f2=guardar or 'ff.png'; md.save_png(f2)
    a=np.array(Image.open(f2).convert('RGB'))
    pat=(a[135:147,198:210,0]>190)
    return pat
for addr in (0x29889, 0x2988B, 0x2988A):
    for ox in (2,0,3):
        pat=prueba(addr,ox,2)
        cols=[c for c in range(12) if pat[:,c].any()]
        print('$%05X off_x=%d -> columnas %s  tinta=%d' % (addr,ox,(min(cols),max(cols)) if cols else None, pat.sum()))
pat=prueba(0x2988B,2,2,'dolar_ok.png')
print()
print('mejor candidato ($2988B, off_x=2):')
for r in range(12): print('   ', ''.join('#' if pat[r,c] else '.' for c in range(12)))
