"""puntero_bd00.py - de donde saca la ventana el nombre del personaje.

La rutina que dibuja la ventana hace: movea.l $bd00.l,a1  ->  copia la cadena.
Aqui se lee $bd00 con la ventana abierta y se vuelca la cadena y su entorno, para
localizar la tabla de nombres que usa la ventana (distinta de la de 0x22919).

Uso: python3 puntero_bd00.py <cue>
"""
import sys; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 8, 60); pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

prg = md.prg8(0, 0x80000)


def w32(a):
    return int.from_bytes(prg[a - 0x10000:a - 0x10000 + 4], 'big')


def txt(off, n=32):
    d = prg[off:off + n]
    out, i = [], 0
    while i < n:
        if d[i] == 0:
            out.append('|'); break
        if d[i] < 0x80:
            out.append('{%02X}' % d[i]); i += 1; continue
        try:
            out.append(d[i:i + 2].decode('shift_jis'))
        except Exception:
            out.append('?')
        i += 2
    return ''.join(out)


print('  sin ventana (menu principal): $bd00 = $%06X  $a600 = $%06X' % (w32(0xBD00), w32(0xA600)))
pulsa('A', 18, 60)
pulsa('C', 8, 70)              # ventana abierta
print('  con la ventana abierta:')
for a in (0xBD00, 0xBD04, 0xBD08, 0xBD0C, 0xA600, 0xA604, 0xA608):
    v = w32(a)
    extra = ''
    if 0x10000 <= v < 0x80000:
        extra = '  -> «%s»' % txt(v - 0x10000)
    print('   $%05X = $%06X%s' % (a, v, extra))
print()
print('  la tabla de personajes ($a600 apunta a $%06X):' % w32(0xA600))
t = w32(0xA600)
if 0x10000 <= t < 0x80000:
    o = t - 0x10000
    print('   bytes:', prg[o:o + 48].hex(' '))
    for k in range(8):
        e = prg[o + 6 * k: o + 6 * k + 6]
        i1 = int.from_bytes(e[0:2], 'big')
        o1 = int.from_bytes(e[2:4], 'big')
        o2 = int.from_bytes(e[4:6], 'big')
        print('   entrada %d: id=%5d off1=$%04X off2=$%04X' % (k, i1, o1, o2))
