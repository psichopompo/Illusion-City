import sys, importlib.util
sys.path.insert(0, '.')
spec=importlib.util.spec_from_file_location('p','/home/user/Illusion City/recursos/tools/parche_lote3.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
import mdcd
from PIL import Image
OFF_X, OFF_A, OFF_T = 0x0AC7, 0x0AD3, 0x0AB5

def build(nombre,x,a,i):
    raw=bytearray(open('/home/user/Illusion City/TEST_F.bin','rb').read())
    ss=bytearray(m.region(raw, m.LBA_SSTART, m.SZ_SSTART))
    ss[OFF_X]=x; ss[OFF_A]=a; ss[OFF_T]=i
    m.escribe_region(raw, m.LBA_SSTART, bytes(ss))
    raw=bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open('b_%s.bin'%nombre,'wb').write(bytes(raw))
    open('b_%s.cue'%nombre,'w').write('FILE "b_%s.bin" BINARY\r\n  TRACK 01 MODE1/2352\r\n    INDEX 01 00:00:00\r\n'%nombre)

def analiza(f):
    im=Image.open(f).convert('RGB'); px=im.load()
    def marco(x,y):
        c=px[x,y]; return c==(238,170,0) or c==(32,101,172)
    def blanco(x,y):
        c=px[x,y]; return c==(238,238,238)
    bordes=[x for x in range(256) if sum(1 for y in range(110,155) if marco(x,y))>25]
    texto=[x for x in range(256) if any(blanco(x,y) for y in range(100,160))]
    if not bordes: return None
    return min(bordes), max(bordes), (min(texto),max(texto)) if texto else None

def corre(nombre,x,a,i):
    build(nombre,x,a,i)
    md = mdcd.MD('b_%s.cue'%nombre)
    t=0
    for _ in range(3):
        md.run_until_frame(t+300); t+=300
        md.press('START'); md.run(20); t+=20; md.release()
    md.run_until_frame(2700)
    f='cap_%s.png'%nombre; md.save_png(f)
    r=analiza(f)
    if not r: print('$04=%d $08=%d $32=%d -> NO SE VE LA CAJA' % (x,a,i)); return
    x0,x1,tx = r
    s='$04=%d $08=%d $32=%d | caja x=%d..%d (ancho %d, centro %.1f)' % (x,a,i,x0,x1,x1-x0+1,(x0+x1)/2)
    if tx: s += ' | texto x=%d..%d | margenes %d / %d' % (tx[0],tx[1],tx[0]-x0,x1-tx[1])
    print(s)

for nom,x,a,i in [('p1',5,24,0),('p2',6,24,0),('p3',5,22,0),('p4',5,24,1),('p5',4,24,0)]:
    try: corre(nom,x,a,i)
    except Exception as e: print(nom,'ERROR',e)
