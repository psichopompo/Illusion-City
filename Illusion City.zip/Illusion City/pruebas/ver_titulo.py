import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mdcd
md = mdcd.MD('/home/user/Illusion City/pruebas/tf.cue')
t=0
for _ in range(3):
    md.run_until_frame(t+300); t+=300
    md.press('START'); md.run(20); t+=20; md.release()
md.run_until_frame(2700)
# mover el cursor a la 2ª opcion para que se vea el resaltado y las tres lineas
md.press('DOWN'); md.run(10); md.release(); md.run(40)
md.save_png('/home/user/Illusion City/verificado_titulo.png')
print('verificado_titulo.png  (TEST_F: caja ampliada + textos traducidos)')
