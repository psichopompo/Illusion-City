import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
from PIL import Image
md = mdcd.MD('n.cue')
t=0
for _ in range(3):
    md.run_until_frame(t+300); t+=300
    md.press(IDS['START']); md.run(20); t+=20; md.release()
md.run_until_frame(t+200); t+=200
md.save_png('p_titulo.png')
md.press(IDS['A']); md.run(40); t+=40; md.release()      # PARTIDA NUEVA (1ª opcion)
# avanzar intro y dialogos
for k in range(60):
    for _ in range(5):
        md.run(55); t+=55
        md.press(IDS['A']); md.run(5); md.release()
        md.press(IDS['B']); md.run(5); md.release()
    md.press(IDS['A']); md.run(12); t+=12; md.release(); md.run(45); t+=45
    if k % 10 == 9:
        md.save_png('p_%02d.png'%k)
        print('  ronda %d (frame %d)' % (k,t))
md.save_png('p_final.png')
print('frame final', t)
