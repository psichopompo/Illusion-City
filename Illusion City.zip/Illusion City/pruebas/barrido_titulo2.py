"""barrido_titulo2.py - barrido del menu del titulo: caja, texto y SELECTOR.

  $04 (file 0x0AC7) = X de la caja        $08 (file 0x0AD3) = ancho de la caja
  $32 (file 0x0AB5) = margen del texto    $2e (file 0x0AC1) = nº de trozos del selector

Uso: python3 barrido_titulo2.py <cue> <build.bin> "8,16,3,9" "9,15,0,10" ...
"""
import sys, importlib.util; sys.path.insert(0, '.')
import mdcd
import numpy as np
from PIL import Image
spec = importlib.util.spec_from_file_location('m', '/home/user/Illusion City/recursos/tools/parche_lote3.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
OFF_X, OFF_A, OFF_T, OFF_S = 0x0AC7, 0x0AD3, 0x0AB5, 0x0AC1
MARCO = np.array([239, 170, 0]); SEL = np.array([98, 170, 238])

def corre(x, a_, t, s, nom):
    raw = bytearray(open(BUILD, 'rb').read())
    ss = bytearray(m.region(raw, m.LBA_SSTART, m.SZ_SSTART))
    ss[OFF_X] = x; ss[OFF_A] = a_; ss[OFF_T] = t; ss[OFF_S] = s
    m.escribe_region(raw, m.LBA_SSTART, bytes(ss))
    raw = bytearray(m.edcecc.repara_bytes(bytes(raw)))
    open('/tmp/tb.bin', 'wb').write(bytes(raw))
    open('/tmp/tb.cue', 'w').write('FILE "tb.bin" BINARY\r\n  TRACK 01 MODE1/2352\r\n    INDEX 01 00:00:00\r\n')
    md = mdcd.MD('/tmp/tb.cue')
    tt = 0
    for _ in range(3):
        md.run_until_frame(tt + 300); tt += 300
        md.press('START'); md.run(20); tt += 20; md.release()
    md.run_until_frame(2700)
    f = '/tmp/tt_%s.png' % nom
    md.save_png(f)
    return f

def mide(png):
    a = np.array(Image.open(png).convert('RGB')).astype(int)
    marco = (np.abs(a - MARCO).sum(axis=2) < 150)
    blanco = (a[:, :, 0] > 200) & (a[:, :, 1] > 200) & (a[:, :, 2] > 200)
    sel = (np.abs(a - SEL).sum(axis=2) < 60)
    cols = [x for x in range(256) if marco[100:160, x].sum() > 25]
    x0, x1 = min(cols), max(cols)
    tx = [x for x in range(256) if blanco[110:150, x].any()]
    sx = [x for x in range(256) if sel[105:130, x].any()]
    return x0, x1, (min(tx), max(tx)), ((min(sx), max(sx)) if sx else None)

BUILD = sys.argv[2]
for k, pr in enumerate(sys.argv[3:]):
    x, a_, t, s = (int(v) for v in pr.split(','))
    f = corre(x, a_, t, s, 'p%d' % k)
    x0, x1, tx, sx = mide(f)
    print('  $04=%d $08=%d $32=%d $2e=%2d | caja x=%d..%d (%d px, centro %.1f) | texto x=%d..%d (margenes %d/%d) | selector x=%s'
          % (x, a_, t, s, x0, x1, x1 - x0 + 1, (x0 + x1) / 2, tx[0], tx[1], tx[0] - x0, x1 - tx[1], sx))
