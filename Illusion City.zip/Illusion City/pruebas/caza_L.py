"""caza_L.py - identifica el tile que dibuja la L del panel.

1. mide las cajas exactas de las letras amarillas (LV, HP, MP)
2. para cada tile candidato: escribe un SOLIDO y mide cuanto se pierde en la caja
   de la L (y solo en ella)
"""
import sys, ctypes; sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

CUE = sys.argv[1] if len(sys.argv) > 1 else 'z.cue'
md = mdcd.MD(CUE)
md.lib.arena_vdp_write16.argtypes = [ctypes.c_uint, ctypes.c_uint]


def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa(md, 'C', 8, 60) if False else pulsa('C', 8, 60)
pulsa('C', 8, 90); md.run(90)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
pulsa('C', 8, 60); pulsa('C', 8, 60)
md.run(700)

md.save_png('/tmp/cl0.png')
a0 = np.array(Image.open('/tmp/cl0.png').convert('RGB')).astype(int)
amar = (np.abs(a0 - np.array([239, 170, 0])).sum(axis=2) < 130)
# dibujar el mapa de las letras para localizar las cajas
print('  mapa amarillo (x=200..240, y=30..100):')
for y in range(30, 100):
    fila = ''.join('#' if amar[y, x] else '.' for x in range(200, 240))
    if '#' in fila:
        print('   y=%3d |%s|' % (y, fila))
