"""sonda_sistema.py - ¿responde el juego o se queda colgado?

Hace la secuencia completa (menu -> Estado -> Combate -> vuelta -> Sistema) y
despues prueba TECLA A TECLA guardando una captura y comprobando si la pantalla
cambia con cada pulsacion. Si una pulsacion no cambia NADA en varios intentos,
es que el juego esta bloqueado ahi.

Uso: python3 sonda_sistema.py <cue> <prefijo> [sin_combate]
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image


def compara(a, b):
    return int((np.abs(a.astype(int) - b.astype(int)).sum(axis=2) > 0).sum())


def main(cue, pref, con_combate=True):
    md = mdcd.MD(cue)
    BLANCO = (238, 238, 238)
    AZUL = ((98, 170, 238), (32, 101, 172))

    def pulsa(b, hold=10, des=70):
        md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

    def foto(n):
        p = '%s_%s.png' % (pref, n)
        md.save_png(p)
        return np.array(Image.open(p).convert('RGB'))

    def filas(a, x0=62, x1=158, y0=40, y1=150):
        fr = []
        for y in range(y0, y1):
            n = ((a[y, :, 0] == BLANCO[0]) & (a[y, :, 1] == BLANCO[1]) &
                 (a[y, :, 2] == BLANCO[2]))[x0:x1].sum()
            if n > 4:
                if fr and y - fr[-1][1] <= 3:
                    fr[-1][1] = y
                else:
                    fr.append([y, y])
        return [(f[0], f[1]) for f in fr]

    def sel(a, fr, x0=62, x1=158):
        for k, (y0, y1) in enumerate(fr):
            for dy in range(2, 6):
                fila = a[y0 - dy, x0:x1]
                if sum(1 for c in fila if (c[0], c[1], c[2]) in AZUL) > 40:
                    return k
        return None

    def pon(fila, x0=62, x1=158, y0=40, y1=150, nom='m'):
        for _ in range(8):
            a = foto('e')
            fr = filas(a, x0, x1, y0, y1)
            s = sel(a, fr, x0, x1)
            if s == fila:
                return a
            pulsa('DOWN', 8, 60)
        print('        (no llego a la fila %d, estoy en %s)' % (fila, s))
        return a

    md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
    pulsa('C', 10, 80)
    pulsa('C', 10, 110)
    md.run(120)
    md.lib.retro_reset(); md.run(500)
    for _ in range(6):
        pulsa('START', 10, 80)
    md.run(300)
    pulsa('C', 10, 70)
    pulsa('C', 10, 150)
    md.run(700)
    pulsa('A', 20, 90)

    if con_combate:
        pon(4)
        pulsa('C', 10, 160); md.run(250)
        pon(2, x0=70, x1=170, y0=85, y1=145)
        pulsa('C', 10, 220); md.run(350)
        foto('combate')
        print('  Combate visto (frame %d)' % md.frame)
        pulsa('B', 10, 130); md.run(250)
        pulsa('B', 10, 130); md.run(250)
        foto('vuelta')
        print('  vuelta al menu (frame %d)' % md.frame)
    else:
        print('  (sin pasar por Combate)')

    pon(5)
    foto('sistema_sel')
    print('  --- entrando en SISTEMA')
    for k, tecla in enumerate(['C', 'C', 'DOWN', 'DOWN', 'DOWN', 'B', 'C', 'A'], 1):
        antes = foto('paso%d_antes' % k)
        pulsa(tecla, 10, 120)
        md.run(120)
        despues = foto('paso%d_%s' % (k, tecla))
        d = compara(antes, despues)
        print('   paso %d  %-5s  pantalla cambia en %6d px   (frame %d)'
              % (k, tecla, d, md.frame))
    md.run(600)
    fin = foto('fin')
    print('  +600 frames despues (frame %d)' % md.frame)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], not (len(sys.argv) > 3 and sys.argv[3] == 'sin_combate'))
