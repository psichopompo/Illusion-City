import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
COLA=pm.COLA
def test(nombre, capturas, avance):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    if capturas:
        md.poke_prg(pm.CAP1_RAM, pm.cap1()); md.poke_prg(pm.CAP2_RAM, pm.cap2())
        md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
        md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    if avance == 'simple':
        md.poke_prg(0x25170, bytes.fromhex('54680014')+COLA)
        md.poke_prg(0x18B54, bytes.fromhex('4ef9')+(0x25170).to_bytes(4,'big')+bytes.fromhex('4e71')*8)
    elif avance == 'completa':
        md.poke_prg(pm.RUT_RAM, pm.rutina())
        md.poke_prg(0x18B54, bytes.fromhex('4ef9')+pm.RUT_RAM.to_bytes(4,'big')+bytes.fromhex('4e71')*8)
    md.press(IDS['A']); md.run(20); md.release(); md.run(80)
    f='a_%s.png'%nombre; md.save_png(f)
    im=Image.open(f).convert('RGB'); px=im.load()
    claro=lambda x,y: px[x,y][0]>190 and px[x,y][1]>190 and px[x,y][2]>190
    res=[]
    for k,y0 in enumerate(range(43,105,12)):
        cols=[x for x in range(50,180) if any(claro(x,y) for y in range(y0,y0+9))]
        res.append((max(cols)-min(cols)+1) if cols else 0)
    w2=md.deswap(md.word_ram_2m())
    print('%-22s filas=%-28s VAR=%s' % (nombre, res, w2[pm.VAR-0x80000:pm.VAR-0x80000+2].hex()))
test('1_sin_nada', False, None)
test('2_solo_capturas', True, None)
test('3_solo_avance8', False, 'simple')
test('4_capturas_avance8', True, 'simple')
