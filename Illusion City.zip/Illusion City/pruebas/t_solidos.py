import sys; sys.path.insert(0,'.')
exec(open('t_hallar.py').read().split("# lugar del $")[0])
import numpy as np
from PIL import Image
SOL=bytes.fromhex('ff'*18)
def prueba_sol(celda, salida):
    md = mdcd.MD('n.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if celda is not None: md.poke_prg(0x294E0+celda*18, SOL)
    md.press(IDS['A']); md.run(20); md.release(); md.run(50)
    md.save_png(salida)
def cambia(f1,f2):
    a=np.array(Image.open(f1).convert('L')).astype(int); b=np.array(Image.open(f2).convert('L')).astype(int)
    d=np.abs(a-b)>60; ys,xs=np.nonzero(d)
    return (int(xs.min()),int(xs.max()),int(ys.min()),int(ys.max())) if len(xs) else None
prueba_sol(None,'s_ref.png')
print('celda (codigo) -> zona que cambia en pantalla:')
for celda,cod in ((33,'$'),(45,'0'),(46,'1'),(55,':'),(69,'H'),(72,'K')):
    prueba_sol(celda,'s_%d.png'%celda)
    print('  celda %2d (%s) -> %s' % (celda,cod,cambia('s_ref.png','s_%d.png'%celda)))
