import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
from md_btn import IDS
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
raw=open('/home/user/Illusion City/TEST_L.bin','rb').read()
st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
# CAP2 guarda TODOS los codigos en $A9F40+2*n (usando un contador en $A9F3E)
ESPIA = (bytes.fromhex('48e7f0f0')+                                   # movem d0-d3/a0-a3
         bytes.fromhex('41f9')+(0x000A9F3E).to_bytes(4,'big')+        # lea $A9F3E,a0
         bytes.fromhex('3210')+                                        # move.w (a0),d1  (contador)
         bytes.fromhex('5241')+                                        # addq.w #1,d1
         bytes.fromhex('3081')+                                        # move.w d1,(a0)  (guarda contador)
         bytes.fromhex('e549')+                                        # lsl.w #2,d1
         bytes.fromhex('41f9')+(0x000A9F60).to_bytes(4,'big')+        # lea $A9F60,a0
         bytes.fromhex('3180')+(0x0000).to_bytes(2,'big')+            # move.w d0,(a0,d1.w)
         bytes.fromhex('4eb9')+(0x18B18).to_bytes(4,'big')+           # jsr pintor
         bytes.fromhex('4cdf0f0f')+                                   # movem (a7)+
         bytes.fromhex('30280008')+bytes.fromhex('4ef9')+(0x18A88).to_bytes(4,'big'))
md.poke_prg(pm.CAP2_RAM, ESPIA)
md.poke_prg(pm.CAP2_RAM+2, ESPIA[2:])
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0])
for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
md.press(IDS['A']); md.run(20); md.release(); md.run(50)
w2=md.deswap(md.word_ram_2m())
n=int.from_bytes(w2[0x1F3E:0x1F40],'big')
print('llamadas espiadas:', n)
cod=[]
for k in range(1,min(n,24)+1):
    v=int.from_bytes(w2[0x1F60+k*4:0x1F62+k*4],'big')
    cod.append('%04X'%v)
print('codigos de los caracteres de la linea del dinero:')
print('  ', ' '.join(cod))
