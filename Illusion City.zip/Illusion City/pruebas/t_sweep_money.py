import sys; sys.path.insert(0,'.')
exec(open('t_solidos.py').read().split("prueba_sol(None,'s_ref.png')")[0])
import numpy as np
from PIL import Image
def zona_dinero(f1,f2):
    a=np.array(Image.open(f1).convert('L')).astype(int); b=np.array(Image.open(f2).convert('L')).astype(int)
    d=np.abs(a-b)>60
    d[:130,:]=False; d[152:,:]=False     # solo la linea del dinero
    ys,xs=np.nonzero(d)
    return (int(xs.min()),int(xs.max())) if len(xs) else None
prueba_sol(None,'sr.png')
print('celdas que afectan a la LINEA DEL DINERO:')
for celda in range(20,100):
    prueba_sol(celda,'sc.png')
    z=zona_dinero('sr.png','sc.png')
    if z: print('   celda %2d -> x=%s  (H~186, K~198, $~210)' % (celda,z))
