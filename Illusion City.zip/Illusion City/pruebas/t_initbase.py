import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
f=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(f)
spec3=importlib.util.spec_from_file_location('p','/home/user/Illusion City/recursos/tools/parche_lote3.py')
m=importlib.util.module_from_spec(spec3); spec3.loader.exec_module(m)
G=f.glifos_david()
# INIT.BIN del fichero
init=m.region(open('/home/user/Illusion City/Gen\'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin','rb').read(),107,149400)
md = mdcd.MD('n.cue')
md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
prg = md.prg8(0,0x80000)
# base de INIT en memoria: busco un bloque suyo
blk = init[0x2000:0x2040]
base = prg.find(blk) - 0x2000
print('INIT.BIN cargado en PRG $%05X' % base)
# el $ esta en INIT+0x1850 (bit 6): lo escribo en memoria
def escribe_bits(buf, bit_off, patron, nbits=144):
    for i in range(nbits):
        b = bit_off + i
        byte, bit = b//8, 7-(b%8)
        if patron[i]: buf[byte] |= (1<<bit)
        else: buf[byte] &= ~(1<<bit)
patr = np.unpackbits(np.frombuffer(f.a_celda12(G['$'], 0), dtype=np.uint8))[:144]
# direccion en memoria del $ (medida con la busqueda): PRG 0x29850 bit 6
buf = bytearray(prg)
escribe_bits(buf, 0x29850*8 + 6, patr)
md.poke_prg(0, bytes(buf))
md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
md.press(IDS['A']); md.run(20); md.release(); md.run(55)
md.save_png('david_dolar2.png')
a=np.array(Image.open('david_dolar2.png').convert('RGB'))
pat=(a[135:147,198:210,0]>190)
print('el $ en pantalla:')
for r in range(12): print('   ', ''.join('#' if pat[r,c] else '.' for c in range(12)))
