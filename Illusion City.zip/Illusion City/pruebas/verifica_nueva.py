"""verifica_nueva.py - PARTIDA NUEVA (sin save): aqui los nombres SI vienen del disco.

guarda (para tener save) -> reset -> titulo -> PARTIDA NUEVA -> captura del HUD.

Uso: python3 verifica_nueva.py <cue> <prefijo>
"""
import sys; sys.path.insert(0,'.')
import mdcd
from md_btn import IDS
import numpy as np
from PIL import Image

cue, pref = sys.argv[1], sys.argv[2]
md = mdcd.MD(cue)

def pulsa(b, hold=8, des=45):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)

md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 8, 60)
md.run(250)
md.save_png(pref + '_titulo.png')
pulsa('DOWN', 6, 40)              # pasar a PARTIDA NUEVA
pulsa('C', 8, 60)
md.run(300)
# avanzar la intro hasta que aparezca el HUD
for k in range(14):
    pulsa('C', 6, 30)
    pulsa('START', 6, 20)
md.run(200)
md.save_png(pref + '_nueva.png')
print('  capturas hechas')
