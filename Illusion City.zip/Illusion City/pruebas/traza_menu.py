"""traza_menu.py - captura DESPUES DE CADA tecla, para ver la navegacion exacta.

Uso: python3 traza_menu.py <cue> <prefijo> <teclas...>
  teclas: A B C START DOWN UP...
ej: python3 traza_menu.py ba.cue /tmp/T combate
      -> flujo limpio, abre el menu y hace la secuencia del bug paso a paso
"""
import sys
sys.path.insert(0, '.')
import mdcd
from md_btn import IDS

cue, pref = sys.argv[1], sys.argv[2]
SEC = sys.argv[3:]
md = mdcd.MD(cue)


def pulsa(b, hold=10, des=70):
    md.press(IDS[b]); md.run(hold); md.release(); md.run(des)


md.load_rzip('/home/user/Illusion City/states/TEST_L.state'); md.run(40)
pulsa('C', 10, 80)
pulsa('C', 10, 110)
md.run(120)
md.lib.retro_reset(); md.run(500)
for _ in range(6):
    pulsa('START', 10, 80)
md.run(300)
pulsa('C', 10, 70)
pulsa('C', 10, 150)
md.run(700)
pulsa('A', 20, 90)
md.run(300)
md.save_png('%s_00_menu.png' % pref)
print('  menu abierto (frame %d)' % md.frame)

# secuencia del submenu de Estado + Combate + vuelta + Sistema
pasos = []
for _ in range(4):
    pasos.append('DOWN')
pasos += ['C', 'DOWN', 'DOWN', 'C']            # submenu -> Combate
pasos += ['B', 'B']                            # vuelta al menu principal
for _ in range(5):                             # hasta Sistema
    pasos.append('DOWN')
pasos += ['C']
for k, t in enumerate(pasos, 1):
    pulsa(t, 10, 110)
    p = '%s_%02d_%s.png' % (pref, k, t)
    md.save_png(p)
    print('  %2d %-5s frame %5d -> %s' % (k, t, md.frame, p.split('/')[-1]))
md.run(200)
md.save_png('%s_final.png' % pref)
print('  final (frame %d)' % md.frame)
