import sys; sys.path.insert(0,'.')
import mdcd, importlib.util
import numpy as np
from md_btn import IDS
from PIL import Image
spec=importlib.util.spec_from_file_location('pm','/home/user/Illusion City/recursos/tools/paso_mixto.py')
pm=importlib.util.module_from_spec(spec); spec.loader.exec_module(pm)
spec2=importlib.util.spec_from_file_location('f','/home/user/Illusion City/recursos/tools/fuente_8px.py')
fp=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(fp)
disp = fp.a_celda12(fp.glifos_david()['$'], 0)
print('glifo a escribir (18 B):', disp.hex(' '))
def corre(escribir, salida):
    md = mdcd.MD('ok.cue')
    md.load_rzip('/home/user/Illusion City/states/TEST_I.state'); md.run(20)
    raw=open('/home/user/Illusion City/TEST_N.bin','rb').read()
    st=pm.m.region(raw, pm.m.LBA_START, pm.m.SZ_START)
    md.poke_prg(pm.CAP1_RAM, pm.captura(pm.CAP1_RAM, pm.VUELTA1, False)[0])
    md.poke_prg(pm.CAP2_RAM, pm.captura(pm.CAP2_RAM, pm.VUELTA2, True)[0])
    md.poke_prg(0x10000+pm.LLAMADA1, bytes.fromhex('4ef9')+pm.CAP1_RAM.to_bytes(4,'big'))
    md.poke_prg(0x10000+pm.LLAMADA2, bytes.fromhex('4ef9')+pm.CAP2_RAM.to_bytes(4,'big'))
    md.poke_prg(0x27AA0, st[0x17AA0:0x17AB0]); md.poke_prg(0x27AD0, st[0x17AD0:0x17AE0])
    for off in (0x10B18,0x10BAE,0x10CE8,0x10DBA): md.poke_prg(0x10000+off, st[off:off+6])
    if escribir:
        md.poke_prg(0x299BA, disp)
        print('   memoria en $299BA tras escribir:', md.prg8(0x299BA,18).hex(' '))
    md.press(IDS['A']); md.run(20); md.release(); md.run(55)
    md.save_png(salida)
    a=np.array(Image.open(salida).convert('RGB'))
    return (a[135:147,205:217,0]>190)
z0=corre(False,'b0.png')
z1=corre(True,'b1.png')
print()
print('ANTES:            ', '               DESPUES ($ = tu glifo):')
for r in range(12):
    print('   ', ''.join('#' if z0[r,c] else '.' for c in range(12)), '   ', ''.join('#' if z1[r,c] else '.' for c in range(12)))
esperado=np.unpackbits(np.frombuffer(disp,dtype=np.uint8))[:144].reshape(12,12)
print()
print('coincidencia con tu glifo: %d/144 px' % (z1==esperado).sum())
