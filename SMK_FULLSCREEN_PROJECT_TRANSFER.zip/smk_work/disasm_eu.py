from pathlib import Path
from capstone import *
r=Path('Super Mario Kart (Europe).sfc').read_bytes();md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX);md.skipdata=True
s,e=0x80c780,0x80c980;off=s&0xffff
for i in md.disasm(r[off:off+(e-s)],s): print(f'{i.address:06X}: {i.bytes.hex():<14} {i.mnemonic:<5} {i.op_str}')
