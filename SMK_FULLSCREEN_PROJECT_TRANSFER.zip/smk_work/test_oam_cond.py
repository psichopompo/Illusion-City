from pathlib import Path
base=bytearray(Path('/home/user/smk_work/Super Mario Kart USA Full Screen.sfc').read_bytes())
# original B9D2: STA $0201,y -> JSR $CE98 (same bank)
assert base[0x5b9dc:0x5b9df]==bytes.fromhex('99 01 02')
base[0x5b9dc:0x5b9df]=bytes.fromhex('20 98 ce')
# conditional Y adjustment routine in bank 85 zero padding
code=bytes.fromhex('c0 70 02 90 0c c0 80 02 b0 08 18 69 40 99 01 02 60')
# CPY #0270, BCC +12, CPY #0280, BCS +8, CLC ADC #40 STA, RTS
assert base[0x5ce98:0x5ce98+len(code)]==bytes(len(code));base[0x5ce98:0x5ce98+len(code)]=code
# keep entries 24-27 visible in fullscreen for start/transition
assert base[0x1bc59:0x1bc60].startswith(bytes.fromhex('a9 55'));base[0x1bc5a]=0
# direct M7 Y hook (same as tested)
base[0x880b8:0x880bb]=bytes.fromhex('4c f3 80')
y=0x2f3+0x40
hook=bytes([0xa9,0x60,0x85,0x7c,0xa9,0x6a,0x85,0xe0,0xa9,y&255,0x8d,0x20,0x21,0xa9,(y>>8)&255,0x8d,0x20,0x21,0x9c,0x06,0x04,0x60])
base[0x880f3:0x880f3+len(hook)]=hook
Path('/home/user/smk_work/candidate_oam_m7.sfc').write_bytes(base)
