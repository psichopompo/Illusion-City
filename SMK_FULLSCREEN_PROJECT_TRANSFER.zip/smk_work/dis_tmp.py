from pathlib import Path
from capstone import *
r=Path('/home/user/smk_work/Super Mario Kart USA Full Screen.sfc').read_bytes()
md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX);md.detail=False
for cpu in [0x808700,0x84ff40,0x859880,0x818a00,0x81fa00,0x80c780,0x80c930]:
 bank=(cpu>>16)&0xff; a=cpu&0xffff
 if a>=0x8000: off=(bank-0x80)*0x10000+a
 else: off=(bank-0x80)*0x10000+a # likely
 print('\n===',hex(cpu),'off',hex(off))
 for i in md.disasm(r[off:off+0x180],cpu): print(f'{i.address:06X}: {i.bytes.hex():<12} {i.mnemonic:<8} {i.op_str}')
