from pathlib import Path
from capstone import *
r=Path('Super Mario Kart (Europe).sfc').read_bytes()
md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX)
md.detail=False

def off(cpu): return ((cpu>>16)&0x3f)*0x10000+(cpu&0xffff)
for start,end in [(0x808000,0x808100),(0x808a80,0x808c20),(0x80c7a0,0x80c970),(0x81fa00,0x81fb20),(0x84ea00,0x84ea80),(0x85dbd0,0x85dfb0)]:
 print('\n===',hex(start),hex(end),'file',hex(off(start)))
 b=r[off(start):off(end)]
 for i in md.disasm(b,start): print(f'{i.address:06X}: {i.bytes.hex():<12} {i.mnemonic:<6} {i.op_str}')
