from pathlib import Path
from capstone import *
files=['Super Mario Kart (USA).sfc','Super Mario Kart (Europe).sfc','Super Mario Kart USA Full Screen.sfc']
# use mode 96
md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX); md.skipdata=True
for fn in files:
 r=Path(fn).read_bytes(); print('\n=======',fn)
 for s,e in [(0x808000,0x8080a0),(0x808a90,0x808c10),(0x80c800,0x80c960),(0x81fa90,0x81fb10),(0x84ea00,0x84ea50)]:
  off=(s>>16&0x3f)*0x10000+(s&0xffff)
  print(f'--{s:06X}-{e:06X}')
  for i in md.disasm(r[off:off+(e-s)],s):
   print(f'{i.address:06X}: {i.bytes.hex():<14} {i.mnemonic:<5} {i.op_str}')
