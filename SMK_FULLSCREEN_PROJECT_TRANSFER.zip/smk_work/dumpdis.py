from capstone import *
from pathlib import Path
md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX);md.detail=False
def off(cpu): return ((cpu>>16)&0x3f)*0x10000+(cpu&0xffff)
for fn in ['Super Mario Kart (USA).sfc','Super Mario Kart USA Full Screen.sfc']:
 r=Path(fn).read_bytes();print('\n###',fn)
 for start,end in [(0x80c7b0,0x80c970),(0x81fa80,0x81fb20),(0x808030,0x8080a0),(0x808a80,0x808c30),(0x888000,0x888220)]:
  print('\n===',hex(start),hex(end),'file',hex(off(start)))
  b=r[off(start):off(end)]
  for i in md.disasm(b,start): print(f'{i.address:06X}: {i.bytes.hex():<14} {i.mnemonic:<6} {i.op_str}')
