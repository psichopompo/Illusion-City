from pathlib import Path
from capstone import *
r=Path('Super Mario Kart (Europe).sfc').read_bytes()
def off(cpu): return ((cpu>>16)&0x3f)*0x10000+(cpu&0xffff)

def ds(start,end,mode):
 md=Cs(CS_ARCH_MOS65XX,mode); md.skipdata=True
 b=r[off(start):off(end)]
 print('\n===',f'{start:06X}-{end:06X}', 'mode',mode)
 for i in md.disasm(b,start): print(f'{i.address:06X}: {i.bytes.hex():<14} {i.mnemonic:<5} {i.op_str}')
for mode in [CS_MODE_MOS65XX_65816_LONG_MX,CS_MODE_MOS65XX_65816_LONG_M,CS_MODE_MOS65XX_65816_LONG_X]:
 ds(0x80c6d0,0x80ca00,mode)
