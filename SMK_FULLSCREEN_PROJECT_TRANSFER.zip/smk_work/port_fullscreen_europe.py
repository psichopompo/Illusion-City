#!/usr/bin/env python3
"""Port the Super Mario Kart Full Screen hack to the European ROM.

The original IPS is for the USA revision (CRC32 CD80DB86).  Europe has
several shorter/different routines, so this script applies the same logical
changes at the corresponding European byte sequences and fixes the absolute
continuations embedded in the new bank-$88 code.
"""
from pathlib import Path
import struct
import zlib

ROOT = Path(__file__).resolve().parent
BASE_PATH = ROOT / "Super Mario Kart (Europe).sfc"
USA_FULL_PATH = ROOT / "Super Mario Kart USA Full Screen.sfc"
OUT_PATH = ROOT / "Super Mario Kart Europe Full Screen (ported).sfc"
IPS_PATH = ROOT / "supermariokart_full_screen_europe.ips"

BASE_SIZE = 0x80000
OUTPUT_SIZE = 0x100000
NEW_REGION_END = 0xAE000


def put(rom: bytearray, offset: int, data: bytes, label: str) -> None:
    """Write a patch and fail loudly if the expected old bytes were not seen."""
    rom[offset:offset + len(data)] = data
    print(f"{label:44s} file ${offset:06X}: {data.hex(' ')}")


def expect(rom: bytes, offset: int, expected: bytes, label: str) -> None:
    got = rom[offset:offset + len(expected)]
    if got != expected:
        raise RuntimeError(
            f"{label}: unexpected bytes at ${offset:06X}: "
            f"got {got.hex(' ')}, expected {expected.hex(' ')}"
        )


def patch_region(rom: bytearray) -> None:
    # Header: 1-Mbit ROM size.  This byte is at the same file offset in both
    # regional revisions.
    expect(rom, 0x00FFD7, bytes.fromhex("09"), "ROM size header")
    put(rom, 0x00FFD7, bytes.fromhex("0A"), "ROM size header")

    # Shared NMI hook.
    expect(rom, 0x00805C, bytes.fromhex("A5 44 F0 FC"), "NMI hook")
    put(rom, 0x00805C, bytes.fromhex("5C 00 80 88"), "NMI hook")

    # European equivalents of the split-screen/HDMA code in bank $80.
    # USA $808AC6 -> Europe $808A9F (operand of LDA #$FE).
    expect(rom, 0x008A9E, bytes.fromhex("A9 FE 8D 0C 42"), "HDMA enable")
    put(rom, 0x008A9F, bytes.fromhex("7E"), "HDMA enable")

    # USA $808B42 -> Europe $808B1B: remove the mid-frame OBSEL writes.
    expect(rom, 0x008B1B, bytes.fromhex("8C 00 21 8E 01 21"), "upper raster registers")
    put(rom, 0x008B1B, bytes.fromhex("EA EA EA EA EA EA"), "upper raster registers")

    # USA $808B4F -> Europe $808B28: do not change M7SEL at the split.
    expect(rom, 0x008B28, bytes.fromhex("8D 1A 21"), "M7SEL split write")
    put(rom, 0x008B28, bytes.fromhex("EA EA EA"), "M7SEL split write")

    # USA $808B67/$808B6F -> Europe $808B40/$808B48.  Keep the existing
    # LDX/JSR that programs the top table, but skip the duplicate/bottom work.
    expect(rom, 0x008B40, bytes.fromhex("20 09 87"), "top-table setup call")
    put(rom, 0x008B40, bytes.fromhex("EA EA EA"), "top-table setup call")
    expect(rom, 0x008B48, bytes.fromhex("20 61 94"), "bottom OAM/table call")
    put(rom, 0x008B48, bytes.fromhex("EA EA EA"), "bottom OAM/table call")

    # USA $808BC2 -> Europe $808BA7: disable colour math/window writes.
    expect(rom, 0x008BA7, bytes.fromhex("8D 31 21"), "colour math write")
    put(rom, 0x008BA7, bytes.fromhex("9C"), "colour math write")

    # USA $808BDA..$808BEA -> Europe $808BBF..$808BCF.
    expect(rom, 0x008BBF, bytes.fromhex(
        "8D 25 21 BD 4E 01 8D 2E 21 BD 7A 01"
    ), "window writes")
    put(rom, 0x008BBF, bytes.fromhex(
        "9C 25 21 BD 4E 01 9C 2E 21 EA A9 30"
    ), "window writes")

    # Projection/height routine.  The European routine is not at the USA
    # offsets, but its instruction sequences are equivalent.
    expect(rom, 0x00C893, bytes.fromhex("65 98"), "object Y offset")
    put(rom, 0x00C894, bytes.fromhex("E0"), "object Y offset")

    # USA $80C87C -> Europe $80C8A1.  The custom routine lives at the same
    # bank-$88 address as in the USA patch; its return target is regional.
    expect(rom, 0x00C8A1, bytes.fromhex("C9 00 03"), "object ratio hook")
    put(rom, 0x00C8A1, bytes.fromhex("5C C3 80 88"), "object ratio hook")

    # USA CMP #$00C0 at $80C88B -> Europe $80C8B0.  Use #$0180.
    expect(rom, 0x00C8B0, bytes.fromhex("C0 00"), "displayable-object bound")
    put(rom, 0x00C8B0, bytes.fromhex("80 01"), "displayable-object bound")

    # USA $80C93A -> Europe $80C95F.
    expect(rom, 0x00C95F, bytes.fromhex("ED 00 60 85"), "height hook")
    put(rom, 0x00C95F, bytes.fromhex("5C D9 80 88"), "height hook")

    # Mode 7 projection routine.  USA $81FAD6/$81FAE8/$81FAF6 map to
    # Europe $81FAA0/$81FAB2/$81FAC0.
    expect(rom, 0x01FAA0, bytes.fromhex("48 65 90 8D"), "Mode 7 params 1/4 hook")
    put(rom, 0x01FAA0, bytes.fromhex("5C 7F 80 88"), "Mode 7 params 1/4 hook")
    expect(rom, 0x01FAB2, bytes.fromhex("65 90 8D 5E"), "Mode 7 params 2/3 hook")
    put(rom, 0x01FAB2, bytes.fromhex("5C 9B 80 88"), "Mode 7 params 2/3 hook")
    expect(rom, 0x01FAC0, bytes.fromhex("E2"), "second Mode 7 routine")
    put(rom, 0x01FAC0, bytes.fromhex("60"), "second Mode 7 routine")

    # Remaining bank-$84/$85 fixes are data/code at identical file offsets in
    # both revisions (verified against the original byte sequences).
    expect(rom, 0x04E94A, bytes.fromhex("A9 FF 8D 23 21"), "brightness/window fix")
    put(rom, 0x04E94B, bytes.fromhex("00"), "brightness/window fix")
    for off, label in [(0x05DC03, "Lakitu lap-count Y"),
                       (0x05DC2B, "Lakitu reverse-message Y"),
                       (0x05DC5F, "Lakitu win-flag Y")]:
        expect(rom, off, bytes.fromhex("F0"), label)
        put(rom, off, bytes.fromhex("FF"), label)
    expect(rom, 0x05DD6C, bytes.fromhex("A0"), "Lakitu lap timer")
    put(rom, 0x05DD6C, bytes.fromhex("90"), "Lakitu lap timer")
    expect(rom, 0x05DF6D, bytes.fromhex("F0"), "Lakitu reverse exit bound")
    put(rom, 0x05DF6D, bytes.fromhex("FF"), "Lakitu reverse exit bound")


def patch_embedded_absolute_targets(rom: bytearray) -> None:
    """Fix the four continuation addresses inside the copied bank-$88 code."""
    # These are 24-bit JML operands in the code copied from the USA build.
    # The main entry remains $808060; the other four continuations differ in
    # the European revision because its routines are shorter.
    replacements = [
        (0x088097, bytes.fromhex("5C E2 FA 81"), bytes.fromhex("5C AC FA 81"),
         "Mode 7 first continuation"),
        (0x0880B4, bytes.fromhex("5C F5 FA 81"), bytes.fromhex("5C BF FA 81"),
         "Mode 7 second continuation"),
        (0x0880D5, bytes.fromhex("5C 83 C8 80"), bytes.fromhex("5C A6 C8 80"),
         "object-ratio continuation"),
        (0x0880EF, bytes.fromhex("5C 41 C9 80"), bytes.fromhex("5C 66 C9 80"),
         "height continuation"),
    ]
    for off, old, new, label in replacements:
        expect(rom, off, old, label)
        put(rom, off, new, label)


def build_rom() -> bytearray:
    base = bytearray(BASE_PATH.read_bytes())
    if len(base) != BASE_SIZE:
        raise RuntimeError(f"European base must be ${BASE_SIZE:X} bytes, got ${len(base):X}")
    if zlib.crc32(base) & 0xFFFFFFFF != 0x56410E5E:
        raise RuntimeError("Unexpected European base CRC32")

    usa_full = USA_FULL_PATH.read_bytes()
    if len(usa_full) < NEW_REGION_END:
        raise RuntimeError("USA full-screen reference is missing the bank-$88/table region")
    if zlib.crc32(usa_full) & 0xFFFFFFFF != 0x6B387ECB:
        raise RuntimeError("Unexpected USA full-screen reference CRC32")

    rom = base + bytearray(OUTPUT_SIZE - len(base))
    # The new bank-$88 code and the four 24-KiB HDMA table blocks are region-
    # independent.  Copy the exact reference region, then adjust its JMLs.
    rom[0x80000:NEW_REGION_END] = usa_full[0x80000:NEW_REGION_END]
    patch_region(rom)
    patch_embedded_absolute_targets(rom)
    return rom


def append_raw(records: bytearray, offset: int, data: bytes) -> None:
    while data:
        chunk = data[:0xFFFF]
        data = data[len(chunk):]
        records += offset.to_bytes(3, "big")
        records += len(chunk).to_bytes(2, "big")
        records += chunk
        offset += len(chunk)


def append_rle(records: bytearray, offset: int, length: int, value: int) -> None:
    while length:
        chunk = min(length, 0xFFFF)
        records += offset.to_bytes(3, "big")
        records += b"\x00\x00"
        records += chunk.to_bytes(2, "big")
        records.append(value)
        offset += chunk
        length -= chunk


def encode_ips(base: bytes, target: bytes) -> bytes:
    """Encode a complete base->target diff, including the 1-Mbit extension."""
    records = bytearray(b"PATCH")
    old_len = len(base)
    pos = 0
    while pos < len(target):
        old = base[pos] if pos < old_len else None
        if old is not None and target[pos] == old:
            pos += 1
            continue
        start = pos
        while pos < len(target):
            old = base[pos] if pos < old_len else None
            if old is not None and target[pos] == old:
                break
            pos += 1
        block = target[start:pos]
        # Prefer RLE for runs of three or more identical bytes.  This keeps
        # the blank extension and the zero-filled gaps compact.
        j = 0
        while j < len(block):
            k = j + 1
            while k < len(block) and block[k] == block[j]:
                k += 1
            if k - j >= 3:
                append_rle(records, start + j, k - j, block[j])
                j = k
            else:
                raw_start = j
                j += 1
                while j < len(block):
                    k = j + 1
                    while k < len(block) and block[k] == block[j]:
                        k += 1
                    if k - j >= 3:
                        break
                    j += 1
                append_raw(records, start + raw_start, block[raw_start:j])
    records += b"EOF"
    return bytes(records)


def main() -> None:
    target = build_rom()
    OUT_PATH.write_bytes(target)
    base = BASE_PATH.read_bytes()
    IPS_PATH.write_bytes(encode_ips(base, target))

    print(f"\nWrote {OUT_PATH} ({len(target):#x} bytes)")
    print(f"CRC32 {zlib.crc32(target) & 0xFFFFFFFF:08X}")
    print(f"Wrote {IPS_PATH} ({IPS_PATH.stat().st_size:#x} bytes)")

    # Re-apply our generated IPS as a sanity check.
    patched = bytearray(base)
    ips = IPS_PATH.read_bytes()
    if ips[:5] != b"PATCH" or ips[-3:] != b"EOF":
        raise RuntimeError("bad generated IPS framing")
    i = 5
    while ips[i:i + 3] != b"EOF":
        off = int.from_bytes(ips[i:i + 3], "big")
        ln = int.from_bytes(ips[i + 3:i + 5], "big")
        i += 5
        if ln:
            data = ips[i:i + ln]
            i += ln
        else:
            rl = int.from_bytes(ips[i:i + 2], "big")
            value = ips[i + 2]
            i += 3
            data = bytes([value]) * rl
        if len(patched) < off + len(data):
            patched.extend(b"\x00" * (off + len(data) - len(patched)))
        patched[off:off + len(data)] = data
    if patched != target:
        raise RuntimeError("generated IPS does not reproduce target ROM")
    print("IPS round-trip: OK")


if __name__ == "__main__":
    main()
