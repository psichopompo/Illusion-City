from pathlib import Path
base=bytearray(Path('/home/user/smk_work/Super Mario Kart USA Full Screen.sfc').read_bytes())
assert base[0x88044:0x88047]==bytes.fromhex('a9 e0 8d')
assert base[0x88052:0x88055]==bytes.fromhex('a9 e0 8d')
for v in [0x00,0x20,0x40,0x60,0x80,0xa0,0xc0,0xe0,0xff]:
 r=base.copy();r[0x88045]=v;r[0x88053]=v
 Path(f'/home/user/smk_work/h_{v:02x}.sfc').write_bytes(r)
