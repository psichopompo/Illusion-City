from pathlib import Path
base=bytearray(Path('/home/user/smk_work/Super Mario Kart USA Full Screen.sfc').read_bytes())
# Set function custom: perspective vars, M7Y + delta, add player y delta, clear high byte for obj 24-27.
# use JMP from $880b8 to $80f3. code must fit before/over our old free code? no, start 0x880f3, length under 0x880??
for d in [0x20,0x30,0x40,0x50,0x60]:
 r=base.copy();r[0x880b8:0x880bb]=bytes.fromhex('4c f3 80')
 y=0x2f3+d
 code=bytearray([0xa9,0x60,0x85,0x7c,0xa9,0x6a,0x85,0xe0,
                  0xa9,y&255,0x8d,0x20,0x21,0xa9,(y>>8)&255,0x8d,0x20,0x21,
                  0x9c,0x06,0x04])
 # add d to player y source bytes
 for a in [0x0271,0x0275,0x0279,0x027d]:
  code += bytes([0xa5,a&255,0x18,0x69,d,0x85,a&255])
 code += bytes.fromhex('60')
 if len(code)>0x50:raise Exception(len(code))
 r[0x880f3:0x880f3+len(code)]=code
 Path(f'/home/user/smk_work/c_{d:02x}.sfc').write_bytes(r)
