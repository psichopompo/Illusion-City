from pathlib import Path
base=bytearray(Path('/home/user/smk_work/Super Mario Kart USA Full Screen.sfc').read_bytes())
assert base[0x880b8:0x880bb]==bytes.fromhex('a9 60 8d')
# Set function jump to code in free area, writes old perspective values + optional OAM high byte
for mode in ['none','oam','oam_m7']:
 r=base.copy();r[0x880b8:0x880bb]=bytes.fromhex('4c f3 80')
 code=bytearray([0xa9,0x60,0x85,0x7c,0xa9,0x6a,0x85,0xe0])
 if mode!='oam': pass
 else: code += bytes.fromhex('9c 06 04')
 if mode=='oam_m7': code += bytes.fromhex('9c 06 04')
 code += bytes.fromhex('60')
 r[0x880f3:0x880f3+len(code)]=code
 Path(f'/home/user/smk_work/oam_{mode}.sfc').write_bytes(r)
