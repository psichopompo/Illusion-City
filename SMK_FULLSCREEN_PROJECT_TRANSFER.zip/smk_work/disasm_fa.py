from pathlib import Path
from capstone import *
md=Cs(CS_ARCH_MOS65XX,CS_MODE_MOS65XX_65816_LONG_MX);md.skipdata=True
for fn in ['Super Mario Kart (USA).sfc','Super Mario Kart (Europe).sfc','Super Mario Kart USA Full Screen.sfc']:
 r=Path(fn).read_bytes();print('\n===',fn)
 s,e=0x81f900,0x81fb40;off=0x10000+(s&0xffff)
 for i in md.disasm(r[off:off+(e-s)],s): print(f'{i.address:06X}: {i.bytes.hex():<14} {i.mnemonic:<5} {i.op_str}')
