# Prompt autocontenido para continuar la investigación de Super Mario Kart Full Screen

Actúa como especialista en ROM hacking de SNES, 65816, PPU/OAM, Mode 7 y bsnes/RetroArch. Continúa una investigación ya iniciada sobre una ROM de Super Mario Kart USA. No te limites a dar teoría: hay que modificar la ROM, generar candidatos comprobables y, cuando la solución sea estable, generar un IPS limpio.

## Objetivo del usuario

Partiendo del parche que elimina el mapa inferior de Super Mario Kart USA:

1. El kart/personaje del jugador no debe quedar en la mitad superior.
2. Debe desplazarse hacia abajo también el centro/eje de rotación y perspectiva de Mode 7, no solamente el sprite.
3. El HUD debe conservar un margen superior parecido al de la ROM sin modificar y no quedar pegado al borde.
4. La transición `ROUND 1` debe verse completa, sin clipping inferior ni cortes horizontales en las letras `R` y `O`.
5. El resultado debe funcionar en RetroArch con el core bsnes y ser reproducible con el save state suministrado.

Habla con el usuario en español y entrega candidatos de forma incremental, explicando qué se ha comprobado en cada uno. No generes decenas de variantes ni capturas innecesarias porque el workspace tiene un límite de 128 MiB.

## Archivos principales del proyecto

Todos los caminos siguientes son relativos a la carpeta `smk_work` del proyecto transferido:

- `Super Mario Kart USA Full Screen.sfc`: ROM USA de trabajo, parche fullscreen original, 1 MiB.
- `Super Mario Kart (USA).sfc`: ROM USA original de 512 KiB para comparar.
- `user_upload/state_payload.bin`: save state reproducible utilizado con el harness.
- `user_upload/Super Mario Kart USA Full Screen.state`: estado original suministrado.
- `user_upload/state_debug.bin`: dump inicial CPU/PPU/OAM/WRAM.
- `user_upload/state_debug_after.bin`: dump posterior a la ejecución más reciente instrumentada.
- `user_upload/m7_trace.txt`: traza de 240 llamadas a la rutina de render Mode 7.
- `user_upload/run_bsnes_state.c`: harness libretro para cargar el estado, ejecutar frames y producir dumps.
- `user_upload/run_bsnes_state`: harness compilado.
- `originalgrego_repo/SuperMarioKart_FullScreen.asm`: fuente ASM del parche fullscreen original.
- `smk_disassembly/bank00.asm`, `bank01.asm`, `bank04.asm`, `bank05.asm`: desensamblado relevante.
- `dis_tmp.py`, `dis_tmp.txt`, `dis_tmp2.py`, `dis_tmp2.txt`: herramientas y salidas de desensamblado usadas durante el análisis.
- `test_m7y_main.py`, `test_oam.py`, `test_combo.py`, `test_e0.py`, `test_oam_cond.py`: scripts de experimentos previos. Algunos generan candidatos temporales; no asumir que un candidato antiguo es final.

El entorno temporal usado para las pruebas tenía un core bsnes instrumentado en `/tmp/libretro_bsnes/bsnes_libretro.so`. Si no existe en el nuevo entorno, hay que reconstruir u obtener un core/harness equivalente antes de interpretar un resultado visual.

## Hallazgos comprobados

### A. Mode 7

En la ROM fullscreen, la función `Set_New_Perspective_Params` reside en el área libre del banco 88. En términos de offsets del archivo ROM:

- `0x880B8` contiene el comienzo de la función que fija `$7C` y `$E0`.
- `0x880F3` es espacio libre utilizado para los hooks de prueba.
- En HiROM esos offsets corresponden aproximadamente a CPU `$8880B8` y `$8880F3`; no confundir offset de archivo con dirección CPU.

El hook probado sustituye los primeros bytes de `0x880B8` por:

```text
4C F3 80
```

Es decir, `JMP $80F3` dentro del banco 88. El código de prueba conserva:

```text
$7C = $60
$E0 = $6A
```

y escribe el nuevo centro Y de Mode 7 mediante `$2120`.

El valor visual inicial que funcionó fue:

```text
M7Y = $02F3 + delta
```

Con `delta = $40`:

```text
M7Y = $0333
```

Resultado comprobado: la pista y la perspectiva se desplazan hacia abajo, mientras el HUD permanece arriba con un margen razonable. Esto demuestra que el eje de Mode 7 se puede corregir por separado y que el valor `$0333` es un candidato visual válido, aunque todavía debe afinarse junto con el desplazamiento del kart.

Los cambios experimentales de `$E0` no sustituyen esta solución: producen cambios en algunos objetos proyectados, pero no desplazan de forma fiable la OAM del kart del jugador.

### B. OAM del kart y de los objetos de transición

En el dump del estado, los objetos relevantes son:

```text
OAM $0260-$026F, objetos 24-27:
  X = 100, 116, 132, 148
  Y = 49
  tiles = 0, 2, 4, 6
  palette = 4
  priority = 3

OAM $0270-$027F, objetos 28-31:
  X = 112, 128, 112, 128
  Y = 71, 71, 87, 87
  tiles = $80, $80, $A0, $A0
  priority = 2
  palette = 1
  size = 1
```

Los objetos 28-31 son los cuatro componentes OAM del kart del jugador en el frame reproducido. El hook Mode 7 intentó modificar directamente `$0271`, `$0275`, `$0279` y `$027D`, pero no tuvo efecto porque se ejecuta antes de que el juego regenere la OAM y esos valores vuelven a escribirse.

La configuración OBJ sí está activa prácticamente durante toda la pantalla:

```text
OBJ activo en y=1..239
baseSize = 0
tiledataAddress = $4000
nameSelect = 0
prioridades = 1/3/4/5
```

Por tanto, la ausencia de determinados objetos no se explica por una capa OBJ desactivada.

### C. Tabla alta de X en `$0406`

En el desensamblado de `bank01.asm`, en `$81BC57`, se encuentra:

```asm
SEP #$20
LDA #$55       ; $81BC59
STA $0406      ; $81BC5B
STA $0626      ; $81BC5E
REP #$20
```

En offsets de archivo de la ROM fullscreen:

```text
0x1BC59: A9 55 8D 06 04 8D 26 06
0x1BC5A: operando inmediato $55
```

El valor `$55` oculta mediante la tabla alta los objetos 24-27 cuando se utiliza el modo de pantalla original. Cambiar el operando de `0x1BC5A` de `$55` a `$00` en este punto concreto hace visibles los objetos con X efectivo `100,116,132,148`. Esto es mejor que ejecutar `STZ $0406` desde el hook Mode 7, porque el `STZ` temprano era sobrescrito después.

La modificación de `$0406` todavía debe validarse específicamente durante la transición `ROUND 1`. No darla por solución final solo porque hace visibles los objetos en el save state de carrera.

### D. Por qué los intentos de mover el kart desde el hook fallaron

Se probó escribir directamente los bytes Y de la OAM del jugador desde el hook Mode 7. El dump posterior seguía mostrando `Y=71/87`. La explicación es temporal: el juego genera los datos OAM después del hook.

Las rutinas genéricas relevantes de `bank05.asm` son:

```asm
CODE_85B999:
    LDA $0000,x
    CMP #$FFFF
    BEQ ...
    STA $0200,y
    INX
    INX
    INY
    INY
    ...

CODE_85B9BB:
    ...
    STA $0200,y       ; copia posiciones X

CODE_85B9D2:
    ...
    STA $0201,y       ; copia bytes Y
```

En offsets de archivo aproximados:

```text
CPU $85B999 -> archivo 0x5B999
CPU $85B9A1, STA $0200,y -> archivo 0x5B9A1, bytes 99 00 02
CPU $85B9D2 -> archivo 0x5B9D2
CPU $85B9DC, STA $0201,y -> archivo 0x5B9DC
```

Existe una zona de ceros utilizada como posible trampolín en:

```text
archivo 0x5CE98, CPU $85CE98
```

El intento anterior de parchear `$85B9D2` no produjo un desplazamiento visible del kart y no debe considerarse validado. No existe todavía una ROM final con ese cambio.

## Próximo paso técnico recomendado

El siguiente experimento debe interceptar la copia de palabras de `$85B999`, pero con mucho cuidado: esta rutina incrementa `Y` de dos en dos y copia tanto palabras de posición como palabras de tile/atributos.

En el bloque del jugador, las palabras de posición son aproximadamente:

```text
$0270, $0274, $0278, $027C   ; X/Y
```

y las palabras de tile/atributos intermedias son:

```text
$0272, $0276, $027A, $027E
```

No hay que sumar `$4000` a todas las direcciones entre `$0270` y `$027F`, porque se corromperían los atributos. La corrección debe aplicarse solamente cuando:

```text
$0270 <= Y < $0280
(Y & 3) == 0
```

Conceptualmente:

```text
si el destino OAM es $0270, $0274, $0278 o $027C:
    sumar $4000 a la palabra empaquetada X/Y
    ; esto suma $40 solamente al byte alto Y
si no:
    copiar la palabra sin modificar
```

Un diseño posible es sustituir el `STA $0200,y` de `$85B999` por un `JSR $CE98` del mismo banco y poner en `$85CE98` una rutina que preserve A, compruebe el rango y el alineamiento de Y, sume `$4000` solo en las palabras de posición y haga el `STA $0200,y`. La rutina debe comprobarse con el estado y con un desensamblado de bytes antes de usarla como candidato.

El desplazamiento inicial debe probarse con el mismo valor que Mode 7:

```text
M7Y = $0333
OAM del kart = +$40 en Y
```

Después de ejecutar 1, 2 y 3 frames, comprobar:

1. Los objetos 28-31 han aumentado su Y en `$40`.
2. Sus tiles, atributos, paleta y prioridad no han cambiado.
3. Los objetos 24-27 conservan X visible cuando se aplica el cambio de `$0406`.
4. El HUD sigue arriba con margen.
5. La pista y el centro de Mode 7 permanecen desplazados.
6. No se han desplazado otros objetos ni se han corrompido tiles.

## Validación de ROUND 1

El save state disponible representa principalmente un frame de carrera y no muestra toda la transición `ROUND 1`. Por eso hay que crear una prueba separada o reproducir la secuencia desde un estado anterior:

- comprobar la pantalla justo antes y durante la transición;
- verificar que `ROUND 1` no queda cortado por abajo;
- revisar especialmente los cortes horizontales de `R` y `O`;
- confirmar que la corrección de `$0406` no oculta o desplaza las letras;
- comprobar que la tabla alta de OAM no se deja permanentemente forzada en pantallas que no sean la carrera.

## Criterio de finalización

No generar el IPS final hasta que exista un único candidato estable que cumpla simultáneamente:

- kart y objetos de jugador en la zona inferior deseada;
- centro/perspectiva de Mode 7 desplazados;
- HUD intacto y con margen superior;
- `ROUND 1` completo y sin cortes;
- funcionamiento reproducible en bsnes/RetroArch.

Cuando esté validado:

1. reconstruir la ROM limpia desde `Super Mario Kart USA Full Screen.sfc`;
2. eliminar cualquier instrumentación y código de prueba no utilizado;
3. generar un único `.sfc` final;
4. generar el `.ips` correspondiente;
5. documentar offsets, bytes y compatibilidad.

Mantén el workspace pequeño: conserva como máximo una ROM candidata, una captura comparativa y los dumps imprescindibles. No crear otra colección grande de variantes.
