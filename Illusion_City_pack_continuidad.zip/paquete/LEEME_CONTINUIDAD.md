# ILLUSION CITY (Mega CD) — Traducción al castellano — PACK DE CONTINUIDAD

**Fecha de este paquete:** 26-28/09/2026 (últimas tandas: 96ª-100ª del diario)
**Solicitado por:** David (Psicopompo)
**Contexto:** la plataforma que ejecuta al agente se corta constantemente y no se
puede completar una tarea larga. Este paquete es AUTOCONTENIDO para continuar el
trabajo en un chat nuevo. Léase entero antes de tocar nada.

---

## 1. QUÉ ES ESTO

Proyecto de traducción al castellano del Illusion City (Gen'ei Toshi) de Mega CD.
Va por menús del sistema. La base de trabajo es una ISO cruda (.bin de 18.444.384 B,
7842 sectores MODE1/2352) que se parchea byte a byte con scripts Python (los parches
recalculan EDC/ECC de cada sector tocado — herramienta `recursos/tools/edcecc.py`,
validada contra la referencia de Neill Corlett).

**El método de trabajo (NORMAS DE DAVID, no negociables):**
- Siempre en castellano, tutear a David. Estilo ingeniero, conciso, sin condescendencia.
- Reconocer los errores propios explícitamente. Distinguir [HECHO] (medido) de [HIPÓTESIS].
- Una sola pregunta por mensaje, al final, con `¿`.
- Capturas individuales, nunca rejillas. Mirar la captura ENTERA antes de enviarla.
- Si David contradice el análisis, comprobarlo antes de descartarlo: casi siempre lleva razón.
- Cuando David menciona un problema antiguo, copiar el MÉTODO, no tocar aquel caso.
- NUNCA partir una palabra. No pedir a David que cambie su texto por falta de espacio
  sin agotar TODAS las vías técnicas.
- La maquetación la decide David. Sólo ROMs numeradas por versión; borrar las descartadas.
- Una ROM, una prueba. No generar ROM hasta ver capturas de cómo quedan los cambios.
- Presupuesto de workspace: 128 MB / 10.000 ficheros. Limpiar periódicamente.

---

## 2. FICHEROS DEL PAQUETE

```
TEST_BK.bin          <- LA ROM OFICIAL ACTUAL (MD5 4dbec10019c2ceec9aee6d7adac1f476)
DIARIO.md            <- diario de ~100 tandas con TODO el conocimiento del proyecto
recursos/            <- herramientas (recursos/tools/*.py) y documentos
pruebas/             <- arnés de emulación (mdcd.py) y navegación (arranque.py, etc.)
```

**Falta en el paquete** (por peso): la base japonesa original
`Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin` (18 MB, MD5
`ab72a6c1b949f8cb3a1c8b1c81f0559e`) y `TEST_BH.bin` (la base de BK). Los tiene David.
Varios scripts (`parche_lote3.py`, `parche_bk.py`, etc.) la referencian como
`PROY/"Gen'ei Toshi - Illusion City (Japan) (Track 01) [CAST].bin"`.
BIOS del Mega CD: las tiene David (bios_CD_E/J/U.bin).

---

## 3. ESTADO: QUÉ HAY EN TEST_BK (verificado y aprobado por David)

TEST_BK = TEST_BH + dos cambios (tanda 97ª, ambos VERIFICADOS en capturas):
1. Menú Objetos (interior): "OBJETOS" en mayúsculas (in-place, file 0x17DB4 de START).
2. Columnas de Cambiar/Tirar movidas 1 espacio a la izquierda (setup 0x12358:
   18→17 y 0x1235E: 33→32).
3. (De la 97ª también): fuente baja 1 px en q y p g j , ; ¡ ¿ — OJO: en la última
   iteración se añadió la 'y' (0x8299) a la lista. El script es
   `recursos/tools/parche_fuente_baja1px.py` (baja la rejilla 12x12 una fila;
   9 glifos, ~20 copias entre INIT y OPEN).

TEST_BH (la base de BK) contiene, entre otros: nombres de personajes completos en
tablas/ventanas/Estado, ficha de Estado maquetada, menú Combate en castellano,
Sistema (Velocidad/Ajustes) traducido con bloque reubicado, menú Objetos con título
amarillo y Usar/Cambiar/Tirar, plantilla de Técnicas traducida y MUDADA a 0x15410
(+410 B, 38 refs reapuntadas — script `parche_tecnicas_bc.py`), con título
∆TÉCNICAS∆ (palabra en la marca &4 de esa paleta) y rótulos ARMA RIFLE OBÚS CAÑÓN /
GARRA VARA ESP. HILO y un % detrás de cada cifra.

**Parches SIN incluir en BK pero pedidos por David** (ver §5: quedaron a medias en
las ROM BJ/BJ2/BL abortadas, y David decidió volver a BH/BK y reaplicarlos como
cambios pequeños y verificados uno a uno).

---

## 4. CONOCIMIENTO TÉCNICO CRÍTICO (aprendido a pulso — NO repetir estos errores)

### 4.1 Arquitectura de la ISO
- Ficheros clave en el disco: START (LBA 59, 98184 B, se carga en RAM $20000),
  SSTART (LBA 43, 32644 B, RAM $10000), INIT (LBA 107, 149400 B, RAM $28000 y $10000),
  OPEN (LBA 285, 69258 B, RAM $10000), CHR (LBA 180), SD (LBA 251).
- Direcciones del código: son RAM (offset de fichero + 0x10000 para START).
  Mapa bin<->region: `(LBA + off//2048)*2352 + 16 + off%2048`.
- Todo cambio de bytes exige recalcular EDC/ECC del sector (`m.edcecc.repara_bytes`).
- Verificación de sectores de referencia: `recursos/terceros/ecc_ref/` (compilar
  ref_check con ecm.cpp).

### 4.2 El motor de ventanas
- Las ventanas se definen con un "descriptor": `$4`=fila, `$6`=col, `$8`=ancho,
  `$a`=alto, `$2e` (significa distinto según ventana), `$1e`=buffer de dibujo (Word RAM
  $A6000-$AA000, empaquetados: pueden solapar), `$22`=puntero a la plantilla de texto.
- Las plantillas son cadenas con códigos: marcas de color `26 xx` (&0=verde, &1=rojo,
  &2/lila o rojo según paleta, &3=amarillo en menú, &4=&5 azules, &6=&7=blanco —
  **CADA VENTANA TIENE SU PALETA**: calibrar SIEMPRE con un test en pantalla antes de
  dar por bueno un color), espacio `81 40`, `%` `81 93`, salto de línea `2f 6e`,
  icono de sección `96 5f` (el "∆" de David: su fuente fila 7 col 5, celda 1349),
  cifras `82 4F`(0)..`82 58`(9), letras fullwidth A-Z=82 60.., a-z=82 81..,
  acentos por HIJACK (á=0x9660, é=0x966B, í=0x967B, ó=0x9682, ú=0x96AF, ñ=0x96B3,
  ¿=0x96C5, ¡=0x96DA, Á=0x95FB...).
- El término "∆" es SOLO la etiqueta conversacional del icono de David (fila 7 col 5
  del PNG de su fuente). No es el glifo Unicode ∆.
- Fuente: celdas 12x12 = 18 B, MSB-first, fila a fila. Están en INIT (0x14E0 y 0x4ED0)
  y OPEN (0x6D20 y 0xA710) y SD. Tablas A (menús) y B (dinero/cifras) con numeraciones
  distintas — NO son intercambiables. Herramienta: `celdas_fuente.py` + `glifo_offset.py`
  (dan la celda de un código), `fuente_8px.py` (glifos de David desde el PNG).

### 4.3 La ventana de TÉCNICAS (la tarea en curso — §6)
- Plantilla en START file 0x15410, 410 B en BK (mudada desde 0x140DE en la 94ª;
  script `parche_tecnicas_bc.py` con el método de reapuntado probado).
- La copia VIVA se rellena al abrir la ventana en PRG-RAM $25410 y el pintor la lee
  de ahí. **Parchear el disco es la única vía** (en caliente el juego re-rellena la
  plantilla al reabrir).
- Estructura (offsets en BK): título off 0-29, rótulo fila 1 (ARMA RIFLE OBÚS CAÑÓN)
  off 30-75, filas de valores en off 76, 124, 172 (grupo 1) y 266, 314, 362 (grupo 2);
  cada fila de valores = `[2634][5 espacios][2637][32 B de 4 campos "000%"][2f6e o 0000]`
  = 48 B. Rótulo fila 2 (GARRA VARA ESP. HILO) off 220-265.
- Referencias a la plantilla: 38 (el setup `move.l #$25410,$22(a0)` en 0x12FF0-ish,
  6 lea en 0x12FFA-0x1302E, blanker de nombres cada 5 frames vía lea a off 78/268 en
  0x13150-0x131C4 como tabla dc.l usada por el bloque 0x130A6-0x1314E con punteros
  en a3, y el escritor de nombres $23C94 con d0=celdas).
- El PINTOR de cadenas es $20852 (file 0x10852 — ¡no confundir con 0x0852!) y copia
  HASTA EL 0. Los nombres de personajes salen de la BD en INIT 0x2291A ("Tian Ren")
  / 0x2292B ("Mei Hong") vía punteros relativos a $49246 resueltos por $195A8 ($BD00).
  El campo del nombre en la plantilla tiene 5 espacios => el juego recorta a
  "Tian R"/"Mei Ho". **Ampliar el campo a 8 espacios es la solución** (ya probada
  en caliente con poke y funcionó: los valores se desplazan con el nombre).
- Los nombres salen AMARILLOS (&3 de la fila) y los valores de Tian/Mei también
  (deberían ser blancos como los ceros). El color de los valores lo pone la marca
  `2634` inicial de cada fila (amarillo en esta paleta) y el `2637` tras los espacios
  pone blanco para los ceros. Habría que cambiar la marca inicial de cada fila para
  blancos... PERO los nombres comparten esa marca: o se parte la fila en dos marcas
  (&blanco nombre + &blanco valores = todo blanco; David quiere nombres amarillos y
  valores blancos: hace falta una marca extra entre el nombre y el &7... el &7 ya es
  blanco y está tras los espacios: el amarillo de los valores viene de 2634 => quitar
  2634 o moverlo a después del nombre). PENDIENTE de decidir/probar.
- **La alineación pedida por David**: nombres completos (8 glifos) => el campo del
  nombre pasa de 5 a 8 espacios y TODOS los valores de la fila se desplazan +3 celdas
  (+6 B). Todas las filas alineadas por los %. La fila pasa de 48 a 54 B => plantilla
  crece 36 B (hay 0xFF detrás: hasta ~0x155AA libre).
- **Experimento EN VIVO verificado** (poke en PRG-RAM $25410 sobre el state de David):
  reconstruir la plantilla con campo de 8 espacios y valores corridos funciona y se
  pinta bien. Faltó: hacerlo en el DISCO con las refs reapuntadas y verificar en el
  flujo completo.

### 4.4 Última iteración (TEST_BL, ABORTADA)
- `recursos/tools/parche_tk_nombres.py` (última versión del log): reconstruye la
  plantilla con filas de 54 B y reapunta refs con mapa completo (38 refs).
  Generó TEST_BL.bin (MD5 52651d639fe2c335f98a8fabee4906f7) PERO **no llegó a
  verificarse en pantalla** (la plataforma cortaba cada dos por tres; la última
  captura hecha con BL cayó en el panel de Magia por fallo de navegación, no de la
  ROM). TEST_BL NO está en este paquete: si se quiere, regenerar con el script
  (tarda segundos) desde TEST_BK.
- RUTA FIABLE DE NAVEGACIÓN A TÉCNICAS (probada una a una con capturas, desde menú
  fresco tras cargar partida): abrir menú (A) → el cursor ARRANCA donde se dejó la
  última vez (¡el menú recuerda la posición!); en proceso recién cargado = Magia.
  → 3 DOWN (Estado) → C (abre DIÁLOGO del maestro) → C (cierra diálogo) → C (ventana
  de nombres) → C (ficha de Estado) → C (submenu flotante Perfiles/Técnicas/Combate)
  → DOWN → C (TÉCNICAS).
  NOTA: el submenu flotante de Estado: cursor arranca en Técnicas (UP=Perfiles,
  DOWN=Combate) según pruebas BM; verificar con ojos en cada paso.
- Estado actual de la navegación del arnés: `pruebas/arranque.py` (flujo limpio con
  verificación por píxeles, etapas menu/sistema/velocidad/salir). Añadir etapa
  'tecnicas' con la ruta de arriba.

### 4.5 Errores que NO hay que repetir (lista negra)
1. Insertar bytes en un módulo SIN reapuntar TODO lo que apunta detrás (el juego
   rebootea a medias: BIOS esperando 'GENE' en $a12020 — pantallazo de título).
2. Reapuntar refs escaneando sin alinear (k%2) ni verificar opcode: rompe el arranque
   (los 2 BSR del SSTART de la BJ v1).
3. Reapuntar en el mismo bucle que decide (la tabla dc.l se rompe con la 2ª entrada).
4. Offsets calculados ANTES de una inserción (buscar SIEMPRE las marcas DESPUÉS).
5. Asumir colores: cada ventana pinta las marcas con su paleta. Calibrar en pantalla.
6. Fiarse de comparaciones con orig.cue sin verificar que carga la ROM correcta.
7. Dejar TEST_I.bin vivo (lo recreaba build_test_ba.py; ya arreglado, se mueve a /tmp).
8. Navegar a ciegas: el menú recuerda el cursor; capturar y MIRAR cada paso.
9. Detectores de color con umbrales fijos: fallan con el dithering. OJOS primero.
10. En las rutas de menú, C sobre Estado abre DIÁLOGO del maestro primero (2 C más).

---

## 5. TAREAS PENDIENTES (lo que David pidió y quedó abierto)

### 5.1 TÉCNICAS (en curso, lo más urgente)
a) Nombres completos "Tian Ren"/"Mei Hong" (ampliar campo a 8 espacios; +6 B por
   fila; valores desplazados; refs reapuntadas). Script último: parche_tk_nombres.py
   (revisar el mapa de offsets contra el volcado de la plantilla antes de confiar).
b) Filas alineadas por los % (consecuencia de a).
c) Valores de Tian/Mei en BLANCO (como los ceros) sin tocar el amarillo de los
   nombres. La marca 2634 de cada fila es amarilla y cubre también el nombre:
   probablemente reordenar las marcas dentro de la fila (2634 tras el nombre, o
   color distinto para el bloque de valores). CALIBRAR EN PANTALLA.
d) Después: alinear las dos filas de rótulos (ARMA.../GARRA...) como indique David
   (dijo que nos diría cómo una vez hecho lo anterior).

### 5.2 Resto de pendientes que David ya pidió (de la tanda 96ª, ABORTADA):
- Títulos de sección "∆PALABRA∆": palabra en AZUL OSCURO (&5 en paleta del menú) y
  en mayúsculas: MAGIA, OBJETOS, EQUIPO, TÉCNICAS, COMBATE, VELOCIDAD. Iconos en
  blanco. **CALIBRAR POR VENTANA** (en la ventana Velocidad no existe el azul oscuro:
  &5=azul claro, &6=azul medio — David elegirá).
  Aviso: en BJ2 la cirugía de Magia falló (borré el rombo de cierre); la última
  versión correcta estaba en parche_tanda96_v2/v3/v4 (Magia: insertar &5 delante y
  quitar el espacio de off 18 de la plantilla de Magia — ¡la plantilla de Magia en
  BH/BK ya es la maqueta de la 80ª! y el nombre tiene dirección fija: compensar
  exactamente, ver v4).
- "Cambiar" de Objetos un espacio más a la izquierda (igual distancia de Usar y de
  Tirar): columna 17 -> 16 (setup 0x1235B).
- Equipo: "∆Tian Ren∆" (ahora "ian Ren" — el título de EQUIPO se arregló en BJ2 pero
  la ventana de nombres de ese menú recorta; menú "hecho un caos": tarea propia).
- TÉCNICAS: ∆TÉCNICAS∆ en azul oscuro (calibrar: &5 sale azul claro en su paleta).
- Velocidad (pantalla interior, la del selector Rápido/Lento): "∆VELOCIDAD∆" azul
  oscuro... su paleta no lo tiene: elegir &5 o &6 con David (capturas en
  capturas_tanda/BJ2_vel5.png y BJ2_vel6.png).
- Dinero: "Dinero: " en amarillo (&3 en la paleta del menú), resto en blanco. En BJ2
  se cambió el color de TODO el recuadro (mal): la cadena del menú es $279C0 con ref
  en 0x10B06; tocar sólo la marca inicial de la cadena.
- Submenú flotante Velocidad/Ajustes: dejar "Velocidad" a secas (ya está en BH/BK).
- Valores SÍ/NO de Ajustes (el ＯＦＦ->ＮＯ de la 89ª, script parche_si_no.py, ya en
  la cadena de build_test_ba.py) — verificar en pantalla.

### 5.3 Después
- Menú EQUIPO completo (David: "hecho un caos desde el principio").
- Costes desalineados de Magia/Técnicas (pendiente antiguo).
- Verificar Sí/NO en pantalla.

---

## 6. CÓMO TRABAJAR (recetas del arnés)

### 6.1 Abrir el juego en el emulador (arnés local)
- Core: `/home/user/emu/bin/genesis_plus_gx_libretro.so` (MD5 e99bec9dadecfa7d6f99140733
  2f2796; incluye tag de CPU en eventos y arena_get_s68k_pc; receta en `emu/RECETA.md`
  — NO está en el paquete, pedir a David si hay que reconstruir).
- BIOS en `Illusion City/bios/` (pedir a David).
- Arnés: `pruebas/mdcd.py` (load_rzip, poke_prg, prg8, word_ram_2m, memoria/flow trace,
  arena_get_s68k_pc...). Mapeo de botones en `pruebas/md_btn.py` (A=Y de RetroPad id 1,
  C=A de RetroPad id 8).
- El core a veces no arranca (pantalla negra congelada): detectar con capturas y
  reintentar en proceso nuevo (el .so es único por proceso).
- Cue de trabajo: crear `TEST_BK.cue` apuntando a `../TEST_BK.bin`.

### 6.2 Flujo limpio de carga (evita estados contaminados)
`pruebas/arranque.py` (state de la sala de guardado -> guarda -> reset -> carga del CD
-> menú; etapas verificadas por píxeles). Para Técnicas, añadir la ruta de §4.4.

### 6.3 States de David
Los states de David (RetroArch/Genesis Plus 1.3.5, rzip) **cargan directamente en el
arnés**: `md.load_rzip('...state')`. Son oro para inspección (la última entrega:
github.com/psichopompo/Illusion-City/raw/refs/heads/main/TEST_BK.state, dentro de la
pantalla de Técnicas). Pedírselos siempre que la navegación sea difícil.

### 6.4 Experimentación en caliente (rápida y segura)
Con el state cargado, `md.poke_prg(addr, bytes)` escribe en la PRG-RAM viva (ojo:
intercambio de bytes por palabra — usar md.poke_prg, ya lo hace). La ventana
re-renderiza su plantilla al ABRIRSE (cerrar B y reabrir). Para la plantilla de
Técnicas: $25410 (410 B en BK). Esto permite PROBAR layouts sin tocar el disco.
(NOTA: en la última sesión los pokes sobre la plantilla con la ventana ya abierta
NO se veían: el render es al abrir; cerrar y reabrir la ventana, o parchear disco.)

### 6.5 Verificación
- Captura SIEMPRE (md.save_png) y MÍRALA con read_file antes de dar nada por bueno.
- Muestreo de píxeles para colores (numpy sobre el PNG), pero con ojos después.
- md5sum de la ROM entregada. Una ROM, una prueba.

---

## 7. HISTORIAL RESUMIDO DE ROMs
- TEST_BH: base buena (todos los menús principales castellanos, sin los colores nuevos).
- TEST_BK = BH + OBJETOS mayúsculas + columnas + fuente 1px (la OFICIAL, incluida).
- TEST_BJ (v1-v2) y TEST_BJ2: los intentos de la tanda de los colores; ROM rotas o no
  verificadas; DESCARTADAS por David ("no arreglan nada, sólo estropean"). No usar.
- TEST_BL: el último intento de Técnicas-nombres (script parche_tk_nombres.py, 38 refs
  reapuntadas, MD5 52651d639fe2c335f98a8fabee4906f7) — NO VERIFICADA en pantalla
  (la plataforma cortaba antes de poder probarla). Regenerable en segundos desde BK.
  Puede que sea correcta: verificarla es el primer paso (captura de la pantalla
  Técnicas con la ruta de §4.4; si los nombres salen completos y las filas alineadas,
  está hecho).

## 8. LO PRIMERO QUE HAY QUE HACER EN EL CHAT NUEVO
1. Leer este fichero y el DIARIO.md (al menos las últimas 10 tandas).
2. Reconstruir el entorno (BIOS + base japonesa + TEST_BH/TEST_BK desde el repo de
   David: github.com/psichopompo/Illusion-City) y comprobar que el arnés abre TEST_BK.
3. Verificar TEST_BL (regenerarla desde BK con parche_tk_nombres.py) con la ruta de
   navegación a Técnicas. Si sale bien: entregar a David con capturas.
   Si no: el experimento en vivo (§6.4) ya demostró que el layout es correcto —
   depurar el reapuntado con el volcado de la plantilla (§6 de la 94ª).
4. Después: blanco de valores en Técnicas, y luego §5.2 con calibración por ventana.
