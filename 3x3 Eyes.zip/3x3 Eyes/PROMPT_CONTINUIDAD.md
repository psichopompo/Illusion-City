# 3x3 Eyes (Seima Densetsu 3x3 Eyes) — Mega CD
# Prompt de continuidad

## ESTADO: SUBSISTEMA DE FUENTES CERRADO Y VALIDADO EN JUEGO (v6, captura David 07/10: "¡Ñu!" perfecto).

### ESQUEMA DEFINITIVO DE CODIFICACION CASTELLANA (todo probado en Genesis Plus GX por David)
- MINUSCULAS y SIGNOS (a-z, á é í ó ú ü ñ, ¡ ¿ !) -> ESTRECHOS 8px via pares F8nn
  (n 0x2A-0x4D, records escritos en glifos DA-FD). PROBADO v4/v6: render perfecto.
- MAYUSCULAS A-Z -> ANCHAS 16px via codes 1-byte < 0xB0 (victimas kanji: 0x8D=Ñ etc.).
  PROBADO v2/v6: render perfecto.
- ACCENTUADAS mayusculas (Á É Í Ó Ú Ü) + N + I -> codes kanji huerfanos F1xx
  (2 bytes: N=雨F102, I=円F103, Á=貝F109, É=竹F139, Í=林F14E, Ó=弓F16A, Ú=午F179, Ü=胃F1BE,
  todos 0 usos en el guion). Mecanismo identico al texto japones. (El F1xx del propio
  juego se renderiza por doquier; los 8 glifos custom van sobre huerfanos.)
- PROHIBIDO: codes 1-byte 0xB0-0xE4 en texto castellano (la tabla runtime los manda a
  sitios que no controlamos; v2/v5 lo demostraron con el "¡"=・ y el triangulo de la Ñ).
- CERO bytes de codigo 68000 parcheados. Japon 100% intacto (kana, kanji vivos, puntuacion).
- Herramientas: recursos/tools/glifos_narrow_es.py (N_DE estrechos, ANCHO_DE anchos,
  frase(texto)->bytes), glifos_es.py (bitmaps anchos), poc_castellano_v6.py (parche POC),
  estado_track.py (diagnostico del track: que version hay aplicada).
- NOTA de enganche: los poc dejan .bak del ORIGINAL; cada version parte del .bak si existe.

### HITOS VALIDADOS EN JUEGO REAL (cronologia de una tarde)
1. v2: "¡ÑU SEIS!" ancho -> radar EV00006 = ciudad Hong Kong.
2. v4: minuscula compacta renderiza (u), via F8 confirmada.
3. v6: "¡Ñu!" completo (Ñ ancha + ¡ u ! compactas) -> ESQUEMA CERRADO.

### PENDIENTE menor: los 8 glifos F1xx custom (A E I O U dieresis N I) aun sin verse
en pantalla (la frase de prueba solo llevaba Ñ). Se veran al traducir de verdad; si
alguno fallara, el fallback es redibujarlos sobre otros huerfanos.

### DOBLE FALLO DE LA v5 diagnosticado con la captura de David (07/10, ¡u! bien, Ñ=triangulo)
1. Los codes 1-byte C0-DF NO van a glifos anchos en runtime: la tabla de RAM los manda a
   RECORDS estrechos (la copia del fichero de la tabla en 0x294C NO refleja el runtime).
   Demostracion: Ñ con code D7 mostro el triangulo original aunque el glifo ancho 0xD7
   estuviera reescrito. (Explica tambien que el "¡" de la v2 fuese en realidad ・ estrecho.)
2. El diccionario ANCHO_DE pisaba la Ñ: MAPA daba D7 sobre el 8D validado de la v2.
   La Ñ dej de existir como 0x8D -> mostro el glifo original de D7.

### v6 (poc_castellano_v6.py) - VERDE en sintetico
- A-Z + Ñ: codes 1-byte < 0xB0 validados en v2 (Ñ=0x8D restaurada).
- N(I) y acentuadas A E I O U + Udieresis: codes kanji huerfanos F1xx (2 bytes):
  N=雨F102, I=円F103, Á=貝F109, É=竹F139, Í=林F14E, Ó=弓F16A, Ú=午F179, Ü=胃F1BE.
  (mecanismo F1xx = el del propio texto japones, certeza total; primera prueba en juego)
- glifos_narrow_es.py: ANCHO_DE + CODES_2B + frase() emite pares F1xx. 33 anchas + 36 records.
- CUIDADO verificacion: records n == glifos anchos 0xB0+n (misma RAM); los glifos DA-DF
  SI se sobrescriben legitimanente con los records a-f. Intactos a probar: C0-D9 y E0+.


### RESULTADO DE LA v4 EN JUEGO REAL (captura David 07/10)
- "¡u!" compactos PERFECTOS. La Ñ mostro el triangulo original (glifo 0xD7 sin redibujar):
  la v4 OLVIDO incluir los glifos anchos de mayusculas (solo llevaba records + I). Omision mia.
- La via quedo reconfirmada: records n<0x100 renderizan, codigo 68000 intacto.

### v5 (poc_castellano_v5.py) - VERDE en sintetico
- = v4 + 34 glifos anchos del grid grande: A-Z (victimas kanji de la v2 + N en 雨 F102
  + I en 円 F103, ambos huerfanos con codes de 2 bytes) + Á É Í Ó Ú Ü Ñ (half-left, via tabla).
- glifos_narrow_es.py: frase() emite N/I como pares F1xx (CODES_2B). N_DE = 36 estrechos.
- Test sintetico: codigo intacto + 36 records + 34 anchas + 8 ventanas OK + restauracion.

### RESULTADO DE LA v3 EN JUEGO REAL (capturas David 07/10)
- El caracter F8 4B (¡, n<0x100) SI se imprimio compacto. Los F9nn (n>=0x100: Ñ U !)
  salieron EN BLANCO (avanzan celda pero no pintan). Causa: los records n>=0x100 viven
  en RAM ($A3600 + n*32 >= $A67A0) que el cargador de fuente NO rellena (la banda
  cargada acaba en $A55FF = n<=0xFF = glifos 0xB0-0x1AF). El parche de mascara
  direccionaba bien pero a memoria vacia. CARGADOR DE FUENTE: aun sin localizar.
- Dato positivo: confirmado que la banda estrecha n 0x00-0x100 SI llega a la RAM y renderiza.

### v4 (poc_castellano_v4.py) - VERDE en sintetico
- CERO bytes de codigo parcheados (ni mascara). Todo en la banda n<0x100.
- 36 glifos ESTRECHOS en n 0x2A-0x4D (glifos DA-FD, muertos): a-z + á é í ó ú ü ñ + ¡ ¿ !
  -> codes F8nn. (glifos_narrow_es.py regenerado: N_DE 36 entradas, frase() mezcla)
- MAYUSCULAS ANCHAS (16px): codes de la v2 (victimas kanji, validadas en juego) via
  glifos_es.ANCHO/ANCHO2/MAPA + I ancha nueva en glifo 0x103 (kanji huerfano 円 F103).
- El castellano es ~85% minusculas -> el ahorro de espacio se mantiene con caps anchas.
- Test sintetico: codigo intacto + 36 records + I ancha + 8 ventanas "¡Ñu!"+espacio (9B) OK.
- NOTA de aritmetica clave: narrow record n ALIAS al glifo grande 0xB0+n (MISMA RAM/file):
  $A3600+n*32 = $A2000+(0xB0+n)*32. Sacrificar records BE/BF/C3 = romper 、。¨ japoneses.

### REINGENIERIA DEL MOTOR DE TEXTO (07/10) - sustituye la understanding de la v2
- Traductor code->glifo (file 0x28EA, mem $9AEA): <0xB0 ancho directo; 0xB0-0xE4 estrecho
  via TABLA EN RAM $9B4C (file 0x294C, 53 entradas BE16; digitos->0x0800+n); 0xE5xx escape
  -> 0xB0+xx; F1xx-F6xx kanji -> indice = code AND $FFF (F100=一->glifo 0x100, confirmado).
- INDICE DE GLIFO >= 0x800 = ESTRECHO (8px real). El estampador (file 0x3200, mem $A400):
  <0x800 lee glifo 16x16 (32B) del grid grande (RAM $A2000 = file 0x29000);
  >=0x800 lee RECORD de 32B en RAM $A3600 = file 0x2A600 + n*32 con n = indice & 0x7FF
  (mascara andi.w #$FF en file 0x32F2 -> SOLO n<=0xFF sin parche). Record = [fila,0x00]x16.
- ANCHO AVANZADO: bucle 0x38BC (y 0x33DC/0x3438/0x2BDA/0x2C22 en otros renderers): todo
  glifo +1 celda; si indice < 0x800 +1 mas. Un solo umbral en todo el motor, un solo stamp.
- VIA NUEVA SIN TOCAR TABLAS: pares F8nn/F9nn (primeros bytes jamas usados por el juego).
  F8nn->0x800+nn (estrecho, nn 0x00-0xFF), F9nn->0x900+nn (0x900..0x9FF = glifos 0xB0+nn
  de la banda ampliada). Parche de UN byte de codigo: file 0x32F4: 00->07 (#$FF->#$7FF)
  para que n alcance 0x7FF. Verificado: es la UNICA mascara limitante en los caminos de texto.
- HUECOS: records n 0x2A-0x4F (glifos DA-FF: controles DA-DF + romanos E0-F9 inalcanzables
  + FF/FE/FD) y kanji huerfanos (423 n libres en total; usados 69). Japon 100% intacto.

### poc_castellano_v3.py (pruebas/) - VERDE en sintetico
- 69 glifos compactos (modulo fuente de la verdad: recursos/tools/glifos_narrow_es.py):
  A-Z a-z á é í ó ú ü ñ Á É Í Ó Ú Ü Ñ ¡ ¿ ! + nativos (0-9 E () espacio via F8 00-0D).
  Hoja: recursos/docs/fuente_compacta_hoja.png | dialogo mixto: fuente_compacta_dialogo.png
- Asignacion n->letra en glifos_narrow_es.N_DE (a=0x2A.. z=0x43, minusculas acentuadas
  0x44-0x4A, ¡¿ 0x4B-0x4C, mayusculas dispersas por kanji huerfanos 0x4D-0x1AC).
- Parchea: 1 byte de mascara + 69 records + 8 ventanas de EV00006 con "¡ÑU!" (cortas
  a proposito: ventanas de 9 bytes) + espacio ancho de relleno.
- El texto castellano se codifica con glifos_narrow_es.frase(texto) -> bytes F8nn/F9nn.


### RESULTADO DEL RADAR (capturas de David, 07/10)
- 5 NPCs de Hong Kong mostraron "¡ÑU SEIS!" -> TODOS de EV00006 -> el mapa overworld de la
  ciudad inicial carga EV00006. Lineas identificadas: 0x148AE (viejo "妖撃社はどこか?"),
  0x14C96 (bromista "妖撃社は出版社よ"), 0x14E64 (explica 妖撃社), 0x14F28 (bienvenida a HK),
  0x14B9E/0x14BD8 (paseante). Renderizado PERFECTO: ¡ ancha, Ñ con tilde, peso y espaciado OK.
- [HECHO] Cadena completa validada end-to-end: fuente parcheada -> encoding -> insercion
  in-place -> el juego lee el EV parcheado del CD -> render correcto en Genesis Plus GX.
- EV00001 = otra escena (sin identificar). La v1 no salio porque no es la ciudad inicial.

### Resultado de la v1 en el juego real (06/10)
- El parche se APLICÓ bien (bytes verificados), pero David habló con todos los NPCs de la
  zona inicial y TODO seguía en japones. Diagnóstico: las 2 frases de la v1 eran líneas
  condicionales (la de pointer[0] exige var 0x2F0, estado tardío) y probablemente EV00001
  ni siquiera es el mapa inicial. Error de selección de objetivos, no de inserción.
- Lección: para validar inserción hay que cubrir MUCHAS líneas de MUCHOS EVs a la vez.

### POC v2 (pruebas/poc_castellano_v2.py) — RADAR
- Fuente: 45 glifos = A-Z ANCHOS (16px) + castellano estrecho (Ñ ñ Á É Í Ó Ú Ü á é í ó ú ü
  ¡ ! ¿ N I). Asignaciones NUEVAS desde la v1: 0xC8=I (▼ 21x), 0xC2=N (・ 423x),
  anchas nuevas: A5=H ヶ(4) 5F=B セ(55) 8A=F ゾ(59) 3A=G ぢ(64) 6A=J ノ(65) 6E=K ヘ(67)
  68=L ヌ(69) 44=M ぴ(74) A1=P ュ(75) 9E=Q ォ(80) 69=V ネ 85=W ゴ 99=X ポ 76=Y ユ 88=Z ズ.
- 51 frases en 8 EVs (EV00001..A, sin 3 y 4 que no tienen ventanas limpias), una FRASE
  DISTINTA por EV: EV00001 "¡ÑU SECUESTRADO!", 02 "¡ÑU DOS!", 05 "¡ÑU CINCO!", 06 "¡ÑU SEIS!",
  07 "¡ÑU SIETE!", 08 "¡ÑU OCHO!", 09 "¡ÑU NUEVE!", 0A "¡ÑU DIEZ!". Ventanas seguras:
  solo bytes de texto/combiners (nada de 00/DA-DC/E0-EF), sin partir pares dakuten,
  primeros 8 punteros con texto de cada EV, longitud intacta (solo se cambia el comienzo).
- Si hay .bak, SIEMPRE parte del original (pisa la v1). --restaurar deja el track como estaba.
- Test sintético VERDE: 51/51 ventanas + 45/45 glifos + restauración idéntica.
  (Los "fallos" intermedios eran bugs de mis scripts de verificación: bytes vs hex-strings.)
- BUG corregido en v2 gracias al test: lba_base necesita el rel de la huella COMPLETO
  (base+0x40), no solo 0x40.

### Tabla de codigos COMPLETA (glifos_es.py es la unica fuente de la verdad)
- ESTRECHOS (8px, 0xB0-0xE4): C0=É C1=Í C2=N C4=ü C8=I CA=Á CB=ñ CC=ú CE=Ó CF=Ú D0=í D1=ó
  D2=¿ D3=Ü D4=é D5=¡ D6=! D7=Ñ D9=á
- ANCHOS (16px, 0x00-0xAF): 3A=G 44=M 45=E 46=C 47=R 5F=B 68=L 69=V 6E=K 76=Y 77=D 7E=S
  85=W 88=Z 89=U 8A=F 8C=T 8D=Ñ 98=O 99=X 9E=Q A1=P A3=¡ A4=A A5=H
- La tabla para volcar/insertar es recursos/tools/3x3eyes_ES.tbl (regenerable desde glifos_es.py)

### POC de inserción (06/10/2026) — MECHANICS DESCUBIERTAS
- Motor de texto (_000PRG 0x028EC): cmpi.b #$B0,d0 -> bcs (ancho 16px) / cmpi.b #$E5 -> fin.
  Codigos 0xB0-0xE4 se imprimen ESTRECHOS (8px, mitad IZQUIERDA del glifo 16x16);
  0x00-0xAF se imprimen ANCHOS (16px, glifo completo). NO hay que parchear codigo.
- Fuente 16x16 en _000PRG 0x29000, 32 bytes/glifo (16 filas x [izq, der] BE), 1bpp MSB first.
  Glifo N = byte N (0x01=あ, 0xB0='0' estrecho, 0xBA=espacio...). Metrica: digitos r2-r14.
- El ! y ? ORIGINALES (0xC6/0xC5) tienen la tinta en la mitad DERECHA -> no sirven como
  estrechos; el 0xC7 ' combi si la tiene en la izquierda. Nuestro ! propio va en 0xD6 (＄).
- Asignaciones castellanas (ver recursos/tools/glifos_es.py, unico fuente de la verdad):
  * ESTRECHOS (8px): D7=Ñ CB=ñ CA=Á C0=É C1=Í CE=Ó CF=Ú D3=Ü D9=á D4=é D0=í D1=ó CC=ú
    C4=ü D5=¡ D6=! D2=¿  (victimas: simbolos JP de baja frecuencia, nunca compuestos)
  * ANCHOS (16px): 8D=Ñ 7E=S 45=E 46=C 89=U 8C=T 47=R A4=A 77=D 98=O A3=¡
    (victimas: kana raros: ヅ 1x, ヲ 16x, ぷ 25x, ぺ 32x, ゼ 31x, ヂ 37x, ぽ 41x, ヵ 43x,
     ヨ 50x, ペ 52x, ＋ 4x) — permiten escribir palabras reales
- Tabla para volcar/insertar: recursos/tools/3x3eyes_ES.tbl (original + 29 entradas nuevas).
- Codigos de control conservados: 00=fin, DA=<br/>, DB=marca de voz, DC=<arrow>,
  E1/E2/E3=portrait/speak, f1/f2/f3/f4/f5=combiners dakuten/small (tinte en mitades).

### poc_castellano.py (pruebas/) — probado en sintetico, VERDE
- Localiza _000PRG y EV00001 por huella de 64B (unicidad verificada al vuelo, aborta si no).
- CONVERSION rel->raw OBLIGATORIA: (lba0 + rel//2048)*2352 + 16 + rel%2048. Sumar el offset
  relativo a la posicion raw de la huella es un BUG (fronteras de sector, 304B overhead).
- Parchea 28 glifos + 2 frases de EV00001 por "¡ÑU SECUESTRADO!": pointer[0] (paseante,
  offset 0x148B0, 21B) y pointer[2] (chico de la Mega Drive, 0x149A8, 19B). Longitud intacta.
- Backup .bak automatico, deteccion de doble parche, --restaurar.
- Test sintetico: aplicar/verificar 28 glifos byte a byte/doble-parche/restaurar = TODO OK.


### Material recibido de David (06/10/2026)
- David extrajo el Track 01 con una aplicación y subió Archivo.zip a su GitHub
  (psichopompo/Illusion-City). Guardado en extraccion/Archivo.zip (6,3 MB).
- Contenido: _000PRG.DAT (327.680 B) + 310 EV*.DAT (TODOS de exactamente 131.072 B = 128 KB,
  bloques fijos) + basura __MACOSX (ignorada). Nombres en HEXADECIMAL: EV0000A = EV de índice 0x0A.
- VERIFICADO: estructura intacta (tabla de punteros BE16, bloques de guion, relleno FF).
  El EV00000 volcado con readopcodes.c da el FINAL del juego (despedida de Pai/Yakumo/Ling-Ling/Long).

### Volcado de textos COMPLETO (textos/)
- 231/231 EVs volcados a textos/EVxxxxx_volcado.txt + textos/_estado.csv.
  * 221 limpios con readopcodes.c (gcc, ROM_INDEX_CSV=rom_index_MAY.csv con nombres en MAYÚSCULAS).
  * 8 con pointer_count del CSV recortado (el CSV se pasa de largo y apunta al relleno):
    EV0001C 30->28, EV00056 25->24, EV00067 30->25, EV00073 28->24, EV000D0 21->18,
    EV000F4 4->3, EV00125 13->10 (falta EV00029 y EV0002F en esta lista, ver abajo).
  * EV00029 y EV0002F: bancos de diálogo NPC del hotel (texto crudo separado por 0xDB,
    sin opcode 0x4C/0x24); volcados con dumper tolerante propio (decodifica 3x3eyes.tbl
    directamente). Los bancos tienen solapes (los punteros apuntan a un pool común).
- Volumen: ~8.866 cadenas (el nº real de cadenas ÚNICAS es menor en EV00029/EV0002F por los
  solapes). Caracteres brutos en cadenas: ~837k (inflado por los mismos solapes; el texto
  único real estará en el orden de 150-300k).

### Descubrimientos de encoding (para la INSERCIÓN)
- La tabla 3x3eyes.tbl del repo documenta la fuente ORIGINAL: 0x01-0x7F kana, 0x80-0xA2
  katakana, 0xA6-0xAF dígitos anchos, y SÓLO estos glifos latinos: 0xB0-0xB9='0'-'9',
  0xBA=espacio, 0xBB='E', 0xBC='(', 0xBD=')', 0xC7='!?'.
- NO hay A-Z/a-z en la fuente original: para el castellano habrá que REDIBUJAR tiles de la
  fuente (está en _000PRG.DAT) y remapear la tabla. Los códigos de control a conservar:
  00 (fin/cad), DA=<br/>, DB=marca de voz/turno, DC=<arrow>, E1=</portrait>, E2=<speak>,
  E3=</speak>, y los opcodes 0x4C/0x24 (PrintText/Print_text, longitud BE16 + texto).
- La fuente expandida a "ASCII completo" del repo es la del HACK de TienRen, NO la del disco
  original de David.

### Herramientas añadidas
- recursos/tools/rom_index_MAY.csv (copia del rom_index.csv con nombres en MAYÚSCULAS para
  que readopcodes.c encuentre los EV*.DAT de David)
- recursos/tools/extract_3x3eyes_v5.py + test_extract_3x3eyes_v5.py (extractor ISO9660 con
  banco de pruebas, VERDE; sustituye a v1-v4; corrige el bug off-by-2 del registro raíz de v4)


### Historial de la extracción (05-06/10/2026)
- [HECHO] El Track 01 de David es MODE1/2352: 310.675.680 bytes = 132.090 sectores exactos,
  sync 00 FF x10 00 en offset 0, datos ISO9660 en +16 de cada sector raw. PVD en LBA 16.
- v1-v3: diagnóstico del formato (v1 leía nombres de directorio como contenido; v2 detectó
  mal 2048; v3 fijó los parámetros correctos).
- v4: FALLÓ con "Root: LBA=1310754 size=0". Bug identificado: leía el LBA del registro raíz
  en pvd[156:160] cuando los campos del registro (que empieza en pvd+156) son rec[0]=len,
  rec[1]=extattr, rec[2:6]=LBA, rec[10:14]=size. El valor 1310754 = 0x00140022 = bytes
  22 00 14 00 = registro estándar de 34 bytes con raíz en LBA 20. EL DISCO ESTÁ BIEN.
- v5 (extract_3x3eyes_v5.py): parseo correcto + validación + fallback (path table + registro
  "." del raíz) + extracción recursiva (subdirectorios y multi-extent) + _manifesto.csv con
  md5 + genera 3x3eyes_textos.zip con _000PRG + EV*.
- test_extract_3x3eyes_v5.py: banco de pruebas con disco sintético. VERDE en 4 escenarios:
  (A) raw 2352 bien formado, (B) PVD raíz corrupto -> fallback recupera, (C) ISO/2048,
  (D) reproduce el bug de v4 (LBA=1310754) y confirma que v5 lee LBA=20.
- Ensayo a escala real (disco sintético de 132.090 sectores con 231 EV + PRG/MAP/PLAY/BNK):
  272/272 ficheros extraídos, md5 todos correctos, zip de ~22 MB con los textos.

## Qué es
Seima Densetsu 3x3 Eyes (聖魔伝説 サザンアイズ) para Sega Mega CD.
RPG de Sega basado en el manga de Yuzo Takada. 47 tracks CD.

## Qué hay disponible (del repo 3x3eyesMCD-main)
- Motor de scripts DOCUMENTADO: 82 event opcodes + 121 text opcodes
- Herramientas en C: readopcodes.c (lee los scripts de los EV files), flagid.c
- Tabla de caracteres (3x3eyes.tbl) con el mapping SJIS
- rom_index.csv con los 231 EV files y sus offsets de texto
- Textos en SJIS SIN COMPRIMIR dentro de los EV files
- Fuente 8x16 expandida a ASCII completo
- Walkthrough con el orden de las escenas

## Estructura de ficheros del juego
- _000PRG.DAT: programa principal + fuente Kanji + menús (en Track 01)
- EV*.DAT: 231 ficheros con sprites, eventos, texto y retratos por escena
  - Texto en offset 0xC800 o 0x14800 (según el EV)
  - Texto en SJIS sin comprimir
- MAP*.DAT: mapas comprimidos con Kosinski
- PLAY*.DAT: sprites de personajes + textos de hints
- BNK*.DAT: instrumentos PCM

## Pendientes / siguientes pasos
1. David prueba poc_castellano_v12.py: bienvenida sin dobles, minusculas 8px.
   NOTA: caps siguen a 16px (unica via sin el cargador). Si David insiste en caps 8px,
   el camino es el cargador (parche-sonda empirico).
2. Si OK: maqueta completa de la ciudad (EV00006) con agrupacion SI/SI-NO y traduccion.
2. MAQUETA de traduccion EV00006: lineas japonesas + control codes separados para que
   David traduzca; la herramienta las reinserta.
2. HERRAMIENTA DE INSERCION MASIVA (v4): longitud variable + tabla ES con codes F8/F9.
2. MAQUETA de traduccion del EV00006 (la ciudad que David ya ve parcheada): formato
   entrada/linea/control codes para que David traduzca y la herramienta la inserte.
3. Menus estaticos (Kosinski en _000PRG 0x3E000+): batalla posterior.
4. Mapa EV->escena: ir llenandolo con el walkthrough (EV00000=FINAL, EV00006=ciudad HK).

## Ventajas vs Illusion City
- Textos sin comprimir (SJIS plano)
- Motor de scripts documentado con herramientas públicas
- Tabla de caracteres ya hecha
- Sistema de opcodes más simple (lineal, no graph-based)
- Comunidad ya investigó el juego (Ginza, TienRen en romhacking.net)
