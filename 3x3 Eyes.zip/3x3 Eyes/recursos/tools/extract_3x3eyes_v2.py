#!/usr/bin/env python3
"""
extract_3x3eyes_v2.py — Parser ISO9660 real para extraer ficheros del Track 01 de 3x3 Eyes.

Uso: python3 extract_3x3eyes_v2.py "Track01.bin"
"""
import sys, os, struct

def read_sector(f, sector_num, sector_size=2352, data_offset=16):
    """Lee un sector del disco."""
    f.seek(sector_num * sector_size + data_offset)
    return f.read(2048)

def parse_iso9660(bin_path, out_dir):
    sector_size = 2352
    data_offset = 16

    f = open(bin_path, 'rb')

    # Verificar formato
    header = f.read(16)
    if header[:12] == b'\x00\xFF' * 6:
        print("Formato: MODE1/2352")
    else:
        sector_size = 2048
        data_offset = 0
        print("Formato: probablemente MODE1/2048")

    # Leer el Primary Volume Descriptor (sector 16)
    pvd_raw = read_sector(f, 16, sector_size, data_offset)
    if pvd_raw[:5] != b'\x01CD001':
        print("ERROR: no es ISO9660")
        f.close()
        return

    print("ISO9660 detectado")
    # Root directory record está en offset 156 del PVD, 34 bytes
    root_record = pvd_raw[156:156+34]
    root_lba = struct.unpack('<I', root_record[2:6])[0]
    root_size = struct.unpack('<I', root_record[10:14])[0]
    print("Root directory: LBA=%d, size=%d" % (root_lba, root_size))

    # Leer el root directory
    sectors_for_root = (root_size + 2047) // 2048
    root_data = b''
    for s in range(sectors_for_root):
        root_data += read_sector(f, root_lba + s, sector_size, data_offset)

    # Parsear los directory records
    files = {}
    pos = 0
    while pos < len(root_data):
        rec_len = root_data[pos]
        if rec_len == 0:
            pos += 1  # pasa al siguiente sector
            continue
        ext_lba = struct.unpack('<I', root_data[pos+2:pos+6])[0]
        ext_size = struct.unpack('<I', root_data[pos+10:pos+14])[0]
        flags = root_data[pos+25]
        name_len = root_data[pos+32]
        name = root_data[pos+33:pos+33+name_len]

        # decodificar nombre
        if name_len == 1 and name == b'\x00':
            pos += rec_len
            continue
        if name_len == 1 and name == b'\x01':
            pos += rec_len
            continue

        name_str = name.decode('ascii', errors='replace').rstrip('.')
        is_dir = (flags & 2) != 0

        if not is_dir:
            files[name_str] = (ext_lba, ext_size)
            print("  %s: LBA=%d size=%d" % (name_str, ext_lba, ext_size))

        pos += rec_len

    # Si hay subdirectorios, explorarlos
    pos = 0
    subdirs = []
    while pos < len(root_data):
        rec_len = root_data[pos]
        if rec_len == 0:
            pos += 1
            continue
        ext_lba = struct.unpack('<I', root_data[pos+2:pos+6])[0]
        ext_size = struct.unpack('<I', root_data[pos+10:pos+14])[0]
        flags = root_data[pos+25]
        name_len = root_data[pos+32]
        name = root_data[pos+33:pos+33+name_len]

        if name_len > 1 and name not in (b'\x00', b'\x01') and (flags & 2):
            name_str = name.decode('ascii', errors='replace').rstrip('.')
            subdirs.append((name_str, ext_lba, ext_size))
        pos += rec_len

    # explorar subdirectorios
    for sd_name, sd_lba, sd_size in subdirs:
        print("\nSubdirectorio: %s (LBA=%d size=%d)" % (sd_name, sd_lba, sd_size))
        sectors = (sd_size + 2047) // 2048
        sd_data = b''
        for s in range(sectors):
            sd_data += read_sector(f, sd_lba + s, sector_size, data_offset)

        pos = 0
        while pos < len(sd_data):
            rec_len = sd_data[pos]
            if rec_len == 0:
                pos += 1
                continue
            ext_lba = struct.unpack('<I', sd_data[pos+2:pos+6])[0]
            ext_size = struct.unpack('<I', sd_data[pos+10:pos+14])[0]
            flags = sd_data[pos+25]
            name_len = sd_data[pos+32]
            name = sd_data[pos+33:pos+33+name_len]

            if name_len <= 1:
                pos += rec_len
                continue

            name_str = name.decode('ascii', errors='replace').rstrip('.')
            if not (flags & 2):  # no es directorio
                files[sd_name + '/' + name_str] = (ext_lba, ext_size)
                print("  %s/%s: LBA=%d size=%d" % (sd_name, name_str, ext_lba, ext_size))
            pos += rec_len

    # Extraer los ficheros que nos interesan
    os.makedirs(out_dir, exist_ok=True)

    # 1) _000PRG.DAT
    for name, (lba, size) in files.items():
        if 'PRG' in name.upper() or 'PRG' in name:
            print("\nExtrayendo %s (LBA=%d, size=%d)..." % (name, lba, size))
            out_data = b''
            sectors = (size + 2047) // 2048
            for s in range(sectors):
                out_data += read_sector(f, lba + s, sector_size, data_offset)
            out_data = out_data[:size]
            out_path = os.path.join(out_dir, name)
            open(out_path, 'wb').write(out_data)
            print("  -> %d bytes" % len(out_data))

    # 2) EV files
    ev_count = 0
    for name, (lba, size) in sorted(files.items()):
        if name.upper().startswith('EV'):
            sectors = (size + 2047) // 2048
            out_data = b''
            for s in range(sectors):
                out_data += read_sector(f, lba + s, sector_size, data_offset)
            out_data = out_data[:size]
            out_path = os.path.join(out_dir, name)
            open(out_path, 'wb').write(out_data)
            ev_count += 1

    print("\n%d EV files extraídos" % ev_count)

    # 3) extraer también otros ficheros de datos útiles
    for name, (lba, size) in sorted(files.items()):
        if any(name.upper().startswith(p) for p in ('MAP', 'PLAY', 'SMON', 'SPLAY')):
            sectors = (size + 2047) // 2048
            out_data = b''
            for s in range(sectors):
                out_data += read_sector(f, lba + s, sector_size, data_offset)
            out_data = out_data[:size]
            out_path = os.path.join(out_dir, name)
            open(out_path, 'wb').write(out_data)

    # resumen
    print("\n=== RESUMEN ===")
    all_files = os.listdir(out_dir)
    total = sum(os.path.getsize(os.path.join(out_dir, f)) for f in all_files)
    print("Ficheros extraídos: %d" % len(all_files))
    print("Tamaño total: %.1f MB" % (total/1024/1024))
    for f_name in sorted(all_files)[:20]:
        print("  %s: %d bytes" % (f_name, os.path.getsize(os.path.join(out_dir, f_name))))
    if len(all_files) > 20:
        print("  ... y %d más" % (len(all_files) - 20))

    f.close()

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Uso: python3 extract_3x3eyes_v2.py <Track01.bin>")
        sys.exit(1)
    parse_iso9660(sys.argv[1], "3x3eyes_extracted")
