# Introduction
Here are a few tools I have made through the use of ChatGPT. No warranties whatsover regarding use.

# flagid.c

This is a small tool which takes the "flagid" provided to a control code in the event script (found in EV-files) and converts it to the specific bit and memory location where it will be stored. For example a unique flag provided to a control code may be "0108", this is translated to a specific memory bit which the control code turns on or off. In this way you can read the script and find interesting flag ids, and then find the memory locations to set breakpoints/watchpoints on during interactive debugging. Or you can find out which memory bits you need to turn on/off to pass flag checks. The program basically reimplements the function for checking flagids in _000PRG.DAT.

# readopcodes.c

This is a small program which reads the text opcode block of an input EV/event file (usually found at 0x14800), according to an overview defined in a CSV-file. It interprets the opcodes according to the opcodes.yml file. Flags are interpreted according to the flag.tbl and text is interpreted according to the text table specified in the CSV file for each EV-file.

---

# Extracción del Track 01 (herramientas del proyecto ES)

## extract_3x3eyes_v5.py
Extractor ISO9660 del Track 01 (MODE1/2352). Parsea PVD (LBA 16, datos en +16 del sector raw),
recorre el árbol de directorios, extrae todo a `3x3eyes_extract/` con un `_manifesto.csv`
(ruta, LBA, tamaño, md5) y genera `3x3eyes_textos.zip` sólo con `_000PRG.DAT` + `EV*.DAT`.

    python3 extract_3x3eyes_v5.py "Seima Densetsu 3x3 Eyes (Japan, Korea) (Track 01).bin"
    # opciones: --out DIR | --listar | --sin-zip

Historial: v1-v3 diagnóstico del formato; v4 bug off-by-2 al leer el registro raíz del PVD
(leía rec[0:4] como LBA); v5 lo corrige y añade validación + fallback por path table.

## test_extract_3x3eyes_v5.py
Banco de pruebas: construye un disco ISO9660 sintético (raw 2352), lo extrae con la v5 y
compara md5. Escenarios: disco válido, PVD raíz corrupto (fallback), ISO/2048 y reproducción
del bug de v4. Ejecutar: `python3 test_extract_3x3eyes_v5.py` → debe decir VERDE.
