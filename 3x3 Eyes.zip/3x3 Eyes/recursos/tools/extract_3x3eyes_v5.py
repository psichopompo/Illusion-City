#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_3x3eyes_v5.py — Extractor ISO9660 del Track 01 de Seima Densetsu 3x3 Eyes (Mega CD).

Historial:
  v1-v3: diagnóstico del formato. Conclusión [HECHA]: imagen MODE1/2352 (132090 sectores),
         datos ISO9660 en offset 16 de cada sector raw, PVD en LBA 16.
  v4:    BUG (corregido aquí): leía el LBA del registro raíz en pvd[156:160]. El registro
         raíz empieza en pvd+156, pero sus campos son rec[0]=len, rec[1]=extattr,
         rec[2:6]=LBA(LE), rec[10:14]=size(LE). v4 leía rec[0:4] → "LBA=1310754, size=0".
         El disco estaba bien: 22 00 14 00 = registro estándar de 34 bytes con raíz en LBA 20.
  v5:    parseo correcto + validación + fallback por path table + extracción completa
         + manifest + zip con los ficheros de texto (_000PRG + EV*).

Uso:
  python3 extract_3x3eyes_v5.py "Seima Densetsu 3x3 Eyes (Japan, Korea) (Track 01).bin"
  python3 extract_3x3eyes_v5.py <bin> --listar      # sólo lista el árbol, no extrae
  python3 extract_3x3eyes_v5.py <bin> --out DIR     # directorio de salida (default 3x3eyes_extract)
  python3 extract_3x3eyes_v5.py <bin> --sin-zip     # no genera 3x3eyes_textos.zip

Sólo stdlib. Sin dependencias.
"""
import argparse, csv, hashlib, os, struct, sys, zipfile

RAW = 2352          # sector MODE1 raw: 12 sync + 4 header + 2048 datos + 288 EDC/ECC
USER = 2048


class Disco:
    """Lectura por LBA con detección automática 2352/2048."""

    def __init__(self, path):
        self.path = path
        self.total = os.path.getsize(path)
        self.f = open(path, 'rb')
        if self.total % RAW == 0 and self._sync(0, RAW):
            self.paso, self.off, self.modo = RAW, 16, 'MODE1/2352 (raw, datos en +16)'
        elif self.total % USER == 0:
            self.paso, self.off, self.modo = USER, 0, 'ISO/2048'
        else:
            raise SystemExit('ERROR: %d bytes no es múltiplo de 2352 ni de 2048' % self.total)
        self.nsec = self.total // self.paso

    def _sync(self, lba, paso):
        self.f.seek(lba * paso)
        return self.f.read(12) == b'\x00' + b'\xff' * 10 + b'\x00'

    def abrir(self):
        self.f = open(self.path, 'rb')

    def leer(self, lba, nbytes):
        out = bytearray()
        while len(out) < nbytes:
            if lba >= self.nsec:
                raise SystemExit('ERROR: lectura fuera del disco (LBA %d >= %d)' % (lba, self.nsec))
            self.f.seek(lba * self.paso + self.off)
            out += self.f.read(USER)
            lba += 1
        return bytes(out[:nbytes])

    def cerrar(self):
        self.f.close()


def le32(b, o):
    return struct.unpack('<I', b[o:o + 4])[0]


def parse_registro(data, pos):
    """Parsea un directory record ISO9660 en data[pos]. Devuelve dict o None."""
    if pos >= len(data) or data[pos] == 0:
        return None
    rlen = data[pos]
    if rlen < 33 or pos + rlen > len(data):
        return None
    rec = data[pos:pos + rlen]
    nlen = rec[32]
    if 33 + nlen > rlen:
        return None
    return {
        'lba': le32(rec, 2),
        'size': le32(rec, 10),
        'flags': rec[25],
        'name': rec[33:33 + nlen],
        'rlen': rlen,
    }


def limpiar_nombre(raw):
    return raw.decode('ascii', errors='replace').split(';')[0].rstrip('.')


def registros_directorio(disco, lba, size):
    """Devuelve la lista de registros de un extent de directorio."""
    data = disco.leer(lba, size)
    recs, pos = [], 0
    while pos < len(data):
        if data[pos] == 0:                      # relleno: saltar al sector siguiente
            pos = (pos // USER + 1) * USER
            continue
        r = parse_registro(data, pos)
        if r is None:
            break
        recs.append(r)
        pos += r['rlen']
    return recs


def recoger(disco, lba, size, prefijo='', prof=0, vistos=None):
    """Recorre el árbol recursivamente. Devuelve {ruta: [(lba, size), ...]} (multi-extent)."""
    if vistos is None:
        vistos = set()
    if prof > 8 or (lba, size) in vistos:
        return {}
    vistos.add((lba, size))
    ficheros = {}
    regs = registros_directorio(disco, lba, size)
    i = 0
    while i < len(regs):
        r = regs[i]
        i += 1
        nombre = limpiar_nombre(r['name'])
        if nombre in ('.', '..', ''):
            continue
        ruta = prefijo + nombre
        if r['flags'] & 0x02:                                   # directorio
            ficheros.update(recoger(disco, r['lba'], r['size'], ruta + '/', prof + 1, vistos))
        else:                                                   # fichero (posiblemente multi-extent)
            extents = [(r['lba'], r['size'])]
            while r['flags'] & 0x80 and i < len(regs):          # 0x80 = continúa en el sig. registro
                r = regs[i]
                i += 1
                extents.append((r['lba'], r['size']))
            ficheros[ruta] = extents
    return ficheros


def raiz_desde_pvd(pvd, disco):
    """Parsea el registro raíz del PVD con los offsets correctos (+156, LBA en +2)."""
    rec = pvd[156:156 + 34]
    if len(rec) < 34 or rec[0] < 34:
        return None, 'registro raíz inválido: ' + rec[:min(34, len(rec))].hex(' ')
    lba = le32(rec, 2)
    size = le32(rec, 10)
    if lba >= disco.nsec or size == 0 or size > disco.nsec * USER:
        return None, ('registro raíz fuera de rango: LBA=%d size=%d | hex: %s'
                      % (lba, size, rec.hex(' ')))
    return {'lba': lba, 'size': size}, 'ok'


def raiz_desde_pathtable(pvd, disco):
    """Fallback: la path table type-L da el LBA del raíz; el registro '.' dentro
    del propio directorio raíz da el LBA y el tamaño fiables."""
    pt_size = le32(pvd, 132)
    pt_lba = le32(pvd, 136)
    if pt_lba >= disco.nsec or pt_size == 0 or pt_size > disco.nsec * USER:
        return None, 'path table inválida (lba=%d size=%d)' % (pt_lba, pt_size)
    pt = disco.leer(pt_lba, min(pt_size, USER * 4))
    if len(pt) < 8:
        return None, 'path table vacía'
    lba_dir = le32(pt, 2)
    if lba_dir >= disco.nsec:
        return None, 'path table apunta fuera del disco (lba=%d)' % lba_dir
    # El primer registro del extent raíz es el '.' y trae el tamaño real del extent
    primer = disco.leer(lba_dir, USER)
    r = parse_registro(primer, 0)
    if r is not None and limpiar_nombre(r['name']) == '.' and r['lba'] == lba_dir:
        return {'lba': r['lba'], 'size': r['size']}, 'ok (fallback path table + registro .)'
    return {'lba': lba_dir, 'size': USER}, 'ok (fallback path table, tamaño supuesto 2048)'


def extraer_fichero(disco, extents, destino):
    h = hashlib.md5()
    with open(destino, 'wb') as g:
        for lba, size in extents:
            quedan, lba_off = size, 0
            while quedan > 0:
                trozo = min(USER * 64, quedan)
                datos = disco.leer(lba + lba_off, trozo)
                g.write(datos)
                h.update(datos)
                lba_off += trozo // USER if trozo % USER == 0 else (trozo // USER) + 1
                quedan -= trozo
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description='Extractor ISO9660 de 3x3 Eyes (Mega CD)')
    ap.add_argument('bin', help='Track 01 .bin (MODE1/2352)')
    ap.add_argument('--out', default='3x3eyes_extract', help='directorio de salida')
    ap.add_argument('--listar', action='store_true', help='sólo listar, no extraer')
    ap.add_argument('--sin-zip', action='store_true', help='no crear 3x3eyes_textos.zip')
    args = ap.parse_args()

    print('=== EXTRACT 3x3 EYES v5 ===')
    disco = Disco(args.bin)
    disco.abrir()
    print('Fichero : %s' % args.bin)
    print('Tamaño  : %d bytes = %d sectores  [%s]' % (disco.total, disco.nsec, disco.modo))

    # --- Header IP.BIN (LBA 0) ---
    cab = disco.leer(0, 0x200)
    print('Header  : %s | %s' % (
        cab[0x00:0x10].hex(), cab[0x20:0x50].decode('ascii', errors='replace').strip()))

    # --- PVD (LBA 16) ---
    pvd = disco.leer(16, USER)
    if pvd[0] != 1 or pvd[1:6] != b'CD001':
        raise SystemExit('ERROR: LBA 16 no contiene un PVD (byte0=%02X, id=%r)'
                         % (pvd[0], pvd[1:6]))
    print('PVD     : OK en LBA 16')
    print('  Sistema   : %r' % pvd[8:40].decode('ascii', errors='replace').rstrip())
    print('  Volumen   : %r' % pvd[40:72].decode('ascii', errors='replace').rstrip())
    print('  Espacio   : %d sectores lógicos de %d bytes'
          % (le32(pvd, 80), struct.unpack('<H', pvd[128:130])[0]))
    print('  PathTable : size=%d  LBA_L=%d' % (le32(pvd, 132), le32(pvd, 136)))

    # --- Registro raíz: campos en +2 (LBA) y +10 (size) dentro del registro de pvd+156 ---
    raiz, msg = raiz_desde_pvd(pvd, disco)
    if raiz is None:
        print('  AVISO   : %s' % msg)
        raiz, msg = raiz_desde_pathtable(pvd, disco)
        if raiz is None:
            print('  AVISO   : %s' % msg)
            print('  Hex PVD[140:200]: %s' % pvd[140:200].hex(' '))
            raise SystemExit('ERROR: no se ha podido localizar el directorio raíz')
    print('  Raíz      : LBA=%d size=%d bytes  [%s]' % (raiz['lba'], raiz['size'], msg))

    # --- Árbol ---
    ficheros = recoger(disco, raiz['lba'], raiz['size'])
    print('\n=== ÁRBOL (%d ficheros) ===' % len(ficheros))
    total_bytes = 0
    for ruta in sorted(ficheros):
        nbytes = sum(s for _, s in ficheros[ruta])
        total_bytes += nbytes
        print('  %-40s %10d bytes  (LBA %d)' % (ruta, nbytes, ficheros[ruta][0][0]))

    categorias = {'EV': 0, 'PRG': 0, 'MAP': 0, 'PLAY': 0, 'BNK': 0, 'otros': 0}
    for ruta in ficheros:
        base = os.path.basename(ruta).upper()
        for k in ('EV', 'MAP', 'PLAY', 'BNK'):
            if base.startswith(k):
                categorias[k] += 1
                break
        else:
            categorias['PRG' if 'PRG' in base else 'otros'] += 1
    print('\nCategorías: %s' % ', '.join('%s=%d' % kv for kv in categorias.items()))
    print('Total: %d ficheros, %.1f MB' % (len(ficheros), total_bytes / 1048576))

    if args.listar:
        disco.cerrar()
        return

    # --- Extracción ---
    print('\n=== EXTRACCIÓN -> %s/ ===' % args.out)
    os.makedirs(args.out, exist_ok=True)
    manifest = []
    for ruta in sorted(ficheros):
        destino = os.path.join(args.out, *ruta.split('/'))
        os.makedirs(os.path.dirname(destino) or '.', exist_ok=True)
        md5 = extraer_fichero(disco, ficheros[ruta], destino)
        nbytes = sum(s for _, s in ficheros[ruta])
        manifest.append((ruta, ficheros[ruta][0][0], nbytes, md5))
        print('  %-40s %10d bytes  md5=%s' % (ruta, nbytes, md5[:12]))

    with open(os.path.join(args.out, '_manifesto.csv'), 'w', newline='') as g:
        w = csv.writer(g)
        w.writerow(['ruta', 'lba', 'bytes', 'md5'])
        w.writerows(manifest)
    print('Manifest: %s/_manifesto.csv' % args.out)

    # --- Zip con los ficheros de texto (_000PRG + EV*) ---
    if not args.sin_zip:
        objetivos = [r for r, _, _, _ in manifest
                     if os.path.basename(r).upper().startswith(('EV', '_000PRG', 'PRG'))]
        if objetivos:
            zpath = '3x3eyes_textos.zip'
            with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                for ruta in objetivos:
                    z.write(os.path.join(args.out, *ruta.split('/')), arcname=os.path.basename(ruta))
            print('\nZIP de textos: %s (%.1f MB, %d ficheros)'
                  % (zpath, os.path.getsize(zpath) / 1048576, len(objetivos)))
        else:
            print('\nNo he encontrado ficheros EV*/PRG* para el zip')

    disco.cerrar()
    print('\nFIN. Siguiente paso con los ficheros: readopcodes.c + rom_index.csv')


if __name__ == '__main__':
    main()
