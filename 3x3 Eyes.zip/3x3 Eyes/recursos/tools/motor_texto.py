#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
motor_texto.py — Motor de volcado/insercion de texto para 3x3 Eyes (Mega CD).

MODELO DEL FORMATO (reingenieria + hilo de Ginza en SegaXtreme):
- EV de 128KB: sprites [0, base), zona de texto [base, ...), resto (retratos...).
- En 'base': BE16 = 8 (offset de la tabla de punteros respecto a base).
  Tabla: BE16 ascendentes relativos a base -> inicio de cada "stream".
- STREAM: secuencia de opcodes (opcodes.yml): 1 byte de opcode + args de 2 bytes BE.
  Los args marcados arg_is_offset apuntan a base+offset: a bloques de TEXTO
  (arg_is_text_offset) o a otros streams (saltos/else). 'continues: false' = fin.
- BLOQUE DE TEXTO: bytes crudos del guion terminados en 0xDB (inclusive),
  codificados con 3x3eyes.tbl / 3x3eyes_ES.tbl / F8nn-F9nn-F1xx (ver glifos_narrow_es).
- Byte 0x00 DENTRO de un texto = marca de espera; 0xDB = fin de bloque.

COMANDOS:
  comprobar <EV.DAT> <base>            parsea y muestra estadistica
  roundtrip <EV.DAT> <base>            reconstruye sin cambios y compara semantica
  volcar   <EV.DAT> <base> <out.txt>   vuelca los bloques (formato maqueta)
  insertar <EV.DAT> <base> <trad.json> <out.DAT>   inserta {off_hex: texto nuevo}
  insertar_directo <EV.DAT> <base> <off_hex> "<texto>" <out.DAT>  (un bloque)

La reconstruccion reempaqueta streams y bloques desde el final de la tabla,
recalcula la tabla de punteros y TODOS los offsets embebidos, y rellena con FF
hasta region_end (default 0x1B000). El resto del EV se copia intacto.
"""
import json, struct, sys

TABLA_REL = 8
FIN_ZONA_DEFAULT = 0x1B000


# ---------------------------------------------------------------- opcodes.yml
def cargar_defs(path):
    """Parser minimo del YAML simple de opcodes (2 espacios de indentacion)."""
    defs = {}
    op = None
    for raw in open(path, encoding='utf-8', errors='replace'):
        ln = raw.rstrip('\r\n')
        if not ln or ln.strip().startswith('#'):
            continue
        ind = len(ln) - len(ln.lstrip())
        cuerpo = ln.strip()
        if ind == 0 and cuerpo.endswith(':'):
            op = None
            continue
        if ind == 2 and cuerpo.endswith(':'):
            op = {'id': int(cuerpo[:-1], 16)}
            defs[op['id']] = op
            continue
        if ind >= 4 and op is not None and ':' in cuerpo:
            k, v = cuerpo.split(':', 1)
            k = k.strip().lower()
            v = v.strip()
            if v.startswith('['):
                vals = [x.strip() for x in v[1:-1].split(',') if x.strip()]
                if all(x.lower() in ('true', 'false') for x in vals):
                    op[k] = [x.lower() == 'true' for x in vals]
                else:
                    op[k] = [int(x, 0) for x in vals]
            elif v.lower() in ('true', 'false'):
                op[k] = v.lower() == 'true'
            else:
                try:
                    op[k] = int(v, 0)
                except ValueError:
                    op[k] = v
    for d in defs.values():
        d.setdefault('arg_count', 0)
        d.setdefault('arg_width', [2] * d['arg_count'])
        d.setdefault('arg_is_offset', [False] * d['arg_count'])
        d.setdefault('arg_is_text_offset', [False] * d['arg_count'])
        d.setdefault('follow_targets', [False] * d['arg_count'])
        d.setdefault('continues', True)
    return defs


def anchos(d):
    """Lista de anchos (1/2/3 bytes) por argumento, default 2."""
    w = d.get('arg_widths', [])
    return [ (w[i] if i < len(w) else 2) for i in range(d['arg_count']) ]


def caminar(data, base, defs, inicio):
    """Generador sobre un stream: cede (pos, opid, def, [(valor, es_offset, es_texto, pos_arg)]).
    Termina cuando la def dice continues=False o al encontrar opcode desconocido
    (lanza EvParseError)."""
    pos = inicio
    while True:
        if pos >= len(data):
            raise EvParseError('stream 0x%X se sale del EV' % inicio)
        opid = data[pos]
        d = defs.get(opid)
        if d is None:
            raise EvParseError('opcode desconocido 0x%02X en 0x%X (stream 0x%X)'
                               % (opid, pos, inicio))
        w = anchos(d)
        args = []
        pa = pos + 1
        for i in range(d['arg_count']):
            if w[i] == 1:
                v = data[pa]
            elif w[i] == 3:
                v = int.from_bytes(data[pa:pa + 3], 'big')
            else:
                v = struct.unpack('>H', data[pa:pa + 2])[0]
            es_off = i < len(d['arg_is_offset']) and d['arg_is_offset'][i]
            es_txt = i < len(d['arg_is_text_offset']) and d['arg_is_text_offset'][i]
            es_fol = i < len(d['follow_targets']) and d['follow_targets'][i]
            args.append((v, es_off, es_txt, pa, es_fol))
            pa += w[i]
        yield pos, opid, d, args
        if not d['continues']:
            break
        pos = pa


# ---------------------------------------------------------------- parseo
class EvParseError(Exception):
    pass


class Bloque:
    __slots__ = ('off', 'tipo', 'datos')

    def __init__(self, off, tipo, datos):
        self.off, self.tipo, self.datos = off, tipo, datos

    def __len__(self):
        return len(self.datos)


def leer_bloque_texto(data, off, fin_zona):
    fin = data.find(b'\xDB', off, fin_zona)
    if fin == -1:
        raise EvParseError('bloque de texto en 0x%X sin terminador DB' % off)
    return data[off:fin + 1]


def parse_ev(data, base, defs, fin_zona=FIN_ZONA_DEFAULT):
    if len(data) < base + 10:
        raise EvParseError('EV demasiado pequeno')
    salto = struct.unpack('>H', data[base:base + 2])[0]
    tabla = base + salto
    punteros = []
    p = tabla
    while True:
        v = struct.unpack('>H', data[p:p + 2])[0]
        destino = base + v
        # fin de tabla: padding, destino invalido, o byte inicial no-opcode
        if v == 0xACAC or v == 0xFFFF or v == 0x0000:
            break
        if destino < tabla + 2 * (len(punteros) + 1) or destino >= fin_zona:
            break
        if data[destino] not in defs:
            break
        punteros.append(v)
        p += 2
        if len(punteros) > 512:
            raise EvParseError('tabla de punteros desbocada')
    if not punteros:
        raise EvParseError('tabla de punteros vacia en 0x%X' % tabla)

    elementos = {}     # off -> Bloque (orden de primera referencia)
    orden = []
    texto_de = {}      # off -> bytes del bloque

    def bloque_texto(off):
        if off in elementos:
            return
        if not base <= off < fin_zona:
            raise EvParseError('bloque de texto fuera de zona: 0x%X' % off)
        datos = leer_bloque_texto(data, off, fin_zona)
        elementos[off] = Bloque(off, 'texto', datos)
        orden.append(off)

    pendientes = [base + v for v in punteros]
    vistos_stream = set()
    refs = []          # (stream_off, pos_arg_abs, target, es_texto)
    while pendientes:
        off = pendientes.pop(0)
        if off in vistos_stream:
            continue
        vistos_stream.add(off)
        fin_stream = off
        for pos, opid, d, args in caminar(data, base, defs, off):
            fin_op = pos + 1 + sum(anchos(d))
            stream_bytes = data[pos:fin_op]
            for (v, es_off, es_txt, pa, es_fol) in args:
                if es_off:
                    destino = base + v
                    refs.append((off, pa, destino, es_txt))
                    if es_txt:
                        bloque_texto(destino)
                    elif es_fol:
                        if destino not in vistos_stream and destino not in pendientes:
                            pendientes.append(destino)
            elementos[pos] = Bloque(pos, 'stream', stream_bytes)
            orden.append(pos)
            fin_stream = fin_op
            if not d['continues']:
                break

    return {'base': base, 'tabla': tabla, 'punteros': punteros,
            'elementos': elementos, 'orden': orden, 'refs': refs}


# ---------------------------------------------------------------- reconstruccion
def reconstruir(ev, data, textos_nuevos=None, fin_zona=FIN_ZONA_DEFAULT):
    """textos_nuevos: {off_original: bytes_nuevos (con DB final)}.
    Reempaqueta desde el final de la tabla y recalcula toda la referencia."""
    base, tabla = ev['base'], ev['tabla']
    textos_nuevos = textos_nuevos or {}

    # nuevos bytes y longitudes de cada elemento
    nuevos = {}
    for off, b in ev['elementos'].items():
        if b.tipo == 'texto' and off in textos_nuevos:
            nuevos[off] = bytearray(textos_nuevos[off])
        else:
            nuevos[off] = bytearray(b.datos)

    # orden de empaquetado: streams en orden de aparicion, luego textos
    streams = [o for o in ev['orden'] if ev['elementos'][o].tipo == 'stream']
    textos = [o for o in ev['orden'] if ev['elementos'][o].tipo == 'texto']
    inicio = tabla + 2 * len(ev['punteros'])
    posiciones = {}
    cur = inicio
    for off in streams + textos:
        posiciones[off] = cur
        cur += len(nuevos[off])
    if cur - base > 0x10000:
        raise EvParseError('la zona de texto no cabe (0x%X > 64KB rel)' % (cur - base))
    if cur > fin_zona:
        raise EvParseError('la zona de texto invade 0x%X' % cur)

    out = bytearray(data)
    # tabla de punteros
    for i, v in enumerate(ev['punteros']):
        nuevo = posiciones[base + v] - base
        out[tabla + 2 * i:tabla + 2 * i + 2] = struct.pack('>H', nuevo)
    # rellenar la zona reconstruida
    out[inicio:fin_zona] = b'\xFF' * (fin_zona - inicio)
    # escribir elementos con refs reescritas
    mapa_args = {}
    for (stream_off, pos_arg, target, es_texto) in ev['refs']:
        mapa_args[pos_arg] = target
    for off in streams + textos:
        dst = posiciones[off]
        b = bytearray(nuevos[off])
        if ev['elementos'][off].tipo == 'stream':
            for pos, opid, d, args in caminar(data, base, ev['defs'], off):
                for idx, (v, es_off, es_txt, pa, es_fol) in enumerate(args):
                    if es_off:
                        target = mapa_args.get(pa)
                        if target is not None and target in posiciones:
                            nuevo_rel = posiciones[target] - base
                            if nuevo_rel > 0xFFFF:
                                raise EvParseError('offset >64KB')
                            w = anchos(d)[idx]
                            rel_en_stream = pa - off
                            b[rel_en_stream:rel_en_stream + w] = nuevo_rel.to_bytes(w, 'big')
        out[dst:dst + len(b)] = b
    return bytes(out), posiciones


# ---------------------------------------------------------------- utilidades
def cargar_tbl(path):
    m = {}
    for ln in open(path, encoding='utf-8', errors='replace'):
        ln = ln.rstrip('\r\n')
        if '=' in ln:
            k, v = ln.split('=', 1)
            try:
                b = bytes.fromhex(k)
                m[b] = v
            except ValueError:
                pass
    return m


def decodificar(bloque, tbl):
    out, i = [], 0
    while i < len(bloque):
        if bloque[i:i + 2] in tbl:
            out.append(tbl[bloque[i:i + 2]]); i += 2
        elif bloque[i:i + 1] in tbl:
            out.append(tbl[bloque[i:i + 1]]); i += 1
        else:
            out.append('{%02X}' % bloque[i]); i += 1
    return ''.join(out)


def textos_por_puntero(ev, data):
    """Test semantico: bloques de texto por puntero en orden de walk."""
    base, defs = ev['base'], ev['defs']
    res = []
    for p in ev['punteros']:
        vistos, secuencia = set(), []
        pend = [base + p]
        while pend:
            off = pend.pop(0)
            if off in vistos:
                continue
            vistos.add(off)
            for pos, opid, d, args in caminar(data, base, defs, off):
                for (v, es_off, es_txt, pa, es_fol) in args:
                    if es_off:
                        destino = base + v
                        if es_txt:
                            fin = data.index(b'\xDB', destino) + 1
                            secuencia.append(data[destino:fin])
                        elif es_fol:
                            pend.append(destino)
        res.append(secuencia)
    return res


# ---------------------------------------------------------------- CLI
def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd = sys.argv[1]
    import os
    tools = os.path.dirname(os.path.abspath(__file__))
    defs = cargar_defs(os.path.join(tools, 'opcodes.yml'))
    data = open(sys.argv[2], 'rb').read()
    base = int(sys.argv[3], 16)

    if cmd == 'comprobar':
        ev = parse_ev(data, base, defs)
        ntext = sum(1 for b in ev['elementos'].values() if b.tipo == 'texto')
        nstream = sum(1 for b in ev['elementos'].values() if b.tipo == 'stream')
        print('punteros: %d | streams: %d | bloques texto: %d | refs: %d'
              % (len(ev['punteros']), nstream, ntext, len(ev['refs'])))
        ultimo = max(posiciones_end(ev))
        print('zona usada: 0x%X..0x%X (%d bytes libres hasta 0x%X)'
              % (ev['tabla'], ultimo, FIN_ZONA_DEFAULT - ultimo, FIN_ZONA_DEFAULT))
    elif cmd == 'roundtrip':
        ev = parse_ev(data, base, defs)
        ev['defs'] = defs
        orig = textos_por_puntero(ev, data)
        data2, posiciones = reconstruir(ev, data, fin_zona=base + 0x6800 if base == 0x14800 else FIN_ZONA_DEFAULT)
        ev2 = parse_ev(data2, base, defs)
        ev2['defs'] = defs
        nuevo = textos_por_puntero(ev2, data2)
        ok = orig == nuevo
        print('punteros %d->%d | textos por puntero identicos: %s'
              % (len(ev['punteros']), len(ev2['punteros']), 'SI' if ok else 'NO'))
        if not ok:
            for i, (a, b) in enumerate(zip(orig, nuevo)):
                if a != b:
                    print('  dif en puntero %d: %d vs %d bloques' % (i, len(a), len(b)))
                    sys.exit(1)
        sys.exit(0 if ok else 1)
    elif cmd == 'volcar':
        out = sys.argv[4]
        ev = parse_ev(data, base, defs)
        ev['defs'] = defs
        tbl = cargar_tbl(os.path.join(tools, '3x3eyes.tbl'))
        vistos = set()
        lineas = ['# Maqueta %s (base 0x%X) - %d punteros' % (sys.argv[2], base, len(ev['punteros'])),
                  '# Rellena las lineas ES: (texto castellano; linea vacia = dejar japones)', '']
        for i, p in enumerate(ev['punteros']):
            lineas.append('=== puntero %d ===' % i)
            vistos_p = set()
            pend = [base + p]
            while pend:
                off = pend.pop(0)
                if off in vistos_p:
                    continue
                vistos_p.add(off)
                for pos, opid, d, args in caminar(data, base, defs, off):
                    for (v, es_off, es_txt, pa, es_fol) in args:
                        if not es_off:
                            continue
                        destino = base + v
                        if es_txt:
                            if destino not in vistos:
                                vistos.add(destino)
                                fin = data.index(b'\xDB', destino) + 1
                                b = data[destino:fin]
                                lineas.append('[bloque 0x%X] (%d bytes)' % (destino, len(b)))
                                lineas.append('JP: %s' % decodificar(b, tbl))
                                lineas.append('ES:')
                                lineas.append('')
                        elif es_fol:
                            pend.append(destino)
            lineas.append('')
        open(out, 'w', encoding='utf-8').write('\n'.join(lineas))
        print('volcado a', out, '(%d bloques)' % len(vistos))
    elif cmd == 'insertar':
        trad = json.load(open(sys.argv[4], encoding='utf-8'))
        ev = parse_ev(data, base, defs)
        ev['defs'] = defs
        textos = {}
        for k, v in trad.items():
            textos[int(k, 16)] = v
        data2, _ = reconstruir(ev, data, textos)
        open(sys.argv[5], 'wb').write(data2)
        print('insertados %d bloques -> %s' % (len(textos), sys.argv[5]))
    elif cmd == 'insertar_directo':
        off = int(sys.argv[4], 16)
        texto = sys.argv[5]
        sys.path.insert(0, tools)
        import glifos_narrow_es as gn
        nuevo = gn.frase(texto) + b'\xDB'
        ev = parse_ev(data, base, defs)
        ev['defs'] = defs
        data2, pos = reconstruir(ev, data, {off: nuevo})
        open(sys.argv[6], 'wb').write(data2)
        print('bloque 0x%X: %d -> %d bytes | reubicado a 0x%X' %
              (off, len(ev['elementos'][off].datos), len(nuevo), pos[off]))
    else:
        print(__doc__); sys.exit(1)


def posiciones_end(ev):
    res = []
    for b in ev['elementos'].values():
        res.append(b.off + len(b.datos))
    return res


if __name__ == '__main__':
    main()
