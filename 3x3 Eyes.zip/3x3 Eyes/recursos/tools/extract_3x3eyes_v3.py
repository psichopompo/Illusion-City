#!/usr/bin/env python3
"""
extract_3x3eyes_v3.py — Busca ficheros en el Track 01 sin asumir ISO9660 estándar.
Prueba múltiples offsets de sector y formatos.
"""
import sys, os, struct

def try_read_sector(f, sector_num, sector_size, data_offset, size=2048):
    f.seek(sector_num * sector_size + data_offset)
    return f.read(size)

def scan_for_files(bin_path, out_dir):
    f = open(bin_path, 'rb')
    total_size = os.path.getsize(bin_path)

    # Buscar la firma "CD001" que identifica un volumen ISO9660
    # Puede estar en el sector 16 de varios formatos
    print("Buscando firma CD001...")
    for sector_size in (2352, 2048, 2336, 2448):
        for data_offset in (0, 12, 16, 8):
            f.seek(16 * sector_size + data_offset + 1)
            sig = f.read(5)
            if sig == b'CD001':
                print("  Encontrado: sector_size=%d, data_offset=%d" % (sector_size, data_offset))
                break
        else:
            continue
        break
    else:
        # No encontramos CD001. Buscar en TODOS los sectores cercanos al inicio
        print("  CD001 no encontrado en sector 16. Escaneando sectores 10-25...")
        for sector_num in range(10, 26):
            f.seek(sector_num * sector_size)
            chunk = f.read(2048)
            idx = chunk.find(b'CD001')
            if idx >= 0:
                print("  CD001 encontrado en sector %d, offset interno %d" % (sector_num, idx))
                # probablemente data_offset = idx - 1 (donde empieza el PVD type byte)
                data_offset = idx - 1
                print("  data_offset = %d" % data_offset)
                break
        else:
            print("  CD001 no encontrado en ningún sector cercano.")
            print("  Probablemente el fichero NO es MODE1/2352 estándar.")
            print("  Buscando el pattern de archivos directamente...")

    # Independientemente del formato, intentar parsear:
    # Volver a leer el PVD con los parámetros encontrados
    pvd_data = None
    for sector_num in range(10, 30):
        for try_offset in (data_offset, 0, 8, 12, 16):
            if sector_size == 2352 and try_offset + 2048 > sector_size:
                continue
            f.seek(sector_num * sector_size + try_offset)
            chunk = f.read(2048)
            if chunk[:5] == b'\x01CD001':
                pvd_data = chunk
                print("PVD leído: sector=%d offset=%d" % (sector_num, try_offset))
                break
        if pvd_data:
            break

    if not pvd_data:
        print("No se pudo leer el PVD. Fallback: búsqueda por firma de datos.")
        f.close()
        return fallback_scan(bin_path, out_dir)

    # Parsear root directory
    root_record = pvd_data[156:156+34]
    root_lba = struct.unpack('<I', root_record[2:6])[0]
    root_size = struct.unpack('<I', root_record[10:14])[0]
    print("Root: LBA=%d size=%d" % (root_lba, root_size))

    # Leer el root directory data
    root_raw = b''
    n_sectors = (root_size + 2047) // 2048
    for s in range(n_sectors):
        f.seek((root_lba + s) * sector_size + try_offset)
        root_raw += f.read(2048)

    files = {}
    pos = 0
    while pos < len(root_raw):
        rec_len = root_raw[pos]
        if rec_len == 0:
            pos = (pos // 2048 + 1) * 2048  # saltar al siguiente sector
            continue
        if pos + rec_len > len(root_raw):
            break
        ext_lba = struct.unpack('<I', root_raw[pos+2:pos+6])[0]
        ext_size = struct.unpack('<I', root_raw[pos+10:pos+14])[0]
        flags = root_raw[pos+25]
        name_len = root_raw[pos+32]
        if name_len == 0:
            pos += rec_len
            continue
        name_raw = root_raw[pos+33:pos+33+name_len]

        # limpiar el nombre (quitar ;1 y punto final)
        name = name_raw.decode('ascii', errors='replace')
        name = name.split(';')[0].rstrip('.')

        is_dir = (flags & 2) != 0
        if not is_dir and name:
            files[name] = (ext_lba, ext_size)
            print("  %s: LBA=%d size=%d" % (name, ext_lba, ext_size))
        elif is_dir and name and name != '.':
            # explorar subdirectorio
            sub_raw = b''
            n_sub = (ext_size + 2047) // 2048
            for s in range(n_sub):
                f.seek((ext_lba + s) * sector_size + try_offset)
                sub_raw += f.read(2048)

            sub_pos = 0
            while sub_pos < len(sub_raw):
                sub_len = sub_raw[sub_pos]
                if sub_len == 0:
                    sub_pos = (sub_pos // 2048 + 1) * 2048
                    continue
                if sub_pos + sub_len > len(sub_raw):
                    break
                sub_lba = struct.unpack('<I', sub_raw[sub_pos+2:sub_pos+6])[0]
                sub_size = struct.unpack('<I', sub_raw[sub_pos+10:sub_pos+14])[0]
                sub_flags = sub_raw[sub_pos+25]
                sub_name_len = sub_raw[sub_pos+32]
                if sub_name_len == 0:
                    sub_pos += sub_len
                    continue
                sub_name_raw = sub_raw[sub_pos+33:sub_pos+33+sub_name_len]
                sub_name = sub_name_raw.decode('ascii', errors='replace').split(';')[0].rstrip('.')
                if not (sub_flags & 2) and sub_name:
                    files[sub_name] = (sub_lba, sub_size)
                    print("  %s: LBA=%d size=%d" % (sub_name, sub_lba, sub_size))
                sub_pos += sub_len
        pos += rec_len

    print("\nTotal ficheros encontrados: %d" % len(files))

    # Extraer los ficheros
    os.makedirs(out_dir, exist_ok=True)
    for name, (lba, size) in sorted(files.items()):
        f.seek(lba * sector_size + try_offset)
        n_read = (size + 2047) // 2048
        out_data = b''
        for s in range(n_read):
            out_data += f.read(2048)
        out_data = out_data[:size]
        if len(out_data) != size:
            print("WARNING: %s: esperaba %d, leí %d" % (name, size, len(out_data)))
        out_path = os.path.join(out_dir, name)
        open(out_path, 'wb').write(out_data)
        print("Extraído: %s (%d bytes)" % (name, len(out_data)))

    # resumen
    print("\n=== RESUMEN ===")
    all_files = os.listdir(out_dir)
    total = sum(os.path.getsize(os.path.join(out_dir, f)) for f in all_files)
    print("Ficheros: %d" % len(all_files))
    print("Tamaño: %.1f MB" % (total/1024/1024))
    f.close()

def fallback_scan(bin_path, out_dir):
    """Búsqueda por firma de datos sin ISO9660."""
    print("\n=== FALLBACK: buscando por patrones de datos ===")
    f = open(bin_path, 'rb')
    total_size = os.path.getsize(bin_path)
    print("Tamaño: %d bytes" % total_size)

    # Leer los primeros 4KB y hacer un hex dump para analizar el formato
    f.seek(0)
    header = f.read(4096)
    print("\nPrimeros 512 bytes (hex):")
    for i in range(0, 512, 32):
        hex_str = ' '.join('%02X' % b for b in header[i:i+32])
        ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in header[i:i+32])
        print("  %04X: %s  %s" % (i, hex_str, ascii_str))

    # buscar "EV0" y "_000PRG" en los primeros 10 MB
    print("\nBuscando firmas de ficheros...")
    f.seek(0)
    chunk_size = 4*1024*1024
    ev_hits = []
    prg_hit = None
    pos = 0
    while pos < min(total_size, 20*1024*1024):
        f.seek(pos)
        chunk = f.read(chunk_size)
        if not chunk:
            break
        # buscar EV0
        import re
        for m in re.finditer(rb'EV0', chunk):
            abs_pos = pos + m.start()
            ev_hits.append(abs_pos)
        idx = chunk.find(b'_000PRG')
        if idx >= 0 and prg_hit is None:
            prg_hit = pos + idx
            print("  _000PRG @ 0x%X" % prg_hit)
        pos += chunk_size - 100

    print("EV0 firmas: %d" % len(ev_hits))
    if ev_hits:
        print("  primeros 5:", [hex(h) for h in ev_hits[:5]])
        print("  espaciado:", [ev_hits[i+1]-ev_hits[i] for i in range(min(4, len(ev_hits)-1))])

    # intentar leer el sector 16 con diferentes tamaños de sector
    print("\nProbando sector 16 con diferentes tamaños:")
    for ss in (512, 1024, 2048, 2336, 2352, 2368, 2448, 2646):
        for do in (0, 1, 8, 12, 15, 16):
            f.seek(16 * ss + do)
            chunk = f.read(100)
            if b'CD001' in chunk:
                print("  CD001 con sector_size=%d data_offset=%d (offset interno %d)" % (ss, do, chunk.find(b'CD001')))
    f.close()

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Uso: python3 extract_3x3eyes_v3.py <Track01.bin>")
        sys.exit(1)
    bin_path = sys.argv[1]
    if not os.path.exists(bin_path):
        print("ERROR: no existe %s" % bin_path)
        sys.exit(1)
    scan_for_files(bin_path, "3x3eyes_extracted")
