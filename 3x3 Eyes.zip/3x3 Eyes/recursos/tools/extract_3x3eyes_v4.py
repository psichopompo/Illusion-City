#!/usr/bin/env python3
"""
extract_3x3eyes_v4.py — ISO9660 parser con sector_size=2352, data_offset=0.
El disco es MODE1/2352 y el PVD está en sector 16 con el byte de tipo en offset 1 del sector.
"""
import sys, os, struct

SECTOR_SIZE = 2352
DATA_OFFSET = 0  # el header de sync empieza en 0; el PVD tiene type=1 en offset 1

def read_sector(f, lba, n=2048):
    """Lee el área de datos de un sector (2048 bytes desde offset 0, pero el
    contenido ISO9660 empieza en el offset 0x10 del sector MODE1 raw... PERO
    el test mostró que con data_offset=0 hay CD001 en el byte 17 del sector).
    
    En MODE1/2352: sync(12) + header(4) + subheader-data(2048) + EDC/ECC(288)
    Los datos ISO9660 empiezan en offset 16 del sector raw.
    PERO el test dice que con data_offset=0 hay CD001 en offset interno 17.
    17 = 1 (type) + 5 (CD001). O sea el PVD type byte está en offset 16 del raw sector.
    Hmm, 16 = 12(sync) + 4(header). Correcto: data empieza en offset 16.
    Y CD001 está en offset interno 17 del bloque leído con offset 0.
    17 = 16 (data start) + 1 (PVD type byte). El PVD type=1 está en offset 16,
    y "CD001" empieza en offset 17. 
    
    ENTONCES: data_offset para leer el contenido ISO9660 es 16 del sector raw.
    Pero el test v3 con data_offset=0 encontró CD001 en offset 17 del chunk de 100B
    que leyó desde 16*2352+0. Es decir: 16*2352+17 = posición de "CD001" en el fichero.
    Y el PVD empieza en 16*2352+16 (el byte type=1), con "CD001" en +1.
    
    Para leer el contenido de un sector ISO: seek(lba*2352+16) y leer 2048.
    """
    f.seek(lba * SECTOR_SIZE + 16)
    return f.read(n)

def main():
    if len(sys.argv) < 2:
        print("Uso: python3 extract_3x3eyes_v4.py <Track01.bin>")
        sys.exit(1)
    bin_path = sys.argv[1]
    out_dir = "3x3eyes_extracted"

    f = open(bin_path, 'rb')
    total = os.path.getsize(bin_path)
    print("Fichero: %s (%d bytes)" % (bin_path, total))

    # verificar el header SEGA
    f.seek(0)
    header = f.read(0x100)
    print("Header: %s" % header[0x20:0x50].decode('ascii', errors='replace').strip())

    # Leer sector 16 (PVD) — offset 16 dentro del sector raw
    f.seek(16 * SECTOR_SIZE + 16)
    pvd = f.read(2048)
    if pvd[:1] != b'\x01' or pvd[1:6] != b'CD001':
        print("ERROR: PVD no encontrado")
        print("  byte 0: 0x%02X, bytes 1-5: %s" % (pvd[0], pvd[1:6]))
        sys.exit(1)
    print("PVD OK: CD001 detectado")

    # Root directory
    root_lba = struct.unpack('<I', pvd[156:160])[0]
    root_size = struct.unpack('<I', pvd[160:164])[0]
    print("Root: LBA=%d size=%d" % (root_lba, root_size))

    def read_dir(lba, size):
        data = b''
        n = (size + 2047) // 2048
        for s in range(n):
            data += read_sector(f, lba + s)
        return data[:size]

    def parse_dir(data, prefix=''):
        entries = {}
        pos = 0
        while pos < len(data):
            rec_len = data[pos]
            if rec_len == 0:
                pos = (pos // 2048 + 1) * 2048
                continue
            if pos + rec_len > len(data):
                break
            ext_lba = struct.unpack('<I', data[pos+2:pos+6])[0]
            ext_size = struct.unpack('<I', data[pos+10:pos+14])[0]
            flags = data[pos+25]
            name_len = data[pos+32]
            if name_len == 0:
                pos += rec_len
                continue
            name_raw = data[pos+33:pos+33+name_len]
            name = name_raw.decode('ascii', errors='replace').split(';')[0].rstrip('.')
            is_dir = (flags & 2) != 0

            if name == '.' or name == '..':
                pos += rec_len
                continue

            full = prefix + name if not prefix else prefix + '/' + name
            if is_dir:
                # recursivo
                sub_data = read_dir_data(f, ext_lba, ext_size)
                sub_entries = parse_dir(sub_data, full + '/')
                entries.update(sub_entries)
            else:
                entries[full] = (ext_lba, ext_size)
                print("  %s: LBA=%d size=%d" % (full, ext_lba, ext_size))
            pos += rec_len
        return entries

    def read_dir_data(f, lba, size):
        data = b''
        n = (size + 2047) // 2048
        for s in range(n):
            data += read_sector(f, lba + s)
        return data[:size]

    # leer el root
    root_data = read_dir_data(f, root_lba, root_size)
    files = parse_dir(root_data)

    print("\nTotal ficheros: %d" % len(files))

    # Extraer TODO
    os.makedirs(out_dir, exist_ok=True)
    for name, (lba, size) in sorted(files.items()):
        # crear subdirectorios si es necesario
        out_path = os.path.join(out_dir, name)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)

        data = read_dir_data(f, lba, size)
        open(out_path, 'wb').write(data)
        print("Extraído: %s (%d bytes)" % (name, len(data)))

    # resumen
    print("\n=== RESUMEN ===")
    all_files = []
    for root, dirs, fnames in os.walk(out_dir):
        for fn in fnames:
            fp = os.path.join(root, fn)
            all_files.append(fp)
    total_size = sum(os.path.getsize(fp) for fp in all_files)
    print("Ficheros: %d" % len(all_files))
    print("Tamaño total: %.1f MB" % (total_size/1024/1024))
    f.close()

if __name__ == '__main__':
    main()
