#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_extract_3x3eyes_v5.py — Banco de pruebas del extractor v5.

Construye un disco sintético ISO9660 real (MODE1/2352, PVD en LBA 16, path tables,
directorio raíz con subdirectorio y ficheros) y comprueba que la v5:
  A) extrae todos los ficheros byte a byte (md5) de un disco bien formado
  B) se recupera de un registro raíz corrupto vía path table + registro '.'
  C) detecta y lee una imagen ISO/2048 sin envoltorio raw

Uso: python3 test_extract_3x3eyes_v5.py     (todo en /tmp, no deja basura)
"""
import hashlib, os, struct, subprocess, sys, tempfile, random

RAW, USER = 2352, 2048
V5 = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'extract_3x3eyes_v5.py')


def bcd(v):
    return ((v // 10) << 4) | (v % 10)


def sector_raw(lba, datos):
    m, resto = divmod(lba, 75 * 60)
    s, f = divmod(resto, 75)
    return (b'\x00' + b'\xff' * 10 + b'\x00'
            + bytes([bcd(m), bcd(s), bcd(f), 0x01])
            + datos.ljust(USER, b'\x00')[:USER]
            + b'\x00' * 288)


def reg(lba, size, flags, nombre: bytes, extra=b''):
    """Directory record ISO9660."""
    nlen = len(nombre)
    rlen = 33 + nlen + ((33 + nlen) % 2)      # longitud total redondeada a par
    b = bytearray([rlen, 0])
    b += struct.pack('<I', lba) + struct.pack('>I', lba)
    b += struct.pack('<I', size) + struct.pack('>I', size)
    b += bytes([126, 10, 6, 0, 0, 0, 0])   # fecha 7 bytes (2026-10-06, tz 0)
    b.append(flags)
    b += b'\x00\x00'                      # unit, gap
    b += struct.pack('<H', 1) + struct.pack('>H', 1)
    b.append(nlen)
    b += nombre
    if (33 + nlen) % 2:          # pad a par dentro del registro
        b += b'\x00'
    b += extra
    assert len(b) == rlen + len(extra), (len(b), rlen, len(extra))
    return bytes(b)


def pt_entrada(lba, padre, nombre: bytes):
    b = bytearray([len(nombre), 0])
    b += struct.pack('<I', lba)
    b += struct.pack('<H', padre)
    b += nombre + (b'\x00' if len(nombre) % 2 else b'')
    return bytes(b)


def build_iso():
    """Devuelve (iso_2048, {ruta: bytes_originales}) con un layout realista."""
    fich = {
        '_000PRG.DAT': 5000,
        'EV00000.DAT': 84000,
        'EV00001.DAT': 123457,
        'BNK01.DAT': 456789,
    }
    sub_fich = {'EV00002.DAT': 3000}

    rnd = random.Random(1993)
    contenido = {n: rnd.randbytes(t) for n, t in fich.items()}
    contenido_sub = {n: rnd.randbytes(t) for n, t in sub_fich.items()}

    # --- asignación de LBAs ---
    LBA_PT, LBA_ROOT, LBA_SUB = 18, 20, 21
    lbas, next_lba = {}, 24
    for n in fich:
        lbas[n] = next_lba
        next_lba += (fich[n] + USER - 1) // USER
    for n in sub_fich:
        lbas['SUBD/' + n] = next_lba
        next_lba += (sub_fich[n] + USER - 1) // USER
    total_sec = next_lba + 2

    # --- extents de datos (splicing multi-sector) ---
    def poner(buf, lba, datos):
        for i in range(0, len(datos), USER):
            sec = lba + i // USER
            buf[sec * USER:(sec + 1) * USER] = datos[i:i + USER].ljust(USER, b'\x00')[:USER]

    # --- directorios ---
    root = b''.join([
        reg(LBA_ROOT, USER, 2, b'\x00'),            # .
        reg(LBA_ROOT, USER, 2, b'\x01'),            # ..
        reg(lbas['_000PRG.DAT'], fich['_000PRG.DAT'], 0, b'_000PRG.DAT;1'),
        reg(lbas['EV00000.DAT'], fich['EV00000.DAT'], 0, b'EV00000.DAT;1'),
        reg(lbas['EV00001.DAT'], fich['EV00001.DAT'], 0, b'EV00001.DAT;1'),
        reg(lbas['BNK01.DAT'], fich['BNK01.DAT'], 0, b'BNK01.DAT;1'),
        reg(LBA_SUB, USER, 2, b'SUBD;1'),
    ])
    sub = b''.join([
        reg(LBA_SUB, USER, 2, b'\x00'),
        reg(LBA_ROOT, USER, 2, b'\x01'),
        reg(lbas['SUBD/EV00002.DAT'], sub_fich['EV00002.DAT'], 0, b'EV00002.DAT;1'),
    ])

    # --- path table ---
    pt = pt_entrada(LBA_ROOT, 1, b'\x00') + pt_entrada(LBA_SUB, 1, b'SUBD')

    # --- PVD ---
    pvd = bytearray(USER)
    pvd[0], pvd[1:6], pvd[6] = 1, b'CD001', 1
    pvd[8:40] = b'SEGA MEGA DRIVE'.ljust(32)
    pvd[40:72] = b'3X3EYES_TEST'.ljust(32)
    pvd[80:84] = struct.pack('<I', total_sec)
    pvd[84:88] = struct.pack('>I', total_sec)
    pvd[120:122] = struct.pack('<H', 1)
    pvd[122:124] = struct.pack('>H', 1)
    pvd[124:126] = struct.pack('<H', 1)
    pvd[126:128] = struct.pack('>H', 1)
    pvd[128:130] = struct.pack('<H', USER)
    pvd[130:132] = struct.pack('>H', USER)
    pvd[132:136] = struct.pack('<I', len(pt))
    pvd[136:140] = struct.pack('<I', LBA_PT)
    raiz_rec = reg(LBA_ROOT, USER, 2, b'\x00')
    pvd[156:156 + len(raiz_rec)] = raiz_rec
    pvd[813:830] = b'2026100600000000\x00'
    term = bytearray(USER)
    term[0], term[1:6], term[6] = 255, b'CD001', 1

    # --- IP.BIN (sector 0, sólo decorativo; el sync lo añade el wrapper) ---
    ip = bytearray(USER)
    ip[16:32] = b'SEGADISCSYSTEM'
    ip[32:48] = b'SEGAIPMENU 3X3EYE'

    # --- montaje ---
    iso = bytearray(total_sec * USER)
    for n, datos in contenido.items():
        poner(iso, lbas[n], datos)
    for n, datos in contenido_sub.items():
        poner(iso, lbas['SUBD/' + n], datos)
    poner(iso, LBA_ROOT, root)
    poner(iso, LBA_SUB, sub)
    poner(iso, LBA_PT, pt)
    poner(iso, 16, bytes(pvd))
    poner(iso, 17, bytes(term))
    poner(iso, 0, bytes(ip))

    originales = {n: d for n, d in contenido.items()}
    for n, d in contenido_sub.items():
        originales['SUBD/' + n] = d
    return bytes(iso), originales


def envolver_raw(iso):
    out = bytearray()
    for lba in range(len(iso) // USER):
        out += sector_raw(lba, iso[lba * USER:(lba + 1) * USER])
    return bytes(out)


def correr_v5(img_path, out_dir):
    return subprocess.run(
        [sys.executable, V5, img_path, '--out', out_dir, '--sin-zip'],
        capture_output=True, text=True)


def verificar(out_dir, originales):
    fallos = []
    for ruta, datos in sorted(originales.items()):
        destino = os.path.join(out_dir, *ruta.split('/'))
        if not os.path.exists(destino):
            fallos.append('%s: NO EXTRAÍDO' % ruta)
            continue
        md5_a = hashlib.md5(datos).hexdigest()
        md5_b = hashlib.md5(open(destino, 'rb').read()).hexdigest()
        if md5_a != md5_b:
            fallos.append('%s: md5 distinto' % ruta)
    return fallos


def main():
    tmp = tempfile.mkdtemp(prefix='test3x3_')
    iso, originales = build_iso()
    ok_global = True

    # ---------- A: disco raw 2352 bien formado ----------
    img = os.path.join(tmp, 'track01.bin')
    open(img, 'wb').write(envolver_raw(iso))
    r = correr_v5(img, os.path.join(tmp, 'outA'))
    fallos = verificar(os.path.join(tmp, 'outA'), originales)
    ok_a = r.returncode == 0 and not fallos
    print('[A] raw 2352 (5 ficheros, 1 subdirectorio): %s' % ('OK' if ok_a else 'FALLO'))
    for f in fallos:
        print('    -', f)
    if not ok_a:
        print(r.stdout[-2000:])
        print(r.stderr[-1000:])
    ok_global &= ok_a

    # ---------- B: registro raíz del PVD corrupto -> fallback path table ----------
    corrompido = bytearray(iso)
    off = 16 * USER + 156
    corrompido[off:off + 34] = b'\xff' * 34
    img_b = os.path.join(tmp, 'track01_corrupto.bin')
    open(img_b, 'wb').write(envolver_raw(bytes(corrompido)))
    r = correr_v5(img_b, os.path.join(tmp, 'outB'))
    fallos = verificar(os.path.join(tmp, 'outB'), originales)
    ok_b = r.returncode == 0 and not fallos
    print('[B] PVD raíz corrupto (fallback path table): %s' % ('OK' if ok_b else 'FALLO'))
    for f in fallos:
        print('    -', f)
    if not ok_b:
        print(r.stdout[-2000:])
        print(r.stderr[-1000:])
    ok_global &= ok_b

    # ---------- C: imagen ISO/2048 sin envoltorio ----------
    img_c = os.path.join(tmp, 'track01.iso')
    open(img_c, 'wb').write(iso)
    r = correr_v5(img_c, os.path.join(tmp, 'outC'))
    fallos = verificar(os.path.join(tmp, 'outC'), originales)
    ok_c = r.returncode == 0 and not fallos
    print('[C] ISO/2048 (auto-detección): %s' % ('OK' if ok_c else 'FALLO'))
    for f in fallos:
        print('    -', f)
    if not ok_c:
        print(r.stdout[-2000:])
        print(r.stderr[-1000:])
    ok_global &= ok_c

    # ---------- D: comprobación del bug de la v4 sobre el disco A ----------
    # Reproducir el parseo erroneo de la v4 y confirmar que la v5 ve LBA=20
    pvd = iso[16 * USER:17 * USER]
    lba_v5 = struct.unpack('<I', pvd[158:162])[0]
    size_v5 = struct.unpack('<I', pvd[166:170])[0]
    lba_v4 = struct.unpack('<I', pvd[156:160])[0]
    print('[D] registro raíz: v4 habría leído LBA=%d (basura) | v5 lee LBA=%d size=%d %s'
          % (lba_v4, lba_v5, size_v5, '(correcto)' if lba_v5 == 20 else '(INESPERADO)'))
    ok_global &= (lba_v5 == 20 and size_v5 == USER)

    print('\nRESULTADO GLOBAL: %s' % ('VERDE — la v5 funciona' if ok_global else 'ROJO'))
    return 0 if ok_global else 1


if __name__ == '__main__':
    sys.exit(main())
