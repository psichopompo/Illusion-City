# _000PRG.DAT

The file _000PRG.DAT contains the game program and some data.

## Filemap

0x174e8 Start of LZ (Kosinski) decompression function run on SCD 68K processor.

0x37602 Start of LZ (Kosinski) decompression function run on MD 68K processor.

0x3e000 LZ-compressed limited font characters used for static menu graphics.

0x3e6a0 LZ-compressed additional Kanji-characters

0x3ea10 LZ-compressed additional thin (1 pixel line) Kanji-characters

0x3eec0 LZ-compressed character status-text Kanji (displayed on top of character portraits)

0x423c0 LZ-compressed tilemap for the New game/Load savegame background with Pai

0x424b0-0x42d4f LZ-compressed Pai graphic from the New game/Load savegame screen

# BNK files

Contains 8-bit PCM instrument samples.

# EV files

EV files (Event?) contain scenario specific sprites, event data, text and portraits for a scenario/script/location. They are loaded, at least, together with a MAP file, which contains the map as expected and a PLAY file, which contains the scenario hints and additional portraits.

The file starts with sprite data from 0x0 to some point before 0xc800. At 0xc800 an event type script data is stored. This includes for example different actions to take depending on if some flags have been set when attempting to open a door. Some times text data is stored here instead. There seems to be at least two variations of the EV files - with text data either at 0xc800 or 0x14800. If no text data at 0xc800, then text data is stored at 0x14800. In that case portraits to use with the text are stored Kosinski-compressed, with a preceding header at 0x1b000, 0x1bd00, 0x1ca00, 0x1d700 and 0x1e400 and an attached tilemap and palette.

The portrait tilemap has primary two byte code attached which specifies which sets of bytes are compressed with XOR delta compression and which are uncompressed. Then each set of 8 bytes has additional two byte control code which specifies which tiles are repeated (00) or direct copy (10) or flipped/rotated (11 - not researched further at this point).

The game CD contains 310 EV files, which gives a hint regarding how large the game is, however for some reason several are duplicates and only 231 are unique.

## Text data block

The first two bytes in the text block (e.g. at 0x14800-14801 in the EV-file) is an offset to the start of the text string pointer table. Usually this is 0x0008, meaning the pointers start at e.g. 0x14808. These text strings are connected to game actors and events in the event data block.

The next two bytes (e.g. 0x14802-14803) is an offset to the start of a pointer table, which again contains opcodes which point to shop text.

The next two bytes (e.g. 0x14804-14805) is an offset to a block of numbers of unknown purpose.

The final two bytes (e.g. 0x14806-14807) is an offset to a pointer table, which again contains opcodes which point to special message text, such as opening chests.

## Story order of EV files

EV000A0.DAT Benares intro

EV000FD.DAT Yakumo meeting Pai in bar in Tokyo

EV00005.DAT Side Quest「あなたしか見えない」 "I can only see you" (EV00053.DAT contains an older/different version of this scenario)

EV00006.DAT Hong Kong

EV00007.DAT Hong Kong (later)

EV00008.DAT Hong Kong (later)

EV00009.DAT Hong Kong (later)

EV0000A.DAT Hong Kong (later)

EV0000B.DAT Hong Kong (later)

EV0000C.DAT Hong Kong (later)

EV0000D.DAT Hong Kong (later)

EV0000E.DAT Hong Kong (later)

EV0000F.DAT Hong Kong (later)

EV00010.DAT Hong Kong (later)

EV00011.DAT Side Quest「夢の狂宴!!.ああ、美女対決!?」 "A dream feast! Ah, a beauty showdown!?"

EV00012.DAT Kowloon

EV00013.DAT Kowloon (later)

EV00014.DAT Kowloon (later)

EV00015.DAT Kowloon (later)

EV00016.DAT Kowloon (later)

EV00017.DAT Yougekisha

EV00018.DAT Yougekisha after first boss/dungeon

EV00019.DAT Yougekisha (later)

EV0001A.DAT Yougekisha (later)

EV0001B.DAT Yougekisha (later)

EV0001C.DAT Yougekisha (later)

EV0001D.DAT Yougekisha (later)

EV0001E.DAT Yougekisha (later)

EV0001F.DAT Yougekisha (later)

EV00020.DAT Yougekisha (later)

EV00021.DAT Yougekisha (later)

EV00022.DAT Yougekisha (later)

EV00023.DAT Yougekisha (later)

EV00024.DAT Yougekisha (later)

EV00025.DAT Yougekisha (later)

EV00026.DAT Side Quest「獣になった少年」"The Boy Who Became a Beast"

EV00027.DAT Yellow Mansion

EV00028.DAT Yellow Mansion (later)

EV00029.DAT Yellow Mansion (later)

EV0002B.DAT Yellow Mansion (later)

EV0002C.DAT Huang Mansion (later)

EV0002D.DAT Huang Mansion (later)

EV0002E.DAT Huang Mansion (later)

EV0002F.DAT Huang Mansion (later)

EV00030.DAT Yellow Mansion (later)

EV00031.DAT Side Quest「愛は山脈を越えて」"Love Across the Mountains"

EV00032.DAT Macau

EV00033.DAT Macau (later)

EV00034.DAT Macau (later)

EV00035.DAT Macau (later)

EV00036.DAT Macau (later)

EV00037.DAT Macau (later)

EV00039.DAT Side Quest「マカオが熱いとき」"When Macau is Hot"

EV0003A.DAT Macau dog racing

EV0003A.DAT Macau dog racing

EV0003B.DAT Side Quest 「失われし憑魔の秘宝」 "The Lost Treasure of the Demonic Possession"

EV0003C.DAT Royal Soarer

EV0003D.DAT Royal Soarer

EV0003E.DAT Side Quest「香港妖魔変」"Hong Kong Demon Transformation"

EV0003F.DAT Royal Soarer

EV00040.DAT Royal Soarer

EV00041.DAT Royal Soarer

EV00042.DAT Royal Soarer

EV00043.DAT 「香港妖魔変２」 "Hong Kong Demon Transformation 2" (EV00016.DAT has a different version of this, missing parts of the ending)

EV00044.DAT Nanning

EV00045.DAT Nanning

EV00046.DAT Nanning

EV00047.DAT Nanning

EV00048.DAT Nanning

EV00049.DAT Unknown Side Quest with Mihoshi

EV0004A.DAT Unknown

EV0004B.DAT Unknown

EV0004C.DAT Unknown Side Quest with Mihoshi

EV0004D.DAT Changsha

EV0004E.DAT Changsha

EV0004F.DAT Changsha

EV00050.DAT Unknown

EV00051.DAT Old man talking about Takuhi

EV00053.DAT Side Quest 「あなたしか見えない」 "I can only see you" variation (EV00005.DAT contains a different version of this scenario)


# MAP files

Contain LZ (Kosinksi) compressed 8x8 tiles, tile color palettes and, probably, tilemaps for the game maps.

# PLAY files

Contain the main character sprite sets (each party configuration seems to have a separate file). Also contains the hint system text data.

PLAY000.DAT Hong Kong. Pai, Pai in Yellow dress and Yakumo sprites.

PLAY001.DAT Hong Kong. Pai, Ling Ling and Yakumo sprites.

# SMON files

Some kind of encoded graphics (monster graphics?)?

# SPLAY files

Some kind of encoded graphics (player graphics?)?
