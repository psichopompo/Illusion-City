#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
poc_castellano_v20.py — BISECCION FUENTE/TEXTO: SOLO la fuente, texto japonés INTACTO.

El EV no se toca NI UN BYTE. Solo se escriben los glifos de la fuente
(38 records estrechos + 30 anchos). El japonés original queda tal cual.

PRUEBA: habla con LOS MISMOS 3 NPCs (el viejo, el guason, la chica) en japones.
  - Si el japonés TAMBIEN sale doble -> el veneno es LA FUENTE (los records
    que escribimos alteran algo global del render).
  - Si el japonés sale LIMPIO -> el veneno es EL ENCODING del texto castellano
    (los escapes F8nn / F-lead disparan un doble-estampado en el motor).

USO: python3 poc_castellano_v20.py "<track>.bin"  |  --restaurar
"""
import sys, os, shutil

SIG_PRG = bytes.fromhex("0000060006003ff80600060007f00e7c1ec636c667866306660c3c3800e00000000000003000300030303018300c300c300630063b061e061e000c000c000000")

RECORDS = {
 0x02A: bytes.fromhex("00000000380004003c00440044003e0000000000380004003c00440044003e00"),  # a
 0x02B: bytes.fromhex("00006000200038002400220022007c0000006000200038002400220022007c00"),  # b
 0x02C: bytes.fromhex("00000000180024002000200022001c0000000000180024002000200022001c00"),  # c
 0x02D: bytes.fromhex("0000060004001c002400440044003e000000060004001c002400440044003e00"),  # d
 0x02E: bytes.fromhex("00000000180024004400780042003c0000000000180024004400780042003c00"),  # e
 0x02F: bytes.fromhex("00000e0010007c00100010001000380000000e0010007c001000100010003800"),  # f
 0x030: bytes.fromhex("00000e001200220022001e0002001c0000000e001200220022001e0002001c00"),  # g
 0x031: bytes.fromhex("0000600020002c0032002200220077000000600020002c003200220022007700"),  # h
 0x032: bytes.fromhex("00000800000018000800080008003e0000000800000018000800080008003e00"),  # i
 0x033: bytes.fromhex("0400000004000400240044004400380004000000040004002400440044003800"),  # j
 0x034: bytes.fromhex("000060002e0024002800380024007600000060002e0024002800380024007600"),  # k
 0x035: bytes.fromhex("00001800080008000800080008001c0000001800080008000800080008001c00"),  # l
 0x036: bytes.fromhex("0000000014002a002a002200220077000000000014002a002a00220022007700"),  # m
 0x037: bytes.fromhex("000000006c0032002200220022007700000000006c0032002200220022007700"),  # n
 0x038: bytes.fromhex("000000001c0022002200220022001c00000000001c0022002200220022001c00"),  # o
 0x039: bytes.fromhex("000018002400220022003c0020002000000018002400220022003c0020002000"),  # p
 0x03A: bytes.fromhex("00000c001200220022001e000200020000000c001200220022001e0002000200"),  # q
 0x03B: bytes.fromhex("000000005c0022002400200020007000000000005c0022002400200020007000"),  # r
 0x03C: bytes.fromhex("000000001c0022001800040022001c00000000001c0022001800040022001c00"),  # s
 0x03D: bytes.fromhex("0000100010007c001000120012000c000000100010007c001000120012000c00"),  # t
 0x03E: bytes.fromhex("00000000770022002200220026001b0000000000770022002200220026001b00"),  # u
 0x03F: bytes.fromhex("0000000077002200220014001400080000000000770022002200140014000800"),  # v
 0x040: bytes.fromhex("000000007700220022002a002a001400000000007700220022002a002a001400"),  # w
 0x041: bytes.fromhex("00000000770022001c0014002200770000000000770022001c00140022007700"),  # x
 0x042: bytes.fromhex("00007700220022001e0002004400380000007700220022001e00020044003800"),  # y
 0x043: bytes.fromhex("000000003c0024000800100022003e00000000003c0024000800100022003e00"),  # z
 0x044: bytes.fromhex("08001000380004003c00440044003e0008001000380004003c00440044003e00"),  # á
 0x045: bytes.fromhex("08001000380044004400780042003c0008001000380044004400780042003c00"),  # é
 0x046: bytes.fromhex("04000800000018000800080008003e0004000800000018000800080008003e00"),  # í
 0x047: bytes.fromhex("040008001c0022002200220022001c00040008001c0022002200220022001c00"),  # ó
 0x048: bytes.fromhex("04000800770022002200220026001b0004000800770022002200220026001b00"),  # ú
 0x049: bytes.fromhex("14000000770022002200220026001b0014000000770022002200220026001b00"),  # ü
 0x04A: bytes.fromhex("3e0000006c00320022002200220077003e0000006c0032002200220022007700"),  # ñ
 0x04B: bytes.fromhex("0000040000000400040004000400040000000400000004000400040004000400"),  # ¡
 0x04C: bytes.fromhex("00000800000008001000200022001c0000000800000008001000200022001c00"),  # ¿
 0x04D: bytes.fromhex("00001c00080008000800080008001c0000001c00080008000800080008001c00"),  # I
 0x04E: bytes.fromhex("0000770022002400380024002200770000007700220024003800240022007700"),  # K
 0x04F: bytes.fromhex("00007700220022002a002a002a00140000007700220022002a002a002a001400"),  # W
}

WIDES = {
 0x045: bytes.fromhex("000000003ffc3ffc0c0c0c0c0c0c0c0c0fc00fc00c000c000c0c0c0c3ffc3ffc"),  # E
 0x046: bytes.fromhex("0000000000f000f0030c030c0c0c0c0c0c000c000c000c000c0c0c0c03f003f0"),  # C
 0x047: bytes.fromhex("000000003ff03ff00c0c0c0c0c0c0c0c0ff00ff00c300c300c0c0c0c3f3f3f3f"),  # R
 0x077: bytes.fromhex("000000003fc03fc00c300c300c0c0c0c0c0c0c0c0c0c0c0c0c300c303fc03fc0"),  # D
 0x07E: bytes.fromhex("0000000003f003f00c0c0c0c0c0c0c0c03c003c030303030300c300c0ff00ff0"),  # S
 0x089: bytes.fromhex("000000003f3f3f3f0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c03f003f0"),  # U
 0x08C: bytes.fromhex("000000003fff3fff30c330c330c330c300c000c000c000c000c000c003f003f0"),  # T
 0x08D: bytes.fromhex("0ffc0ffc000000003c3f3c3f0f0c0f0c0ccc0ccc0c3c0c3c0c0c0c0c3f0f3f0f"),  # Ñ
 0x098: bytes.fromhex("0000000003f003f00c0c0c0c300c300c300c300c300c300c303030300fc00fc0"),  # O
 0x0A4: bytes.fromhex("0000000000f000f0030c030c0c0c0c0c0c0c0c0c0ffc0ffc0c0c0c0c3f3f3f3f"),  # A
 0x102: bytes.fromhex("000000003c3f3c3f0c0c0c0c0f0c0f0c0ccc0ccc0c3c0c3c0c0c0c0c3f0f3f0f"),  # N
 0x109: bytes.fromhex("0030003000c000c003f003f00c0c0c0c0c0c0c0c0ffc0ffc0c0c0c0c3f3f3f3f"),  # Á
 0x10A: bytes.fromhex("000000000ff00ff0030c030c030c030c03f003f0030c030c030c030c0ff00ff0"),  # B
 0x122: bytes.fromhex("000000003ffc3ffc0c0c0c0c0c0c0c0c0fc00fc00c000c000c000c003f003f00"),  # F
 0x132: bytes.fromhex("0000000003f003f00c0c0c0c30003000303f303f300c300c0c0c0c0c03f003f0"),  # G
 0x139: bytes.fromhex("0030003000c000c03ffc3ffc0c0c0c0c0c0c0c0c0fc00fc00c0c0c0c3ffc3ffc"),  # É
 0x14A: bytes.fromhex("000000003f3f3f3f0c0c0c0c0c0c0c0c0ffc0ffc0c0c0c0c0c0c0c0c3f3f3f3f"),  # H
 0x14E: bytes.fromhex("0030003000c000c003f003f000c000c000c000c000c000c000c000c003f003f0"),  # Í
 0x168: bytes.fromhex("0000000000fc00fc00300030003000300c300c3030303030303030300fc00fc0"),  # J
 0x16A: bytes.fromhex("0030003000c000c003f003f00c0c0c0c300c300c300c300c303030300fc00fc0"),  # Ó
 0x179: bytes.fromhex("0030003000c000c03f3f3f3f0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c03f003f0"),  # Ú
 0x180: bytes.fromhex("000000003f003f000c000c000c000c000c000c000c0c0c0c0c0c0c0c3ffc3ffc"),  # L
 0x181: bytes.fromhex("000000003c0f3c0f0f3c0f3c0ccc0ccc0ccc0ccc0c0c0c0c0c0c0c0c3f3f3f3f"),  # M
 0x189: bytes.fromhex("000000003ff03ff00c0c0c0c0c0c0c0c0c0c0c0c0ff00ff00c000c003f003f00"),  # P
 0x18B: bytes.fromhex("0000000003c003c00c300c30300c300c300c300c30cc30cc303030300fcc0fcc"),  # Q
 0x18F: bytes.fromhex("000000003f3f3f3f0c0c0c0c0c0c0c0c033003300330033000c000c000c000c0"),  # V
 0x1BE: bytes.fromhex("03300330000000003f3f3f3f0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c03f003f0"),  # Ü
 0x1C2: bytes.fromhex("000000003f3f3f3f0c0c0c0c0330033000c000c0033003300c0c0c0c3f3f3f3f"),  # X
 0x1C3: bytes.fromhex("000000003f3f3f3f0c0c0c0c0c0c0c0c0330033000c000c000c000c003f003f0"),  # Y
 0x1C8: bytes.fromhex("000000000ffc0ffc0c0c0c0c0030003000c000c0030003000c0c0c0c0ffc0ffc"),  # Z
}

def buscar(datos, aguja, nombre):
    p, i = [], datos.find(aguja)
    while i != -1 and len(p) <= 3:
        p.append(i); i = datos.find(aguja, i + 1)
    if len(p) != 1:
        sys.exit("ERROR: huella de " + nombre + " x" + str(len(p)) + ". Aborto.")
    return p[0]

def lba_base(rawpos, rel_huella):
    lba_fp, off_fp = divmod(rawpos, 2352)
    off_fp -= 16
    k, rem = divmod(rel_huella, 2048)
    if rem != off_fp: sys.exit("ERROR: huella no cuadra")
    return lba_fp - k

def pos_abs(lba0, rel):
    return (lba0 + rel//2048)*2352 + 16 + rel % 2048

def main():
    if len(sys.argv) < 2: print(__doc__); sys.exit(1)
    ruta = sys.argv[1]
    bak = ruta + ".bak"
    if "--restaurar" in sys.argv:
        if not os.path.exists(bak): sys.exit("No existe " + bak)
        shutil.copy2(bak, ruta); print("Restaurado desde", bak); return
    con_bak = os.path.exists(bak)
    origen = open(bak, "rb").read() if con_bak else open(ruta, "rb").read()
    print("Track:", len(origen), "bytes" + (" (parto del .bak)" if con_bak else ""))
    buf = bytearray(origen)
    lba_prg = lba_base(buscar(origen, SIG_PRG, "_000PRG"), 0x29020)
    print("_000PRG: LBA %d" % lba_prg)
    for n, bmp in sorted(RECORDS.items()):
        p = pos_abs(lba_prg, 0x2A600 + n*32)
        buf[p:p+32] = bmp
    for code, bmp in sorted(WIDES.items()):
        p = pos_abs(lba_prg, 0x29000 + code*32)
        buf[p:p+32] = bmp
    print("fuente: %d records + %d anchos | EV intacto (japones original)" % (len(RECORDS), len(WIDES)))
    if not con_bak:
        print("Backup ->", bak)
        shutil.copy2(ruta, bak)
    open(ruta, "wb").write(bytes(buf))
    print("")
    print("=== POC v20 APLICADA (solo fuente) ===")
    print("Deshacer: python3 poc_castellano_v20.py \"<track>.bin\" --restaurar")

if __name__ == "__main__":
    main()