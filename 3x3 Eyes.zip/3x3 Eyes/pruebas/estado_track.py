#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""estado_track.py — Diagnostico NO destructivo: que hay en tu track?"""
import sys, os

SIG_PRG = bytes.fromhex("0000060006003ff80600060007f00e7c1ec636c667866306660c3c3800e00000000000003000300030303018300c300c300630063b061e061e000c000c000000")
SIG_EV  = bytes.fromhex("0a0c0a840ade0b1e0b620b820bca0fc00fc2101c0c6c0d364c005c01f23ef359c3da01bef516f5170b2e3c0d06c5daf516f5170b2e15271e2e190b4d07f12306")
ORIG0   = bytes.fromhex("f4f2f50ef1981a3d0a")
V6_WIN0 = bytes.fromhex("f84b8df83ef84df80a")
V5_WIN0 = bytes.fromhex("f84bd7f83ef84df80a")
V2_WIN0 = bytes.fromhex("a38d89ba7e45c87ed6")
OFF_FONT = 0x29000
Ñ_ESPERADA = bytes.fromhex("18c00d800c300e300f300db00db00cd80cd80c780c780c380c300c300c300000")

def lba_base(rawpos, rel_huella):
    lba_fp, off_fp = divmod(rawpos, 2352)
    off_fp -= 16
    k, rem = divmod(rel_huella, 2048)
    return lba_fp - k

def rel_a_raw(lba0, rel):
    s, c = divmod(rel, 2048)
    return (lba0 + s) * 2352 + 16 + c

def main():
    ruta = sys.argv[1]
    datos = open(ruta, "rb").read()
    print("Track:", len(datos), "bytes")
    j = datos.find(SIG_PRG)
    n = datos.count(SIG_PRG)
    print("_000PRG: %d huella(s), primera en raw 0x%X" % (n, j))
    lba_prg = lba_base(j, 0x29020)
    j2 = datos.find(SIG_EV)
    lba_ev = lba_base(j2, 0x14840)
    print("EV00006: LBA", lba_ev)
    p0 = rel_a_raw(lba_ev, 0x148AE)
    win0 = datos[p0:p0+9]
    if win0 == ORIG0: print("ventana NPC1: ORIGINAL (sin parche de castellano)")
    elif win0 == V6_WIN0: print("ventana NPC1: v6 (¡Ñu!)")
    elif win0 == V5_WIN0: print("ventana NPC1: v5 (¡Ñu! con D7)")
    elif win0 == V2_WIN0: print("ventana NPC1: v2 (¡ÑU SEIS!)")
    else: print("ventana NPC1: DESCONOCIDA:", win0.hex(" "))
    pñ = rel_a_raw(lba_prg, OFF_FONT + 0x8D*32)
    g = datos[pñ:pñ+32]
    tinta = sum(bin(b).count("1") for b in g)
    print("glifo 0x8D: %d px de tinta %s" % (tinta, "(Ñ v2/v6 OK)" if g == Ñ_ESPERADA else "(NO coincide con la Ñ esperada)"))
    # mascara
    pm = rel_a_raw(lba_prg, 0x32F4)
    print("byte mascara 0x32F4: %02X %s" % (datos[pm], "(v3 la cambio a 07; v4+ no debe tocarla)"))

if __name__ == "__main__":
    main()